# Pacote de replicação — 1/N

Material para reproduzir as tabelas e as figuras do Apêndice A
(`documentacao/10-apendice-replicacao.tex`).

## Layout após descompactar

Copie o conteúdo para a raiz do repositório `mestrado/`, com estes destinos
(os scripts usam caminhos relativos a essa raiz):

```text
mestrado/
  codigo_fonte/                 <- codigo/
  ibov/
    prices_adjust_close_...csv  <- obter (Economatica; nao vem no zip)
    economatica_valorMercado.xlsx
    economaticavolumeNegociado.xlsx
    rf_selic_daily_31102025.csv <- dados_publicos/
  nefin_RF.csv                  <- dados_publicos/
  nefin_factors.csv             <- dados_publicos/
  diario_BOVA11_IBOV.csv        <- dados_publicos/
  resultados/carteiras_aleatorias_liquidas/  <- carteiras_e_universos/
  resultados/ranking_factivel_b3/            <- ranking_factivel_b3/
  resultados/ranking_sharpe_1a/              <- ranking_sharpe_1a/
  resultados/ranking_factivel_nefin/         <- ranking_factivel_nefin/
```

## Ambiente

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r codigo_fonte/requirements.txt
python3 -m pip install openpyxl
```

MongoDB local: `mongodb://127.0.0.1:27017/`.

## Comandos (mesma ordem do apêndice)

| Arquivo | Trecho do apêndice |
|---------|--------------------|
| `comandos/02_rodar_dgu.txt` | Motor DGU em `bases_dgu/<periodo>/` |
| `comandos/01_gerar_bases.txt` | Capítulo 4, Passo 1 (Tabela 1 e Tabela 2) |
| `comandos/02_rodar_dgu_vwN.txt` | Capítulo 4, Passo 2 |
| `comandos/03_agregar_resultados.txt` | Capítulo 4, Passo 3 |
| `comandos/04_ranking_factivel.txt` | Capítulo 4, Passo 4 (Tabela 1) |
| `comandos/05_ranking_sharpe.txt` | Capítulo 4, Passo 5 (Tabela 2) |

Os passos do investidor (Capítulo 5 do apêndice) estão nos blocos verbatim
do `.tex`. O backtest usa `backtest_carteiras_individuais_retornos_v4_1.py`.

## Parâmetros

- DGU: `M=60`, `--cost-bps 12` (o custo entra no return-loss)
- Carteiras líquidas: semente `20250725`, ADV mínimo 1000 (mil R$, isto é, R$ 1 milhão/dia)
- Carteiras DGU: semente `15`, até 3000 sorteios; o ranking lê no máximo 1000

## Não incluído

Painel de preços, valor de mercado, volume e dívida líquida/EBITDA da
Economatica, e dumps do MongoDB. Ver `LICENCA_DADOS.txt`.
