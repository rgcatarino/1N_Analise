"""Resultados do simulador Pessoa Investidora — v6 (diferenças vs Ibovespa).

Gera Excel e LaTeX no formato consolidado de diferenças 1/N − Ibovespa
(médias cross-section por período e N ativos), para carteiras com
rebalanceamento e IR. Opcionalmente gera a tabela compacta de robustez
temporal (HAC + stationary bootstrap com B=3.000 reamostragens por padrão).

Lê ``aux_metrics_{sufixo}`` das carteiras no banco de liquidez e o benchmark
``aux_metrics_BOVA11_{inicio_fim}`` (série do índice Ibovespa) no banco de
benchmark. Carteiras com a mesma composição de ativos são deduplicadas.

Exemplo::

    python codigo_fonte/mestrado_resultados_simulador_pessoa_investidora_v6.py \\
      --tcost-bps 12 --ir sim --universo-tag liq_1MM --rebalanceamento com

Saída (ex.): ``diferencas_1n_ibovespa_liquidez_com_reb.csv``;
com ``--rebalanceamento sem``: ``..._sem_reb.csv``.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from pymongo import MongoClient
from pymongo.database import Database

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

from mestrado_resultados_simulador_pessoa_investidora import (  # noqa: E402
    DEFAULT_MONGO_URI,
    diff_summary,
)
from mestrado_resultados_simulador_pessoa_investidora_v2 import (  # noqa: E402
    DEFAULT_DB_BOVA11,
    DEFAULT_DB_LIQUIDEZ,
    REBALANCE_FREQS,
)
from mestrado_resultados_simulador_pessoa_investidora_v5 import (  # noqa: E402
    DEFAULT_ATIVOS,
    DEFAULT_OUTPUT_DIR,
    ParsedResCollection,
    _dedupe_res_metrics_by_composition,
    _load_strategy_tickers,
    _reb_matches,
    _resolve_exclude_universo_tags,
    build_output_stem,
    build_tab_fonte,
    discover_res_collections,
    filter_collections_for_args,
    infer_run_plan,
    print_collection_inventory,
    resolve_collection,
    resolve_export_title,
)
from mestrado_tabela_hac_bootstrap_compacta import (  # noqa: E402
    DEFAULT_ALPHA,
    DEFAULT_BASE_LAG,
    build_compact_table,
    discover_excess_collections,
    display_frame,
    filter_index as filter_excess_index,
    write_latex as write_hac_latex,
)
from mestrado_resultados_simulador_pessoa_investidora import (  # noqa: E402
    DEFAULT_AVG_BLOCKS,
    DEFAULT_BOOT_SEED,
    DEFAULT_HAC_LAGS,
)

DEFAULT_BOOT_B = 3000

DEFAULT_TITLE = (
    "Diferenças 1/N - Ibovespa com filtro de liquidez "
    "(médias cross-section por período e número de ativos; testes sobre Sharpe)"
)
DEFAULT_TAB_FONTE = build_tab_fonte("com")
DEFAULT_HAC_TITLE = (
    "Teste pareado 1/N versus Ibovespa com robustez temporal "
    "(HAC + stationary bootstrap) — resumo consolidado"
)
DEFAULT_HAC_STEM = "hac_bootstrap_compacta_1n_vs_ibovespa"
DEFAULT_HAC_LABEL = "tab:hac-bootstrap-compacta"

TABLE_COLUMNS = (
    "Período",
    "Ativos por carteira",
    "Retorno total em excesso (acumulado)",
    "Sharpe (excesso)",
    "Volatilidade anual (excesso)",
    "p-valor (Sharpe)",
    "p-valor (Wilcoxon)",
)
EXPORT_COLUMNS = TABLE_COLUMNS + (
    "N carteiras",
    "n_carteiras_brutas",
    "_collection",
    "_benchmark_collection",
)

AUX_METRICS = (
    "total_excess_return",
    "sharpe_excess",
    "vol_excess_ann",
)
AUX_PERCENT_METRICS = {"total_excess_return", "vol_excess_ann"}
AUX_LOWER_IS_BETTER = {"vol_excess_ann"}

METRIC_LABELS = {
    "total_excess_return": "Retorno total em excesso (acumulado)",
    "sharpe_excess": "Sharpe (excesso)",
    "vol_excess_ann": "Volatilidade anual (excesso)",
}


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Gera tabela consolidada de diferenças 1/N − Ibovespa "
            "(Excel + LaTeX) a partir das collections aux_metrics_*."
        )
    )
    parser.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    parser.add_argument("--db-name", default=DEFAULT_DB_LIQUIDEZ)
    parser.add_argument(
        "--db-name-benchmark",
        default=DEFAULT_DB_BOVA11,
        help="Banco do benchmark Ibovespa (default: Backtest_Mestrado_PF_ExcessAjustado)",
    )
    parser.add_argument(
        "--benchmark-prefix",
        default="BOVA11",
        help="Prefixo das collections aux_metrics do benchmark (default: BOVA11)",
    )
    parser.add_argument("--ativos", type=int, nargs="+", default=None)
    parser.add_argument(
        "--ir",
        choices=("sim", "nao", "ambos", "auto"),
        default="auto",
    )
    parser.add_argument(
        "--rebalanceamento",
        choices=("com", "sem"),
        default="com",
    )
    parser.add_argument("--rebalance-freq", choices=REBALANCE_FREQS, default="annual")
    parser.add_argument("--tcost-bps", type=float, default=None)
    parser.add_argument("--start-m", type=int, default=7)
    parser.add_argument("--end-m", type=int, default=10)
    parser.add_argument("--end-y", type=int, default=2025)
    parser.add_argument("--periodos", nargs="+", default=None)
    parser.add_argument("--universo-tag", default="")
    parser.add_argument(
        "--exclude-universo-tag",
        nargs="+",
        default=None,
        help=(
            "Tags de universo a ignorar (default: liq_divliq_1MM). "
            "Use --exclude-universo-tag '' para não excluir nenhuma."
        ),
    )
    parser.add_argument("--sem-reb-tag", default="buyhold")
    parser.add_argument(
        "--engine",
        choices=("v4", "v41", "all"),
        default="v41",
        help=(
            "Motor das collections: v41 = sufixo *_v41 (default); "
            "v4 = legado; all = ambos (preferindo v41)."
        ),
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--title", default=DEFAULT_TITLE)
    parser.add_argument(
        "--stem",
        default="diferencas_1n_ibovespa_liquidez",
    )
    parser.add_argument(
        "--label",
        default="tab:diferencas-1n-ibovespa-liquidez",
    )
    parser.add_argument("--allow-missing", action="store_true", default=True)
    parser.add_argument("--require-all", dest="allow_missing", action="store_false")
    parser.add_argument(
        "--skip-hac-bootstrap",
        action="store_true",
        help="Não gera a tabela compacta HAC + stationary bootstrap",
    )
    parser.add_argument(
        "--hac-lags",
        type=int,
        nargs="+",
        default=list(DEFAULT_HAC_LAGS),
        help="Grid de lags HAC para a faixa de p_boot (default: 3 4 6 12)",
    )
    parser.add_argument(
        "--avg-blocks",
        type=int,
        nargs="+",
        default=list(DEFAULT_AVG_BLOCKS),
        help="Grid de blocos do stationary bootstrap (default: 3 6 12)",
    )
    parser.add_argument(
        "--base-lag",
        type=int,
        default=DEFAULT_BASE_LAG,
        help="Lag HAC reportado na coluna p_HAC (default: 6)",
    )
    parser.add_argument(
        "--boot-b",
        type=int,
        default=DEFAULT_BOOT_B,
        help=f"Reamostragens do stationary bootstrap (default: {DEFAULT_BOOT_B})",
    )
    parser.add_argument("--boot-seed", type=int, default=DEFAULT_BOOT_SEED)
    parser.add_argument(
        "--alpha",
        type=float,
        default=DEFAULT_ALPHA,
        help="Nível de significância para a coluna Conclusão (default: 0.05)",
    )
    parser.add_argument("--hac-title", default=DEFAULT_HAC_TITLE)
    parser.add_argument("--hac-stem", default=DEFAULT_HAC_STEM)
    parser.add_argument("--hac-label", default=DEFAULT_HAC_LABEL)
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--list-collections", action="store_true")
    args = parser.parse_args(list(argv) if argv is not None else None)
    if not 1 <= args.start_m <= 12 or not 1 <= args.end_m <= 12:
        parser.error("Mês de início/fim deve estar entre 1 e 12.")
    return args


def benchmark_suffix(prefix: str, start_y: int, end_y: int) -> str:
    return f"{prefix}_{start_y}_{end_y}"


def _load_aux_metrics_frame(db: Database, suffix: str) -> pd.DataFrame:
    collection_name = f"aux_metrics_{suffix}"
    if collection_name not in db.list_collection_names():
        raise RuntimeError(f"Collection ausente: {db.name}.{collection_name}")

    docs = list(
        db[collection_name].find(
            {},
            {
                "_id": 0,
                "strategy": 1,
                "tickers": 1,
                "total_excess_return": 1,
                "sharpe_excess": 1,
                "vol_excess_ann": 1,
            },
        )
    )
    if not docs:
        raise RuntimeError(f"Nenhum documento em {db.name}.{collection_name}")

    df = pd.DataFrame(docs)
    if "strategy" not in df.columns:
        raise RuntimeError(f"Campo strategy ausente em {collection_name} ({db.name}).")
    return df


def _load_unique_aux_metrics(
    db: Database,
    suffix: str,
) -> Tuple[pd.DataFrame, int, int]:
    df = _load_aux_metrics_frame(db, suffix)
    tickers_map = _load_strategy_tickers(db, suffix)
    deduped, n_raw, n_unique = _dedupe_res_metrics_by_composition(df, tickers_map)
    return deduped, n_raw, n_unique


def _load_benchmark_doc(
    db_benchmark: Database,
    *,
    prefix: str,
    start_y: int,
    end_y: int,
) -> Tuple[Dict[str, float], str]:
    suffix = benchmark_suffix(prefix, start_y, end_y)
    collection_name = f"aux_metrics_{suffix}"
    if collection_name not in db_benchmark.list_collection_names():
        raise RuntimeError(
            f"Benchmark ausente: {db_benchmark.name}.{collection_name}"
        )

    doc = db_benchmark[collection_name].find_one(
        {},
        {"_id": 0, "total_excess_return": 1, "sharpe_excess": 1, "vol_excess_ann": 1},
    )
    if not doc:
        raise RuntimeError(f"Benchmark vazio: {db_benchmark.name}.{collection_name}")

    values: Dict[str, float] = {}
    for metric in AUX_METRICS:
        raw = doc.get(metric)
        values[metric] = float(raw) if raw is not None else np.nan
    return values, collection_name


def _scale_diff_mean(metric: str, mean_value: float) -> float:
    if pd.isna(mean_value):
        return np.nan
    if metric in AUX_PERCENT_METRICS:
        return float(mean_value) * 100.0
    return float(mean_value)


def _metric_diff_row(
    series: pd.Series,
    benchmark_value: float,
    *,
    metric: str,
) -> Dict[str, float]:
    higher_is_better = metric not in AUX_LOWER_IS_BETTER
    summary = diff_summary(series, benchmark_value, higher_is_better=higher_is_better)
    return {
        "mean": _scale_diff_mean(metric, summary["mean"]),
        "t_pvalue": summary["t_pvalue"],
        "wilcoxon_pvalue": summary["wilcoxon_pvalue"],
        "n": summary["n"],
    }


def load_difference_row(
    db: Database,
    db_benchmark: Database,
    parsed: Optional[ParsedResCollection],
    *,
    benchmark_prefix: str,
    start_y: int,
    end_y: int,
    allow_missing: bool,
    quiet: bool,
    expected_name: str = "",
) -> Dict[str, object]:
    collection_name = parsed.suffix if parsed is not None else expected_name
    empty_row = {
        METRIC_LABELS[metric]: np.nan for metric in AUX_METRICS
    }
    empty_row.update(
        {
            "p-valor (Sharpe)": np.nan,
            "p-valor (Wilcoxon)": np.nan,
            "N carteiras": 0,
            "n_carteiras_brutas": 0,
            "_collection": expected_name,
            "_benchmark_collection": benchmark_suffix(benchmark_prefix, start_y, end_y),
        }
    )

    if parsed is None:
        message = f"Collection não encontrada: {expected_name or '(sem correspondência)'}"
        if allow_missing:
            if not quiet:
                print(f"  SKIP {message}", flush=True)
            return empty_row
        raise RuntimeError(message)

    try:
        df, n_raw, n_unique = _load_unique_aux_metrics(db, parsed.suffix)
        benchmark, benchmark_collection = _load_benchmark_doc(
            db_benchmark,
            prefix=benchmark_prefix,
            start_y=start_y,
            end_y=end_y,
        )
    except RuntimeError as exc:
        if allow_missing:
            if not quiet:
                print(f"  SKIP {parsed.suffix}: {exc}", flush=True)
            row = dict(empty_row)
            row["_collection"] = f"aux_metrics_{parsed.suffix}"
            row["_benchmark_collection"] = benchmark_suffix(
                benchmark_prefix, start_y, end_y
            )
            return row
        raise

    if not quiet and n_raw > n_unique:
        print(
            f"  composições únicas: {n_unique} "
            f"(de {n_raw} estratégias; {n_raw - n_unique} duplicadas por composição)",
            flush=True,
        )

    row: Dict[str, object] = {
        "_collection": f"aux_metrics_{parsed.suffix}",
        "_benchmark_collection": benchmark_collection,
        "N carteiras": n_unique,
        "n_carteiras_brutas": n_raw,
    }

    sharpe_stats: Dict[str, float] = {}
    for metric in AUX_METRICS:
        if metric not in df.columns:
            row[METRIC_LABELS[metric]] = np.nan
            continue
        benchmark_value = benchmark.get(metric, np.nan)
        if pd.isna(benchmark_value):
            row[METRIC_LABELS[metric]] = np.nan
            continue
        stats_row = _metric_diff_row(
            df[metric],
            float(benchmark_value),
            metric=metric,
        )
        row[METRIC_LABELS[metric]] = stats_row["mean"]
        if metric == "sharpe_excess":
            sharpe_stats = stats_row

    row["p-valor (Sharpe)"] = sharpe_stats.get("t_pvalue", np.nan)
    row["p-valor (Wilcoxon)"] = sharpe_stats.get("wilcoxon_pvalue", np.nan)
    return row


def build_difference_table(
    db: Database,
    db_benchmark: Database,
    *,
    ativos: Sequence[int],
    period_windows: Sequence[Tuple[str, int, int, int, int]],
    rebalance: bool,
    rebalance_freq: str,
    tcost_bps: float,
    apply_stock_ir: bool,
    universo_tag: str,
    sem_reb_tag: str,
    benchmark_prefix: str,
    allow_missing: bool,
    quiet: bool,
    collection_index: Sequence[ParsedResCollection],
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []

    for n_ativos in ativos:
        for period_label, start_y, start_m, end_y, end_m in period_windows:
            parsed = resolve_collection(
                collection_index,
                n_ativos=int(n_ativos),
                start_y=int(start_y),
                start_m=int(start_m),
                end_y=int(end_y),
                end_m=int(end_m),
                rebalance=rebalance,
                rebalance_freq=rebalance_freq,
                tcost_bps=float(tcost_bps),
                apply_stock_ir=bool(apply_stock_ir),
                universo_tag=str(universo_tag or ""),
                sem_reb_tag=str(sem_reb_tag or "buyhold"),
            )
            expected_suffix = (
                f"{n_ativos}atv_*_{start_y}{start_m:02d}_{end_y}{end_m:02d}_*"
            )
            if not quiet:
                status = (
                    f"aux_metrics_{parsed.suffix}"
                    if parsed is not None
                    else f"aux_metrics_{expected_suffix} (NÃO ENCONTRADA)"
                )
                print(f"N={n_ativos:>2} | {period_label} | {status}", flush=True)

            metrics = load_difference_row(
                db,
                db_benchmark,
                parsed,
                benchmark_prefix=benchmark_prefix,
                start_y=int(start_y),
                end_y=int(end_y),
                allow_missing=allow_missing,
                quiet=quiet,
                expected_name=expected_suffix,
            )

            row = {
                "Período": period_label,
                "Ativos por carteira": int(n_ativos),
            }
            for column in TABLE_COLUMNS[2:]:
                value = metrics.get(column, np.nan)
                if column in (
                    "Retorno total em excesso (acumulado)",
                    "Sharpe (excesso)",
                    "Volatilidade anual (excesso)",
                ):
                    row[column] = (
                        round(float(value), 2)
                        if isinstance(value, (float, np.floating)) and not pd.isna(value)
                        else np.nan
                    )
                else:
                    row[column] = value
            row["N carteiras"] = int(metrics.get("N carteiras", 0) or 0)
            row["n_carteiras_brutas"] = int(metrics.get("n_carteiras_brutas", 0) or 0)
            row["_collection"] = metrics.get("_collection", "")
            row["_benchmark_collection"] = metrics.get("_benchmark_collection", "")
            rows.append(row)

    table = pd.DataFrame(rows)
    if not table.empty:
        table["_period_start"] = (
            table["Período"].astype(str).str.split("-", n=1).str[0].astype(int)
        )
        table = table.sort_values(
            ["_period_start", "Ativos por carteira"],
            kind="mergesort",
        ).reset_index(drop=True)
        table = table.drop(columns=["_period_start"])
    return table[list(EXPORT_COLUMNS)]


def _format_display_value(value: object) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    if isinstance(value, (float, np.floating)):
        return f"{float(value):.2f}"
    return str(value)


def _format_pvalue(value: object) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    number = float(value)
    if number == 0.0:
        return "0"
    if number < 0.0001:
        return f"{number:.2e}"
    return f"{number:.4f}".rstrip("0").rstrip(".")


def write_excel(table: pd.DataFrame, path: Path, *, title: str) -> None:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, Side
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "openpyxl é necessário para gravar Excel. Instale com: pip install openpyxl"
        ) from exc

    wb = Workbook()
    ws = wb.active
    ws.title = "Diferenças Ibovespa"

    thin = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ncol = len(TABLE_COLUMNS)
    last_col_letter = chr(ord("A") + ncol - 1)
    ws.merge_cells(f"A1:{last_col_letter}1")
    title_cell = ws["A1"]
    title_cell.value = title
    title_cell.font = Font(bold=True, size=12)
    title_cell.alignment = center

    for col, header in enumerate(TABLE_COLUMNS, start=1):
        cell = ws.cell(row=2, column=col, value=header)
        cell.font = Font(bold=True)
        cell.alignment = center
        cell.border = thin

    start_row = 3
    for i, rec in enumerate(table[list(TABLE_COLUMNS)].itertuples(index=False)):
        r = start_row + i
        for col in range(1, ncol + 1):
            value = rec[col - 1]
            cell = ws.cell(
                row=r,
                column=col,
                value=value if value == value else None,
            )
            cell.alignment = center
            cell.border = thin
            if col >= 3 and isinstance(value, (int, float)) and value == value:
                if col in (6, 7):
                    cell.number_format = "0.0000"
                else:
                    cell.number_format = "0.00"

    widths = {
        "A": 14,
        "B": 18,
        "C": 28,
        "D": 16,
        "E": 24,
        "F": 16,
        "G": 22,
    }
    for letter, width in widths.items():
        ws.column_dimensions[letter].width = width

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def _latex_escape(text: str) -> str:
    replacements = {
        "\\": "\\textbackslash{}",
        "&": "\\&",
        "%": "\\%",
        "$": "\\$",
        "#": "\\#",
        "_": "\\_",
        "{": "\\{",
        "}": "\\}",
        "~": "\\textasciitilde{}",
        "^": "\\textasciicircum{}",
    }
    out = str(text)
    for src, dst in replacements.items():
        out = out.replace(src, dst)
    return out


LATEX_HEADER_WRAPS = {
    "Período": "Período",
    "Ativos por carteira": r"\shortstack{Ativos por\\carteira}",
    "Retorno total em excesso (acumulado)": r"\shortstack{Retorno total em\\excesso (acum.)}",
    "Sharpe (excesso)": "Sharpe",
    "Volatilidade anual (excesso)": r"\shortstack{Volatilidade anual\\(excesso)}",
    "p-valor (Sharpe)": r"\shortstack{p-valor\\(Sharpe)}",
    "p-valor (Wilcoxon)": r"\shortstack{p-valor\\(Wilcoxon)}",
}

LATEX_COL_SPEC = (
    "@{}"
    r">{\centering\arraybackslash}p{0.11\linewidth}"
    r">{\centering\arraybackslash}p{0.10\linewidth}"
    r">{\centering\arraybackslash}p{0.18\linewidth}"
    r">{\centering\arraybackslash}p{0.10\linewidth}"
    r">{\centering\arraybackslash}p{0.15\linewidth}"
    r">{\centering\arraybackslash}p{0.10\linewidth}"
    r">{\centering\arraybackslash}p{0.12\linewidth}"
    "@{}"
)


def write_latex(
    table: pd.DataFrame,
    path: Path,
    *,
    title: str,
    label: str,
    tabfonte: str,
) -> None:
    header_cells = [LATEX_HEADER_WRAPS[column] for column in TABLE_COLUMNS]
    lines: List[str] = [
        "% Gerado por mestrado_resultados_simulador_pessoa_investidora_v6.py",
        "% Requer: \\usepackage{array} e \\usepackage{booktabs}",
        "\\begin{table}[htbp]",
        "\\centering",
        f"\\caption{{{_latex_escape(title)}}}",
        f"\\label{{{_latex_escape(label)}}}",
        "\\footnotesize",
        "\\setlength{\\tabcolsep}{3pt}",
        "\\renewcommand{\\arraystretch}{1.15}",
        f"\\begin{{tabular}}{{{LATEX_COL_SPEC}}}",
        "\\toprule",
        " & ".join(header_cells) + r" \\",
        "\\midrule",
    ]

    for rec in table[list(TABLE_COLUMNS)].itertuples(index=False):
        cells = [
            rf"\mbox{{{_latex_escape(str(rec[0]))}}}",
            str(rec[1]),
            _format_display_value(rec[2]),
            _format_display_value(rec[3]),
            _format_display_value(rec[4]),
            _format_pvalue(rec[5]),
            _format_pvalue(rec[6]),
        ]
        lines.append(" & ".join(cells) + r" \\")

    lines.extend(
        [
            "\\bottomrule",
            "\\end{tabular}",
            tabfonte,
            "\\end{table}",
            "",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def build_hac_bootstrap_tables(
    db: Database,
    db_benchmark: Database,
    *,
    plan,
    rebalance: bool,
    rebalance_freq: str,
    sem_reb_tag: str,
    engine: str,
    hac_lags: Sequence[int],
    avg_blocks: Sequence[int],
    base_lag: int,
    boot_b: int,
    boot_seed: int,
    alpha: float,
    allow_missing: bool,
    quiet: bool,
) -> List[Tuple[bool, pd.DataFrame]]:
    all_excess = discover_excess_collections(db)
    results: List[Tuple[bool, pd.DataFrame]] = []

    for apply_ir in plan.ir_modes:
        ir_tag = "ir" if apply_ir else "noir"
        filtered = filter_excess_index(
            all_excess,
            rebalance=rebalance,
            rebalance_freq=rebalance_freq,
            sem_reb_tag=sem_reb_tag,
            universo_tag=plan.universo_tag,
            tcost_bps=plan.tcost_bps,
            ir_tag=ir_tag,
            engine=str(engine),
        )
        if not filtered:
            raise RuntimeError(
                "Nenhuma collection ret_excess_acum_pct_* compatível com o filtro "
                f"(engine={engine}) para a tabela HAC + bootstrap."
            )
        if not quiet:
            print(
                f"\n=== HAC + bootstrap | engine={engine} | "
                f"IR={'sim' if apply_ir else 'nao'} | "
                f"B={boot_b} | {len(filtered)} collections ===",
                flush=True,
            )
        frame = build_compact_table(
            db,
            db_benchmark,
            index=filtered,
            ativos=plan.ativos,
            period_windows=plan.period_windows,
            hac_lags=hac_lags,
            avg_blocks=avg_blocks,
            base_lag=base_lag,
            boot_b=boot_b,
            boot_seed=boot_seed,
            alpha=alpha,
            allow_missing=allow_missing,
            quiet=quiet,
        )
        results.append((apply_ir, frame))

    return results


def main(argv: Optional[Sequence[str]] = None) -> Path:
    args = parse_args(argv)
    rebalance = args.rebalanceamento == "com"
    args.output_dir.mkdir(parents=True, exist_ok=True)

    client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=15000)
    try:
        db = client[args.db_name]
        db_benchmark = client[args.db_name_benchmark]
        all_collections = discover_res_collections(db)

        if args.list_collections:
            filtered = filter_collections_for_args(all_collections, args)
            print_collection_inventory(
                filtered,
                db_name=args.db_name,
                filters={
                    "engine": args.engine,
                    "rebalanceamento": args.rebalanceamento,
                    "universo-tag": args.universo_tag or "(qualquer)",
                    "exclude-universo-tag": sorted(_resolve_exclude_universo_tags(args)),
                    "tcost-bps": args.tcost_bps,
                    "ir": args.ir,
                },
            )
            bm_cols = sorted(
                name
                for name in db_benchmark.list_collection_names()
                if name.startswith("aux_metrics_")
                and args.benchmark_prefix in name
            )
            print(
                f"\n{args.db_name_benchmark}: {len(bm_cols)} collections "
                f"aux_metrics_{args.benchmark_prefix}_*",
                flush=True,
            )
            for name in bm_cols:
                print(f"  {name}", flush=True)
            print(
                "\n(Inventário apenas — nenhum CSV/Excel/LaTeX gerado. "
                "Remova --list-collections para exportar arquivos.)",
                flush=True,
            )
            return args.output_dir

        plan = infer_run_plan(all_collections, args)
        if not args.quiet:
            print("\nPlano inferido do banco:", flush=True)
            print(f"  universo:   {plan.universo_tag or '(sem tag)'}", flush=True)
            print(f"  engine:     {args.engine}", flush=True)
            print(f"  tcost:      {plan.tcost_bps} bps", flush=True)
            print(f"  ativos:     {' '.join(map(str, plan.ativos))}", flush=True)
            print(
                "  períodos:   "
                + ", ".join(label for label, *_ in plan.period_windows),
                flush=True,
            )
            print(
                "  IR:         "
                + ", ".join("sim" if mode else "nao" for mode in plan.ir_modes),
                flush=True,
            )
            print(
                f"  benchmark:  {args.db_name_benchmark} / "
                f"aux_metrics_{args.benchmark_prefix}_{{inicio}}_{{fim}}",
                flush=True,
            )

        frames: List[pd.DataFrame] = []
        for apply_ir in plan.ir_modes:
            ir_tag = "ir" if apply_ir else "noir"
            filtered_index = [
                item
                for item in plan.collection_index
                if item.ir_tag == ir_tag
                and _reb_matches(
                    item,
                    rebalance=rebalance,
                    rebalance_freq=args.rebalance_freq,
                    sem_reb_tag=str(args.sem_reb_tag or "buyhold"),
                )
            ]
            if not args.quiet:
                print(
                    f"\n=== {args.db_name} | IR={'sim' if apply_ir else 'nao'} | "
                    f"{len(filtered_index)} collections ===",
                    flush=True,
                )

            table = build_difference_table(
                db,
                db_benchmark,
                ativos=plan.ativos,
                period_windows=plan.period_windows,
                rebalance=rebalance,
                rebalance_freq=args.rebalance_freq,
                tcost_bps=plan.tcost_bps,
                apply_stock_ir=bool(apply_ir),
                universo_tag=plan.universo_tag,
                sem_reb_tag=str(args.sem_reb_tag or "buyhold"),
                benchmark_prefix=str(args.benchmark_prefix),
                allow_missing=args.allow_missing,
                quiet=args.quiet,
                collection_index=filtered_index,
            )
            frames.append(table)
    finally:
        client.close()

    if not frames:
        raise RuntimeError("Nenhuma linha gerada.")

    export_title = resolve_export_title(
        args.title,
        args.rebalanceamento,
        default_title=DEFAULT_TITLE,
    )
    hac_export_title = resolve_export_title(
        args.hac_title,
        args.rebalanceamento,
        default_title=DEFAULT_HAC_TITLE,
    )
    tabfonte = build_tab_fonte(
        args.rebalanceamento,
        tcost_bps=plan.tcost_bps,
        benchmark="Ibovespa",
    )

    last_xlsx: Optional[Path] = None
    for apply_ir, frame in zip(plan.ir_modes, frames):
        ir_tag = "ir" if apply_ir else "noir"
        stem = build_output_stem(
            args.stem,
            rebalanceamento=args.rebalanceamento,
            ir_tag=ir_tag if len(plan.ir_modes) > 1 else None,
        )
        label = args.label if len(plan.ir_modes) == 1 else f"{args.label}_{ir_tag}"

        csv_path = args.output_dir / f"{stem}.csv"
        xlsx_path = args.output_dir / f"{stem}.xlsx"
        tex_path = args.output_dir / f"{stem}.tex"

        frame.to_csv(csv_path, index=False, encoding="utf-8-sig")
        write_excel(frame[list(TABLE_COLUMNS)], xlsx_path, title=export_title)
        write_latex(
            frame[list(TABLE_COLUMNS)],
            tex_path,
            title=export_title,
            label=label,
            tabfonte=tabfonte,
        )
        last_xlsx = xlsx_path

        if not args.quiet:
            print(f"\nCSV:   {csv_path}", flush=True)
            print(f"Excel: {xlsx_path}", flush=True)
            print(f"LaTeX: {tex_path}", flush=True)

    if not args.skip_hac_bootstrap:
        client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=15000)
        try:
            db = client[args.db_name]
            db_benchmark = client[args.db_name_benchmark]
            hac_tables = build_hac_bootstrap_tables(
                db,
                db_benchmark,
                plan=plan,
                rebalance=rebalance,
                rebalance_freq=args.rebalance_freq,
                sem_reb_tag=str(args.sem_reb_tag or "buyhold"),
                engine=str(getattr(args, "engine", "v41")),
                hac_lags=args.hac_lags,
                avg_blocks=args.avg_blocks,
                base_lag=args.base_lag,
                boot_b=args.boot_b,
                boot_seed=args.boot_seed,
                alpha=args.alpha,
                allow_missing=args.allow_missing,
                quiet=args.quiet,
            )
        finally:
            client.close()

        for apply_ir, hac_table in hac_tables:
            ir_tag = "ir" if apply_ir else "noir"
            hac_stem = build_output_stem(
                args.hac_stem,
                rebalanceamento=args.rebalanceamento,
                ir_tag=ir_tag if len(hac_tables) > 1 else None,
            )
            hac_label = (
                args.hac_label
                if len(hac_tables) == 1
                else f"{args.hac_label}_{ir_tag}"
            )
            hac_csv = args.output_dir / f"{hac_stem}.csv"
            hac_tex = args.output_dir / f"{hac_stem}.tex"
            hac_table.to_csv(hac_csv, index=False, encoding="utf-8-sig")
            write_hac_latex(
                hac_table,
                hac_tex,
                title=hac_export_title,
                label=hac_label,
                base_lag=args.base_lag,
                hac_lags=args.hac_lags,
                avg_blocks=args.avg_blocks,
                alpha=args.alpha,
                tcost_bps=plan.tcost_bps,
                ir=bool(apply_ir),
                universo_tag=plan.universo_tag,
                boot_b=args.boot_b,
                rebalanceamento=args.rebalanceamento,
            )
            if not args.quiet:
                print("\nTabela HAC + bootstrap (compacta):", flush=True)
                print(display_frame(hac_table).to_string(index=False), flush=True)
                print(f"\nCSV:   {hac_csv}", flush=True)
                print(f"LaTeX: {hac_tex}", flush=True)

    if last_xlsx is None:
        raise RuntimeError("Nenhum arquivo gerado.")
    return last_xlsx


if __name__ == "__main__":
    main()
