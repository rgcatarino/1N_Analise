# Tratamento de deslistagem e conversão de ticker (pessoa investidora)

Este é o tratamento recomendado para o bloco da pessoa investidora (Capítulo 7 e extensões de liquidez / DivLiq). **Não** se confunde com o painel balanceado do protocolo DGU (Capítulo 6).

Implementação: `ticker_continuacao.py` + `backtest_carteiras_individuais_retornos_v4.py`.  
Banco MongoDB: `Backtest_Mestrado_PF_LIQUIDEZ_1MM`. Sufixo das collections com a tag do universo, por exemplo `12atv_liq_1MM_200107_202510_reb-annual_t122bps_ir` (não é preciso passar `--collections-suffix`).

---

## O que não fazer

Filtrar o universo de formação para ficar só com quem ainda cotava em outubro de 2025 é **viés de sobrevivência (look-ahead)**. Quem era líquido em junho de 2001 (2006, 2011) entra no sorteio, mesmo que depois desliste, converta o ticker ou sofra OPA.

O v3 (`prepare_price_window`) faz `ffill` + `dropna(how="any")`: depois da última cotação o preço **congela**, o retorno fica zero e o capital permanece preso no papel morto. Isso não é o que a pessoa investidora faria.

---

## Dois casos

### 1. Conversão de código (mesmo ativo econômico)

A série de preços do ticker original continua no sucessor, alinhada no último pregão comum (fator de splice). Fontes:

- mapa explícito (`AMBV4→ABEV3`, `VALE5→VALE3`, `LAME4→BHIA3`, …) em `CONTINUACAO_EXPLICITA`;
- heurística de **mesmo prefixo de quatro letras** quando outra classe da empresa segue cotada (`WEGE4→WEGE3`, `UGPA4→UGPA3`).

Se o sucessor **já está na carteira**, não se encadeia (evita duplicar a empresa): o papel que some é liquidado e o sucessor permanece com o peso que já tinha, redistribuindo $1/(N-1)$ entre os vivos.

### 2. Deslistagem verdadeira (sem sucessor no painel)

No primeiro pregão em que o nome some:

1. vende pelo último preço disponível;
2. cobra o custo de transação (122 bps no caso base);
3. se `--apply-stock-ir`, apura IR de 15% sobre o ganho, com isenção mensal de R$ 20.000 no volume de vendas do evento;
4. reinveste o produto em pesos iguais nos $N-1$ (ou $K$) papéis ainda listados.

Lacunas curtas (suspensão) recebem `ffill` de no máximo `--max-gap-days` (default 5). Não se preenche depois da última cotação.

Retorno terminal de *distress* (literatura, da ordem de −30%, no espírito de Shumway) é **opcional**: `--delist-terminal-return -0.30`. O default é 0 (liquidação no último preço observado).

---

## Formação do universo

Os CSVs ponto-a-ponto **incluem** deslistados:

| Formação | Só liquidez | Liq + DivLiq/EBITDA ≤ 1,5 |
|---|---:|---:|
| 2001-06 | 57 papéis | 39 |
| 2006-06 | 106 | 71 |
| 2011-06 | 171 | 97 |

Semente de sorteio: `20250725`. Arquivos em `resultados/carteiras_aleatorias_liquidas/`. As listas `deslistadas_*.csv` são **diagnóstico**, não filtro de formação.

Sem a planilha de volume Economatica, os universos foram restaurados a partir de `pacote_replicacao_1N/carteiras_e_universos/` (cópia anterior ao filtro de sobreviventes). Com o Excel:

```bash
python3 codigo_fonte/gerar_carteiras_aleatorias_liquidas.py \
  --formation-months 2001-06,2006-06,2011-06 \
  --no-divliq-filter \
  --n-carteiras 3000 --seed 20250725 --sizes 8,10,12,15,20

python3 codigo_fonte/gerar_carteiras_aleatorias_liquidas.py \
  --formation-months 2001-06,2006-06,2011-06 \
  --divliq-xlsx ibov/economatica_DivLiq_EBTIDA.xlsx \
  --divliq-max 1.5 --divliq-cutoff-month 6 \
  --n-carteiras 3000 --seed 20250725 --sizes 8,10,12,15,20
```

---

## Backtest v4

```bash
python3 codigo_fonte/backtest_carteiras_individuais_retornos_v4.py \
  --carteiras resultados/carteiras_aleatorias_liquidas/carteiras_8atv_liq_1MM_200106.csv \
  --start-m 7 --start-y 2001 \
  --end-m 10 --end-y 2025 \
  --rebalance --rebalance-freq annual \
  --tcost-bps 122 \
  --apply-stock-ir
```

Buy-and-hold (`--no-rebalance`) ainda liquida e reinveste $1/(N-1)$ na deslistagem; só omite o rebalance de julho.

Tabelas a partir do Mongo:

```bash
python3 codigo_fonte/mestrado_resultados_simulador_pessoa_investidora_v4.py \
  --ativos 8 \
  --universo-tag liq_1MM \
  --ir sim \
  --rebalanceamento com \
  --start-m 7 --start-y 2001 \
  --end-m 10 --end-y 2025
```

O v3 e o banco `Backtest_Mestrado_PF_LIQUIDEZ_1MM` permanecem para conferir as Tabelas 25–86 desta versão do PDF (preço congelado / painel exigido completo). Replicações novas da pessoa investidora com universos líquidos devem usar o v4.
