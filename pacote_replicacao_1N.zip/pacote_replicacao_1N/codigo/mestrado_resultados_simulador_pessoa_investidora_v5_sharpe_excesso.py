"""Tabela consolidada v5 com Sharpe mensal em excesso.

Mesma grade da v5 (retorno total, retorno médio, volatilidade e excesso
acumulado continuam vindo de ``res_*`` e ``aux_metrics_*``). A coluna
``Sharpe anualizado`` deixa de ser o quociente do retorno total mensal do NAV
e passa a ser o Sharpe clássico do excesso mensal:

    e_t = r_{p,t} - r_{f,t}
    S   = mean(e) * sqrt(12) / std(e)

``r_{p,t}`` é o retorno do NAV entre fechamentos de mês. ``r_{f,t}`` é a taxa
livre de risco composta no mesmo intervalo, recuperada das séries já gravadas
``ret_acum_pct_{sufixo}`` e ``ret_excess_acum_pct_{sufixo}`` (último pregão de
cada mês). O primeiro mês-fim serve só de base e não entra no Sharpe, como em
``nav.resample("ME").last().pct_change()``.

Não altera ``mestrado_resultados_simulador_pessoa_investidora_v5.py`` nem os
arquivos ``desempenho_carteiras_aleatorias_liquidez_com_reb.*``.

Exemplo::

    python3 codigo_fonte/mestrado_resultados_simulador_pessoa_investidora_v5_sharpe_excesso.py --self-test

    python3 codigo_fonte/mestrado_resultados_simulador_pessoa_investidora_v5_sharpe_excesso.py \\
      --universo-tag liq_1MM \\
      --tcost-bps 12 --ir sim \\
      --rebalanceamento com \\
      --engine v41
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from pymongo import MongoClient
from pymongo.database import Database

sys.path.insert(0, str(Path(__file__).resolve().parent))

import mestrado_resultados_simulador_pessoa_investidora_v5 as v5  # noqa: E402

# Guardado antes de qualquer troca: build_summary_table chama v5.load_summary_row.
_V5_LOAD_SUMMARY_ROW = v5.load_summary_row

DEFAULT_STEM = "desempenho_carteiras_aleatorias_liquidez_sharpe_excesso"
DEFAULT_LABEL = "tab:desempenho-carteiras-aleatorias-liquidez-sharpe-excesso"
DEFAULT_TITLE = (
    v5.DEFAULT_TITLE + " — Sharpe mensal em excesso"
)
SHARPE_NOTE = (
    " Sharpe anualizado: excesso mensal e = r - rf entre fechamentos de mês "
    "(NAV menos a taxa livre de risco NEFIN), "
    "S = media(e) * sqrt(12) / desvio-padrão(e); "
    "o primeiro mês-fim da série é apenas a base."
)


def monthly_excess_sharpe(cum_total_pct: pd.Series, cum_excess_pct: pd.Series) -> float:
    """Sharpe anualizado do excesso mensal aritmético.

    As séries de entrada estão em percentual acumulado no fechamento do mês,
    na convenção gravada por ``save_series_in_collection``.
    """
    both = pd.concat(
        {"total": pd.to_numeric(cum_total_pct, errors="coerce"),
         "excess": pd.to_numeric(cum_excess_pct, errors="coerce")},
        axis=1,
    )
    both = both.replace([np.inf, -np.inf], np.nan).dropna().sort_index()
    if len(both) < 3:
        return np.nan

    wealth = 1.0 + both["total"].to_numpy(dtype=float) / 100.0
    excess_wealth = 1.0 + both["excess"].to_numpy(dtype=float) / 100.0
    w_prev = wealth[:-1]
    x_prev = excess_wealth[:-1]
    ok_base = (w_prev > 0.0) & (x_prev != 0.0) & np.isfinite(wealth[1:]) & np.isfinite(excess_wealth[1:])
    if not np.any(ok_base):
        return np.nan

    r = wealth[1:][ok_base] / w_prev[ok_base] - 1.0
    g = excess_wealth[1:][ok_base] / x_prev[ok_base] - 1.0
    denom = 1.0 + g
    ok = np.isfinite(r) & np.isfinite(g) & (np.abs(denom) > 1e-12)
    if int(ok.sum()) < 2:
        return np.nan
    rf = (1.0 + r[ok]) / denom[ok] - 1.0
    excess = r[ok] - rf
    excess = excess[np.isfinite(excess)]
    if excess.size < 2:
        return np.nan
    sigma = float(excess.std(ddof=1))
    if not np.isfinite(sigma) or sigma <= 0.0:
        return np.nan
    return float(excess.mean() / sigma * np.sqrt(12.0))


def _load_month_end_cumulative(db: Database, collection_name: str) -> pd.DataFrame:
    """Lê a série longa ``{strategy, date, value}`` e devolve valor por estratégia/data."""
    if collection_name not in set(db.list_collection_names()):
        raise RuntimeError(f"Collection ausente: {db.name}.{collection_name}")
    cursor = db[collection_name].find({}, {"_id": 0, "strategy": 1, "date": 1, "value": 1})
    frame = pd.DataFrame(list(cursor))
    if frame.empty:
        raise RuntimeError(f"Nenhum ponto em {db.name}.{collection_name}")
    frame["strategy"] = frame["strategy"].astype(str)
    frame = frame.loc[frame["strategy"].str.strip() != ""]
    frame["date"] = pd.to_datetime(frame["date"], errors="coerce")
    frame["value"] = pd.to_numeric(frame["value"], errors="coerce")
    frame = frame.dropna(subset=["strategy", "date", "value"])
    frame = frame.sort_values(["strategy", "date"], kind="mergesort")
    frame = frame.drop_duplicates(subset=["strategy", "date"], keep="last")
    return frame


def sharpe_excess_by_strategy(db: Database, suffix: str, strategies: Sequence[str]) -> pd.Series:
    """Calcula S em excesso só para as estratégias já deduplicadas."""
    wanted = pd.Index(
        pd.unique(np.asarray([str(item) for item in strategies if str(item).strip()], dtype=object))
    )
    total = _load_month_end_cumulative(db, f"ret_acum_pct_{suffix}")
    excess = _load_month_end_cumulative(db, f"ret_excess_acum_pct_{suffix}")
    total = total.loc[total["strategy"].isin(wanted), ["strategy", "date", "value"]]
    excess = excess.loc[excess["strategy"].isin(wanted), ["strategy", "date", "value"]]
    merged = total.merge(
        excess,
        on=["strategy", "date"],
        how="inner",
        suffixes=("_total", "_excess"),
    )
    if merged.empty:
        return pd.Series(np.nan, index=wanted, dtype=float)

    values: Dict[str, float] = {}
    for strategy, group in merged.groupby("strategy", sort=False):
        series_total = pd.Series(group["value_total"].to_numpy(), index=pd.DatetimeIndex(group["date"]))
        series_excess = pd.Series(group["value_excess"].to_numpy(), index=pd.DatetimeIndex(group["date"]))
        values[str(strategy)] = monthly_excess_sharpe(series_total, series_excess)
    return pd.Series(values, dtype=float).reindex(wanted)


def load_summary_row_excess(
    db: Database,
    parsed: Optional[v5.ParsedResCollection],
    *,
    allow_missing: bool,
    quiet: bool,
    expected_name: str = "",
) -> Dict[str, object]:
    """Igual à v5, com ``monthly_sharpe`` substituído pelo Sharpe de excesso."""
    row = _V5_LOAD_SUMMARY_ROW(
        db,
        parsed,
        allow_missing=allow_missing,
        quiet=quiet,
        expected_name=expected_name,
    )
    if parsed is None or row.get("n_carteiras", 0) in (0, None):
        return row

    try:
        metrics, _n_raw, _n_unique = v5._load_unique_res_metrics(db, parsed.suffix)
    except RuntimeError:
        row["Sharpe anualizado"] = np.nan
        return row

    try:
        sharpe = sharpe_excess_by_strategy(db, parsed.suffix, list(metrics.index))
    except RuntimeError as exc:
        message = f"{parsed.collection}: Sharpe em excesso indisponível ({exc})"
        if allow_missing:
            if not quiet:
                print(f"  SKIP {message}", flush=True)
            row["Sharpe anualizado"] = np.nan
            return row
        raise

    aligned = sharpe.reindex(metrics.index)
    n_ok = int(aligned.notna().sum())
    if not quiet:
        print(
            f"  Sharpe mensal em excesso: {n_ok}/{len(aligned)} carteiras",
            flush=True,
        )
    if n_ok == 0:
        row["Sharpe anualizado"] = np.nan
        return row
    row["Sharpe anualizado"] = float(aligned.mean(skipna=True))
    return row


def build_tab_fonte_excess(
    rebalanceamento: str,
    *,
    tcost_bps: float = 12.0,
    benchmark: Optional[str] = None,
    n_carteiras: Optional[int] = None,
) -> str:
    raw = v5.build_tab_fonte(
        rebalanceamento,
        tcost_bps=tcost_bps,
        benchmark=benchmark,
        n_carteiras=n_carteiras,
    )
    if raw.endswith("}"):
        return raw[:-1] + SHARPE_NOTE + "}"
    return raw + SHARPE_NOTE


def _apply_output_defaults(args):
    if args.stem == "desempenho_carteiras_aleatorias_liquidez":
        args.stem = DEFAULT_STEM
    if args.label == "tab:desempenho-carteiras-aleatorias-liquidez":
        args.label = DEFAULT_LABEL
    if args.title == v5.DEFAULT_TITLE:
        args.title = DEFAULT_TITLE
    return args


def run_self_test() -> None:
    """Recupera e = r - rf a partir dos acumulados e confere o Sharpe."""
    rng = np.random.default_rng(27)
    r = rng.normal(0.012, 0.04, size=48)
    rf = np.full(48, 0.008)
    excess = r - rf
    wealth = np.cumprod(1.0 + r)
    excess_wealth = np.cumprod((1.0 + r) / (1.0 + rf))
    dates = pd.date_range("2018-01-31", periods=48, freq="ME")
    got = monthly_excess_sharpe(
        pd.Series((wealth - 1.0) * 100.0, index=dates),
        pd.Series((excess_wealth - 1.0) * 100.0, index=dates),
    )
    used = excess[1:]
    expected = float(used.mean() / used.std(ddof=1) * np.sqrt(12.0))
    if not np.isfinite(got) or abs(got - expected) > 1e-10:
        raise AssertionError(f"Sharpe em excesso divergiu: obtido {got}, esperado {expected}")

    rf_zero = np.zeros(48)
    wealth_z = np.cumprod(1.0 + r)
    excess_z = np.cumprod((1.0 + r) / (1.0 + rf_zero))
    got_zero = monthly_excess_sharpe(
        pd.Series((wealth_z - 1.0) * 100.0, index=dates),
        pd.Series((excess_z - 1.0) * 100.0, index=dates),
    )
    total_used = r[1:]
    expected_zero = float(total_used.mean() / total_used.std(ddof=1) * np.sqrt(12.0))
    if abs(got_zero - expected_zero) > 1e-10:
        raise AssertionError(
            f"Com rf = 0 o Sharpe deveria coincidir com o do retorno total: "
            f"obtido {got_zero}, esperado {expected_zero}"
        )
    if abs(got - got_zero) < 1e-6:
        raise AssertionError("rf positiva não alterou o Sharpe; a subtração de rf falhou.")
    print(
        f"self-test ok | Sharpe excesso={got:.6f} | Sharpe com rf=0={got_zero:.6f}",
        flush=True,
    )


def main(argv: Optional[Sequence[str]] = None) -> Path:
    argv_list = list(sys.argv[1:] if argv is None else argv)
    if "--self-test" in argv_list:
        run_self_test()
        return Path()

    args = _apply_output_defaults(v5.parse_args(argv_list))
    rebalance = args.rebalanceamento == "com"
    args.output_dir.mkdir(parents=True, exist_ok=True)
    client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=15000)
    original_loader = v5.load_summary_row
    v5.load_summary_row = load_summary_row_excess
    frames: List[pd.DataFrame] = []
    plan = None
    try:
        db = client[args.db_name]
        all_collections = v5.discover_res_collections(db)
        if args.list_collections:
            filtered = v5.filter_collections_for_args(all_collections, args)
            v5.print_collection_inventory(
                filtered,
                db_name=args.db_name,
                filters={
                    "engine": args.engine,
                    "rebalanceamento": args.rebalanceamento,
                    "universo-tag": args.universo_tag or "(qualquer)",
                    "exclude-universo-tag": sorted(v5._resolve_exclude_universo_tags(args)),
                    "tcost-bps": args.tcost_bps,
                    "ir": args.ir,
                    "sharpe": "mensal em excesso",
                },
            )
            print(
                "\n(Inventário apenas — nenhum CSV/Excel/LaTeX gerado. "
                "Remova --list-collections para exportar arquivos.)",
                flush=True,
            )
            return args.output_dir

        plan = v5.infer_run_plan(all_collections, args)
        if not args.quiet:
            print("\nPlano inferido do banco (Sharpe mensal em excesso):", flush=True)
            print(f"  universo: {plan.universo_tag or '(sem tag)'}", flush=True)
            print(f"  engine:   {args.engine}", flush=True)
            print(f"  tcost:    {plan.tcost_bps} bps", flush=True)
            print(f"  ativos:   {' '.join(map(str, plan.ativos))}", flush=True)
            print(
                "  períodos: " + ", ".join(label for label, *_ in plan.period_windows),
                flush=True,
            )
            print(
                "  IR:       " + ", ".join("sim" if mode else "nao" for mode in plan.ir_modes),
                flush=True,
            )

        for apply_ir in plan.ir_modes:
            ir_tag = "ir" if apply_ir else "noir"
            filtered_index = [
                item
                for item in plan.collection_index
                if item.ir_tag == ir_tag
                and v5._reb_matches(
                    item,
                    rebalance=rebalance,
                    rebalance_freq=args.rebalance_freq,
                    sem_reb_tag=str(args.sem_reb_tag or "buyhold"),
                )
            ]
            if not args.quiet:
                print(
                    f"\n=== {args.db_name} | IR={'sim' if apply_ir else 'nao'} | "
                    f"{len(filtered_index)} collections ===",
                    flush=True,
                )
            frames.append(
                v5.build_summary_table(
                    db,
                    ativos=plan.ativos,
                    period_windows=plan.period_windows,
                    rebalance=rebalance,
                    rebalance_freq=args.rebalance_freq,
                    tcost_bps=plan.tcost_bps,
                    apply_stock_ir=bool(apply_ir),
                    universo_tag=plan.universo_tag,
                    sem_reb_tag=str(args.sem_reb_tag or "buyhold"),
                    allow_missing=args.allow_missing,
                    quiet=args.quiet,
                    collection_index=filtered_index,
                )
            )
    finally:
        v5.load_summary_row = original_loader
        client.close()

    if plan is None or not frames:
        raise RuntimeError("Nenhuma linha gerada.")

    export_title = v5.resolve_export_title(
        args.title,
        args.rebalanceamento,
        default_title=DEFAULT_TITLE,
    )
    last_xlsx: Optional[Path] = None
    for apply_ir, frame in zip(plan.ir_modes, frames):
        ir_tag = "ir" if apply_ir else "noir"
        stem = v5.build_output_stem(
            args.stem,
            rebalanceamento=args.rebalanceamento,
            ir_tag=ir_tag if len(plan.ir_modes) > 1 else None,
        )
        label = args.label if len(plan.ir_modes) == 1 else f"{args.label}_{ir_tag}"
        tabfonte = build_tab_fonte_excess(
            args.rebalanceamento,
            tcost_bps=plan.tcost_bps,
            n_carteiras=v5._n_carteiras_from_frame(frame),
        )
        csv_path = args.output_dir / f"{stem}.csv"
        xlsx_path = args.output_dir / f"{stem}.xlsx"
        tex_path = args.output_dir / f"{stem}.tex"
        frame.to_csv(csv_path, index=False, encoding="utf-8-sig")
        v5.write_excel(frame[list(v5.TABLE_COLUMNS)], xlsx_path, title=export_title)
        v5.write_latex(
            frame[list(v5.TABLE_COLUMNS)],
            tex_path,
            title=export_title,
            label=label,
            tabfonte=tabfonte,
        )
        last_xlsx = xlsx_path
        if not args.quiet:
            print(f"\nCSV:   {csv_path}", flush=True)
            print(f"Excel: {xlsx_path}", flush=True)
            print(f"LaTeX: {tex_path}", flush=True)

    if last_xlsx is None:
        raise RuntimeError("Nenhum arquivo gerado.")
    return last_xlsx


if __name__ == "__main__":
    main()
