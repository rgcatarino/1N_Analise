# Regra do universo de liquidez de 1 MM

Este documento descreve como foi formada a lista de ações líquidas usada no banco MongoDB `Backtest_Mestrado_PF_LIQUIDEZ_1MM` e nas carteiras aleatórias de liquidez.

Implementação: `codigo_fonte/gerar_carteiras_aleatorias_liquidas.py` (`load_liquid_universe`).

---

## Critério

Entram no universo os papéis cujo **volume diário médio (ADV)** na janela de estudo é **maior que R$ 1 milhão**.

Na planilha Economática o volume está em **milhares de reais**. O limiar operacional é, portanto:

\[
\mathrm{ADV} > 1.000 \text{ mil R\$} \quad \Leftrightarrow \quad \mathrm{ADV} > \text{R\$ } 1\text{ milhão/dia}.
\]

Parâmetros-padrão:

| Parâmetro | Valor |
|---|---|
| Fonte | `ibov/economaticavolumeNegociado.xlsx` |
| Janela | 2001-01-01 a 2025-10-31 |
| Limiar (`adv_min`) | 1.000 mil R$ |
| Resultado | 305 tickers / 277 empresas |

---

## Cálculo do ADV

Para cada ticker da planilha (todas as colunas, exceto `Data`):

1. Converter o volume para número.
2. Restringir as datas à janela 2001-01-01 … 2025-10-31.
3. Tratar dia sem dado como **volume zero** (`fillna(0)`).
4. Calcular a média ao longo de **todos** os pregões da janela (não só dos dias em que o papel negociou).
5. Manter o ticker se \(\mathrm{ADV} > 1.000\).

Dias sem observação puxam a média para baixo. Um papel que negociou pouco tempo, ou só no fim da amostra, tende a ficar de fora.

---

## Padronização de códigos

Antes de gravar o universo, os tickers são mapeados para o código usado na base de preços:

| Origem | Destino |
|---|---|
| AXIA3 | ELET3 |
| AXIA6 | ELET6 |
| EMBJ3 | EMBR3 |
| GOL, GOLL4, GOLL53 | GOLL54 |

Se o mesmo papel aparecer com dois nomes, permanece o de **maior ADV**.

A empresa é o prefixo de quatro letras (ITUB4 → ITUB, GOLL54 → GOLL). Duas classes da mesma empresa (ex.: ITUB3 e ITUB4) podem coexistir no universo; **não entram juntas na mesma carteira aleatória**.

---

## O que este universo não inclui

O recorte de **1 MM** é só de liquidez. Filtros posteriores são outro universo:

- Dívida líquida/EBITDA ≤ 1,5 em 2001, com isenção de bancos, holdings (ITSA) e seguradoras → 73 papéis em `ativos_liquidos.json` (após o filtro).
- O universo completo de liquidez (305 papéis) ficou em `ativos_liquidos_universo_completo.json`.

---

## Como regenerar

```bash
cd ~/mestrado
source .venv/bin/activate
python3 codigo_fonte/gerar_carteiras_aleatorias_liquidas.py \
  --volume-xlsx ibov/economaticavolumeNegociado.xlsx \
  --out-dir resultados/carteiras_aleatorias_liquidas \
  --n-carteiras 6000 \
  --seed 20250725 \
  --sizes 8,10,12,15,20
```

Saída esperada: `resultados/carteiras_aleatorias_liquidas/universo_ativos_liquidos.csv` (coluna `adv_mil_reais`).

---

## Universos ponto-a-ponto (ADV de junho)

Para os backtests que começam em julho de 2001, 2006 e 2011, o universo **não** usa a média 2001–2025. Cada horizonte tem o próprio recorte:

1. ADV = média do volume em **junho** daquele ano (dias sem dado = 0).
2. Pelo menos **10** pregões com volume observado no mês.
3. ADV > 1.000 mil R$.
4. Pelo menos um preço não nulo em **julho** (início do backtest).
5. Mesma padronização de códigos e regra de uma classe por empresa na carteira.

```bash
python3 codigo_fonte/gerar_carteiras_aleatorias_liquidas.py \
  --formation-months 2001-06,2006-06,2011-06 \
  --no-divliq-filter \
  --n-carteiras 3000 \
  --seed 20250725 \
  --sizes 8,10,12,15,20
```

Saídas (não sobrescrevem o universo de 24 anos):

- `universo_liq_1MM_YYYY06.csv`
- `carteiras_{N}atv_liq_1MM_YYYY06.csv`

Backtest: `--carteiras .../carteiras_12atv_liq_1MM_200106.csv --start-m 7 --start-y 2001`.

Detalhe do plano: `codigo_fonte/PLANO_UNIVERSOS_LIQUIDEZ_JUNHO.md`.

---

## Universos ponto-a-ponto (ADV junho + DivLiq/EBITDA ≤ 1,5)

Combina o ADV de junho com filtro de endividamento **sem look-ahead**: usa o último DivLiq/EBITDA disponível com data **≤ 30/06** do ano de formação. Bancos, holdings (ITSA) e seguradoras entram por isenção setorial (mesma regra de `filtrar_ativos_divliq_ebitda.py`).

Implementação: `codigo_fonte/divliq_ebitda.py` + flags em `gerar_carteiras_aleatorias_liquidas.py`.

| Formação | Só liquidez | Liq + DivLiq |
|---|---:|---:|
| 2001-06 | 57 papéis / 47 empresas | 39 / 30 |
| 2006-06 | 106 / 94 | 71 / 62 |
| 2011-06 | 171 / 156 | 97 / 88 |

```bash
python3 codigo_fonte/gerar_carteiras_aleatorias_liquidas.py \
  --formation-months 2001-06,2006-06,2011-06 \
  --divliq-xlsx ibov/economatica_DivLiq_EBTIDA.xlsx \
  --divliq-max 1.5 \
  --divliq-cutoff-month 6 \
  --n-carteiras 3000 \
  --seed 20250725 \
  --sizes 8,10,12,15,20
```

Saídas:

- `universo_liq_divliq_1MM_YYYY06.csv` (colunas de liquidez + `divliq_ebitda`, `divliq_data_ref`, `divliq_motivo`)
- `carteiras_{N}atv_liq_divliq_1MM_YYYY06.csv`
- `audit_divliq_YYYY06.csv`

Backtest: `--carteiras .../carteiras_12atv_liq_divliq_1MM_200106.csv --start-m 7 --start-y 2001 --universo-tag liq_divliq_1MM`.

Detalhe do plano: `codigo_fonte/PLANO_UNIVERSOS_LIQUIDEZ_DIVLIQ_JUNHO.md`.

---

## Deslistados pertencem ao universo de formação

Os papéis que eram líquidos em junho entram no sorteio mesmo que depois saiam da B3. Filtrar sobreviventes (cotação até out/2025) é look-ahead e **não** deve ser reaplicado. O motor da pessoa investidora que liquida no evento e reinveste \(1/(N-1)\) é o v4; ver `codigo_fonte/TRATAMENTO_DESLISTAGEM.md` e o apêndice de replicação (seção de deslistagem).
