"""Percentual de ocorrências na 1ª posição do Ranking de Sharpe (B3 vwN).

Lê as collections Mongo ``DGU_BRASIL.B3_RESULTS_{periodo}_vwN``, ranqueia as
estratégias factíveis por composição de carteira (ordem dos tickers irrelevante)
pelo Sharpe mensal, exclui o oráculo ``MV (in sample)`` e gera Excel + LaTeX no
formato da tabela:

    Percentual de ocorrências na primeira posição do Ranking de Sharpe
    Período | Ativos por carteira | Estratégias (EW … MV-MIN)

Exemplo:
    python codigo_fonte/mestrado_tabela_pct_primeira_sharpe_vwn.py

    python codigo_fonte/mestrado_tabela_pct_primeira_sharpe_vwn.py \\
      --db-name DGU_BRASIL \\
      --collection-name \\
        B3_RESULTS_2001_2025_vwN \\
        B3_RESULTS_2006_2025_vwN \\
        B3_RESULTS_2011_2025_vwN \\
      --ativos 8 10 12 15 20 25 30 35 40 \\
      --max-carteiras 1000 \\
      --output-dir resultados/ranking_sharpe_1a_vwn
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from pymongo import MongoClient

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MONGO_URI = "mongodb://172.23.224.1:27017/"
DEFAULT_DB = "DGU_BRASIL"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "resultados" / "ranking_sharpe_1a_vwn"
DEFAULT_PERIODOS = ("2001_2025", "2006_2025", "2011_2025")
DEFAULT_COLLECTION_TEMPLATE = "B3_RESULTS_{periodo}_vwN"
DEFAULT_ATIVOS = (8, 10, 12, 15, 20, 25, 30, 35, 40)
DEFAULT_MAX_CARTEIRAS = 1000

SHARPE = "Sharpe (monthly)"
ORACLE = "MV (in sample)"
PORTFOLIO_KEY = "portfolio_key"

# Ordem das colunas conforme a figura / planilha anexa.
STRATEGY_COLUMNS = (
    "EW",
    "VW",
    "BS",
    "BS-C",
    "DM",
    "EW-MIN",
    "G-MIN-C",
    "MIN",
    "MIN-C",
    "MP",
    "MV",
    "MV-C",
    "MV-MIN",
)

PERIOD_DISPLAY = {
    "2001_2025": "2001-2025",
    "2006_2025": "2006-2025",
    "2011_2025": "2011-2025",
}

COLUMN_ALIASES = {
    "base": "Base",
    "base_id": "Base",
    "Base_id": "Base",
    "carteira_id": "Base",
    "strategy": "Strategy",
    "total_papeis": "Total_papeis",
    "Total_Papeis": "Total_papeis",
    "n_ativos": "Total_papeis",
}

TITLE = "Percentual de ocorrências na primeira posição do Ranking de Sharpe"
LATEX_TITLE = (
    r"Percentual de ocorrências na primeira posição do Ranking de Sharpe"
)
DEFAULT_TAB_FONTE = (
    r"\tabfonte{Fonte: Elaboração própria. Notas: (1) Sharpe e CEQ são mensais e brutos. "
    r"O custo de 12 pontos-base é considerado somente no \emph{return-loss}. "
    r"(2) O \emph{ranking} multicritério soma os postos de Sharpe, de CEQ ($\gamma=1$) "
    r"e de \emph{turnover}, com posto melhor para menor giro. "
    r"(3) Não inclui MV (in sample). "
    r"(4) Valores em percentual de carteiras em que a estratégia ocupa a 1\textsuperscript{a} "
    r"posição no ranking de Sharpe mensal.}"
)


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Tabela % 1ª posição no Ranking de Sharpe por estratégia "
            "(collections B3_RESULTS_*_vwN)."
        )
    )
    parser.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    parser.add_argument("--db-name", default=DEFAULT_DB)
    parser.add_argument(
        "--collection-name",
        nargs="+",
        default=None,
        help=(
            "Collections explícitas "
            "(default: B3_RESULTS_{periodo}_vwN para --periodos)."
        ),
    )
    parser.add_argument(
        "--collection-template",
        default=DEFAULT_COLLECTION_TEMPLATE,
        help=f"Template sem --collection-name (default: {DEFAULT_COLLECTION_TEMPLATE})",
    )
    parser.add_argument(
        "--periodos",
        nargs="+",
        default=list(DEFAULT_PERIODOS),
        help="Períodos usados com --collection-template",
    )
    parser.add_argument(
        "--ativos",
        type=int,
        nargs="+",
        default=list(DEFAULT_ATIVOS),
        help=(
            "N de ativos por carteira na tabela "
            f"(default: {' '.join(map(str, DEFAULT_ATIVOS))})"
        ),
    )
    parser.add_argument(
        "--max-carteiras",
        type=int,
        default=DEFAULT_MAX_CARTEIRAS,
        help=(
            "Máximo de carteiras distintas por período e N "
            f"(default: {DEFAULT_MAX_CARTEIRAS}; 0 = sem limite)"
        ),
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--exclude-oracle",
        dest="exclude_oracle",
        action="store_true",
        default=True,
        help="Exclui 'MV (in sample)' (default)",
    )
    group.add_argument(
        "--include-oracle",
        dest="exclude_oracle",
        action="store_false",
        help="Inclui 'MV (in sample)'",
    )
    parser.add_argument(
        "--stem",
        default="pct_primeira_sharpe_vwn",
        help="Prefixo dos arquivos de saída (xlsx/tex/csv)",
    )
    parser.add_argument(
        "--allow-missing",
        action="store_true",
        default=True,
        help="Segue com collections ausentes (células vazias; default)",
    )
    parser.add_argument(
        "--require-all",
        dest="allow_missing",
        action="store_false",
        help="Falha se alguma collection solicitada não existir",
    )
    parser.add_argument("--quiet", action="store_true")
    return parser.parse_args(argv)


def infer_periodo_from_collection(name: str) -> str:
    match = re.search(r"(\d{4}_\d{4})", name)
    if not match:
        raise ValueError(
            f"Não foi possível inferir período AAAA_AAAA em '{name}'. "
            "Use --periodos com --collection-template."
        )
    return match.group(1)


def resolve_collection_jobs(
    *,
    collection_names: Optional[Sequence[str]],
    periodos: Sequence[str],
    collection_template: str,
) -> List[Tuple[str, str]]:
    if collection_names:
        return [(infer_periodo_from_collection(name), name) for name in collection_names]
    return [(p, collection_template.format(periodo=p)) for p in periodos]


def canonical_carteira_key(value: object) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    text = str(value).strip()
    if not text:
        return ""
    if text.lower().endswith(".csv"):
        return text
    parts = [part.strip() for part in text.split(",") if part.strip()]
    if not parts:
        return text
    return ",".join(sorted(parts))


def add_portfolio_key(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    source = out["Carteira"] if "Carteira" in out.columns else out["Base"]
    out[PORTFOLIO_KEY] = source.map(canonical_carteira_key)
    missing = out[PORTFOLIO_KEY].eq("")
    if missing.any():
        out.loc[missing, PORTFOLIO_KEY] = out.loc[missing, "Base"].astype(str)
    return out


def normalize_results_df(df: pd.DataFrame, *, collection: str) -> pd.DataFrame:
    out = df.copy()
    rename = {
        src: dst
        for src, dst in COLUMN_ALIASES.items()
        if src in out.columns and dst not in out.columns
    }
    if rename:
        out = out.rename(columns=rename)

    if "Base" not in out.columns and "Carteira" in out.columns:
        out["Base"] = out["Carteira"].astype(str)

    required = {"Strategy", "Base", "Total_papeis", SHARPE}
    missing = required - set(out.columns)
    if missing:
        raise RuntimeError(f"Campos ausentes em {collection}: {sorted(missing)}")

    out["Total_papeis"] = pd.to_numeric(out["Total_papeis"], errors="coerce").astype("Int64")
    out[SHARPE] = pd.to_numeric(out[SHARPE], errors="coerce")
    out = out.dropna(subset=["Strategy", "Base", "Total_papeis", SHARPE])
    out["Total_papeis"] = out["Total_papeis"].astype(int)
    out["Strategy"] = out["Strategy"].astype(str)
    out["Base"] = out["Base"].astype(str)
    return out


def load_collection(
    client: MongoClient,
    *,
    db_name: str,
    collection: str,
    exclude_oracle: bool = True,
) -> pd.DataFrame:
    docs = list(client[db_name][collection].find({}, {"_id": 0}))
    if not docs:
        raise RuntimeError(f"Collection vazia: {db_name}.{collection}")
    df = normalize_results_df(pd.DataFrame(docs), collection=collection)
    if exclude_oracle:
        df = df[df["Strategy"] != ORACLE].copy()
    return df


def select_portfolio_keys(
    keys: Sequence[str],
    *,
    max_carteiras: Optional[int],
) -> List[str]:
    unique = sorted({k for k in keys if k})
    if max_carteiras is None or max_carteiras <= 0:
        return unique
    return unique[: int(max_carteiras)]


def rank_one_portfolio(group: pd.DataFrame) -> pd.DataFrame:
    """Rank 1 = melhor Sharpe mensal (empates: ordem estável por mergesort)."""
    g = group.copy()
    g = g.sort_values(SHARPE, ascending=False, kind="mergesort")
    g["r_sharpe"] = np.arange(1, len(g) + 1)
    return g


def first_place_percentages(ranked: pd.DataFrame) -> Dict[str, float]:
    """% de carteiras em que cada estratégia ocupa a 1ª posição no Sharpe."""
    key_col = PORTFOLIO_KEY if PORTFOLIO_KEY in ranked.columns else "Base"
    n_portfolios = int(ranked[key_col].nunique())
    out: Dict[str, float] = {s: float("nan") for s in STRATEGY_COLUMNS}
    if n_portfolios == 0:
        return out

    winners = ranked.loc[ranked["r_sharpe"] == 1, [key_col, "Strategy"]].drop_duplicates(
        subset=[key_col], keep="first"
    )
    counts = winners["Strategy"].value_counts()
    for strategy in STRATEGY_COLUMNS:
        if strategy in counts.index:
            out[strategy] = round(float(counts[strategy]) / n_portfolios * 100.0, 2)
        elif strategy in set(ranked["Strategy"]):
            out[strategy] = 0.0
    return out


def rebuild_n(
    df: pd.DataFrame,
    *,
    n: int,
    max_carteiras: Optional[int] = DEFAULT_MAX_CARTEIRAS,
) -> Dict[str, object]:
    subset = df[df["Total_papeis"] == n].copy()
    if subset.empty:
        raise RuntimeError(f"Sem dados para N={n}")

    subset = add_portfolio_key(subset)
    subset = subset.drop_duplicates(subset=[PORTFOLIO_KEY, "Strategy"], keep="first")

    keep_keys = select_portfolio_keys(
        subset[PORTFOLIO_KEY].tolist(),
        max_carteiras=max_carteiras,
    )
    if not keep_keys:
        raise RuntimeError(f"Sem carteiras distintas para N={n}")
    subset = subset[subset[PORTFOLIO_KEY].isin(keep_keys)].copy()

    ranked_parts = [
        rank_one_portfolio(group) for _, group in subset.groupby(PORTFOLIO_KEY, sort=False)
    ]
    ranked = pd.concat(ranked_parts, ignore_index=True)
    pcts = first_place_percentages(ranked)
    return {
        **pcts,
        "n_portfolios": int(ranked[PORTFOLIO_KEY].nunique()),
    }


def format_pct(value: object) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    return f"{float(value):.2f}"


def empty_row(ativos: int, periodo: str) -> Dict[str, object]:
    row: Dict[str, object] = {
        "ativos": ativos,
        "periodo": periodo,
        "Periodo_label": PERIOD_DISPLAY.get(periodo, periodo.replace("_", "-")),
        "n_portfolios": 0,
    }
    for s in STRATEGY_COLUMNS:
        row[s] = float("nan")
    return row


def build_table_grid(
    results: Dict[Tuple[int, str], Dict[str, object]],
    *,
    ativos: Sequence[int],
    periodos: Sequence[str],
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    for periodo in periodos:
        for n in ativos:
            key = (n, periodo)
            if key in results:
                row = dict(results[key])
                row["ativos"] = n
                row["periodo"] = periodo
                row["Periodo_label"] = PERIOD_DISPLAY.get(
                    periodo, periodo.replace("_", "-")
                )
                rows.append(row)
            else:
                rows.append(empty_row(n, periodo))

    table = pd.DataFrame(rows)
    if table.empty:
        return table

    table["_period_start"] = (
        table["periodo"].astype(str).str.split("_", n=1).str[0].astype(int)
    )
    table = table.sort_values(
        ["_period_start", "ativos"],
        kind="mergesort",
    ).reset_index(drop=True)
    return table.drop(columns=["_period_start"])


def _display_table(table: pd.DataFrame) -> pd.DataFrame:
    data: Dict[str, object] = {
        "Período": table["Periodo_label"],
        "Ativos por carteira": table["ativos"].astype(int),
    }
    for s in STRATEGY_COLUMNS:
        data[s] = table[s]
    return pd.DataFrame(data)


def write_excel(table: pd.DataFrame, path: Path, *, title: str) -> None:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, Side
        from openpyxl.utils import get_column_letter
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "openpyxl é necessário para gravar Excel. Instale com: pip install openpyxl"
        ) from exc

    display = _display_table(table)
    n_strat = len(STRATEGY_COLUMNS)
    ncol = 2 + n_strat  # Período + Ativos + estratégias

    wb = Workbook()
    ws = wb.active
    ws.title = "Pct 1a Sharpe"

    thin = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    last_col = get_column_letter(ncol)

    ws.merge_cells(f"A1:{last_col}1")
    title_cell = ws["A1"]
    title_cell.value = title
    title_cell.font = Font(bold=True, size=12)
    title_cell.alignment = center

    # Cabeçalho em 2 linhas (como na figura anexa)
    ws.merge_cells("A2:A3")
    ws["A2"] = "Período"
    ws.merge_cells("B2:B3")
    ws["B2"] = "Ativos por carteira"
    ws.merge_cells(start_row=2, start_column=3, end_row=2, end_column=ncol)
    ws.cell(row=2, column=3, value="Estratégias")

    for i, strat in enumerate(STRATEGY_COLUMNS):
        ws.cell(row=3, column=3 + i, value=strat)

    for col in range(1, ncol + 1):
        for row in (2, 3):
            c = ws.cell(row=row, column=col)
            c.font = Font(bold=True)
            c.alignment = center
            c.border = thin

    start_row = 4
    for i, rec in enumerate(display.itertuples(index=False)):
        r = start_row + i
        ws.cell(row=r, column=1, value=rec[0]).alignment = center
        ws.cell(row=r, column=2, value=int(rec[1])).alignment = center
        for j in range(n_strat):
            value = rec[2 + j]
            cell = ws.cell(
                row=r,
                column=3 + j,
                value=None if value != value else float(value),
            )
            cell.alignment = center
            if isinstance(value, (int, float)) and value == value:
                cell.number_format = "0.00"
        for col in range(1, ncol + 1):
            ws.cell(row=r, column=col).border = thin

    for periodo in display["Período"].unique():
        idxs = [i for i, v in enumerate(display["Período"]) if v == periodo]
        if len(idxs) >= 2:
            r0 = start_row + idxs[0]
            r1 = start_row + idxs[-1]
            ws.merge_cells(start_row=r0, start_column=1, end_row=r1, end_column=1)
            ws.cell(row=r0, column=1).alignment = Alignment(
                horizontal="center", vertical="center"
            )

    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 18
    for i in range(n_strat):
        ws.column_dimensions[get_column_letter(3 + i)].width = 10

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def write_latex(table: pd.DataFrame, path: Path, *, title: str, label: str) -> None:
    """Gera tabular larga cabendo em \\linewidth (adjustbox + fonte reduzida)."""
    display = _display_table(table)
    n_strat = len(STRATEGY_COLUMNS)
    col_spec = "@{}cc" + "c" * n_strat + "@{}"
    # Cabeçalhos compostos em duas linhas (só os mais longos).
    strat_header_map = {
        "BS-C": r"\shortstack{BS\\C}",
        "EW-MIN": r"\shortstack{EW\\MIN}",
        "G-MIN-C": r"\shortstack{G-MIN\\C}",
        "MIN-C": r"\shortstack{MIN\\C}",
        "MV-C": r"\shortstack{MV\\C}",
        "MV-MIN": r"\shortstack{MV\\MIN}",
    }
    strat_headers = " & ".join(
        strat_header_map.get(name, name) for name in STRATEGY_COLUMNS
    )
    ativos_header = r"\shortstack{Ativos por\\carteira}"

    lines: List[str] = [
        "% Gerado por mestrado_tabela_pct_primeira_sharpe_vwn.py",
        "% Requer: \\usepackage{booktabs}, \\usepackage{multirow}, \\usepackage{adjustbox}",
        "\\begin{table}[htbp]",
        "\\centering",
        f"\\caption{{{title}}}",
        f"\\label{{{label}}}",
        "\\scriptsize",
        "\\setlength{\\tabcolsep}{2.5pt}",
        "\\begin{adjustbox}{max width=\\linewidth, center}",
        f"\\begin{{tabular}}{{{col_spec}}}",
        "\\toprule",
        f" &  & \\multicolumn{{{n_strat}}}{{c}}{{Estratégias}} \\\\",
        f"\\cmidrule(lr){{3-{2 + n_strat}}}",
        f"Período & {ativos_header} & {strat_headers} \\\\",
        "\\midrule",
    ]

    period_order = list(dict.fromkeys(display["Período"]))
    for periodo in period_order:
        block = display[display["Período"] == periodo]
        n_rows = len(block)
        for j, rec in enumerate(block.itertuples(index=False)):
            periodo_cell = (
                f"\\multirow{{{n_rows}}}{{*}}{{{rec[0]}}}" if j == 0 else ""
            )
            pct_cells = " & ".join(format_pct(rec[2 + k]) for k in range(n_strat))
            lines.append(
                f"{periodo_cell} & {int(rec[1])} & {pct_cells} \\\\"
            )
        lines.append("\\midrule")

    if lines[-1] == "\\midrule":
        lines[-1] = "\\bottomrule"
    else:
        lines.append("\\bottomrule")

    lines.extend(
        [
            "\\end{tabular}",
            "\\end{adjustbox}",
            DEFAULT_TAB_FONTE,
            "\\end{table}",
            "",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def main(argv: Optional[Sequence[str]] = None) -> Path:
    args = parse_args(argv)
    jobs = resolve_collection_jobs(
        collection_names=args.collection_name,
        periodos=args.periodos,
        collection_template=args.collection_template,
    )
    period_order = [p for p, _ in jobs]
    if args.collection_name is None:
        period_order = list(args.periodos)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=15000)
    results: Dict[Tuple[int, str], Dict[str, object]] = {}
    loaded_periodos: List[str] = []

    try:
        for periodo, collection in jobs:
            exists = collection in client[args.db_name].list_collection_names()
            if not exists:
                msg = f"Collection ausente: {args.db_name}.{collection}"
                if args.allow_missing:
                    if not args.quiet:
                        print(f"SKIP {msg} (células vazias na tabela)", flush=True)
                    continue
                raise RuntimeError(msg)

            if not args.quiet:
                print(
                    f"\n=== {periodo} | {args.db_name}.{collection} ===",
                    flush=True,
                )

            df = load_collection(
                client,
                db_name=args.db_name,
                collection=collection,
                exclude_oracle=args.exclude_oracle,
            )
            loaded_periodos.append(periodo)
            available_n = sorted(df["Total_papeis"].unique())
            if not args.quiet:
                print(
                    f"N disponíveis={available_n} | docs={len(df)} | "
                    f"estratégias={sorted(df['Strategy'].unique())}",
                    flush=True,
                )

            for n in args.ativos:
                if n not in available_n:
                    if not args.quiet:
                        print(f"  SKIP N={n}: ausente na collection", flush=True)
                    continue
                try:
                    stats = rebuild_n(
                        df,
                        n=n,
                        max_carteiras=args.max_carteiras,
                    )
                except RuntimeError as exc:
                    print(f"  SKIP N={n}: {exc}", flush=True)
                    continue

                results[(n, periodo)] = stats
                if not args.quiet:
                    lim = (
                        f" (cap {args.max_carteiras})"
                        if args.max_carteiras and args.max_carteiras > 0
                        else ""
                    )
                    top = sorted(
                        ((s, stats[s]) for s in STRATEGY_COLUMNS if stats[s] == stats[s]),
                        key=lambda x: float(x[1]),
                        reverse=True,
                    )[:3]
                    top_txt = ", ".join(f"{s}={format_pct(v)}%" for s, v in top)
                    print(
                        f"  N={n} ({stats['n_portfolios']} carteiras{lim}): {top_txt}",
                        flush=True,
                    )
    finally:
        client.close()

    if not results:
        raise RuntimeError(
            "Nenhum ranking gerado. Verifique se B3_RESULTS_*_vwN existem em "
            f"{args.db_name} e contêm Total_papeis solicitados."
        )

    table = build_table_grid(
        results,
        ativos=args.ativos,
        periodos=period_order if period_order else list(DEFAULT_PERIODOS),
    )

    stem = args.stem
    csv_path = args.output_dir / f"{stem}.csv"
    xlsx_path = args.output_dir / f"{stem}.xlsx"
    tex_path = args.output_dir / f"{stem}.tex"

    display = _display_table(table)
    export = display.copy()
    export["periodo"] = table["periodo"].values
    export["N carteiras"] = table["n_portfolios"].values
    export.to_csv(csv_path, index=False)
    write_excel(table, xlsx_path, title=TITLE)
    write_latex(
        table,
        tex_path,
        title=LATEX_TITLE,
        label="tab:pct_primeira_sharpe_vwn",
    )

    if not args.quiet:
        print(f"\nPeríodos carregados: {loaded_periodos}", flush=True)
        print(f"CSV:   {csv_path}", flush=True)
        print(f"Excel: {xlsx_path}", flush=True)
        print(f"LaTeX: {tex_path}", flush=True)
        print("\n=== % 1ª posição Sharpe (células vazias = sem dados) ===", flush=True)
        print(display.to_string(index=False), flush=True)

    return xlsx_path


if __name__ == "__main__":
    main()
