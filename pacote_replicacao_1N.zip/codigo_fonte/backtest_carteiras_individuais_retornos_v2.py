"""Backtest de carteiras individuais com retornos (v2).

Convertido a partir do notebook:
    Backtest_CarteirasIndividuais_Retornos_v2.ipynb

Estratégia Equal Weight com rebalanceamento anual em julho, custo de transação
e persistência de resultados no MongoDB.
"""

import argparse
import io
import re
from contextlib import redirect_stdout
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import bt
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from bson import ObjectId
from pymongo import MongoClient, UpdateOne
from pymongo.collection import Collection

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_PRICES_PATH = REPO_ROOT / "ibov" / "prices_adjust_close_B3_economatica_1986-out_2025.csv"
DEFAULT_RF_PATH = REPO_ROOT / "nefin_RF.csv"
DEFAULT_COLLECTIONS_SUFFIX = "20atv_2006_2025"
DEFAULT_IR_RATE = 0.15
DEFAULT_IR_MONTHLY_SALES_EXEMPTION = 20_000.0


@dataclass
class MongoCollections:
    """Nomes de bancos/collections usados na leitura de carteiras e gravação de resultados."""

    db_name: str = "Backtest_Mestrado_PF"
    col_res: str = f"res_{DEFAULT_COLLECTIONS_SUFFIX}"
    metrics_collection: str = f"aux_metrics_{DEFAULT_COLLECTIONS_SUFFIX}"
    series_gross_return: str = f"ret_acum_pct_{DEFAULT_COLLECTIONS_SUFFIX}"
    series_excess_return: str = f"ret_excess_acum_pct_{DEFAULT_COLLECTIONS_SUFFIX}"
    carteiras_db: str = "DGU_2009"
    carteiras_collection: str = "B3_RESULTS_2006_2025"

    @classmethod
    def from_suffix(
        cls,
        suffix: str,
        *,
        db_name: str = "Backtest_Mestrado_PF",
        carteiras_db: str = "DGU_2009",
        carteiras_collection: str = "B3_RESULTS_2006_2025",
    ) -> "MongoCollections":
        return cls(
            db_name=db_name,
            col_res=f"res_{suffix}",
            metrics_collection=f"aux_metrics_{suffix}",
            series_gross_return=f"ret_acum_pct_{suffix}",
            series_excess_return=f"ret_excess_acum_pct_{suffix}",
            carteiras_db=carteiras_db,
            carteiras_collection=carteiras_collection,
        )


@dataclass
class BacktestRunConfig:
    mongo_uri: str
    tcost: float
    start_y: int
    start_m: int
    end_date: str
    capital: float
    prices_path: Path
    rf_path: Path
    collections: MongoCollections = field(default_factory=MongoCollections)
    total_papeis: int = 20
    apply_stock_ir: bool = False
    ir_rate: float = DEFAULT_IR_RATE
    ir_monthly_sales_exemption: float = DEFAULT_IR_MONTHLY_SALES_EXEMPTION


SETUP_SUBSTEPS = (
    "Carregar preços",
    "Carregar taxa livre de risco (RF)",
    "Carregar carteiras do MongoDB",
    "Conectar ao MongoDB",
    "Verificar estratégias já processadas",
)

PORTFOLIO_SUBSTEPS = (
    "Executar backtest EW",
    "Salvar res.display no MongoDB",
    "Salvar métricas auxiliares",
    "Salvar série de retorno acumulado",
    "Salvar série de retorno em excesso",
)


class BatchRunProgress:
    """Indicador de progresso global e por etapa/sub-etapa."""

    def __init__(self, setup_steps: int, portfolios_to_run: int, substeps_per_portfolio: int):
        self.setup_steps = setup_steps
        self.portfolios_to_run = portfolios_to_run
        self.substeps_per_portfolio = substeps_per_portfolio
        self.total_units = setup_steps + portfolios_to_run * substeps_per_portfolio
        self.done_units = 0
        self.phase = "Preparação"

    def _print(self, stage_label: str, stage_current: int, stage_total: int, detail: str = "") -> None:
        overall_pct = 100.0 * self.done_units / self.total_units if self.total_units else 100.0
        stage_pct = 100.0 * stage_current / stage_total if stage_total else 100.0
        line = (
            f"[GERAL {overall_pct:5.1f}%] "
            f"Fase: {self.phase} | "
            f"Etapa: {stage_label} ({stage_current}/{stage_total}, {stage_pct:5.1f}% da etapa)"
        )
        if detail:
            line += f" — {detail}"
        print(line, flush=True)

    def tick_setup(self, step_index: int, detail: str = "") -> None:
        self.phase = "Preparação"
        self.done_units += 1
        label = SETUP_SUBSTEPS[step_index - 1] if 0 < step_index <= len(SETUP_SUBSTEPS) else "Preparação"
        self._print(label, step_index, self.setup_steps, detail)

    def tick_portfolio(self, portfolio_index: int, substep_index: int, detail: str = "") -> None:
        self.phase = "Processamento de carteiras"
        self.done_units += 1
        label = (
            PORTFOLIO_SUBSTEPS[substep_index - 1]
            if 0 < substep_index <= len(PORTFOLIO_SUBSTEPS)
            else "Processamento"
        )
        stage_label = f"Carteira {portfolio_index}/{self.portfolios_to_run} · {label}"
        self._print(stage_label, substep_index, self.substeps_per_portfolio, detail)

    def finish(self, processed: int, skipped: int) -> None:
        self.done_units = self.total_units
        print(
            f"[GERAL 100.0%] Concluído — processadas: {processed}, ignoradas (já existentes): {skipped}",
            flush=True,
        )

    def set_portfolio_workload(self, portfolios_to_run: int) -> None:
        self.portfolios_to_run = portfolios_to_run
        self.total_units = self.setup_steps + portfolios_to_run * self.substeps_per_portfolio


def _build_pending_portfolios(df_cb_10: pd.DataFrame, existing: set) -> List[pd.Series]:
    pending: List[pd.Series] = []
    for _index, row in df_cb_10.iterrows():
        strat_name = "-".join(str(row["Carteira"]).split(","))
        if strat_name not in existing:
            pending.append(row)
    return pending


def _smooth_abs_quantity(q: float, smooth_abs_eps: float = 1e-10) -> float:
    abs_smooth = (q * q + smooth_abs_eps) ** 0.5 - (smooth_abs_eps ** 0.5)
    return max(0.0, abs_smooth)


def compute_stock_ir_on_rebalances(
    tx: pd.DataFrame,
    rebalance_dates: List[pd.Timestamp],
    *,
    ir_rate: float = DEFAULT_IR_RATE,
    monthly_sales_exemption: float = DEFAULT_IR_MONTHLY_SALES_EXEMPTION,
) -> pd.Series:
    """
    IR sobre ganho de capital em vendas (PF, mercado à vista) nos rebalanceamentos.

    Regra simplificada (B3 / pessoa física):
    - Preço médio por ativo, atualizado a cada compra.
    - Lucro do dia = soma((preço_venda - PM) * quantidade_vendida) por ativo.
    - Isenção mensal: se volume de vendas no mês <= monthly_sales_exemption, IR = 0.
    - Caso contrário: IR = ir_rate * max(0, lucro_líquido das vendas no rebalanceamento).
    """
    if tx is None or getattr(tx, "empty", True):
        return pd.Series(dtype=float)

    rebalance_set = {pd.Timestamp(d).normalize() for d in rebalance_dates}
    tx = tx.sort_index()

    if not isinstance(tx.index, pd.MultiIndex) or tx.index.nlevels < 2:
        return pd.Series(dtype=float)

    cost_basis: Dict[str, Dict[str, float]] = {}
    ir_by_date: Dict[pd.Timestamp, float] = {}

    dates = pd.to_datetime(tx.index.get_level_values(0)).unique()
    tx_dates_norm = pd.to_datetime(tx.index.get_level_values(0)).normalize()
    for dt in sorted(dates):
        dt_ts = pd.Timestamp(dt).normalize()
        day_tx = tx.loc[tx_dates_norm == dt_ts]

        if isinstance(day_tx, pd.Series):
            day_tx = day_tx.to_frame().T

        month_sales = 0.0
        day_net_gain = 0.0

        day_rows: List[tuple] = []
        for ticker, row in day_tx.iterrows():
            if isinstance(ticker, tuple):
                ticker = ticker[-1]
            q = float(row.get("quantity", row.iloc[1] if len(row) > 1 else 0.0))
            p = float(row.get("price", row.iloc[0] if len(row) > 0 else 0.0))
            if q == 0.0 or not np.isfinite(q) or not np.isfinite(p):
                continue
            day_rows.append((str(ticker), q, p))

        # Compras antes de vendas no mesmo pregão (preço médio correto).
        day_rows.sort(key=lambda item: (0 if item[1] > 0 else 1, item[0]))

        for ticker, q, p in day_rows:
            pos = cost_basis.get(ticker, {"qty": 0.0, "avg": 0.0})

            if q > 0:
                new_qty = pos["qty"] + q
                if new_qty > 0:
                    pos["avg"] = (pos["qty"] * pos["avg"] + q * p) / new_qty
                    pos["qty"] = new_qty
                    cost_basis[ticker] = pos
            else:
                sold = abs(q)
                avg = pos["avg"] if pos["qty"] > 0 else p
                month_sales += sold * p
                day_net_gain += (p - avg) * sold
                pos["qty"] = max(0.0, pos["qty"] - sold)
                if pos["qty"] > 0:
                    cost_basis[ticker] = pos
                else:
                    cost_basis[ticker] = {"qty": 0.0, "avg": 0.0}

        if dt_ts not in rebalance_set:
            continue

        if month_sales <= float(monthly_sales_exemption):
            ir = 0.0
        else:
            ir = float(ir_rate) * max(0.0, day_net_gain)

        if ir > 0:
            ir_by_date[pd.Timestamp(dt)] = ir

    return pd.Series(ir_by_date, dtype=float)


def adjust_nav_for_ir_payments(
    nav: pd.Series,
    ir_payments: pd.Series,
    initial_capital: float,
) -> pd.Series:
    """
    Converte pagamentos de IR (R$) para unidades do NAV do bt e deduz cumulativamente.

    O bt reporta NAV em unidades proporcionais ao capital (ex.: 100 para capital 10_000),
    enquanto o IR é apurado em reais a partir de preço * quantidade.
    """
    if ir_payments is None or len(ir_payments) == 0:
        return nav

    nav0 = float(nav.iloc[0])
    cap = float(initial_capital)
    if nav0 == 0.0 or cap == 0.0:
        raise ValueError("NAV inicial ou capital inválido para converter IR.")

    brl_to_nav = nav0 / cap
    ir_nav = ir_payments.astype(float) * brl_to_nav
    ir_aligned = ir_nav.reindex(nav.index, fill_value=0.0)
    return nav - ir_aligned.cumsum()


def _recompute_return_metrics(
    nav: pd.Series,
    rf: Optional[pd.Series],
    ann_factor: int,
) -> Dict[str, Any]:
    rets = nav.pct_change().dropna()
    drawdown = nav / nav.cummax() - 1.0
    retorno_acum_pct = (nav / nav.iloc[0] - 1.0) * 100.0

    excess = None
    retorno_excesso_acum_pct = None
    sharpe_excess = None
    vol_excess_ann = None
    total_excess_return = None

    if rf is not None:
        excess = (rets - rf.reindex(rets.index)).dropna()

    if excess is not None and len(excess) > 0:
        aligned_idx = excess.index
        rets_for_excess = rets.reindex(aligned_idx)
        rf_for_excess = rf.reindex(aligned_idx)
        growth_ratio = (
            (1.0 + rets_for_excess) / (1.0 + rf_for_excess)
        ).replace([np.inf, -np.inf], np.nan).dropna()

        if len(growth_ratio) > 0:
            retorno_excesso_acum_pct = (growth_ratio.cumprod() - 1.0) * 100.0
            total_excess_return = growth_ratio.prod() - 1.0

        if len(excess) > 1:
            vol_excess_ann = excess.std(ddof=1) * np.sqrt(ann_factor)
            sharpe_excess = (
                (excess.mean() * ann_factor) / vol_excess_ann
                if vol_excess_ann and vol_excess_ann > 0
                else np.nan
            )

    ceq_base = excess if (excess is not None and len(excess) > 1) else rets
    ceq_gamma1_daily = np.nan
    ceq_gamma1_ann = np.nan
    if ceq_base is not None and len(ceq_base) > 1:
        mu = float(ceq_base.mean())
        var = float(ceq_base.var(ddof=1))
        ceq_gamma1_daily = mu - 0.5 * var
        ceq_gamma1_ann = ceq_gamma1_daily * float(ann_factor)

    total_return = nav.iloc[-1] / nav.iloc[0] - 1.0
    years = (nav.index[-1] - nav.index[0]).days / 365.25
    cagr = (1 + total_return) ** (1 / years) - 1 if years > 0 else np.nan

    return {
        "nav": nav,
        "returns": rets,
        "excess_returns": excess,
        "drawdown": drawdown,
        "retorno_acumulado_pct": retorno_acum_pct,
        "retorno_excesso_acumulado_pct": retorno_excesso_acum_pct,
        "sharpe_excess": sharpe_excess,
        "vol_excess_ann": vol_excess_ann,
        "cagr": cagr,
        "total_return": total_return,
        "total_excess_return": total_excess_return,
        "ceq_gamma1_daily": ceq_gamma1_daily,
        "ceq_gamma1_ann": ceq_gamma1_ann,
        "ceq_base": "excess_returns" if (excess is not None and len(excess) > 1) else "returns",
    }


def run_bt_backtest_ew_july(
    df_prices: pd.DataFrame,
    tickers: list,
    tcost: float,
    start_y: int,
    start_m: int,
    end_date_str: str,
    initial_capital: float,
    strat_name: str = "EW_July_Annual_Rebalance_TCost",
    rf_df: pd.DataFrame = None,
    rf_date_col: str = "DATE",
    rf_col: str = "RF",
    rf_align_fill: str = "ffill",  # "ffill", "bfill" ou None
    ann_factor: int = 252,
    integer_positions: bool = False,
    smooth_abs_eps: float = 1e-10,
    apply_stock_ir: bool = False,
    ir_rate: float = DEFAULT_IR_RATE,
    ir_monthly_sales_exemption: float = DEFAULT_IR_MONTHLY_SALES_EXEMPTION,
):
    def _safe_get_transactions_from_strategy(strategy):
        prc = pd.DataFrame({x.name: x.prices for x in strategy.securities}).unstack()

        positions = pd.DataFrame()
        for x in strategy.securities:
            if x.name in positions.columns:
                positions[x.name] = positions[x.name].add(x.positions, fill_value=0.0)
            else:
                positions[x.name] = x.positions

        trades = positions.diff()
        if len(trades) > 0:
            trades.iloc[0, :] = positions.iloc[0, :]  # atribuição única, sem chained assignment

        trades = trades.where(trades != 0).unstack().dropna()

        if getattr(strategy, "_bidoffer_set", False):
            bidoffer = pd.DataFrame({x.name: x.bidoffers_paid for x in strategy.securities}).unstack()
            prc = prc.add(bidoffer.div(trades), fill_value=0.0)

        tx = pd.DataFrame({"price": prc, "quantity": trades}).dropna(subset=["quantity"])
        tx.index.names = ["Security", "Date"]
        return tx.swaplevel().sort_index()
    if "Date" not in df_prices.columns:
        raise ValueError("df_prices precisa ter a coluna 'Date'.")

    px = df_prices.copy()
    px["Date"] = pd.to_datetime(px["Date"])
    px = px.sort_values("Date").set_index("Date")

    missing = [c for c in tickers if c not in px.columns]
    if missing:
        raise ValueError(f"Colunas ausentes no df_prices: {missing}")

    prices = (
        px[tickers]
        .apply(pd.to_numeric, errors="coerce")
        .sort_index()
        .ffill()
    )

    end_target = pd.to_datetime(end_date_str)
    prices = prices.loc[:end_target]

    start_month = prices[(prices.index.year == start_y) & (prices.index.month == start_m)]
    if start_month.empty:
        raise ValueError(f"Não encontrei datas de pregão em {start_m:02d}/{start_y} no df_prices.")
    start_target = start_month.index.min()

    prices = prices.loc[start_target:].ffill().dropna(how="any")
    if prices.empty:
        raise ValueError("Após limpar NaNs, não sobrou período válido com preços para todos os tickers.")

    rebalance_dates = []
    for y in range(prices.index.min().year, prices.index.max().year + 1):
        d = prices[(prices.index.year == y) & (prices.index.month == 7)].index
        if len(d) > 0:
            rebalance_dates.append(d.min())

    rebalance_dates = sorted([d for d in rebalance_dates if prices.index.min() <= d <= prices.index.max()])
    if len(rebalance_dates) == 0:
        raise ValueError("Não foi possível montar datas de rebalanceamento (julho) no período efetivo.")

    def commissions(q, p):
        qf = float(q)
        pf = float(p)
        return _smooth_abs_quantity(qf, smooth_abs_eps) * pf * float(tcost)

    strategy = bt.Strategy(
        strat_name,
        [
            bt.algos.RunOnDate(*rebalance_dates),
            bt.algos.SelectThese(tickers),
            bt.algos.WeighEqually(),
            bt.algos.Rebalance(),
        ],
    )

    test = bt.Backtest(
        strategy,
        prices,
        initial_capital=float(initial_capital),
        commissions=commissions,
        integer_positions=bool(integer_positions),
    )
    test.name = str(strat_name)

    res = bt.run(test)

    try:
        tx = _safe_get_transactions_from_strategy(res.backtests[test.name].strategy)
    except Exception:
        tx = None

    nav = res.prices[test.name].dropna()
    nav_gross = nav.copy()
    total_return_gross = nav_gross.iloc[-1] / nav_gross.iloc[0] - 1.0
    ir_payments = pd.Series(dtype=float)
    if apply_stock_ir:
        ir_payments = compute_stock_ir_on_rebalances(
            tx,
            rebalance_dates,
            ir_rate=ir_rate,
            monthly_sales_exemption=ir_monthly_sales_exemption,
        )
        nav = adjust_nav_for_ir_payments(
            nav,
            ir_payments,
            initial_capital=float(initial_capital),
        )

    rf = None
    if rf_df is not None:
        rf_local = rf_df.copy()

        if rf_date_col not in rf_local.columns:
            for cand in ["Date", "date", "DATA", "data"]:
                if cand in rf_local.columns:
                    rf_date_col = cand
                    break
        if rf_col not in rf_local.columns:
            for cand in ["Rf", "rf", "RISKFREE", "risk_free", "Selic", "SELIC"]:
                if cand in rf_local.columns:
                    rf_col = cand
                    break

        if rf_date_col not in rf_local.columns or rf_col not in rf_local.columns:
            raise ValueError(f"RF DF precisa ter colunas de data e RF. Colunas encontradas: {list(rf_local.columns)}")

        rf_local[rf_date_col] = pd.to_datetime(rf_local[rf_date_col])
        rf_local = rf_local.sort_values(rf_date_col).set_index(rf_date_col)
        rf = pd.to_numeric(rf_local[rf_col], errors="coerce").sort_index()
        rf = rf.reindex(nav.index)
        if rf_align_fill == "ffill":
            rf = rf.ffill().bfill()
        elif rf_align_fill == "bfill":
            rf = rf.bfill().ffill()

    metrics = _recompute_return_metrics(nav, rf, ann_factor)
    rets = metrics["returns"]
    excess = metrics["excess_returns"]
    drawdown = metrics["drawdown"]
    retorno_acum_pct = metrics["retorno_acumulado_pct"]
    retorno_excesso_acum_pct = metrics["retorno_excesso_acumulado_pct"]
    sharpe_excess = metrics["sharpe_excess"]
    vol_excess_ann = metrics["vol_excess_ann"]
    total_excess_return = metrics["total_excess_return"]
    ceq_gamma1_daily = metrics["ceq_gamma1_daily"]
    ceq_gamma1_ann = metrics["ceq_gamma1_ann"]
    cagr = metrics["cagr"]
    total_return = metrics["total_return"]
    total_ir_paid = float(ir_payments.sum()) if len(ir_payments) else 0.0

    turnover_series = pd.Series(0.0, index=nav.index)

    if tx is not None and hasattr(tx, "empty") and (not tx.empty):
        try:
            if isinstance(tx.index, pd.MultiIndex):
                dts = pd.to_datetime(tx.index.get_level_values(0))
            else:
                dts = pd.to_datetime(tx.index)

            if isinstance(tx.columns, pd.MultiIndex):
                lvl_last = tx.columns.get_level_values(-1)
                if "value" in set(lvl_last):
                    traded_line = tx.xs("value", level=-1, axis=1).abs().sum(axis=1)
                elif ("quantity" in set(lvl_last)) and ("price" in set(lvl_last)):
                    q = tx.xs("quantity", level=-1, axis=1).fillna(0.0)
                    p = tx.xs("price", level=-1, axis=1).fillna(0.0)
                    traded_line = (q.abs() * p).sum(axis=1)
                else:
                    traded_line = tx.select_dtypes(include=[np.number]).abs().sum(axis=1)
            else:
                if ("quantity" in tx.columns) and ("price" in tx.columns):
                    traded_line = tx["quantity"].abs() * tx["price"]
                elif "value" in tx.columns:
                    traded_line = tx["value"].abs()
                else:
                    traded_line = tx.select_dtypes(include=[np.number]).abs().sum(axis=1)

            traded_line = pd.Series(traded_line.values, index=dts).replace([np.inf, -np.inf], np.nan).dropna()
            if not traded_line.empty:
                traded_value_by_day = traded_line.groupby(traded_line.index).sum()

                nav_on_trade_days = nav.reindex(traded_value_by_day.index)
                turnover_trade_days = (traded_value_by_day / nav_on_trade_days).replace([np.inf, -np.inf], np.nan)

                turnover_series = turnover_trade_days.reindex(nav.index).fillna(0.0)

        except Exception:
            turnover_series = pd.Series(0.0, index=nav.index)

    avg_turnover_all_days = float(turnover_series.mean()) if len(turnover_series) else np.nan
    avg_turnover_trade_days = float(turnover_series[turnover_series > 0].mean()) if (turnover_series > 0).any() else 0.0

    aux = {
        "prices": prices,
        "rebalance_dates": rebalance_dates,
        "nav": nav,
        "returns": rets,
        "rf": rf,
        "excess_returns": excess,
        "drawdown": drawdown,
        "retorno_acumulado_pct": retorno_acum_pct,
        "retorno_excesso_acumulado_pct": retorno_excesso_acum_pct,
        "sharpe_excess": sharpe_excess,
        "vol_excess_ann": vol_excess_ann,
        "cagr": cagr,
        "total_return": total_return,
        "total_return_gross": float(total_return_gross),
        "total_excess_return": total_excess_return,
        "ceq_gamma1_daily": ceq_gamma1_daily,
        "ceq_gamma1_ann": ceq_gamma1_ann,
        "ceq_base": metrics["ceq_base"],
        "turnover": turnover_series,
        "avg_turnover": avg_turnover_all_days,
        "avg_turnover_trade_days": avg_turnover_trade_days,
        "n_trade_days": int((turnover_series > 0).sum()),
        "bt_test_name": test.name,
        "apply_stock_ir": bool(apply_stock_ir),
        "ir_rate": float(ir_rate) if apply_stock_ir else None,
        "ir_monthly_sales_exemption": float(ir_monthly_sales_exemption) if apply_stock_ir else None,
        "total_ir_paid": total_ir_paid,
    }
    return res, aux


def run_bt_backtest_ew_buyhold(
    df_prices: pd.DataFrame,
    tickers: list,
    tcost: float,
    start_y: int,
    start_m: int,
    end_date_str: str,
    initial_capital: float,
    strat_name: str = "EW_BuyHold_TCost",
    rf_df: pd.DataFrame = None,
    rf_date_col: str = "DATE",
    rf_col: str = "RF",
    rf_align_fill: str = "ffill",  # "ffill", "bfill" ou None
    ann_factor: int = 252,
    integer_positions: bool = False,
    smooth_abs_eps: float = 1e-10,
    ignore_initial_trade_for_turnover: bool = True,  # <- útil p/ BOVA11 sem “rebalance”
):
    """
    Versão SEM rebalanceamento: compra 1x (EW) no início e segura (buy-and-hold).
    - Sem datas de rebalance (julho).
    - Turnover tende a ocorrer só no 1º dia (alocação inicial).
      Se ignore_initial_trade_for_turnover=True, turnover médio fica 0 (compatível com benchmark "sem rebalance").
    """
    if "Date" not in df_prices.columns:
        raise ValueError("df_prices precisa ter a coluna 'Date'.")

    px = df_prices.copy()
    px["Date"] = pd.to_datetime(px["Date"])
    px = px.sort_values("Date").set_index("Date")

    missing = [c for c in tickers if c not in px.columns]
    if missing:
        raise ValueError(f"Colunas ausentes no df_prices: {missing}")

    prices = (
        px[tickers]
        .apply(pd.to_numeric, errors="coerce")
        .sort_index()
        .ffill()
    )

    end_target = pd.to_datetime(end_date_str)
    prices = prices.loc[:end_target]

    start_month = prices[(prices.index.year == start_y) & (prices.index.month == start_m)]
    if start_month.empty:
        raise ValueError(f"Não encontrei datas de pregão em {start_m:02d}/{start_y} no df_prices.")
    start_target = start_month.index.min()

    prices = prices.loc[start_target:].ffill().dropna(how="any")
    if prices.empty:
        raise ValueError("Após limpar NaNs, não sobrou período válido com preços para todos os tickers.")

    def commissions(q, p):
        qf = float(q)
        pf = float(p)
        return _smooth_abs_quantity(qf, smooth_abs_eps) * pf * float(tcost)

    # ✅ Estratégia buy-and-hold (executa 1x e não rebalanceia depois)
    strategy = bt.Strategy(
        strat_name,
        [
            bt.algos.RunOnce(),
            bt.algos.SelectThese(tickers),
            bt.algos.WeighEqually(),
            bt.algos.Rebalance(),  # somente na 1ª execução (RunOnce)
        ],
    )

    test = bt.Backtest(
        strategy,
        prices,
        initial_capital=float(initial_capital),
        commissions=commissions,
        integer_positions=bool(integer_positions),
    )
    test.name = str(strat_name)

    res = bt.run(test)

    nav = res.prices[test.name].dropna()
    rets = nav.pct_change().dropna()

    # ---------------- RF / excesso ----------------
    rf = None
    excess = None
    if rf_df is not None:
        rf_local = rf_df.copy()

        if rf_date_col not in rf_local.columns:
            for cand in ["Date", "date", "DATA", "data"]:
                if cand in rf_local.columns:
                    rf_date_col = cand
                    break
        if rf_col not in rf_local.columns:
            for cand in ["Rf", "rf", "RISKFREE", "risk_free", "Selic", "SELIC"]:
                if cand in rf_local.columns:
                    rf_col = cand
                    break

        if rf_date_col not in rf_local.columns or rf_col not in rf_local.columns:
            raise ValueError(f"RF DF precisa ter colunas de data e RF. Colunas encontradas: {list(rf_local.columns)}")

        rf_local[rf_date_col] = pd.to_datetime(rf_local[rf_date_col])
        rf_local = rf_local.sort_values(rf_date_col).set_index(rf_date_col)
        rf = pd.to_numeric(rf_local[rf_col], errors="coerce").sort_index()

        rf = rf.reindex(rets.index)
        if rf_align_fill == "ffill":
            rf = rf.ffill().bfill()
        elif rf_align_fill == "bfill":
            rf = rf.bfill().ffill()
        elif rf_align_fill is None:
            pass

        excess = (rets - rf).dropna()

    # ---------------- métricas ----------------
    drawdown = nav / nav.cummax() - 1.0
    retorno_acum_pct = (nav / nav.iloc[0] - 1.0) * 100.0

    retorno_excesso_acum_pct = None
    sharpe_excess = None
    vol_excess_ann = None
    total_excess_return = None

    if excess is not None and len(excess) > 0:
        # Excesso por período (t): correto para Sharpe/CEQ
        #   excess_t = r_p,t - rf_t
        #
        # Acumulado relativo ao RF: usar razão de crescimentos,
        # e não compor diretamente (1 + excess_t).
        #   wealth_excess_t = cumprod((1 + r_p,t) / (1 + rf_t)) - 1
        aligned_idx = excess.index
        rets_for_excess = rets.reindex(aligned_idx)
        rf_for_excess = rf.reindex(aligned_idx)

        growth_ratio = ((1.0 + rets_for_excess) / (1.0 + rf_for_excess)).replace([np.inf, -np.inf], np.nan).dropna()

        if len(growth_ratio) > 0:
            retorno_excesso_acum_pct = (growth_ratio.cumprod() - 1.0) * 100.0
            total_excess_return = growth_ratio.prod() - 1.0

        if len(excess) > 1:
            vol_excess_ann = excess.std(ddof=1) * np.sqrt(ann_factor)
            sharpe_excess = (excess.mean() * ann_factor) / vol_excess_ann if vol_excess_ann and vol_excess_ann > 0 else np.nan

    ceq_base = excess if (excess is not None and len(excess) > 1) else rets
    ceq_gamma1_daily = np.nan
    ceq_gamma1_ann = np.nan
    if ceq_base is not None and len(ceq_base) > 1:
        mu = float(ceq_base.mean())
        var = float(ceq_base.var(ddof=1))
        ceq_gamma1_daily = mu - 0.5 * var
        ceq_gamma1_ann = ceq_gamma1_daily * float(ann_factor)

    # ---------------- turnover ----------------
    turnover_series = pd.Series(0.0, index=nav.index)

    try:
        tx = res.get_transactions()
    except Exception:
        tx = None

    if tx is not None and hasattr(tx, "empty") and (not tx.empty):
        try:
            if isinstance(tx.index, pd.MultiIndex):
                dts = pd.to_datetime(tx.index.get_level_values(0))
            else:
                dts = pd.to_datetime(tx.index)

            if isinstance(tx.columns, pd.MultiIndex):
                lvl_last = tx.columns.get_level_values(-1)
                if "value" in set(lvl_last):
                    traded_line = tx.xs("value", level=-1, axis=1).abs().sum(axis=1)
                elif ("quantity" in set(lvl_last)) and ("price" in set(lvl_last)):
                    q = tx.xs("quantity", level=-1, axis=1).fillna(0.0)
                    p = tx.xs("price", level=-1, axis=1).fillna(0.0)
                    traded_line = (q.abs() * p).sum(axis=1)
                else:
                    traded_line = tx.select_dtypes(include=[np.number]).abs().sum(axis=1)
            else:
                if ("quantity" in tx.columns) and ("price" in tx.columns):
                    traded_line = tx["quantity"].abs() * tx["price"]
                elif "value" in tx.columns:
                    traded_line = tx["value"].abs()
                else:
                    traded_line = tx.select_dtypes(include=[np.number]).abs().sum(axis=1)

            traded_line = pd.Series(traded_line.values, index=dts).replace([np.inf, -np.inf], np.nan).dropna()
            if not traded_line.empty:
                traded_value_by_day = traded_line.groupby(traded_line.index).sum()
                nav_on_trade_days = nav.reindex(traded_value_by_day.index)
                turnover_trade_days = (traded_value_by_day / nav_on_trade_days).replace([np.inf, -np.inf], np.nan)

                turnover_series = turnover_trade_days.reindex(nav.index).fillna(0.0)

                # opcional: “zerar” o turnover do 1º dia (alocação inicial)
                if ignore_initial_trade_for_turnover:
                    first_td = traded_value_by_day.index.min()
                    if first_td in turnover_series.index:
                        turnover_series.loc[first_td] = 0.0

        except Exception:
            turnover_series = pd.Series(0.0, index=nav.index)

    avg_turnover_all_days = float(turnover_series.mean()) if len(turnover_series) else np.nan
    avg_turnover_trade_days = float(turnover_series[turnover_series > 0].mean()) if (turnover_series > 0).any() else 0.0

    total_return = nav.iloc[-1] / nav.iloc[0] - 1.0
    years = (nav.index[-1] - nav.index[0]).days / 365.25
    cagr = (1 + total_return) ** (1 / years) - 1 if years > 0 else np.nan

    aux = {
        "prices": prices,
        "invest_date": start_target,
        "nav": nav,
        "returns": rets,
        "rf": rf,
        "excess_returns": excess,
        "drawdown": drawdown,
        "retorno_acumulado_pct": retorno_acum_pct,
        "retorno_excesso_acumulado_pct": retorno_excesso_acum_pct,
        "sharpe_excess": sharpe_excess,
        "vol_excess_ann": vol_excess_ann,
        "cagr": cagr,
        "total_return": total_return,
        "total_excess_return": total_excess_return,
        "ceq_gamma1_daily": ceq_gamma1_daily,
        "ceq_gamma1_ann": ceq_gamma1_ann,
        "ceq_base": "excess_returns" if (excess is not None and len(excess) > 1) else "returns",
        "turnover": turnover_series,
        "avg_turnover": avg_turnover_all_days,
        "avg_turnover_trade_days": avg_turnover_trade_days,
        "n_trade_days": int((turnover_series > 0).sum()),
        "bt_test_name": test.name,
        "ignore_initial_trade_for_turnover": bool(ignore_initial_trade_for_turnover),
    }
    return res, aux


def report_and_plot_backtest(res, aux, title_prefix: str = "Carteira EW (com custo e rebalance em julho)"):
    """
    Imprime o resumo (res.display + métricas do aux) e plota:
      - Retorno acumulado (%)
      - Retorno relativo acumulado ao RF (%) (se existir)
      - Drawdown
    """
    # ---- prints ----
    print(res.display())
    if "cagr" in aux and "total_return" in aux and aux["cagr"] is not None and aux["total_return"] is not None:
        print(f"CAGR: {aux['cagr']*100:.2f}% | Retorno total: {aux['total_return']*100:.2f}%")
    if aux.get("sharpe_excess") is not None:
        print(f"Sharpe (excesso, RF do CSV): {aux['sharpe_excess']:.3f}")

    # ---- Retorno acumulado (%) ----
    if aux.get("retorno_acumulado_pct") is not None:
        plt.figure(figsize=(10,4))
        plt.plot(aux["retorno_acumulado_pct"].index, aux["retorno_acumulado_pct"].values)
        plt.title(f"Retorno acumulado (%) - {title_prefix}")
        plt.xlabel("Data")
        plt.ylabel("Retorno acumulado (%)")
        plt.show()

    # ---- Retorno relativo acumulado ao RF (%) ----
    if aux.get("retorno_excesso_acumulado_pct") is not None:
        plt.figure(figsize=(10,4))
        plt.plot(aux["retorno_excesso_acumulado_pct"].index, aux["retorno_excesso_acumulado_pct"].values)
        plt.title("Retorno relativo acumulado ao RF (%) - razão entre crescimento da carteira e do RF")
        plt.xlabel("Data")
        plt.ylabel("Retorno relativo acumulado ao RF (%)")
        plt.show()

    # ---- Drawdown ----
    if aux.get("drawdown") is not None:
        plt.figure(figsize=(10,3))
        plt.plot(aux["drawdown"].index, aux["drawdown"].values)
        plt.title("Drawdown")
        plt.xlabel("Data")
        plt.ylabel("Drawdown")
        plt.show()


def _to_py(x):
    """Converte tipos numpy/pandas para tipos serializáveis em BSON."""
    if x is None:
        return None
    if isinstance(x, (np.floating, np.float32, np.float64)): return float(x)
    if isinstance(x, (np.integer, np.int32, np.int64)): return int(x)
    if isinstance(x, (np.bool_,)): return bool(x)
    if isinstance(x, (pd.Timestamp,)): return x.to_pydatetime()
    if isinstance(x, (pd.Timedelta, np.timedelta64)): return str(x)
    if isinstance(x, (dict, list, str, int, float, bool)): return x
    return str(x)

def _parse_display_value(v: str):
    """Tenta converter o valor do display (string) para tipos úteis, sem perder o texto original."""
    if v is None:
        return {"text": None, "value": None, "unit": None}

    txt = str(v).strip()

    # datas YYYY-MM-DD
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", txt):
        try:
            dt = pd.to_datetime(txt).to_pydatetime()
            return {"text": txt, "value": dt, "unit": "date"}
        except Exception:
            pass

    # percentuais
    if txt.endswith("%"):
        try:
            num = float(txt.replace("%", "").replace(",", "").strip())
            return {"text": txt, "value": num, "unit": "pct"}  # em pontos percentuais (ex.: 25.6)
        except Exception:
            return {"text": txt, "value": None, "unit": "pct"}

    # números (comuns)
    try:
        num = float(txt.replace(",", "").strip())
        return {"text": txt, "value": num, "unit": "num"}
    except Exception:
        return {"text": txt, "value": None, "unit": None}

def _extract_res_display_docs(res, base_name: str) -> List[Dict[str, Any]]:
    """
    Extrai SOMENTE os dados agregados que aparecem no res.display().
    Tenta primeiro via res.stats (DataFrame). Se não existir, captura o stdout do res.display() e faz parse.
    Retorna 1 doc por estratégia.
    """
    # ---- caminho 1: res.stats em DataFrame (mais robusto p/ múltiplas estratégias) ----
    stats_df = None
    if hasattr(res, "stats"):
        st = res.stats
        if callable(st):
            try:
                st = st()
            except Exception:
                st = None
        if isinstance(st, pd.DataFrame):
            stats_df = st

    if isinstance(stats_df, pd.DataFrame) and stats_df.shape[0] > 0:
        docs = []
        for strat in stats_df.columns:
            doc = {
                "base_name": base_name,
                "type": "res_display",
                "strategy": str(strat),
                "generated_at_utc": datetime.now(timezone.utc),
            }
            seen = {}
            for metric, val in stats_df[strat].items():
                m = str(metric).strip()
                # evita colisão se houver métricas repetidas
                seen[m] = seen.get(m, 0) + 1
                key = m if seen[m] == 1 else f"{m}__{seen[m]}"
                doc[key] = _to_py(val)
            docs.append(doc)
        return docs

    # ---- caminho 2: captura do texto do res.display() (para versões que só imprimem) ----
    buf = io.StringIO()
    with redirect_stdout(buf):
        _ = res.display()
    text = buf.getvalue().splitlines()

    # acha header: "Stat  <strat1>  <strat2> ..."
    header_idx = None
    header_cols = None
    for i, line in enumerate(text):
        parts = re.split(r"\s{2,}", line.strip())
        if len(parts) >= 2 and parts[0].lower() == "stat":
            header_idx = i
            header_cols = parts
            break
    if header_idx is None or header_cols is None:
        raise ValueError("Não consegui identificar o cabeçalho do res.display() para fazer o parse.")

    strategies = [str(x).strip() for x in header_cols[1:] if str(x).strip() != ""]
    if len(strategies) == 0:
        raise ValueError("Não consegui identificar o(s) nome(s) de estratégia(s) no res.display().")

    # inicializa docs por estratégia
    docs_by_strat = {}
    for s in strategies:
        docs_by_strat[s] = {
            "base_name": base_name,
            "type": "res_display",
            "strategy": s,
            "generated_at_utc": datetime.now(timezone.utc),
        }
    seen_metric = {s: {} for s in strategies}

    # parse linhas após o header
    for line in text[header_idx + 1:]:
        if not line.strip():
            continue
        # ignora linhas de separação
        if set(line.strip()) <= set("-"):
            continue

        parts = re.split(r"\s{2,}", line.strip())
        if len(parts) < 2:
            continue

        metric = parts[0].strip()
        values = parts[1:]

        # se a linha for de seção (sem valores para colunas), ignora
        if metric.lower() in ("stat",):
            continue

        # mapeia valores para estratégias (pode haver menos valores que estratégias)
        for j, s in enumerate(strategies):
            v = values[j].strip() if j < len(values) else None

            # trata duplicidade de métrica (ex.: "Daily Sharpe" aparece duas vezes)
            seen_metric[s][metric] = seen_metric[s].get(metric, 0) + 1
            key = metric if seen_metric[s][metric] == 1 else f"{metric}__{seen_metric[s][metric]}"

            parsed = _parse_display_value(v)
            # guarda tanto a versão numérica (quando possível) quanto o texto do display
            docs_by_strat[s][key] = _to_py(parsed["value"]) if parsed["value"] is not None else None
            docs_by_strat[s][f"{key}__text"] = parsed["text"]
            docs_by_strat[s][f"{key}__unit"] = parsed["unit"]

    return list(docs_by_strat.values())

def save_res_display_only_to_mongo(
    mongo_uri: str,
    base_name: str,
    res,
    db_name: str = "Backtest_Mestrado_PF",
    col_res: str = "res_2001_2026",
):
    """
    Salva SOMENTE os dados agregados do res.display() na collection col_res.

    Regra: NÃO permite inserir se já existir qualquer documento com o mesmo base_name.
    - Se já existir: não grava nada e apenas imprime uma mensagem (sem erro).
    - Se não existir: insere 1 doc por estratégia.
    """
    client = MongoClient(mongo_uri)
    db = client[db_name]
    c = db[col_res]

    # Se já existe qualquer doc com esse base_name, não faz nada
    already = c.find_one({"base_name": base_name}, {"_id": 1})
    if already is not None:
        client.close()
        msg = f"[SKIP] Já existe base_name='{base_name}' na collection '{db_name}.{col_res}'. Nada foi gravado."
        print(msg)
        return {
            "status": "skipped",
            "message": msg,
            "db": db_name,
            "collection": col_res,
            "base_name": base_name,
            "docs_upserted": 0,
            "strategies": [],
        }

    # Extrai docs e grava (upsert continua ok, mas aqui será 1ª inserção)
    docs = _extract_res_display_docs(res, base_name)

    ops = []
    for d in docs:
        ops.append(
            UpdateOne(
                {"base_name": d["base_name"], "type": d["type"], "strategy": d["strategy"]},
                {"$set": d},
                upsert=True,
            )
        )

    if ops:
        c.bulk_write(ops, ordered=False)

    client.close()
    return {
        "status": "inserted",
        "db": db_name,
        "collection": col_res,
        "base_name": base_name,
        "docs_upserted": len(ops),
        "strategies": [d["strategy"] for d in docs],
    }


def load_carteira_base_df_total10(
    mongo_uri: str,
    db_name: str = "DGU_2009",
    collection_name: str = "B3_RESULTS_2001_2025",
    total_papeis_value: int = 10,
    carteira_field: str = "Carteira",
    base_field: str = "Base",
    total_papeis_field: str = "Total_papeis",
    drop_csv_suffix: bool = True,
    unique_only: bool = True,
):
    """
    Lê do MongoDB os campos Carteira e Base (removendo '.csv') filtrando Total_papeis=10
    e devolve um DataFrame.

    Ajuste: usa DISTINCT no campo `Carteira` e busca um documento representativo por carteira.
    - Se `unique_only=True`, retorna 1 linha por carteira (ainda mantendo Base e Total_papeis).
    - Se você tiver mais de uma Base para a mesma Carteira, este método mantém a primeira Base encontrada.
    """

    client = MongoClient(mongo_uri)
    col = client[db_name][collection_name]

    query_base = {total_papeis_field: total_papeis_value}

    rows = []

    try:
        # 1) lista as carteiras distintas para o filtro dado
        carteiras = col.distinct(carteira_field, filter=query_base)

        # 2) para cada carteira, pega um doc representativo (Base/Total_papeis)
        proj = {"_id": 0, carteira_field: 1, base_field: 1, total_papeis_field: 1}

        for carteira in carteiras:
            doc = col.find_one(
                {**query_base, carteira_field: carteira},
                proj
            )
            if not doc:
                continue

            base = doc.get(base_field)

            if drop_csv_suffix and isinstance(base, str) and base.lower().endswith(".csv"):
                base = base[:-4]

            rows.append({
                "Carteira": doc.get(carteira_field),
                "Base": base,
                "Total_papeis": doc.get(total_papeis_field),
            })

    finally:
        client.close()

    df = pd.DataFrame(rows)

    if unique_only and not df.empty:
        # aqui já deve estar único por Carteira, mas garantimos
        df = df.drop_duplicates(subset=["Carteira"]).reset_index(drop=True)

    return df


# ---------------------------
# 1) Collection "métricas" (sem séries)
# ---------------------------

AUX_KEYS_METRICS = [
    "rebalance_dates",
    "sharpe_excess",
    "vol_excess_ann",
    "cagr",
    "total_return",
    "ceq_gamma1_daily",
    "ceq_gamma1_ann",
    "ceq_base",
    "avg_turnover",
    "avg_turnover_trade_days",
    "n_trade_days",
    "bt_test_name",
    "total_excess_return",
    "total_return_gross",
    "apply_stock_ir",
    "ir_rate",
    "ir_monthly_sales_exemption",
    "total_ir_paid",
]

def _to_jsonable_scalar(x: Any):
    """Serializa escalares/listas (não Series) para Mongo-friendly."""
    if x is None:
        return None

    # numpy scalars -> python
    if isinstance(x, (np.floating, np.integer, np.bool_)):
        x = x.item()

    # timestamps
    if isinstance(x, pd.Timestamp):
        return x.isoformat()

    # Index / DatetimeIndex
    if isinstance(x, pd.Index):
        if isinstance(x, pd.DatetimeIndex):
            return [d.isoformat() for d in x.to_pydatetime()]
        return x.tolist()

    # list/tuple
    if isinstance(x, (list, tuple)):
        out = []
        for v in x:
            if isinstance(v, pd.Timestamp):
                out.append(v.isoformat())
            else:
                out.append(_to_jsonable_scalar(v))
        return out

    # floats: nan/inf -> None
    if isinstance(x, float):
        return None if (not np.isfinite(x)) else float(x)

    if isinstance(x, (int, bool, str)):
        return x

    if isinstance(x, dict):
        return {str(k): _to_jsonable_scalar(v) for k, v in x.items()}

    return str(x)

def upsert_aux_metrics(
    mongo_uri: str,
    db_name: str,
    metrics_collection: str,
    aux: Dict[str, Any],
    strategy: str,
    extra_fields: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Upsert (1 doc por strategy) com métricas escalares/listas.
    NÃO salva drawdown/turnover e NÃO salva as séries de retorno acumulado aqui.
    """
    doc = {"strategy": str(strategy)}

    for k in AUX_KEYS_METRICS:
        doc[k] = _to_jsonable_scalar(aux.get(k, None))

    if extra_fields:
        doc.update({str(kk): _to_jsonable_scalar(vv) for kk, vv in extra_fields.items()})

    client = MongoClient(mongo_uri)
    try:
        col = client[db_name][metrics_collection]
        r = col.update_one({"strategy": str(strategy)}, {"$set": doc}, upsert=True)
        # retorna id do doc (se upsert ocorreu)
        return str(r.upserted_id) if r.upserted_id is not None else str(strategy)
    finally:
        client.close()


# ---------------------------
# 2) Collections "séries" (1 doc por data) para retorno_acumulado_pct e retorno_excesso_acumulado_pct
# ---------------------------

def _series_to_long_docs(
    s: pd.Series,
    strategy: str,
    date_field: str = "date",
    value_field: str = "value",
) -> List[dict]:
    """Converte uma Series (index datas) em lista de docs long: {strategy, date, value}."""
    if s is None:
        return []

    s = pd.Series(s).copy()
    # tenta garantir datetime index
    try:
        s.index = pd.to_datetime(s.index)
    except Exception:
        pass

    s = s.replace([np.inf, -np.inf], np.nan).dropna()
    if s.empty:
        return []

    docs = []
    for dt, val in s.items():
        # dt pode ser Timestamp ou algo parseável
        if isinstance(dt, pd.Timestamp):
            dt_iso = dt.isoformat()
        else:
            try:
                dt_iso = pd.to_datetime(dt).isoformat()
            except Exception:
                dt_iso = str(dt)

        v = float(val)
        if not np.isfinite(v):
            continue

        docs.append(
            {
                "strategy": str(strategy),
                date_field: dt_iso,
                value_field: v,
            }
        )
    return docs


def save_series_in_collection(
    mongo_uri: str,
    db_name: str,
    series_collection: str,
    series: Optional[pd.Series],
    strategy: str,
    overwrite_strategy: bool = True,
    chunk_size: int = 5000,
    date_field: str = "date",
    value_field: str = "value",
    monthly_rule: str = "ME",          # "ME" (month-end) ou "MS" (month-start)
    monthly_how: str = "last",        # "last", "mean", "sum"
) -> int:
    if series is None:
        return 0

    s = pd.Series(series).copy()
    try:
        s.index = pd.to_datetime(s.index)
    except Exception:
        pass

    s = s.replace([np.inf, -np.inf], np.nan).dropna()
    if s.empty:
        return 0

    if monthly_how == "last":
        s_m = s.resample(monthly_rule).last()
    elif monthly_how == "mean":
        s_m = s.resample(monthly_rule).mean()
    elif monthly_how == "sum":
        s_m = s.resample(monthly_rule).sum()
    else:
        raise ValueError("monthly_how deve ser um de: 'last', 'mean', 'sum'")

    s_m = s_m.dropna()
    if s_m.empty:
        return 0

    docs = _series_to_long_docs(s_m, strategy=strategy, date_field=date_field, value_field=value_field)
    if not docs:
        return 0

    client = MongoClient(mongo_uri)
    try:
        col = client[db_name][series_collection]

        if overwrite_strategy:
            col.delete_many({"strategy": str(strategy)})

        inserted = 0
        for i in range(0, len(docs), chunk_size):
            batch = docs[i : i + chunk_size]
            col.insert_many(batch, ordered=False)
            inserted += len(batch)

        return inserted
    finally:
        client.close()


def bson_to_python(x):
    if isinstance(x, ObjectId):
        return str(x)
    if isinstance(x, dict):
        return {k: bson_to_python(v) for k, v in x.items()}
    if isinstance(x, list):
        return [bson_to_python(v) for v in x]
    return x

def _ensure_collection(coll_or_name, db=None):
    if isinstance(coll_or_name, Collection):
        return coll_or_name
    if isinstance(coll_or_name, str):
        if db is None:
            raise TypeError("Você passou o nome da collection (string). Informe db=... ou passe db['NOME'].")
        return db[coll_or_name]
    raise TypeError(f"Tipo inválido: {type(coll_or_name)}. Passe uma Collection do pymongo ou o nome (str).")

def load_collection_as_df(
    coll_or_name,
    db=None,
    query=None,
    projection=None,
    batch_size=2000,
    max_docs=None,
    flatten=True,
    sep="."
):
    col = _ensure_collection(coll_or_name, db=db)
    query = query or {}

    cursor = col.find(query, projection=projection, batch_size=batch_size)

    docs = []
    for i, doc in enumerate(cursor, start=1):
        docs.append(bson_to_python(doc))
        if max_docs is not None and i >= max_docs:
            break

    if not docs:
        return pd.DataFrame()

    return pd.json_normalize(docs, sep=sep) if flatten else pd.DataFrame.from_records(docs)


def parse_args(argv: Optional[List[str]] = None) -> BacktestRunConfig:
    parser = argparse.ArgumentParser(
        description="Backtest EW (rebalance julho) para carteiras individuais — v2"
    )
    parser.add_argument(
        "--mongo-uri",
        default="mongodb://172.23.224.1:27017/",
        help="URI de conexão MongoDB",
    )
    parser.add_argument("--tcost", type=float, default=0.0122, help="Custo de transação (fração)")
    parser.add_argument("--start-y", type=int, default=2006, help="Ano de início")
    parser.add_argument("--start-m", type=int, default=7, help="Mês de início")
    parser.add_argument("--end-date", default="2025-10-31", help="Data final (YYYY-MM-DD)")
    parser.add_argument("--capital", type=float, default=10_000.0, help="Capital inicial")
    parser.add_argument(
        "--prices-path",
        type=Path,
        default=DEFAULT_PRICES_PATH,
        help="CSV de preços ajustados",
    )
    parser.add_argument(
        "--rf-path",
        type=Path,
        default=DEFAULT_RF_PATH,
        help="CSV da taxa livre de risco (NEFIN)",
    )
    parser.add_argument(
        "--collections-suffix",
        default=DEFAULT_COLLECTIONS_SUFFIX,
        help=(
            "Sufixo para montar automaticamente col_res, aux_metrics, ret_acum_pct e "
            "ret_excess_acum_pct (ex.: 20atv_2006_2025)"
        ),
    )
    parser.add_argument("--db-name", default="Backtest_Mestrado_PF", help="Banco MongoDB de resultados")
    parser.add_argument(
        "--col-res",
        default=None,
        help="Collection res.display (default: res_<collections-suffix>)",
    )
    parser.add_argument(
        "--metrics-collection",
        default=None,
        help="Collection de métricas auxiliares (default: aux_metrics_<collections-suffix>)",
    )
    parser.add_argument(
        "--series-collection-gross-return",
        default=None,
        help="Collection de retorno acumulado (%%) (default: ret_acum_pct_<collections-suffix>)",
    )
    parser.add_argument(
        "--series-collection-excess-return",
        default=None,
        help=(
            "Collection de retorno excesso acumulado (%%) "
            "(default: ret_excess_acum_pct_<collections-suffix>)"
        ),
    )
    parser.add_argument("--carteiras-db", default="DGU_2009", help="Banco MongoDB de carteiras")
    parser.add_argument(
        "--carteiras-collection",
        default="B3_RESULTS_2006_2025",
        help="Collection de carteiras",
    )
    parser.add_argument(
        "--total-papeis",
        type=int,
        default=20,
        help="Filtro Total_papeis ao carregar carteiras",
    )
    parser.add_argument(
        "--apply-stock-ir",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Aplica IR sobre ganho de capital nas vendas dos rebalanceamentos (B3, PF)",
    )
    parser.add_argument(
        "--ir-rate",
        type=float,
        default=DEFAULT_IR_RATE,
        help="Alíquota de IR sobre ganho de capital (default: 0.15 = 15%%)",
    )
    parser.add_argument(
        "--ir-monthly-sales-exemption",
        type=float,
        default=DEFAULT_IR_MONTHLY_SALES_EXEMPTION,
        help="Isenção mensal por volume de vendas em R$ (default: 20000)",
    )
    args = parser.parse_args(argv)

    collections = MongoCollections.from_suffix(
        args.collections_suffix,
        db_name=args.db_name,
        carteiras_db=args.carteiras_db,
        carteiras_collection=args.carteiras_collection,
    )
    if args.col_res is not None:
        collections.col_res = args.col_res
    if args.metrics_collection is not None:
        collections.metrics_collection = args.metrics_collection
    if args.series_collection_gross_return is not None:
        collections.series_gross_return = args.series_collection_gross_return
    if args.series_collection_excess_return is not None:
        collections.series_excess_return = args.series_collection_excess_return

    return BacktestRunConfig(
        mongo_uri=args.mongo_uri,
        tcost=args.tcost,
        start_y=args.start_y,
        start_m=args.start_m,
        end_date=args.end_date,
        capital=args.capital,
        prices_path=args.prices_path,
        rf_path=args.rf_path,
        collections=collections,
        total_papeis=args.total_papeis,
        apply_stock_ir=args.apply_stock_ir,
        ir_rate=args.ir_rate,
        ir_monthly_sales_exemption=args.ir_monthly_sales_exemption,
    )


def load_prices(prices_path: Path) -> pd.DataFrame:
    df_prices = pd.read_csv(prices_path)
    try:
        df_prices = df_prices.drop(columns=["Unnamed: 0"])
    except Exception:
        pass
    return df_prices


def run_batch_backtests(config: BacktestRunConfig) -> None:
    """Executa backtests em lote e grava resultados nas collections informadas em `config.collections`."""
    if not config.mongo_uri:
        raise ValueError("Defina mongo_uri na configuração.")

    cols = config.collections
    setup_steps = len(SETUP_SUBSTEPS)
    substeps = len(PORTFOLIO_SUBSTEPS)

    progress = BatchRunProgress(setup_steps, 0, substeps)
    print("Iniciando batch de backtests...", flush=True)

    df_prices = load_prices(config.prices_path)
    progress.tick_setup(1, str(config.prices_path))

    rf_df = pd.read_csv(config.rf_path)
    progress.tick_setup(2, str(config.rf_path))

    df_cb_10 = load_carteira_base_df_total10(
        mongo_uri=config.mongo_uri,
        db_name=cols.carteiras_db,
        collection_name=cols.carteiras_collection,
        total_papeis_value=config.total_papeis,
        unique_only=True,
    )
    progress.tick_setup(3, f"{len(df_cb_10)} carteiras | {cols.carteiras_db}.{cols.carteiras_collection}")

    client = MongoClient(config.mongo_uri, serverSelectionTimeoutMS=15000)
    db = client[cols.db_name]
    col = db[cols.metrics_collection]
    n_docs = col.count_documents({})
    progress.tick_setup(4, f"{cols.db_name}.{cols.metrics_collection} ({n_docs} docs)")

    df_aux = load_collection_as_df(col)
    if df_aux.empty:
        existing = set()
    else:
        existing = set(df_aux["strategy"].astype(str).dropna().unique())

    pending = _build_pending_portfolios(df_cb_10, existing)
    skipped = len(df_cb_10) - len(pending)
    progress.tick_setup(
        5,
        f"já processadas: {len(existing)} | pendentes: {len(pending)} | ignoradas neste run: {skipped}",
    )
    progress.set_portfolio_workload(len(pending))

    if config.apply_stock_ir:
        print(
            "IR ativo nos rebalanceamentos:",
            f"alíquota={config.ir_rate:.2%},",
            f"isenção mensal vendas=R$ {config.ir_monthly_sales_exemption:,.2f}",
            flush=True,
        )
    print(
        "Collections de saída:",
        f"db={cols.db_name!r},",
        f"col_res={cols.col_res!r},",
        f"metrics={cols.metrics_collection!r},",
        f"gross={cols.series_gross_return!r},",
        f"excess={cols.series_excess_return!r}",
        flush=True,
    )

    if not pending:
        progress.finish(processed=0, skipped=skipped)
        client.close()
        return

    processed = 0
    for portfolio_index, row in enumerate(pending, start=1):
        tickers = row["Carteira"].split(",")
        strat_name = "-".join(tickers)
        base_name = row["Base"]
        detail_base = f"{base_name} | {strat_name[:80]}"

        res, aux = run_bt_backtest_ew_july(
            df_prices=df_prices,
            tickers=tickers,
            tcost=config.tcost,
            start_y=config.start_y,
            start_m=config.start_m,
            end_date_str=config.end_date,
            initial_capital=config.capital,
            rf_df=rf_df,
            rf_date_col="DATE",
            rf_col="RF",
            strat_name=strat_name,
            apply_stock_ir=config.apply_stock_ir,
            ir_rate=config.ir_rate,
            ir_monthly_sales_exemption=config.ir_monthly_sales_exemption,
        )
        progress.tick_portfolio(portfolio_index, 1, detail_base)

        info = save_res_display_only_to_mongo(
            mongo_uri=config.mongo_uri,
            base_name=base_name,
            res=res,
            db_name=cols.db_name,
            col_res=cols.col_res,
        )
        progress.tick_portfolio(portfolio_index, 2, f"{detail_base} | status={info.get('status')}")

        upsert_aux_metrics(
            mongo_uri=config.mongo_uri,
            db_name=cols.db_name,
            metrics_collection=cols.metrics_collection,
            aux=aux,
            strategy=strat_name,
            extra_fields={
                "tcost": config.tcost,
                "tickers": tickers,
                "apply_stock_ir": config.apply_stock_ir,
                "ir_rate": config.ir_rate if config.apply_stock_ir else None,
            },
        )
        progress.tick_portfolio(portfolio_index, 3, detail_base)

        n1 = save_series_in_collection(
            mongo_uri=config.mongo_uri,
            db_name=cols.db_name,
            series_collection=cols.series_gross_return,
            series=aux.get("retorno_acumulado_pct"),
            strategy=strat_name,
            overwrite_strategy=True,
            monthly_how="last",
            monthly_rule="ME",
        )
        progress.tick_portfolio(portfolio_index, 4, f"{detail_base} | pontos={n1}")

        n2 = save_series_in_collection(
            mongo_uri=config.mongo_uri,
            db_name=cols.db_name,
            series_collection=cols.series_excess_return,
            series=aux.get("retorno_excesso_acumulado_pct"),
            strategy=strat_name,
            overwrite_strategy=True,
            monthly_how="last",
            monthly_rule="ME",
        )
        progress.tick_portfolio(portfolio_index, 5, f"{detail_base} | pontos={n2}")

        processed += 1
        print(
            f"    ↳ res.display: {info.get('status')} | ret_acum={n1} | ret_excess={n2} | "
            f"IR pago={aux.get('total_ir_paid', 0):.2f}",
            flush=True,
        )

    progress.finish(processed=processed, skipped=skipped)
    client.close()


def main(config: Optional[BacktestRunConfig] = None) -> None:
    run_batch_backtests(config or parse_args())


if __name__ == "__main__":
    main()
