#!/usr/bin/env python3
"""Gera CSVs top-N (1 carteira/N) para o motor BARRA — passo 2D do plano Marcelo.

Lê ``universo_liq_1MM_{YYYYMM}.csv``, monta o prefixo ADV com 1 papel/empresa
e grava ``carteiras_{N}atv_liq_top_1MM_{YYYYMM}.csv`` (coluna Carteira, 1 linha).

Exemplo (grade completa do plano):
    python codigo_fonte/gerar_carteiras_topn_liquidez.py \\
      --formations 200106 200606 201106 \\
      --ns 8 10 12 15 20 25 30 35 40
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "codigo_fonte"))

from economatica_gerador_bases_dgu2009_v3_vwN import load_topn_from_universo  # noqa: E402

DEFAULT_UNIV_DIR = REPO_ROOT / "resultados" / "carteiras_aleatorias_liquidas"
DEFAULT_TAG = "liq_top_1MM"
DEFAULT_NS = (8, 10, 12, 15, 20, 25, 30, 35, 40)
DEFAULT_FORMATIONS = ("200106", "200606", "201106")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="CSVs top-N ADV para run_sensibilidade_barra_pf.py")
    p.add_argument(
        "--universo-dir",
        type=Path,
        default=DEFAULT_UNIV_DIR,
        help=f"Pasta com universo_liq_1MM_YYYYMM.csv (default: {DEFAULT_UNIV_DIR})",
    )
    p.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Saída (default: mesma pasta do universo)",
    )
    p.add_argument("--universo-prefix", default="universo_liq_1MM")
    p.add_argument("--tag", default=DEFAULT_TAG, help=f"Tag no nome do CSV (default: {DEFAULT_TAG})")
    p.add_argument("--formations", nargs="+", default=list(DEFAULT_FORMATIONS))
    p.add_argument("--ns", type=int, nargs="+", default=list(DEFAULT_NS))
    p.add_argument(
        "--no-dedupe-company",
        action="store_true",
        help="Não deduplicar por empresa (não recomendado)",
    )
    return p.parse_args()


def main() -> int:
    args = parse_args()
    univ_dir = args.universo_dir.resolve()
    out_dir = (args.output_dir or univ_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    n_ok = 0
    for yyyymm in args.formations:
        univ_path = univ_dir / f"{args.universo_prefix}_{yyyymm}.csv"
        if not univ_path.is_file():
            print(f"ERRO: universo ausente: {univ_path}", file=sys.stderr)
            return 1
        for n in args.ns:
            df = load_topn_from_universo(
                univ_path,
                k_assets=int(n),
                dedupe_company=not args.no_dedupe_company,
            )
            tickers = [str(df.iloc[0][c]) for c in df.columns]
            carteira = ",".join(tickers)
            out_path = out_dir / f"carteiras_{n}atv_{args.tag}_{yyyymm}.csv"
            with out_path.open("w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(["Carteira"])
                w.writerow([carteira])
            print(f"OK {out_path.name}  ({n} ativos: {carteira[:60]}{'…' if len(carteira)>60 else ''})")
            n_ok += 1

    print(f"\nConcluído: {n_ok} arquivo(s) em {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
