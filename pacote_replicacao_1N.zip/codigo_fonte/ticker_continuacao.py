"""Encadeamento de tickers B3 e detecção de deslistagem.

Dois casos distintos:

1. Conversão / troca de código (mesmo ativo econômico): a série de preços
   continua no sucessor (VALE5→VALE3, AMBV4→ABEV3, mesmo prefixo de empresa).
2. Deslistagem verdadeira (falência, OPA em dinheiro, cancelamento sem sucessor
   no painel): não há encadeamento; o motor v4 liquida no último preço e
   reinveste 1/(N−1) nos papéis ainda listados.

O mapa explícito cobre mudanças de prefixo. A heurística de mesmo prefixo
de quatro letras cobre unificação de classes (WEGE4→WEGE3, UGPA4→UGPA3).
Se o sucessor já está na carteira, não se encadeia: evita duplicar a empresa.
"""

from __future__ import annotations

import re
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import pandas as pd

OLD_SERIES_RE = re.compile(r"-OLD$", re.IGNORECASE)

# Padronização já usada na formação do universo.
TICKER_RENAME = {
    "AXIA3": "ELET3",
    "AXIA6": "ELET6",
    "EMBJ3": "EMBR3",
    "GOLL4": "GOLL54",
    "GOLL53": "GOLL54",
    "GOL": "GOLL54",
}

# Conversões com prefixo diferente (fusão societária com troca de código,
# não OPA apenas em dinheiro). Sucessor deve existir no painel de preços.
CONTINUACAO_EXPLICITA: Dict[str, str] = {
    "AMBV3": "ABEV3",
    "AMBV4": "ABEV3",
    "VIVO3": "VIVT3",
    "VIVO4": "VIVT4",
    "RAIA3": "RADL3",
    "RDCD3": "RADL3",
    "KROT3": "COGN3",
    "KROT11": "COGN3",
    "AEDU3": "COGN3",
    "FIBR3": "SUZB3",
    "SDIA4": "BRFS3",
    "DURA3": "DXCO3",
    "DURA4": "DXCO3",
    "LAME3": "BHIA3",
    "LAME4": "BHIA3",
    "ALLL3": "RAIL3",
    "ALLL11": "RAIL3",
    "TCSL3": "TIMS3",
    "TCSL4": "TIMS3",
    "UBBR3": "ITUB4",
    "UBBR4": "ITUB4",
    "UBBR11": "ITUB4",
    "BNCA3": "BBAS3",
    "CTIP3": "B3SA3",
    "TNLP3": "OIBR3",
    "TNLP4": "OIBR4",
    "BRTP3": "OIBR3",
    "BRTP4": "OIBR4",
    "VCPA4": "SUZB3",
    "ARCZ6": "SUZB3",
    "ALSC3": "ALOS3",
    "BRML3": "ALOS3",
    "IGTA3": "IGTI3",
    "HGTX3": "SOMA3",
    "CESP3": "AURE3",
    "CESP5": "AURE3",
    "CESP6": "AURE3",
    "SULA11": "RDOR3",
    "ENAT3": "BRAV3",
    "GETI3": "AESB3",
    "GETI4": "AESB3",
    "ELPL4": "ENGI11",
    "ELPL5": "ENGI11",
    "EQTL11": "EQTL3",
    "STBP11": "STBP3",
    "PCAR4": "PCAR3",
    "VIVT4": "VIVT3",
}


def company_key(ticker: str) -> str:
    match = re.match(r"^([A-Z]{4})", str(ticker).strip().upper())
    return match.group(1) if match else str(ticker).strip().upper()


def padronizar_ticker(ticker: str) -> str:
    t = str(ticker).strip().upper()
    return TICKER_RENAME.get(t, t)


def last_valid_timestamp(series: pd.Series) -> Optional[pd.Timestamp]:
    s = pd.to_numeric(series, errors="coerce").dropna()
    if s.empty:
        return None
    return pd.Timestamp(s.index.max())


def _series_continues_after(
    panel: pd.DataFrame,
    ticker: str,
    last_date: pd.Timestamp,
) -> bool:
    if ticker not in panel.columns:
        return False
    last = last_valid_timestamp(panel[ticker])
    return last is not None and last > pd.Timestamp(last_date)


def resolve_successor(
    ticker: str,
    last_date: pd.Timestamp,
    panel: pd.DataFrame,
    *,
    occupied: Optional[Iterable[str]] = None,
    sample_end: Optional[pd.Timestamp] = None,
) -> Optional[str]:
    """Devolve o ticker sucessor, ou None se a deslistagem for terminal."""
    occupied_set = {padronizar_ticker(t) for t in (occupied or [])}
    occupied_set.discard(padronizar_ticker(ticker))
    occupied_cos = {company_key(t) for t in occupied_set}
    last_date = pd.Timestamp(last_date)
    sample_end = pd.Timestamp(sample_end) if sample_end is not None else pd.Timestamp(panel.index.max())

    explicit = CONTINUACAO_EXPLICITA.get(padronizar_ticker(ticker))
    if explicit:
        explicit = padronizar_ticker(explicit)
        if (
            explicit not in occupied_set
            and company_key(explicit) not in occupied_cos
            and _series_continues_after(panel, explicit, last_date)
        ):
            return explicit

    prefix = company_key(ticker)
    ranked: List[Tuple[pd.Timestamp, str]] = []
    for col in panel.columns:
        cand = padronizar_ticker(str(col))
        if cand == padronizar_ticker(ticker) or cand in occupied_set:
            continue
        if company_key(cand) != prefix:
            continue
        if company_key(cand) in occupied_cos and cand not in occupied_set:
            continue
        last = last_valid_timestamp(panel[cand])
        if last is None or last <= last_date:
            continue
        ranked.append((last, cand))
    if not ranked:
        return None
    ranked.sort(reverse=True)
    best = ranked[0][1]
    if ranked[0][0] <= last_date:
        return None
    return best


def splice_price_series(old: pd.Series, new: pd.Series) -> pd.Series:
    """Continua `old` com os retornos de `new` após o último pregão de `old`."""
    old_s = pd.to_numeric(old, errors="coerce").dropna()
    new_s = pd.to_numeric(new, errors="coerce").dropna()
    if old_s.empty:
        return new_s.copy()
    if new_s.empty:
        return old_s.copy()
    last = old_s.index.max()
    after = new_s.loc[new_s.index > last]
    if after.empty:
        return old_s.copy()
    if last in new_s.index and float(new_s.loc[last]) != 0.0:
        factor = float(old_s.loc[last]) / float(new_s.loc[last])
        tail = after * factor
    else:
        ref = float(after.iloc[0])
        if ref == 0.0:
            return old_s.copy()
        factor = float(old_s.iloc[-1]) / ref
        tail = after * factor
    out = pd.concat([old_s, tail])
    return out[~out.index.duplicated(keep="last")].sort_index()


def build_chained_price(
    ticker: str,
    panel: pd.DataFrame,
    *,
    occupied: Optional[Sequence[str]] = None,
    max_hops: int = 5,
) -> Tuple[pd.Series, List[str], bool]:
    """Monta a série encadeada.

    Retorna (série, cadeia de tickers, True se ainda listada no fim da janela).
    """
    ticker = padronizar_ticker(ticker)
    occupied = list(occupied or [])
    chain: List[str] = [ticker]
    if ticker not in panel.columns:
        return pd.Series(dtype=float), chain, False

    series = pd.to_numeric(panel[ticker], errors="coerce")
    sample_end = pd.Timestamp(panel.index.max())
    current = ticker
    visited = {current}

    for _ in range(max_hops):
        last = last_valid_timestamp(series)
        if last is None:
            break
        # Folga de ~1 mês de pregão: ainda cotada no fim da amostra.
        if last >= sample_end - pd.Timedelta(days=31):
            return series, chain, True
        nxt = resolve_successor(
            current,
            last,
            panel,
            occupied=occupied,
            sample_end=sample_end,
        )
        if not nxt or nxt in visited or nxt not in panel.columns:
            return series, chain, False
        series = splice_price_series(series, panel[nxt])
        chain.append(nxt)
        visited.add(nxt)
        current = nxt
        occupied = [t for t in occupied if padronizar_ticker(t) != ticker] + [nxt]

    last = last_valid_timestamp(series)
    still_listed = bool(last is not None and last >= sample_end - pd.Timedelta(days=31))
    return series, chain, still_listed


def chain_portfolio_prices(
    panel: pd.DataFrame,
    tickers: Sequence[str],
    *,
    max_gap_days: int = 5,
) -> Tuple[pd.DataFrame, List[dict]]:
    """Encadeia cada ticker da carteira contra o painel completo."""
    tickers = [padronizar_ticker(t) for t in tickers]
    audit: List[dict] = []
    cols = {}
    for t in tickers:
        others = [x for x in tickers if x != t]
        series, chain, still_listed = build_chained_price(t, panel, occupied=others)
        cols[t] = series
        audit.append(
            {
                "ticker": t,
                "cadeia": chain,
                "conversao": len(chain) > 1,
                "ainda_listada": still_listed,
                "ultima_cotacao_encadeada": last_valid_timestamp(series),
            }
        )
    prices = pd.DataFrame(cols).sort_index()
    if max_gap_days and max_gap_days > 0:
        prices = prices.ffill(limit=int(max_gap_days))
    return prices, audit
