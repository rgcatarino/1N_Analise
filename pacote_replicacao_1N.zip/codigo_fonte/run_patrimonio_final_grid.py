#!/usr/bin/env python3
"""Gera a tabela de patrimônio final a partir do MongoDB (somente leitura).

Não executa backtests. Lê ``aux_metrics_*`` com ``final_wealth_brl`` e grava
``.tex`` / ``.xlsx`` / CSV via ``gerar_tabela_patrimonio_final_liq1mm``.

Exemplo::

    python codigo_fonte/run_patrimonio_final_grid.py --periodos 2001-2025
    python codigo_fonte/run_patrimonio_final_grid.py \\
        --periodos 2001-2025 --tex-name tabela_patrimonio_final_2001_2025.tex
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional, Sequence

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT / "codigo_fonte") not in sys.path:
    sys.path.insert(0, str(REPO_ROOT / "codigo_fonte"))

import gerar_tabela_patrimonio_final_liq1mm as gen  # noqa: E402


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--periodos",
        nargs="+",
        required=True,
        help="Ex.: 2001-2025 2006-2025 2011-2025",
    )
    p.add_argument("--mongo-uri", default=gen.DEFAULT_URI)
    p.add_argument("--db-name", default=gen.DEFAULT_DB)
    p.add_argument("--universo-tag", default="liq_1MM")
    p.add_argument("--capital", type=float, default=10_000.0)
    p.add_argument("--require-ir", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument(
        "--engine",
        choices=gen.ENGINE_CHOICES,
        default="v41",
        help="v41 (default, collections *_v41), v4 (legado) ou all.",
    )
    p.add_argument("--output-dir", type=Path, default=gen.DEFAULT_OUT)
    p.add_argument("--tex-dir", type=Path, default=gen.DEFAULT_TEX)
    p.add_argument(
        "--tex-name",
        default=None,
        help=(
            "Nome do arquivo .tex (com ou sem extensão). "
            "Encaminhado a gerar_tabela_patrimonio_final_liq1mm."
        ),
    )
    p.add_argument(
        "--allow-missing",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Aceita células ausentes (padrão: sim).",
    )
    p.add_argument("--min-obs", type=int, default=1)
    return p.parse_args(list(argv) if argv is not None else None)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    # Reutiliza o gerador; monta argv compatível com gerar_tabela_* .
    gen_argv = [
        "--periodos",
        *args.periodos,
        "--mongo-uri",
        args.mongo_uri,
        "--db-name",
        args.db_name,
        "--universo-tag",
        args.universo_tag,
        "--capital",
        str(args.capital),
        "--engine",
        args.engine,
        "--output-dir",
        str(args.output_dir),
        "--tex-dir",
        str(args.tex_dir),
        "--min-obs",
        str(args.min_obs),
    ]
    if args.tex_name:
        gen_argv.extend(["--tex-name", args.tex_name])
    if args.require_ir:
        gen_argv.append("--require-ir")
    else:
        gen_argv.append("--no-require-ir")
    if args.allow_missing:
        gen_argv.append("--allow-missing")

    print(
        f"[tabela] lendo Mongo db={args.db_name!r} periodos={args.periodos} "
        f"engine={args.engine}",
        flush=True,
    )
    gen.main(gen_argv)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
