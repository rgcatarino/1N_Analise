#!/usr/bin/env python3
"""Agregador local de resultados DGU 2009 (versão .py do notebook Agregador).

Lê os CSVs gerados por ``dgu_2009_general_backtests_v2_0.py`` em pastas como
``resultados/dgu_backtest/2001_2025``, faz merge de Summary + returnloss,
enriquece com metadados da base (Carteira, Total_papeis) e grava no MongoDB
e/ou em CSV agregado.

Exemplo:
    python codigo_fonte/dgu_2009_agregador_backtests.py \\
        --results-dir resultados/dgu_backtest/2001_2025

    python codigo_fonte/dgu_2009_agregador_backtests.py \\
        --results-dir resultados/dgu_backtest/2006_2025 \\
        --no-mongo \\
        --output-csv resultados/dgu_backtest/agregado_2006_2025.csv

    # VW das N (após backtest paralelo em resultados/dgu_backtest/2001_2025_vwN):
    python codigo_fonte/dgu_2009_agregador_backtests.py \\
        --results-dir resultados/dgu_backtest/2001_2025_vwN \\
        --bases-dir bases_dgu/2001_2025_vwN \\
        --collection-name B3_RESULTS_2001_2025_vwN \\
        --db-name DGU_BRASIL
"""

from __future__ import annotations

import argparse
import re
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional, Sequence

import numpy as np
import pandas as pd
from pymongo import MongoClient, ReplaceOne

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_RESULTS_DIR = REPO_ROOT / "resultados" / "dgu_backtest" / "2001_2025"
DEFAULT_BASES_DIR = REPO_ROOT / "bases_dgu"
DEFAULT_MONGO_URI = "mongodb://172.23.224.1:27017/"
DEFAULT_DB = "DGU_2009"

SUMMARY_SUFFIX = "_Summary_latest"
RETURNLOSS_SUFFIX = "_returnloss"
DGU_PREFIX = "DGU_2009_"

EXCLUDED_BASE_COLS = {"DATE", "MktRF", "RF"}


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Agrega resultados locais de backtests DGU 2009 (Summary + returnloss)."
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=DEFAULT_RESULTS_DIR,
        help=f"Pasta com os CSVs de saída do backtest (default: {DEFAULT_RESULTS_DIR})",
    )
    parser.add_argument(
        "--bases-dir",
        type=Path,
        default=None,
        help="Pasta com CSVs das bases DGU (default: bases_dgu/<periodo>/)",
    )
    parser.add_argument(
        "--periodo",
        default=None,
        help=(
            "Tag do período, ex. 2001_2025 ou 2001_2025_vwN "
            "(inferido do nome da pasta se omitido)"
        ),
    )
    parser.add_argument(
        "--collection-name",
        default=None,
        help="Collection MongoDB (default: B3_RESULTS_<periodo>)",
    )
    parser.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    parser.add_argument("--db-name", default=DEFAULT_DB)
    parser.add_argument(
        "--output-csv",
        type=Path,
        default=None,
        help="CSV agregado de saída (default: <results-dir>/agregado_<periodo>.csv)",
    )
    parser.add_argument(
        "--no-mongo",
        action="store_true",
        help="Não gravar no MongoDB; apenas exportar CSV",
    )
    parser.add_argument(
        "--error-dir",
        type=Path,
        default=None,
        help="Pasta para logs de erro por base (default: <results-dir>/erros_agregacao)",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Processar no máximo N bases (útil para teste)",
    )
    return parser.parse_args(argv)


# Aceita 2001_2025 e variantes com sufixo (2001_2025_vwN, 2001_2025_liq, …).
_PERIODO_RE = re.compile(r"^(\d{4}_\d{4})(?:_[A-Za-z0-9]+)*$")


def infer_periodo(results_dir: Path) -> str:
    name = results_dir.name
    if _PERIODO_RE.fullmatch(name):
        return name
    raise ValueError(
        f"Não foi possível inferir o período a partir de '{results_dir.name}'. "
        "Use --periodo explicitamente (ex.: 2001_2025_vwN)."
    )


def default_collection_name(periodo: str) -> str:
    return f"B3_RESULTS_{periodo}"


def _suggest_backtest_cmd(periodo: str, bases_hint: Path | None = None) -> str:
    bases = bases_hint or (DEFAULT_BASES_DIR / periodo)
    out = REPO_ROOT / "resultados" / "dgu_backtest" / periodo
    return (
        "python3 codigo_fonte/dgu_2009_general_backtests_v2_0_parallel.py \\\n"
        f"  --bases-dir {bases} \\\n"
        f"  --output-dir {out} \\\n"
        "  --workers 6 --batch-size 10 --skip-existing"
    )


def _format_missing_results_error(results_dir: Path, *, periodo: str | None) -> str:
    parent = results_dir.parent
    siblings: list[str] = []
    if parent.is_dir():
        siblings = sorted(p.name for p in parent.iterdir() if p.is_dir())[:12]
    tag = periodo or results_dir.name
    bases_guess = DEFAULT_BASES_DIR / tag
    lines = [
        f"Pasta de resultados não encontrada: {results_dir}",
        "",
        "O agregador lê CSVs do *backtest* (DGU_2009_*_Summary_latest.csv),",
        "não as bases em bases_dgu/. Gere os resultados antes, por exemplo:",
        "",
        _suggest_backtest_cmd(tag, bases_guess if bases_guess.is_dir() else None),
        "",
    ]
    if siblings:
        lines.append(f"Pastas existentes em {parent}:")
        lines.extend(f"  - {s}" for s in siblings)
    return "\n".join(lines)


def format_progress(current: int, total: int) -> str:
    if total <= 0:
        return "[  0.00% | 0/0]"
    pct = 100.0 * current / total
    return f"[{pct:6.2f}% | {current}/{total}]"


def discover_base_ids(results_dir: Path) -> list[str]:
    pattern = f"{DGU_PREFIX}*{SUMMARY_SUFFIX}.csv"
    ids: list[str] = []
    for path in sorted(results_dir.glob(pattern)):
        stem = path.stem  # DGU_2009_<base_id>_Summary_latest
        if not stem.startswith(DGU_PREFIX) or not stem.endswith(SUMMARY_SUFFIX):
            continue
        base_id = stem[len(DGU_PREFIX) : -len(SUMMARY_SUFFIX)]
        if base_id:
            ids.append(base_id)
    return ids


def _read_table(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    if path.suffix.lower() in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    raise ValueError(f"Formato não suportado: {path}")


def _resolve_file(results_dir: Path, base_id: str, suffix: str) -> Path:
    for ext in (".csv", ".xlsx", ".xls"):
        candidate = results_dir / f"{DGU_PREFIX}{base_id}{suffix}{ext}"
        if candidate.exists():
            return candidate
    raise FileNotFoundError(
        f"Arquivo não encontrado para base '{base_id}' com sufixo '{suffix}' em {results_dir}"
    )


def get_filtered_columns_info(df: pd.DataFrame) -> tuple[str, int]:
    filtered = [col for col in df.columns if col not in EXCLUDED_BASE_COLS]
    return ",".join(filtered), len(filtered)


def find_base_csv(bases_dirs: Iterable[Path], base_id: str) -> Optional[Path]:
    candidates: list[Path] = []
    for root in bases_dirs:
        if not root.exists():
            continue
        candidates.extend(
            [
                root / f"{base_id}.csv",
                root / "processadas" / f"{base_id}.csv",
            ]
        )
    for path in candidates:
        if path.is_file():
            return path
    return None


def merge_return_loss(df_sumario: pd.DataFrame, df_returnloss: pd.DataFrame) -> pd.DataFrame:
    if "strategy" not in df_returnloss.columns:
        raise KeyError("returnloss não possui coluna 'strategy'.")
    if "return_loss" not in df_returnloss.columns:
        raise KeyError("returnloss não possui coluna 'return_loss'.")
    if "Strategy" not in df_sumario.columns:
        raise KeyError("Summary não possui coluna 'Strategy'.")

    out = df_sumario.copy()
    rl = df_returnloss.copy()
    rl["_key"] = rl["strategy"].astype(str).str.strip()
    out["_key"] = out["Strategy"].astype(str).str.strip()

    rl_cols = ["_key", "return_loss"]
    if "return_loss_bps" in rl.columns:
        rl_cols.append("return_loss_bps")

    rl_map = (
        rl[rl_cols]
        .dropna(subset=["_key"])
        .drop_duplicates(subset=["_key"], keep="last")
    )
    out = out.merge(rl_map, on="_key", how="left")
    out.drop(columns=["_key"], inplace=True)

    missing = out["return_loss"].isna().sum()
    if missing:
        print(f"  Aviso: {missing} estratégia(s) sem return_loss para esta base.")

    return out


def enrich_with_base_metadata(
    df_sumario: pd.DataFrame,
    *,
    base_id: str,
    bases_dirs: Iterable[Path],
) -> pd.DataFrame:
    out = df_sumario.copy()
    base_path = find_base_csv(bases_dirs, base_id)
    if base_path is None:
        print(f"  Aviso: base CSV não encontrada para '{base_id}' — Carteira/Total_papeis omitidos.")
        out["Carteira"] = None
        out["Total_papeis"] = None
    else:
        df_base = pd.read_csv(base_path)
        carteira, total = get_filtered_columns_info(df_base)
        out["Carteira"] = carteira
        out["Total_papeis"] = total

    out["Base"] = f"{base_id}.csv"
    return out


def salvar_df_sumario_no_mongo(
    df_sumario: pd.DataFrame,
    mongo_uri: str,
    db_name: str,
    collection_name: str,
    *,
    key_fields: Sequence[str] = ("Base", "Strategy"),
    batch_size: int = 1000,
) -> dict[str, int]:
    if df_sumario.empty:
        return {"upserted": 0, "matched": 0, "modified": 0}

    df = df_sumario.copy()
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = pd.to_datetime(df[col], errors="coerce").dt.to_pydatetime()
    df = df.where(pd.notna(df), None)

    def _py(v):
        if isinstance(v, np.generic):
            return v.item()
        return v

    records = [{k: _py(v) for k, v in rec.items()} for rec in df.to_dict("records")]

    client = MongoClient(mongo_uri)
    try:
        coll = client[db_name][collection_name]
        ops = []
        for rec in records:
            filt = {k: rec.get(k) for k in key_fields}
            if any(filt[k] is None for k in key_fields):
                raise ValueError(f"Registro sem key_fields {key_fields}: {filt}")
            ops.append(ReplaceOne(filt, rec, upsert=True))

        upserted = matched = modified = 0
        total_ops = len(ops)
        for i in range(0, total_ops, batch_size):
            chunk = ops[i : i + batch_size]
            res = coll.bulk_write(chunk, ordered=False)
            upserted += res.upserted_count
            matched += res.matched_count
            modified += res.modified_count
            done = min(i + len(chunk), total_ops)
            if total_ops > batch_size:
                pct = 100.0 * done / total_ops
                print(
                    f"  MongoDB: {format_progress(done, total_ops)} "
                    f"({done} registros gravados)",
                    flush=True,
                )

        return {"upserted": upserted, "matched": matched, "modified": modified}
    finally:
        client.close()


def process_one_base(
    base_id: str,
    *,
    results_dir: Path,
    bases_dirs: Sequence[Path],
) -> pd.DataFrame:
    summary_path = _resolve_file(results_dir, base_id, SUMMARY_SUFFIX)
    returnloss_path = _resolve_file(results_dir, base_id, RETURNLOSS_SUFFIX)

    df_sumario = _read_table(summary_path)
    df_returnloss = _read_table(returnloss_path)
    df_sumario = merge_return_loss(df_sumario, df_returnloss)
    df_sumario = enrich_with_base_metadata(df_sumario, base_id=base_id, bases_dirs=bases_dirs)
    return df_sumario


def resolve_bases_dirs(periodo: str, bases_dir: Optional[Path]) -> list[Path]:
    roots: list[Path] = []
    if bases_dir is not None:
        roots.append(bases_dir)
    else:
        roots.append(DEFAULT_BASES_DIR / periodo)
    roots.append(DEFAULT_BASES_DIR)
    # deduplica preservando ordem
    seen: set[Path] = set()
    ordered: list[Path] = []
    for p in roots:
        rp = p.resolve()
        if rp not in seen:
            seen.add(rp)
            ordered.append(rp)
    return ordered


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    results_dir = args.results_dir.resolve()
    if not results_dir.is_dir():
        print(
            _format_missing_results_error(results_dir, periodo=args.periodo),
            file=sys.stderr,
        )
        return 1

    try:
        periodo = args.periodo or infer_periodo(results_dir)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    collection_name = args.collection_name or default_collection_name(periodo)
    output_csv = args.output_csv or (results_dir / f"agregado_{periodo}.csv")
    error_dir = args.error_dir or (results_dir / "erros_agregacao")
    bases_dirs = resolve_bases_dirs(periodo, args.bases_dir)

    base_ids = discover_base_ids(results_dir)
    if args.limit is not None:
        base_ids = base_ids[: args.limit]

    if not base_ids:
        print(
            f"Nenhum Summary encontrado em {results_dir}\n"
            f"(padrão: {DGU_PREFIX}*{SUMMARY_SUFFIX}.csv)\n\n"
            "Rode o backtest antes de agregar:\n"
            f"{_suggest_backtest_cmd(periodo, args.bases_dir)}",
            file=sys.stderr,
        )
        return 1

    print(f"Período:        {periodo}")
    print(f"Resultados:     {results_dir}")
    print(f"Bases:          {', '.join(str(p) for p in bases_dirs)}")
    print(f"Bases a agregar:{len(base_ids)}")
    if not args.no_mongo:
        print(f"MongoDB:        {args.mongo_uri} / {args.db_name}.{collection_name}")
    print(f"Saída CSV:      {output_csv}")
    print()

    frames: list[pd.DataFrame] = []
    errors = 0
    total_bases = len(base_ids)

    for i, base_id in enumerate(base_ids, start=1):
        print(f"{format_progress(i, total_bases)} {base_id}", flush=True)
        try:
            df = process_one_base(base_id, results_dir=results_dir, bases_dirs=bases_dirs)
            frames.append(df)
            print(f"  OK — {len(df)} estratégias", flush=True)
        except Exception as exc:
            errors += 1
            err_msg = f"{type(exc).__name__}: {exc}\n\nTRACEBACK:\n{traceback.format_exc()}"
            print(f"  ERRO: {exc}", flush=True)
            error_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            log_path = error_dir / f"ERRO_{base_id}_{ts}.txt"
            log_path.write_text(err_msg, encoding="utf-8")

    if not frames:
        print("\nNenhuma base agregada com sucesso.", file=sys.stderr)
        return 1

    df_agregado = pd.concat(frames, ignore_index=True)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    df_agregado.to_csv(output_csv, index=False)
    print(f"\nCSV agregado: {output_csv} ({len(df_agregado)} linhas)")

    if not args.no_mongo:
        print("\nGravando no MongoDB...", flush=True)
        stats = salvar_df_sumario_no_mongo(
            df_agregado,
            args.mongo_uri,
            args.db_name,
            collection_name,
        )
        print(
            f"MongoDB: upserted={stats['upserted']}, "
            f"matched={stats['matched']}, modified={stats['modified']}"
        )

    print(
        f"\nConcluído: {format_progress(len(frames), total_bases)} "
        f"{len(frames)} bases OK, {errors} erros.",
        flush=True,
    )
    return 0 if errors == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
