#!/usr/bin/env python3
"""Gera bases mensais DGU (B3) com VW das N ações (leitura B).

Fork de ``economatica_gerador_bases_dgu2009_v2.py``:

- Mantém sorteio aleatório (1 ticker/empresa) ou lê carteiras prontas
  (CSV Cap. 7 / top-N / manifest Asset_*).
- Coluna ``MktRF`` deixa de ser o fator NEFIN e passa a ser o retorno em
  excesso **value-weighted das N ações daquela carteira**, com pesos

      w_{i,t-1} = Cap_{i,t-1} / sum_j Cap_{j,t-1}

  (Cap = valor de mercado Economatica, mil R$ × 1000).
- ``RF`` continua vindo do NEFIN (DI-swap 30d).
- Formato de saída idêntico ao v2 → o backtest DGU lê ``MktRF`` como VW
  sem alteração de código.

Exemplos::

    # Aleatórias + painel de market cap (Excel largo Data + tickers)
    python3 codigo_fonte/economatica_gerador_bases_dgu2009_v3_vwN.py \\
      --prices-path ibov/prices_adjust_close_B3_economatica_1986-out_2025.csv \\
      --mktcap-path ibov/economatica_valorMercado.xlsx \\
      --rf-path nefin_RF.csv \\
      --k-assets 8 10 12 15 20 25 30 35 40 \\
      --n-portfolios 3000 --seed 15 \\
      --output-dir bases_dgu/2001_2025_vwN \\
      --deterministic-names --save-manifest \\
      --start-complete 2001-01-01 \\
      --end-complete 2025-10-31 \\
      --panel-start 2001-01-04

    # Top-N a partir do universo por liquidez
    python3 codigo_fonte/economatica_gerador_bases_dgu2009_v3_vwN.py \\
      --prices-path ibov/prices_adjust_close_B3_economatica_1986-out_2025.csv \\
      --mktcap-path ibov/economatica_valorMercado.xlsx \\
      --universo-topn-csv resultados/carteiras_aleatorias_liquidas/universo_liq_1MM_200106.csv \\
      --k-assets 8 15 20 30 40 \\
      --n-portfolios 0 \\
      --output-dir bases_dgu/topN_vwN \\
      --deterministic-names --save-manifest \\
      --start-complete 2001-01-01 --end-complete 2025-10-31 \\
      --panel-start 2001-01-04
"""
from __future__ import annotations

import argparse
import json
import sys
import uuid
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
sys.path.insert(0, str(SCRIPT_DIR))

from economatica_gerador_bases_dgu2009_v2 import (  # noqa: E402
    DEFAULT_END_COMPLETE,
    DEFAULT_PANEL_START,
    DEFAULT_PRICES_PATH,
    DEFAULT_RF_PATH,
    DEFAULT_SEED,
    DEFAULT_START_COMPLETE,
    ProgressReporter,
    build_daily_panels,
    colunas_completas_no_periodo,
    company_key,
    is_ticker_column,
    mensalizar_retorno_diario,
    resolve_excess_daily as resolve_excess_daily_v2,
    sample_random_portfolios,
    zip_bases,
)
from ticker_continuacao import padronizar_ticker  # noqa: E402

DEFAULT_MKTCAP_PATH = REPO_ROOT / "ibov" / "economatica_valorMercado.xlsx"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "bases_dgu" / "vwN"
DEFAULT_PREFIX = "B3_aleatoria_vwN"
DEFAULT_N_PORTFOLIOS = 1000
DEFAULT_K_ASSETS = (8,)


def collapse_duplicate_asset_cols(
    df: pd.DataFrame, *, date_col: str | None = "DATE"
) -> pd.DataFrame:
    """Colapsa colunas de ativo duplicadas (ex.: GOLL53→GOLL54) via média.

    Após ``padronizar_ticker``, GOLL53 e GOLL54 viram duas colunas GOLL54;
    selects pandas subsequentes multiplicam (2→4→16). Espelha o padrão de
    ``load_mktcap_panel`` / ``load_total_returns_from_prices``.
    """
    if not df.columns.duplicated().any():
        return df
    if date_col is not None and date_col in df.columns:
        date = df[[date_col]]
        assets = df.drop(columns=[date_col])
        if assets.columns.duplicated().any():
            assets = assets.T.groupby(level=0).mean().T
        return pd.concat([date, assets], axis=1)
    return df.T.groupby(level=0).mean().T


def load_rf_series(rf_path: Path) -> pd.Series:
    rf = pd.read_csv(rf_path)
    if "DATE" not in rf.columns:
        for cand in ("Date", "date", "Data"):
            if cand in rf.columns:
                rf = rf.rename(columns={cand: "DATE"})
                break
    if "DATE" not in rf.columns:
        raise ValueError(f"Coluna DATE não encontrada em {rf_path}")
    if "RF" not in rf.columns:
        raise ValueError(f"Coluna RF não encontrada em {rf_path}")
    rf["DATE"] = pd.to_datetime(rf["DATE"], errors="coerce")
    return rf.set_index("DATE")["RF"].astype(float).sort_index()


def load_mktcap_panel(
    path: Path,
    *,
    unit_multiplier: float = 1000.0,
) -> pd.DataFrame:
    """Painel largo Data/DATE + tickers. Valores Economatica em mil R$ → R$."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Painel de market cap não encontrado: {path}. "
            "Exporte Valor de Mercado (diário, largo) da Economatica para este path."
        )

    if path.suffix.lower() in {".xlsx", ".xls"}:
        raw = pd.read_excel(path, sheet_name=0, engine="openpyxl")
    else:
        raw = pd.read_csv(path, low_memory=False)

    drop = [c for c in raw.columns if str(c).startswith("Unnamed")]
    if drop:
        raw = raw.drop(columns=drop)

    date_col = next((c for c in ("Data", "DATE", "Date", "date") if c in raw.columns), None)
    if date_col is None:
        raise ValueError(f"Coluna de data não encontrada em {path} (Data/DATE).")

    raw[date_col] = pd.to_datetime(raw[date_col], errors="coerce")
    raw = raw.dropna(subset=[date_col]).sort_values(date_col).set_index(date_col)
    raw.index.name = "DATE"

    tickers = [c for c in raw.columns if is_ticker_column(str(c))]
    if not tickers:
        tickers = [c for c in raw.columns if str(c).strip()]
    if not tickers:
        raise ValueError(f"Nenhuma coluna de ticker em {path}")

    cap = raw[tickers].apply(pd.to_numeric, errors="coerce") * float(unit_multiplier)

    renamed = {c: padronizar_ticker(str(c)) for c in cap.columns}
    cap = cap.rename(columns=renamed)
    if cap.columns.duplicated().any():
        cap = cap.T.groupby(level=0).mean().T
    return cap.sort_index()


def load_total_returns_from_prices(prices_path: Path) -> pd.DataFrame:
    """Retornos totais diários (pct_change) indexados por DATE."""
    prices = pd.read_csv(prices_path, low_memory=False)
    drop = [c for c in prices.columns if str(c).startswith("Unnamed")]
    if drop:
        prices = prices.drop(columns=drop)
    date_col = next((c for c in ("Date", "DATE", "Data") if c in prices.columns), None)
    if date_col is None:
        raise ValueError(f"Coluna de data não encontrada em {prices_path}")
    prices[date_col] = pd.to_datetime(prices[date_col], errors="coerce")
    prices = prices.sort_values(date_col).set_index(date_col)
    prices.index.name = "DATE"
    tickers = [c for c in prices.columns if is_ticker_column(c)]
    px = prices[tickers].apply(pd.to_numeric, errors="coerce")
    rets = px.pct_change()
    renamed = {c: padronizar_ticker(str(c)) for c in rets.columns}
    rets = rets.rename(columns=renamed)
    if rets.columns.duplicated().any():
        rets = rets.T.groupby(level=0).mean().T
    return rets.sort_index()


def vw_excess_of_names(
    tickers: Sequence[str],
    *,
    total_rets: pd.DataFrame,
    mktcap: pd.DataFrame,
    rf: pd.Series,
    dates: pd.DatetimeIndex,
) -> pd.Series:
    """Excesso diário VW das N: R_vw = Σ w_{t-1} R_t ; MktRF = (1+R_vw)/(1+RF)-1."""
    cols = [t for t in tickers if t in total_rets.columns and t in mktcap.columns]
    if len(cols) < 1:
        return pd.Series(np.nan, index=dates, dtype=float)

    R = total_rets.reindex(index=dates, columns=cols)
    C = mktcap.reindex(index=dates, columns=cols)
    w_raw = C.shift(1)
    valid = w_raw.notna() & (w_raw > 0) & R.notna()
    w = w_raw.where(valid, 0.0)
    denom = w.sum(axis=1)
    w = w.div(denom.replace(0.0, np.nan), axis=0)
    r_vw = (w * R.where(valid)).sum(axis=1)
    r_vw = r_vw.where(denom > 0)

    rf_aligned = rf.reindex(dates).ffill()
    return ((1.0 + r_vw) / (1.0 + rf_aligned) - 1.0).astype(float)


def parse_portfolio_row(cell: str) -> list[str]:
    parts = [padronizar_ticker(x.strip()) for x in str(cell).replace(";", ",").split(",")]
    return [p for p in parts if p]


def load_portfolios_csv(path: Path, *, k_assets: int | None = None) -> pd.DataFrame:
    """Aceita Cap. 7 (coluna Carteira) ou manifest Asset_1..Asset_N."""
    df = pd.read_csv(path)
    if "Carteira" in df.columns:
        rows: list[list[str]] = []
        for cell in df["Carteira"].tolist():
            r = parse_portfolio_row(cell)
            if k_assets is None:
                rows.append(r)
            elif len(r) == int(k_assets):
                rows.append(r)
            elif len(r) > int(k_assets):
                rows.append(r[: int(k_assets)])
        if not rows:
            raise ValueError(f"Nenhuma carteira válida em {path}")
        n = max(len(r) for r in rows)
        data = [r + [None] * (n - len(r)) for r in rows]
        return pd.DataFrame(data, columns=[f"Asset_{i+1}" for i in range(n)])

    asset_cols = [c for c in df.columns if str(c).startswith("Asset_")]
    if not asset_cols:
        raise ValueError(f"{path}: esperado coluna 'Carteira' ou Asset_1..Asset_N")
    out = df[asset_cols].copy()
    for c in asset_cols:
        out[c] = out[c].map(
            lambda x: padronizar_ticker(str(x)) if pd.notna(x) and str(x).strip() else np.nan
        )
    return out


def load_topn_from_universo(
    universo_csv: Path,
    *,
    k_assets: int,
    dedupe_company: bool = True,
) -> pd.DataFrame:
    """Prefixo ADV do universo_liq_*.csv → 1 carteira top-N."""
    u = pd.read_csv(universo_csv)
    if "ticker" not in u.columns:
        raise ValueError(f"{universo_csv}: falta coluna ticker")
    if "adv_mil_reais" in u.columns:
        u = u.sort_values("adv_mil_reais", ascending=False)
    tickers: list[str] = []
    seen_co: set[str] = set()
    for _, row in u.iterrows():
        t = padronizar_ticker(str(row["ticker"]))
        if dedupe_company:
            co = t[:4]
            if co in seen_co:
                continue
            seen_co.add(co)
        if t in tickers:
            continue
        tickers.append(t)
        if len(tickers) >= k_assets:
            break
    if len(tickers) < k_assets:
        raise ValueError(
            f"Universo {universo_csv} só tem {len(tickers)} tickers após dedupe; N={k_assets}"
        )
    return pd.DataFrame([tickers], columns=[f"Asset_{i+1}" for i in range(k_assets)])


def export_portfolio_bases_vwN(
    dfs: list[pd.DataFrame],
    *,
    total_rets: pd.DataFrame,
    mktcap: pd.DataFrame,
    rf: pd.Series,
    output_dir: Path,
    prefix: str = DEFAULT_PREFIX,
    deterministic_names: bool = False,
    run_tag: str = "",
    progress: ProgressReporter | None = None,
) -> list[Path]:
    """Como v2.export_portfolio_bases, mas MktRF = VW excesso das N."""
    output_dir.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []
    n_fallback_ew = 0

    for i, carteira in enumerate(dfs, start=1):
        df_indexed = carteira.set_index("DATE").sort_index()
        df_indexed.index = pd.to_datetime(df_indexed.index, errors="coerce")
        rename_map = {
            c: padronizar_ticker(str(c))
            for c in df_indexed.columns
            if c not in {"RF", "MktRF"}
        }
        df_indexed = df_indexed.rename(columns=rename_map)
        df_indexed = collapse_duplicate_asset_cols(df_indexed, date_col=None)
        tickers = [c for c in df_indexed.columns if is_ticker_column(str(c))]

        dates = df_indexed.index
        mkt_rf = vw_excess_of_names(
            tickers,
            total_rets=total_rets,
            mktcap=mktcap,
            rf=rf,
            dates=dates,
        )
        if mkt_rf.notna().sum() == 0:
            n_fallback_ew += 1
            mkt_rf = df_indexed[tickers].apply(pd.to_numeric, errors="coerce").mean(axis=1)

        rf_aligned = rf.reindex(dates).ffill()
        df_merged = df_indexed[tickers].copy()
        df_merged["MktRF"] = mkt_rf
        df_merged["RF"] = rf_aligned

        if df_merged.dropna(how="all").empty:
            if progress is not None:
                progress.update(i)
            continue

        rets_m = mensalizar_retorno_diario(df_merged, freq="ME")
        df_out = rets_m.reset_index()
        date_col = df_out.columns[0]
        df_out = df_out.rename(columns={date_col: "DATE"})
        df_out["DATE"] = pd.to_datetime(df_out["DATE"], errors="coerce").dt.strftime("%Y%m%d")

        if deterministic_names:
            tag = f"_{run_tag}" if run_tag else ""
            out_name = f"{prefix}{tag}_{i-1:05d}.csv"
        else:
            out_name = f"{prefix}_{uuid.uuid4().hex}.csv"

        out_path = output_dir / out_name
        df_out.to_csv(out_path, index=False)
        saved.append(out_path)
        if progress is not None:
            progress.update(i)

    if progress is not None:
        progress.finish()
    if n_fallback_ew:
        print(
            f"Aviso: {n_fallback_ew} carteira(s) sem Cap válido → MktRF = EW dos excessos.",
            file=sys.stderr,
            flush=True,
        )
    return saved


def resolve_portfolios(
    args: argparse.Namespace,
    *,
    cols_ok: list[str],
    k_assets: int,
) -> pd.DataFrame:
    if args.universo_topn_csv is not None:
        return load_topn_from_universo(
            args.universo_topn_csv,
            k_assets=k_assets,
            dedupe_company=not args.no_dedupe_company,
        )

    if args.portfolios_csv is not None:
        df = load_portfolios_csv(args.portfolios_csv, k_assets=k_assets)
        if args.n_portfolios and args.n_portfolios > 0:
            df = df.iloc[: int(args.n_portfolios)].copy()
        return df

    n_port = (
        int(args.n_portfolios)
        if args.n_portfolios and args.n_portfolios > 0
        else DEFAULT_N_PORTFOLIOS
    )
    _, df_ports = sample_random_portfolios(
        cols_ok, n_portfolios=n_port, k_assets=k_assets, seed=int(args.seed)
    )
    return df_ports


def run_generation_vwN(
    *,
    df_b3_daily: pd.DataFrame,
    total_rets: pd.DataFrame,
    mktcap: pd.DataFrame,
    rf: pd.Series,
    output_dir: Path,
    k_assets: int,
    args: argparse.Namespace,
    global_offset: int = 0,
    global_total: int = 0,
) -> dict:
    cols_ok = colunas_completas_no_periodo(
        df_b3_daily,
        date_col="DATE",
        start=args.start_complete,
        end=args.end_complete,
        drop_all_nan_dates=True,
    )
    n_companies = len({company_key(t) for t in cols_ok})
    print(
        f"Universo completo ({args.start_complete} → {args.end_complete}): "
        f"{len(cols_ok)} tickers / {n_companies} empresas"
    )
    # Sorteio aleatório exige 1 ticker/empresa → o teto é n_empresas, não n_tickers.
    if args.portfolios_csv is None and args.universo_topn_csv is None:
        if n_companies < k_assets:
            reason = (
                f"empresas insuficientes para sorteio 1/empresa: "
                f"{n_companies} < {k_assets}"
            )
            print(
                f"Aviso: pulando N={k_assets} — {reason} "
                f"(tickers={len(cols_ok)}, empresas={n_companies}).",
                file=sys.stderr,
                flush=True,
            )
            return {
                "k_assets": k_assets,
                "n_portfolios_requested": 0,
                "n_portfolios_exported": 0,
                "n_universe": len(cols_ok),
                "n_companies": n_companies,
                "skipped": True,
                "skip_reason": reason,
                "vw_mode": "N_assets_mktcap",
                "manifest": None,
                "output_dir": str(output_dir),
                "sample_files": [],
            }

    try:
        df_portfolios = resolve_portfolios(args, cols_ok=cols_ok, k_assets=k_assets)
    except ValueError as exc:
        print(
            f"Aviso: pulando N={k_assets} — {exc} "
            f"(tickers={len(cols_ok)}, empresas={n_companies}).",
            file=sys.stderr,
            flush=True,
        )
        return {
            "k_assets": k_assets,
            "n_portfolios_requested": 0,
            "n_portfolios_exported": 0,
            "n_universe": len(cols_ok),
            "n_companies": n_companies,
            "skipped": True,
            "skip_reason": str(exc),
            "vw_mode": "N_assets_mktcap",
            "manifest": None,
            "output_dir": str(output_dir),
            "sample_files": [],
        }

    n_portfolios = len(df_portfolios)
    print(f"Carteiras a exportar (N={k_assets}): {n_portfolios}")

    panel_prog = ProgressReporter(f"N={k_assets} painéis diários", n_portfolios)
    dfs = build_daily_panels(
        df_b3_daily, df_portfolios, args.panel_start, progress=panel_prog
    )

    run_tag = f"N{k_assets}_s{args.seed}"
    export_prog = ProgressReporter(
        f"N={k_assets} exportando CSV (VW-N)",
        n_portfolios,
        global_current_fn=lambda c: global_offset + c,
        global_total=global_total,
    )
    saved = export_portfolio_bases_vwN(
        dfs,
        total_rets=total_rets,
        mktcap=mktcap,
        rf=rf,
        output_dir=output_dir,
        prefix=args.prefix,
        deterministic_names=args.deterministic_names,
        run_tag=run_tag,
        progress=export_prog,
    )

    manifest_path = None
    if args.save_manifest:
        manifest_path = output_dir / f"manifest_{run_tag}.csv"
        df_portfolios.to_csv(manifest_path, index=False)
        meta = {
            "vw_definition": "value_weighted_of_N_assets",
            "mktcap_path": str(args.mktcap_path),
            "mktcap_unit_multiplier": args.mktcap_unit_multiplier,
            "weights": "Cap_{i,t-1} / sum Cap_{j,t-1}",
            "mktRF_formula": "(1+R_vw)/(1+RF)-1",
            "rf_source": str(args.rf_path),
            "note": "MktRF NÃO é NEFIN Rm_minus_Rf; é VW das N desta carteira.",
        }
        (output_dir / f"meta_vwN_{run_tag}.json").write_text(
            json.dumps(meta, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    return {
        "k_assets": k_assets,
        "n_portfolios_requested": n_portfolios,
        "n_portfolios_exported": len(saved),
        "n_universe": len(cols_ok),
        "n_companies": n_companies,
        "skipped": False,
        "vw_mode": "N_assets_mktcap",
        "manifest": str(manifest_path) if manifest_path else None,
        "output_dir": str(output_dir),
        "sample_files": [str(p) for p in saved[:3]],
    }


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=(
            "Bases mensais DGU B3 com MktRF = VW das N ações (market cap Economatica). "
            "Leitura B — não usa NEFIN MktRF como estratégia VW."
        )
    )
    src = p.add_mutually_exclusive_group(required=False)
    src.add_argument("--excess-daily-path", type=Path, default=None)
    src.add_argument("--prices-path", type=Path, default=None)

    p.add_argument("--rf-path", type=Path, default=DEFAULT_RF_PATH)
    p.add_argument(
        "--mktcap-path",
        type=Path,
        default=DEFAULT_MKTCAP_PATH,
        help="Excel/CSV largo Data+tickers com Valor de Mercado (mil R$)",
    )
    p.add_argument(
        "--mktcap-unit-multiplier",
        type=float,
        default=1000.0,
        help="Multiplicador mil R$ → R$ (default 1000)",
    )
    p.add_argument(
        "--portfolios-csv",
        type=Path,
        default=None,
        help="CSV Cap.7 (Carteira) ou manifest Asset_* — sobrescreve sorteio",
    )
    p.add_argument(
        "--universo-topn-csv",
        type=Path,
        default=None,
        help="universo_liq_*.csv → 1 carteira top-N por ADV (dedupe empresa)",
    )
    p.add_argument(
        "--no-dedupe-company",
        action="store_true",
        help="No top-N, não remove 2ª classe da mesma empresa",
    )

    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--k-assets", type=int, nargs="+", default=list(DEFAULT_K_ASSETS))
    p.add_argument(
        "--n-portfolios",
        type=int,
        default=DEFAULT_N_PORTFOLIOS,
        help="Nº no sorteio; com --portfolios-csv, 0=todas",
    )
    p.add_argument("--seed", type=int, default=DEFAULT_SEED)
    p.add_argument("--start-complete", default=DEFAULT_START_COMPLETE)
    p.add_argument("--end-complete", default=DEFAULT_END_COMPLETE)
    p.add_argument("--panel-start", default=DEFAULT_PANEL_START)
    p.add_argument("--prefix", default=DEFAULT_PREFIX)
    p.add_argument("--deterministic-names", action="store_true")
    p.add_argument("--save-manifest", action="store_true")
    p.add_argument("--zip", dest="make_zip", action="store_true")
    p.add_argument("--zip-path", type=Path, default=None)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if not args.mktcap_path.exists():
        raise FileNotFoundError(
            f"Market cap não encontrado: {args.mktcap_path}\n"
            "Exporte da Economatica (Valor de Mercado, diário, painel largo) "
            "para ibov/economatica_valorMercado.xlsx"
        )

    print(f"Carregando market cap: {args.mktcap_path}")
    mktcap = load_mktcap_panel(
        args.mktcap_path, unit_multiplier=args.mktcap_unit_multiplier
    )
    print(
        f"Market cap: {mktcap.shape[1]} tickers, "
        f"{mktcap.index.min().date()} → {mktcap.index.max().date()}"
    )

    prices_for_rets = args.prices_path or DEFAULT_PRICES_PATH
    if not Path(prices_for_rets).exists():
        raise FileNotFoundError(
            f"Preços necessários para retorno total VW: {prices_for_rets}"
        )
    print(f"Retornos totais a partir de: {prices_for_rets}")
    total_rets = load_total_returns_from_prices(Path(prices_for_rets))

    rf = load_rf_series(args.rf_path)
    print(f"RF NEFIN: {len(rf)} dias ({rf.index.min().date()} → {rf.index.max().date()})")

    # Namespace mínimo para resolve_excess_daily do v2
    class _NS:
        pass

    ns = _NS()
    ns.prices_path = args.prices_path
    ns.rf_path = args.rf_path
    ns.excess_daily_path = args.excess_daily_path
    df_b3_daily = resolve_excess_daily_v2(ns)  # type: ignore[arg-type]

    asset_cols = [c for c in df_b3_daily.columns if c != "DATE" and is_ticker_column(str(c))]
    rename = {c: padronizar_ticker(str(c)) for c in asset_cols}
    df_b3_daily = df_b3_daily.rename(columns=rename)
    df_b3_daily = collapse_duplicate_asset_cols(df_b3_daily, date_col="DATE")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    summaries = []
    global_total = max(1, len(args.k_assets) * max(int(args.n_portfolios), 1))
    global_offset = 0

    for k in args.k_assets:
        print(f"\n=== Gerando N={k} com VW das N (market cap) ===")
        summary = run_generation_vwN(
            df_b3_daily=df_b3_daily,
            total_rets=total_rets,
            mktcap=mktcap,
            rf=rf,
            output_dir=args.output_dir,
            k_assets=int(k),
            args=args,
            global_offset=global_offset,
            global_total=global_total,
        )
        global_offset += int(summary["n_portfolios_exported"])
        summaries.append(summary)
        print(json.dumps(summary, indent=2, ensure_ascii=False))

    if args.make_zip:
        zip_path = args.zip_path or (args.output_dir / "B3_carteiras_vwN.zip")
        created = zip_bases(args.output_dir, args.prefix, zip_path)
        print(f"ZIP criado: {created}")

    total = sum(s["n_portfolios_exported"] for s in summaries)
    skipped = [s for s in summaries if s.get("skipped")]
    print(f"\nConcluído: {total} base(s) em {args.output_dir}")
    if skipped:
        ns = ", ".join(f"N={s['k_assets']}" for s in skipped)
        print(f"Pulados por universo insuficiente: {ns}", flush=True)
    print(
        "Importante: nestas bases, a coluna MktRF = VW das N (caps t-1), "
        "não o Market Factor NEFIN."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
