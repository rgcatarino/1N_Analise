#!/usr/bin/env python3
"""Sensibilidade a market impact BARRA (square-root) — Cap. 7 / liq_1MM.

Proxy Torre-Ferrari / square-root law:
    c_{i,t} = eta * sigma_{i,t} * sqrt(|q_{i,t}| / ADV_{i,t})

Cenarios por carteira: gross (tcost=0), net-flat (12 bps), net-BARRA (eta calibrado).
Calibracao: mediana (N=calib-n, sample-n carteiras) do custo medio por rebalance ≈ target bps.

Parametros flexiveis via CLI:
  --sample-n, --ns, --start-y/m, --end-y/m, --rebalance-freq, --rebalance-month,
  --universo-tag, --formation-yyyymm, --calib-n, --calib-target-bps,
  --nav-csv (NAV medio ano a ano × N; default Cap. 7),
  --capital-per-name (AUM = N*K; painel tensao Marcelo)

No modo ``mean_nav`` (default sem ``--capital-per-name``), o notional/custo BARRA
em cada rebalance usa o NAV medio cross-section do CSV naquele ano×N. O CSV foi
gerado com capital inicial R$ 10.000 (mesmo ``--capital`` default do Cap. 7); se
``--capital`` diferir, os valores do CSV sao reescalados por capital/10000.
O wealth path da carteira parte de ``--capital``.

Aggregate/precheck (formacao): exporta formacao_metricas_por_N.csv e plota
  figura_custo_marginal_barra_vs_N.png + figura_adv_p10_vs_N.png (ancoras);
  mean_cost_bps / ADV medio ficam como robustez secundaria.

Exemplos::

    # Baseline Cap. 7 (NAV medio ano a ano do CSV)
    python codigo_fonte/run_sensibilidade_barra_pf.py --mode all \\
      --sample-n 300 --ns 8 15 20 30 40 --rebalance-freq annual

    # Legado: NAV inicial fixo (sem CSV)
    python codigo_fonte/run_sensibilidade_barra_pf.py --mode all \\
      --no-nav-csv --capital 10000 --sample-n 300 --ns 8 20 40

    # Painel B: AUM = N x K (posicao constante por nome)
    python codigo_fonte/run_sensibilidade_barra_pf.py --mode all \\
      --sample-n 1 --ns 8 10 12 15 20 25 30 35 40 --capital-per-name 10000 \\
      --universo-tag liq_top_1MM --formation-yyyymm 200106 \\
      --rebalance-freq annual --require-cost-up-with-n \\
      --out-dir resultados/sensibilidade_barra/topN_annual_2001_aumN_n_8_10_12_15_20_25_30_35_40

Modos: --mode calibrate|run|aggregate|all|precheck
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

from backtest_carteiras_individuais_retornos_v2 import (  # noqa: E402
    DEFAULT_IR_MONTHLY_SALES_EXEMPTION,
    DEFAULT_IR_RATE,
    _recompute_return_metrics,
    load_prices,
)
from backtest_carteiras_individuais_retornos_v3 import (  # noqa: E402
    REBALANCE_FREQS,
    _turnover_from_tx,
    build_rebalance_dates,
    load_carteiras_csv,
    month_end,
)
from backtest_carteiras_individuais_retornos_v4 import (  # noqa: E402
    EPS,
    SimpleRes,
    _prepare_panel,
    _tx_from_records,
    nav_to_res_stats,
)
from barra_market_impact import (  # noqa: E402
    ADV_FLOOR_BRL,
    VOL_WINDOW,
    barra_unit_bps,
    barra_unit_cost as barra_unit_cost_fn,
    build_sigma_adv_panels,
    load_volume_brl,
    portfolio_barra_cost,
    prices_df_to_wide,
    volume_cache_path,
)
from ticker_continuacao import chain_portfolio_prices, padronizar_ticker  # noqa: E402

DEFAULT_PRICES_PATH = REPO_ROOT / "ibov" / "prices_adjust_close_B3_economatica_1986-out_2025.csv"
DEFAULT_RF_PATH = REPO_ROOT / "nefin_RF.csv"
DEFAULT_VOLUME_XLSX = REPO_ROOT / "ibov" / "economaticavolumeNegociado.xlsx"
DEFAULT_OUT_DIR = REPO_ROOT / "resultados" / "sensibilidade_barra"
DEFAULT_CARTEIRAS_DIR = REPO_ROOT / "resultados" / "carteiras_aleatorias_liquidas"
DEFAULT_SEED = 20250725
DEFAULT_SAMPLE_N = 300
DEFAULT_NS = (8, 15, 20, 30, 40)
DEFAULT_FLAT_BPS = 12.0
DEFAULT_CAPITAL = 10000.0
# CSV de NAV medio (Cap. 7) foi gerado com capital inicial R$ 10.000.
NAV_CSV_BASE_CAPITAL = 10_000.0
DEFAULT_START_Y, DEFAULT_START_M = 2001, 7
DEFAULT_END_Y, DEFAULT_END_M = 2025, 10
DEFAULT_WORKERS = 6
DEFAULT_UNIVERSO_TAG = "liq_1MM"
DEFAULT_REBALANCE_FREQ = "annual"
DEFAULT_REBALANCE_MONTH = 7
DEFAULT_CALIB_N = 20
DEFAULT_CALIB_TARGET_BPS = 12.0
DEFAULT_NAV_CSV = (
    REPO_ROOT
    / "resultados"
    / "liquidez_1mm_delist"
    / "nav_medio_ano_a_ano_liq_1MM_200107_202510_reb-annual_t12bps_ir.csv"
)

_PROC_CACHE: Dict[str, Any] = {}


def nav_csv_meta_path(csv_path: Path) -> Path:
    return csv_path.with_name(csv_path.stem + ".meta.json")


def read_nav_csv_base_capital(csv_path: Path) -> float:
    """Capital inicial (R$) com o qual o CSV de NAV medio foi gerado."""
    meta_path = nav_csv_meta_path(Path(csv_path))
    if meta_path.exists():
        try:
            payload = json.loads(meta_path.read_text(encoding="utf-8"))
            base = payload.get("base_capital", payload.get("capital"))
            if base is not None:
                return float(base)
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            pass
    return float(NAV_CSV_BASE_CAPITAL)


def scale_nav_wide_to_capital(
    nav_wide: pd.DataFrame,
    *,
    capital: float,
    base_capital: float = NAV_CSV_BASE_CAPITAL,
) -> pd.DataFrame:
    """Reescala NAV do CSV (gerado com ``base_capital``) para o ``capital`` do run."""
    base = float(base_capital)
    if base <= 0:
        raise ValueError(f"base_capital invalido: {base}")
    factor = float(capital) / base
    if abs(factor - 1.0) < 1e-12:
        return nav_wide
    return nav_wide * factor


def load_nav_medio_csv(path: Path) -> pd.DataFrame:
    """CSV wide: ano, N8, N10, ... → index=ano, cols=int N.

    Valores em R$ absolutos com capital inicial tipicamente R$ 10.000
    (``NAV_CSV_BASE_CAPITAL`` / ``*.meta.json``).
    """
    df = pd.read_csv(path)
    if "ano" not in df.columns:
        raise ValueError(f"CSV de NAV medio sem coluna 'ano': {path}")
    n_cols = {}
    for c in df.columns:
        s = str(c)
        if s.startswith("N") and s[1:].isdigit():
            n_cols[c] = int(s[1:])
    if not n_cols:
        raise ValueError(f"CSV de NAV medio sem colunas N*: {path}")
    out = df.set_index("ano")[list(n_cols.keys())].rename(columns=n_cols)
    out.index = out.index.astype(int)
    out = out.apply(pd.to_numeric, errors="coerce").sort_index()
    return out


def nav_by_year_for_n(nav_wide: pd.DataFrame, n_ativos: int) -> Dict[int, float]:
    if int(n_ativos) not in nav_wide.columns:
        raise KeyError(
            f"N={n_ativos} ausente no CSV de NAV medio. "
            f"Disponiveis: {sorted(int(c) for c in nav_wide.columns)}"
        )
    s = nav_wide[int(n_ativos)].dropna()
    return {int(y): float(v) for y, v in s.items()}


def lookup_nav_for_date(
    dt: pd.Timestamp,
    nav_by_year: Dict[int, float],
    *,
    fallback: float,
) -> float:
    """NAV de referencia no rebalance: ultimo year-end do CSV com ano < year(dt).

    Ex.: julho/2002 → NAV medio de 2001; abertura julho/2001 (sem ano anterior) → fallback
    (tipicamente R$ 10.000, o mesmo capital inicial do CSV Cap. 7).
    """
    if not nav_by_year:
        return float(fallback)
    ts = pd.Timestamp(dt)
    y = int(ts.year)
    # Year-end anterior ao calendario do evento (rebalance em julho usa Dez Y-1).
    candidates = [yy for yy in nav_by_year if yy < y]
    if not candidates:
        return float(fallback)
    return float(nav_by_year[max(candidates)])


def default_formation_yyyymm(start_y: int, start_m: int) -> str:
    """Convencao Cap. 7: formacao em junho quando o backtest comeca em julho."""
    if int(start_m) == 7:
        return f"{int(start_y)}06"
    if int(start_m) == 1:
        return f"{int(start_y) - 1}12"
    return f"{int(start_y)}{int(start_m) - 1:02d}"


def rebalance_freq_label(freq: str) -> str:
    labels = {
        "monthly": "mensal",
        "quarterly": "trimestral",
        "semiannual": "semestral",
        "annual": "anual",
    }
    return labels.get(str(freq), str(freq))


def carteiras_path_for_n(
    n: int,
    carteiras_dir: Path,
    *,
    universo_tag: str,
    formation_yyyymm: str,
) -> Path:
    return carteiras_dir / f"carteiras_{n}atv_{universo_tag}_{formation_yyyymm}.csv"


def sample_manifest_path(
    out_dir: Path,
    n: int,
    sample_n: int,
    seed: int,
    *,
    formation_yyyymm: str,
    universo_tag: str,
) -> Path:
    return out_dir / (
        f"sample_N{n}_{sample_n}_seed{seed}_{universo_tag}_{formation_yyyymm}.json"
    )


def build_deterministic_sample(
    df_carteiras: pd.DataFrame,
    *,
    n: int,
    seed: int,
) -> pd.DataFrame:
    """Mesmo padrao de run_sensibilidade_tcost_pf.py: sort strategy + RandomState.choice."""
    df = df_carteiras.drop_duplicates(subset=["Carteira"]).copy()
    df["strategy"] = df["Carteira"].astype(str).map(lambda s: "-".join(s.split(",")))
    df = df.sort_values("strategy", kind="mergesort").reset_index(drop=True)
    if len(df) < n:
        raise ValueError(f"Universo tem {len(df)} carteiras; pedido n={n}.")
    rng = np.random.RandomState(seed)
    idx = rng.choice(len(df), size=n, replace=False)
    idx = np.sort(idx)
    return df.iloc[idx].reset_index(drop=True)


def save_sample_manifest(
    sample: pd.DataFrame,
    path: Path,
    *,
    seed: int,
    universe_n: int,
    n_ativos: int,
    universo_tag: str,
    formation_yyyymm: str,
) -> None:
    payload = {
        "seed": seed,
        "n_sample": int(len(sample)),
        "universe_n": int(universe_n),
        "n_ativos": int(n_ativos),
        "universo_tag": universo_tag,
        "formation_yyyymm": formation_yyyymm,
        "methodology": (
            f"Carteiras distintas {universo_tag} N={n_ativos} formacao={formation_yyyymm}; "
            "strategy = tickers unidos por '-'; ordenacao lexicografica estavel (mergesort); "
            f"np.random.RandomState({seed}).choice(..., replace=False); indices ordenados."
        ),
        "strategies": sample["strategy"].tolist(),
        "bases": sample["Base"].tolist(),
        "carteiras": sample["Carteira"].tolist(),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def simulate_ew_nav_costed(
    prices: pd.DataFrame,
    *,
    cost_mode: str,
    flat_tcost: float,
    eta: float,
    sigma_panel: Optional[pd.DataFrame],
    adv_panel: Optional[pd.DataFrame],
    initial_capital: float,
    rebalance: bool,
    rebalance_dates: Sequence[pd.Timestamp],
    apply_stock_ir: bool,
    ir_rate: float,
    ir_monthly_sales_exemption: float,
    delist_terminal_return: float,
    adv_floor: float = ADV_FLOOR_BRL,
    nav_by_year: Optional[Dict[int, float]] = None,
) -> Tuple[pd.Series, pd.DataFrame, List[dict], float, List[dict]]:
    """EW 1/N com custo flat ou BARRA. Devolve tambem cost_events.

    Se ``nav_by_year`` for fornecido, o notional/custo BARRA (e o flat) em cada
    rebalance e dimensionado pelo NAV medio de referencia daquele ano; o desconto
    e aplicado proporcionalmente ao equity real da carteira.
    """
    tickers = [str(c) for c in prices.columns]
    px = prices.to_numpy(dtype=float)
    dates = pd.DatetimeIndex(prices.index)
    t_count, n_count = px.shape
    if t_count == 0 or n_count == 0:
        raise ValueError("Painel de precos vazio.")

    sig_arr = None
    adv_arr = None
    if cost_mode == "barra":
        if sigma_panel is None or adv_panel is None:
            raise ValueError("BARRA requer sigma_panel e adv_panel")
        sig = sigma_panel.reindex(index=dates, columns=tickers)
        adv = adv_panel.reindex(index=dates, columns=tickers)
        sig_arr = sig.to_numpy(dtype=float)
        adv_arr = adv.to_numpy(dtype=float)

    all_live = np.all(np.isfinite(px) & (px > 0), axis=1)
    start_i = int(np.argmax(all_live)) if all_live.any() else 0
    px = px[start_i:]
    dates = dates[start_i:]
    t_count = px.shape[0]
    if sig_arr is not None:
        sig_arr = sig_arr[start_i:]
        adv_arr = adv_arr[start_i:]

    last_end = np.array(
        [
            int(pd.Timestamp(prices[c].dropna().index.max()).value)
            if prices[c].notna().any()
            else 0
            for c in prices.columns
        ],
        dtype=np.int64,
    )

    shares = np.zeros(n_count, dtype=float)
    cash = float(initial_capital)
    last_px = np.full(n_count, np.nan)
    nav_brl = np.zeros(t_count, dtype=float)
    records: List[Tuple[pd.Timestamp, str, float, float]] = []
    events: List[dict] = []
    cost_events: List[dict] = []
    cost_qty = np.zeros(n_count, dtype=float)
    cost_avg = np.zeros(n_count, dtype=float)
    total_ir = 0.0
    reb_set = {pd.Timestamp(d).normalize() for d in rebalance_dates}
    already_delisted = np.zeros(n_count, dtype=bool)

    def still_listed(t: int) -> np.ndarray:
        return (int(pd.Timestamp(dates[t]).value) <= last_end) & (~already_delisted)

    def mark_prices(t: int) -> np.ndarray:
        p = np.array(px[t], dtype=float, copy=True)
        missing = ~np.isfinite(p) | (p <= 0)
        p[missing] = last_px[missing]
        p[~still_listed(t)] = np.nan
        return p

    def mark_value(t: int) -> float:
        p = mark_prices(t)
        live = np.isfinite(p) & (p > 0)
        return cash + float(np.nansum(shares * np.where(live, p, 0.0)))

    def record_trade(t: int, i: int, qty: float, price: float) -> None:
        if abs(qty) <= EPS or not np.isfinite(price) or price <= 0:
            return
        records.append((pd.Timestamp(dates[t]), tickers[i], float(qty), float(price)))
        if qty > 0:
            new_qty = cost_qty[i] + qty
            if new_qty > 0:
                cost_avg[i] = (cost_qty[i] * cost_avg[i] + qty * price) / new_qty
                cost_qty[i] = new_qty
        else:
            sold = min(abs(qty), cost_qty[i])
            cost_qty[i] = max(0.0, cost_qty[i] - sold)
            if cost_qty[i] <= EPS:
                cost_qty[i] = 0.0
                cost_avg[i] = 0.0

    def apply_ir(t: int, sales_notional: float, net_gain: float) -> None:
        nonlocal cash, total_ir
        if not apply_stock_ir or sales_notional <= EPS:
            return
        if sales_notional <= float(ir_monthly_sales_exemption):
            ir = 0.0
        else:
            ir = float(ir_rate) * max(0.0, net_gain)
        if ir > 0:
            cash -= ir
            total_ir += ir

    def equity_for_cost(t: int, equity_actual: float) -> float:
        if not nav_by_year:
            return float(equity_actual)
        return lookup_nav_for_date(
            dates[t],
            nav_by_year,
            fallback=float(equity_actual),
        )

    def compute_cost_and_notionals(
        t: int,
        live: np.ndarray,
        p: np.ndarray,
        old_shares: np.ndarray,
        equity: float,
        k: int,
    ) -> Tuple[float, np.ndarray, float]:
        raw_target = equity / k
        raw_shares = np.where(live, raw_target / np.where(p > 0, p, np.nan), 0.0)
        q = np.abs(raw_shares - old_shares) * np.where(live, p, 0.0)
        q = np.where(np.isfinite(q), q, 0.0)

        if cost_mode == "gross":
            return 0.0, q, 0.0
        if cost_mode == "flat":
            traded = float(np.nansum(q))
            return traded * float(flat_tcost), q, 0.0

        assert sig_arr is not None and adv_arr is not None
        cost, raw_cost = portfolio_barra_cost(
            sig_arr[t],
            adv_arr[t],
            q,
            live,
            eta=float(eta),
            adv_floor=float(adv_floor),
        )
        return cost, q, raw_cost

    def barra_unit_cost(t: int, i: int, q_i: float) -> float:
        assert sig_arr is not None and adv_arr is not None
        sig_i = sig_arr[t, i]
        if not np.isfinite(sig_i) or sig_i < 0:
            live = still_listed(t)
            live_sig = sig_arr[t][live & np.isfinite(sig_arr[t])]
            sig_i = float(np.nanmedian(live_sig)) if live_sig.size else 0.0
            if not np.isfinite(sig_i):
                sig_i = 0.0
        adv_i = adv_arr[t, i]
        return barra_unit_cost_fn(
            sig_i, adv_i, q_i, eta=float(eta), adv_floor=float(adv_floor)
        )

    def rebalance_to_live(t: int, live: np.ndarray, p: np.ndarray, event_tag: str) -> Tuple[float, float]:
        nonlocal cash, shares
        equity = cash + float(np.nansum(shares * np.where(np.isfinite(p) & (p > 0), p, 0.0)))
        k = int(live.sum())
        sales_notional = 0.0
        net_gain = 0.0
        if k == 0:
            for i in range(n_count):
                if shares[i] > EPS and np.isfinite(last_px[i]) and last_px[i] > 0:
                    price = float(last_px[i])
                    qty = shares[i]
                    avg = cost_avg[i] if cost_qty[i] > 0 else price
                    q_i = qty * price
                    if cost_mode == "flat":
                        proceeds = q_i * (1.0 - float(flat_tcost))
                    elif cost_mode == "barra":
                        proceeds = q_i * (1.0 - barra_unit_cost(t, i, q_i))
                    else:
                        proceeds = q_i
                    cash += proceeds
                    sales_notional += q_i
                    net_gain += (price - avg) * qty
                    record_trade(t, i, -qty, price)
                    shares[i] = 0.0
            return sales_notional, net_gain

        equity_ref = equity_for_cost(t, equity)
        old_shares = shares.copy()
        # Notionais/custo no NAV de referencia; desconto proporcional no equity real.
        if nav_by_year and abs(equity) > EPS and abs(equity_ref - equity) > EPS:
            scale_q = float(equity_ref) / float(equity)
            old_shares_cost = old_shares * scale_q
        else:
            scale_q = 1.0
            old_shares_cost = old_shares

        cost_ref, q_ref, raw_cost_ref = compute_cost_and_notionals(
            t, live, p, old_shares_cost, equity_ref, k
        )
        if abs(equity_ref) > EPS:
            cost = float(cost_ref) * (float(equity) / float(equity_ref))
            raw_cost = float(raw_cost_ref) * (float(equity) / float(equity_ref))
        else:
            cost, raw_cost = float(cost_ref), float(raw_cost_ref)

        equity_net = max(0.0, equity - cost)
        target = equity_net / k
        new_shares = np.where(live, target / np.where(live, p, np.nan), 0.0)
        for i in range(n_count):
            delta = float(new_shares[i] - old_shares[i])
            price = float(p[i]) if live[i] else (float(last_px[i]) if np.isfinite(last_px[i]) else np.nan)
            if abs(delta) <= EPS or not np.isfinite(price) or price <= 0:
                shares[i] = float(new_shares[i])
                continue
            if delta < 0:
                sold = -delta
                avg = cost_avg[i] if cost_qty[i] > 0 else price
                sales_notional += sold * price
                net_gain += (price - avg) * sold
            record_trade(t, i, delta, price)
            shares[i] = float(new_shares[i])
        cash = equity_net - float(np.nansum(shares * np.where(live, p, 0.0)))
        nav_pre = max(equity_ref, EPS)
        cost_events.append(
            {
                "date": str(pd.Timestamp(dates[t]).date()),
                "event": event_tag,
                "nav_pre": float(nav_pre),
                "nav_actual": float(equity),
                "cost_brl": float(cost),
                "cost_bps_nav": float(10000.0 * cost_ref / nav_pre),
                "raw_cost_brl_eta1": float(raw_cost),
                "raw_cost_bps_nav_eta1": float(10000.0 * raw_cost_ref / nav_pre),
                "traded_notional": float(np.nansum(q_ref)),
            }
        )
        return sales_notional, net_gain

    for t in range(t_count):
        finite = np.isfinite(px[t]) & (px[t] > 0)
        last_px[finite] = px[t][finite]
        still = still_listed(t)
        dead = (shares > EPS) & (~still) & (~already_delisted)
        is_reb = pd.Timestamp(dates[t]).normalize() in reb_set
        must_reb = (t == 0) or bool(dead.any()) or (rebalance and is_reb)
        p_mark = mark_prices(t)

        day_sales = 0.0
        day_gain = 0.0
        if dead.any():
            for i in np.where(dead)[0]:
                price = float(last_px[i]) * (1.0 + float(delist_terminal_return))
                if not np.isfinite(price) or price <= 0:
                    shares[i] = 0.0
                    already_delisted[i] = True
                    continue
                qty = float(shares[i])
                avg = cost_avg[i] if cost_qty[i] > 0 else price
                q_i = qty * price
                if cost_mode == "flat":
                    proceeds = q_i * (1.0 - float(flat_tcost))
                elif cost_mode == "barra":
                    proceeds = q_i * (1.0 - barra_unit_cost(t, i, q_i))
                else:
                    proceeds = q_i
                cash += proceeds
                day_sales += q_i
                day_gain += (price - avg) * qty
                record_trade(t, i, -qty, price)
                events.append(
                    {
                        "date": str(pd.Timestamp(dates[t]).date()),
                        "ticker": tickers[i],
                        "event": "delist",
                        "price": price,
                        "quantity": qty,
                    }
                )
                shares[i] = 0.0
                already_delisted[i] = True

        if must_reb:
            live = still_listed(t) & np.isfinite(p_mark) & (p_mark > 0)
            tag = "open" if t == 0 else ("rebalance" if is_reb else "delist_reb")
            sales_notional, net_gain = rebalance_to_live(t, live, p_mark, tag)
            apply_ir(t, day_sales + sales_notional, day_gain + net_gain)

        nav_brl[t] = mark_value(t)

    nav = pd.Series(nav_brl, index=dates, name="nav")
    if float(nav.iloc[0]) == 0.0:
        raise ValueError("NAV inicial nulo.")
    nav_bt = nav / float(nav.iloc[0]) * 100.0
    tx = _tx_from_records(records)
    return nav_bt, tx, events, total_ir, cost_events

def run_barra_backtest_ew(
    df_prices: pd.DataFrame,
    tickers: list,
    *,
    cost_mode: str,
    flat_tcost: float = 0.0,
    eta: float = 0.0,
    sigma_panel: Optional[pd.DataFrame] = None,
    adv_panel: Optional[pd.DataFrame] = None,
    start_y: int,
    start_m: int,
    end_y: int,
    end_m: int,
    initial_capital: float,
    rebalance: bool,
    rebalance_freq: str = "annual",
    rebalance_month: int = 7,
    strat_name: str = "EW",
    rf_df: Optional[pd.DataFrame] = None,
    rf_date_col: str = "DATE",
    rf_col: str = "RF",
    rf_align_fill: str = "ffill",
    ann_factor: int = 252,
    apply_stock_ir: bool = True,
    ir_rate: float = DEFAULT_IR_RATE,
    ir_monthly_sales_exemption: float = DEFAULT_IR_MONTHLY_SALES_EXEMPTION,
    max_gap_days: int = 5,
    delist_terminal_return: float = 0.0,
    adv_floor: float = ADV_FLOOR_BRL,
    nav_by_year: Optional[Dict[int, float]] = None,
):
    tickers = [padronizar_ticker(t) for t in tickers]
    panel = _prepare_panel(df_prices, start_y, start_m, end_y, end_m)
    missing = [t for t in tickers if t not in panel.columns]
    if missing:
        raise ValueError(f"Colunas ausentes no CSV de precos: {missing}")

    prices, chain_audit = chain_portfolio_prices(panel, tickers, max_gap_days=max_gap_days)
    prices = prices[tickers]
    if prices.empty:
        raise ValueError("Apos o encadeamento, nao restou periodo com precos.")

    start_target = prices.index.min()
    end_target = prices.index.max()
    if rebalance:
        rebalance_dates = build_rebalance_dates(
            prices.index,
            freq=rebalance_freq,
            annual_month=rebalance_month,
            start=start_target,
            end=end_target,
        )
        if not rebalance_dates:
            raise ValueError("Nao foi possivel montar datas de rebalanceamento.")
    else:
        rebalance_dates = [pd.Timestamp(start_target)]

    nav, tx, events, total_ir_paid, cost_events = simulate_ew_nav_costed(
        prices,
        cost_mode=cost_mode,
        flat_tcost=flat_tcost,
        eta=eta,
        sigma_panel=sigma_panel,
        adv_panel=adv_panel,
        initial_capital=initial_capital,
        rebalance=rebalance,
        rebalance_dates=rebalance_dates,
        apply_stock_ir=apply_stock_ir,
        ir_rate=ir_rate,
        ir_monthly_sales_exemption=ir_monthly_sales_exemption,
        delist_terminal_return=delist_terminal_return,
        adv_floor=adv_floor,
        nav_by_year=nav_by_year,
    )

    rf = None
    if rf_df is not None:
        rf_local = rf_df.copy()
        if rf_date_col not in rf_local.columns:
            for cand in ("Date", "date", "DATA", "data"):
                if cand in rf_local.columns:
                    rf_date_col = cand
                    break
        if rf_col not in rf_local.columns:
            for cand in ("Rf", "rf", "RISKFREE", "risk_free"):
                if cand in rf_local.columns:
                    rf_col = cand
                    break
        rf_local[rf_date_col] = pd.to_datetime(rf_local[rf_date_col])
        rf_local = rf_local.sort_values(rf_date_col).set_index(rf_date_col)
        rf = pd.to_numeric(rf_local[rf_col], errors="coerce").sort_index().reindex(nav.index)
        if rf_align_fill == "ffill":
            rf = rf.ffill().bfill()
        elif rf_align_fill == "bfill":
            rf = rf.bfill().ffill()

    metrics = _recompute_return_metrics(nav, rf, ann_factor)
    turnover_series = _turnover_from_tx(tx, nav, zero_first=not rebalance)
    stats = nav_to_res_stats(nav)
    res = SimpleRes(strat_name, stats, nav)

    reb_costs = [e for e in cost_events if e.get("event") in ("rebalance", "open", "delist_reb")]
    mean_cost_bps = float(np.mean([e["cost_bps_nav"] for e in reb_costs])) if reb_costs else np.nan
    mean_raw_bps = (
        float(np.mean([e["raw_cost_bps_nav_eta1"] for e in reb_costs])) if reb_costs else np.nan
    )
    annual_reb = [e for e in cost_events if e.get("event") == "rebalance"]
    if not annual_reb:
        annual_reb = reb_costs
    mean_cost_bps_reb = float(np.mean([e["cost_bps_nav"] for e in annual_reb])) if annual_reb else np.nan
    mean_raw_bps_reb = (
        float(np.mean([e["raw_cost_bps_nav_eta1"] for e in annual_reb])) if annual_reb else np.nan
    )

    aux = {
        "sharpe_excess": metrics["sharpe_excess"],
        "vol_excess_ann": metrics["vol_excess_ann"],
        "cagr": metrics["cagr"],
        "total_return": metrics["total_return"],
        "total_excess_return": metrics["total_excess_return"],
        "ceq_gamma1_ann": metrics["ceq_gamma1_ann"],
        "avg_turnover": float(turnover_series.mean()) if len(turnover_series) else np.nan,
        "n_trade_days": int((turnover_series > 0).sum()),
        "total_ir_paid": float(total_ir_paid),
        "cost_mode": cost_mode,
        "flat_tcost": float(flat_tcost),
        "eta": float(eta),
        "mean_cost_bps_nav": mean_cost_bps,
        "mean_cost_bps_nav_reb": mean_cost_bps_reb,
        "mean_raw_cost_bps_nav_eta1": mean_raw_bps,
        "mean_raw_cost_bps_nav_eta1_reb": mean_raw_bps_reb,
        "n_cost_events": len(cost_events),
        "n_rebalance_cost_events": len(annual_reb),
        "cost_events": cost_events,
        "n_delist": sum(1 for e in events if e.get("event") == "delist"),
        "rebalance": bool(rebalance),
        "engine": "barra_sens_v1",
    }
    return res, aux


def _init_worker(prices_path: str, rf_path: str, volume_cache: str, sigma_cache: str, adv_cache: str) -> None:
    global _PROC_CACHE
    if _PROC_CACHE.get("ready"):
        return
    df_prices = load_prices(Path(prices_path))
    rf_df = pd.read_csv(rf_path)
    sigma = pd.read_pickle(sigma_cache)
    adv = pd.read_pickle(adv_cache)
    _PROC_CACHE = {
        "ready": True,
        "df_prices": df_prices,
        "rf_df": rf_df,
        "sigma": sigma,
        "adv": adv,
    }


def _worker_one(payload: Dict[str, Any]) -> Dict[str, Any]:
    t0 = time.perf_counter()
    try:
        df_prices = _PROC_CACHE["df_prices"]
        rf_df = _PROC_CACHE["rf_df"]
        sigma = _PROC_CACHE["sigma"]
        adv = _PROC_CACHE["adv"]
        tickers = [t.strip() for t in payload["tickers_csv"].split(",") if t.strip()]
        res, aux = run_barra_backtest_ew(
            df_prices=df_prices,
            tickers=tickers,
            cost_mode=payload["cost_mode"],
            flat_tcost=float(payload.get("flat_tcost", 0.0)),
            eta=float(payload.get("eta", 0.0)),
            sigma_panel=sigma if payload["cost_mode"] == "barra" else None,
            adv_panel=adv if payload["cost_mode"] == "barra" else None,
            start_y=int(payload["start_y"]),
            start_m=int(payload["start_m"]),
            end_y=int(payload["end_y"]),
            end_m=int(payload["end_m"]),
            initial_capital=float(payload["capital"]),
            rebalance=bool(payload["rebalance"]),
            rebalance_freq=str(payload.get("rebalance_freq", DEFAULT_REBALANCE_FREQ)),
            rebalance_month=int(payload.get("rebalance_month", DEFAULT_REBALANCE_MONTH)),
            strat_name=payload["strategy"],
            rf_df=rf_df,
            apply_stock_ir=bool(payload["apply_stock_ir"]),
            nav_by_year=payload.get("nav_by_year"),
        )
        return {
            "status": "ok",
            "n_ativos": int(payload["n_ativos"]),
            "strategy": payload["strategy"],
            "scenario": payload["scenario"],
            "cost_mode": payload["cost_mode"],
            "rebalance": bool(payload["rebalance"]),
            "rebalance_freq": str(payload.get("rebalance_freq", DEFAULT_REBALANCE_FREQ)),
            "rebalance_month": int(payload.get("rebalance_month", DEFAULT_REBALANCE_MONTH)),
            "start_y": int(payload["start_y"]),
            "start_m": int(payload["start_m"]),
            "end_y": int(payload["end_y"]),
            "end_m": int(payload["end_m"]),
            "capital": float(payload["capital"]),
            "capital_mode": payload.get("capital_mode", "fixed"),
            "sharpe_excess": aux["sharpe_excess"],
            "total_excess_return": aux["total_excess_return"],
            "total_return": aux["total_return"],
            "ceq_gamma1_ann": aux["ceq_gamma1_ann"],
            "cagr": aux["cagr"],
            "mean_cost_bps_nav": aux["mean_cost_bps_nav"],
            "mean_cost_bps_nav_reb": aux["mean_cost_bps_nav_reb"],
            "mean_raw_cost_bps_nav_eta1": aux["mean_raw_cost_bps_nav_eta1"],
            "mean_raw_cost_bps_nav_eta1_reb": aux["mean_raw_cost_bps_nav_eta1_reb"],
            "n_rebalance_cost_events": aux["n_rebalance_cost_events"],
            "total_ir_paid": aux["total_ir_paid"],
            "avg_turnover": aux["avg_turnover"],
            "eta": aux["eta"],
            "elapsed_s": time.perf_counter() - t0,
            "error": None,
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "status": "error",
            "n_ativos": int(payload.get("n_ativos", -1)),
            "strategy": payload.get("strategy"),
            "scenario": payload.get("scenario"),
            "cost_mode": payload.get("cost_mode"),
            "rebalance": payload.get("rebalance"),
            "rebalance_freq": payload.get("rebalance_freq"),
            "elapsed_s": time.perf_counter() - t0,
            "error": f"{type(exc).__name__}: {exc}",
        }


def ensure_sigma_adv_cache(
    out_dir: Path,
    df_prices: pd.DataFrame,
    volume_brl: pd.DataFrame,
) -> Tuple[Path, Path]:
    sigma_path = out_dir / "cache" / "sigma_21d.pkl"
    adv_path = out_dir / "cache" / "adv_21d.pkl"
    sigma_path.parent.mkdir(parents=True, exist_ok=True)
    if sigma_path.exists() and adv_path.exists():
        return sigma_path, adv_path
    wide = prices_df_to_wide(df_prices)
    common = [c for c in wide.columns if c in volume_brl.columns]
    vol = volume_brl.reindex(columns=wide.columns)
    print(f"Construindo sigma/ADV (window={VOL_WINDOW}) em {len(wide.columns)} tickers...", flush=True)
    t0 = time.perf_counter()
    sigma, adv = build_sigma_adv_panels(wide, vol, window=VOL_WINDOW)
    sigma.to_pickle(sigma_path)
    adv.to_pickle(adv_path)
    print(
        f"sigma/ADV OK em {time.perf_counter()-t0:.1f}s | common_vol_cols={len(common)}",
        flush=True,
    )
    return sigma_path, adv_path

def load_or_build_samples(
    out_dir: Path,
    ns: Sequence[int],
    sample_n: int,
    seed: int,
    carteiras_dir: Path,
    *,
    universo_tag: str,
    formation_yyyymm: str,
) -> Dict[int, pd.DataFrame]:
    samples: Dict[int, pd.DataFrame] = {}
    for n in ns:
        path = carteiras_path_for_n(
            n,
            carteiras_dir,
            universo_tag=universo_tag,
            formation_yyyymm=formation_yyyymm,
        )
        if not path.exists():
            raise FileNotFoundError(
                f"CSV de carteiras ausente: {path}. "
                f"Gere com gerar_carteiras_aleatorias_liquidas.py "
                f"(N={n}, tag={universo_tag}, formacao={formation_yyyymm})."
            )
        df = load_carteiras_csv(path)
        sample = build_deterministic_sample(df, n=sample_n, seed=seed)
        man = sample_manifest_path(
            out_dir,
            n,
            sample_n,
            seed,
            formation_yyyymm=formation_yyyymm,
            universo_tag=universo_tag,
        )
        save_sample_manifest(
            sample,
            man,
            seed=seed,
            universe_n=len(df),
            n_ativos=n,
            universo_tag=universo_tag,
            formation_yyyymm=formation_yyyymm,
        )
        samples[n] = sample
        print(f"Sample N={n}: {len(sample)}/{len(df)} -> {man.name}", flush=True)
    return samples


def run_jobs(
    jobs: List[Dict[str, Any]],
    *,
    workers: int,
    prices_path: Path,
    rf_path: Path,
    volume_cache: Path,
    sigma_cache: Path,
    adv_cache: Path,
) -> List[Dict[str, Any]]:
    if not jobs:
        return []
    results: List[Dict[str, Any]] = []
    if workers <= 1:
        _init_worker(str(prices_path), str(rf_path), str(volume_cache), str(sigma_cache), str(adv_cache))
        for i, job in enumerate(jobs, 1):
            r = _worker_one(job)
            results.append(r)
            if i % 10 == 0 or i == len(jobs):
                print(
                    f"  progress {i}/{len(jobs)} last={r.get('scenario')} status={r.get('status')}",
                    flush=True,
                )
        return results

    with ProcessPoolExecutor(
        max_workers=workers,
        initializer=_init_worker,
        initargs=(str(prices_path), str(rf_path), str(volume_cache), str(sigma_cache), str(adv_cache)),
    ) as ex:
        futs = {ex.submit(_worker_one, job): job for job in jobs}
        done = 0
        for fut in as_completed(futs):
            r = fut.result()
            results.append(r)
            done += 1
            if done % 20 == 0 or done == len(jobs):
                print(f"  progress {done}/{len(jobs)} status={r.get('status')}", flush=True)
    return results


def resolve_initial_capital(n_ativos: int, args: argparse.Namespace) -> float:
    """Capital inicial do wealth path.

    - ``per_name``: AUM = N * K
    - ``mean_nav`` / ``fixed``: ``--capital`` (default R$ 10.000, alinhado ao CSV)
    """
    if getattr(args, "capital_per_name", None) is not None:
        return float(n_ativos) * float(args.capital_per_name)
    return float(args.capital)


def capital_mode_label(args: argparse.Namespace) -> str:
    if getattr(args, "capital_per_name", None) is not None:
        return "per_name"
    if getattr(args, "nav_csv", None) is not None:
        return "mean_nav"
    return "fixed"


def load_nav_wide_for_run(
    args: argparse.Namespace,
    nav_wide: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    """Carrega CSV de NAV medio e reescala para ``args.capital`` (base tipica R$ 10k).

    Se ``nav_wide`` ja vier preenchido (ex.: cache do calibrate/run), devolve-o
    sem reescalar de novo.
    """
    if nav_wide is not None:
        return nav_wide
    path = Path(args.nav_csv)
    wide = load_nav_medio_csv(path)
    base = read_nav_csv_base_capital(path)
    return scale_nav_wide_to_capital(
        wide,
        capital=float(args.capital),
        base_capital=base,
    )


def resolve_nav_by_year(
    n_ativos: int,
    args: argparse.Namespace,
    nav_wide: Optional[pd.DataFrame] = None,
) -> Optional[Dict[int, float]]:
    """Serie ano→NAV medio para o N (ja na escala de ``args.capital``), ou None."""
    if capital_mode_label(args) != "mean_nav":
        return None
    wide = load_nav_wide_for_run(args, nav_wide=nav_wide)
    return nav_by_year_for_n(wide, int(n_ativos))


def make_job(
    *,
    n_ativos: int,
    strategy: str,
    tickers_csv: str,
    scenario: str,
    cost_mode: str,
    flat_tcost: float,
    eta: float,
    rebalance: bool,
    args: argparse.Namespace,
    nav_wide: Optional[pd.DataFrame] = None,
) -> Dict[str, Any]:
    nav_by_year = resolve_nav_by_year(n_ativos, args, nav_wide=nav_wide)
    return {
        "n_ativos": n_ativos,
        "strategy": strategy,
        "tickers_csv": tickers_csv,
        "scenario": scenario,
        "cost_mode": cost_mode,
        "flat_tcost": flat_tcost,
        "eta": eta,
        "rebalance": rebalance,
        "rebalance_freq": args.rebalance_freq,
        "rebalance_month": args.rebalance_month,
        "start_y": args.start_y,
        "start_m": args.start_m,
        "end_y": args.end_y,
        "end_m": args.end_m,
        "capital": resolve_initial_capital(n_ativos, args),
        "capital_mode": capital_mode_label(args),
        "capital_per_name": (
            float(args.capital_per_name)
            if getattr(args, "capital_per_name", None) is not None
            else None
        ),
        "nav_by_year": nav_by_year,
        "nav_csv": str(args.nav_csv) if getattr(args, "nav_csv", None) else None,
        "apply_stock_ir": args.apply_stock_ir,
    }


def calibrate_eta(
    samples: Dict[int, pd.DataFrame],
    args: argparse.Namespace,
    paths: Dict[str, Path],
) -> Dict[str, Any]:
    calib_n = int(args.calib_n)
    if calib_n not in samples:
        raise ValueError(
            f"--calib-n={calib_n} precisa estar em --ns={list(samples.keys())}"
        )
    sample = samples[calib_n]
    if args.limit is not None:
        sample = sample.iloc[: int(args.limit)].copy()
    nav_wide = None
    if capital_mode_label(args) == "mean_nav":
        nav_wide = load_nav_wide_for_run(args)
    jobs = []
    for _, row in sample.iterrows():
        jobs.append(
            make_job(
                n_ativos=calib_n,
                strategy=row["strategy"],
                tickers_csv=row["Carteira"],
                scenario="calib_barra_eta1",
                cost_mode="barra",
                flat_tcost=0.0,
                eta=1.0,
                rebalance=True,
                args=args,
                nav_wide=nav_wide,
            )
        )
    print(
        f"Calibrando eta em N={calib_n}, {len(jobs)} carteiras "
        f"(eta=1, freq={args.rebalance_freq}, alvo={args.calib_target_bps:g} bps)...",
        flush=True,
    )
    results = run_jobs(
        jobs,
        workers=args.workers,
        prices_path=paths["prices"],
        rf_path=paths["rf"],
        volume_cache=paths["volume_cache"],
        sigma_cache=paths["sigma"],
        adv_cache=paths["adv"],
    )
    ok = [r for r in results if r["status"] == "ok"]
    if not ok:
        raise RuntimeError("Calibracao falhou: nenhum resultado ok")
    raw = pd.Series([r["mean_raw_cost_bps_nav_eta1_reb"] for r in ok], dtype=float)
    median_raw = float(raw.median())
    if not np.isfinite(median_raw) or median_raw <= 0:
        raise RuntimeError(f"Mediana raw invalida: {median_raw}")
    target = float(args.calib_target_bps)
    eta = target / median_raw
    payload = {
        "n_ativos": calib_n,
        "n_portfolios": len(ok),
        "n_errors": len(results) - len(ok),
        "target_bps": target,
        "median_raw_cost_bps_nav_reb_eta1": median_raw,
        "mean_raw_cost_bps_nav_reb_eta1": float(raw.mean()),
        "p25_raw": float(raw.quantile(0.25)),
        "p75_raw": float(raw.quantile(0.75)),
        "eta": eta,
        "formula": "eta = target_bps / median(mean_raw_cost_bps_nav per rebalance at eta=1)",
        "window": f"{args.start_y}-{args.start_m:02d} to {args.end_y}-{args.end_m:02d}",
        "rebalance_freq": args.rebalance_freq,
        "rebalance_month": args.rebalance_month,
        "universo_tag": args.universo_tag,
        "formation_yyyymm": args.formation_yyyymm,
        "vol_window": VOL_WINDOW,
        "adv_floor_brl": ADV_FLOOR_BRL,
        "capital_mode": capital_mode_label(args),
        "capital": float(args.capital),
        "capital_per_name": (
            float(args.capital_per_name)
            if getattr(args, "capital_per_name", None) is not None
            else None
        ),
        "nav_csv": str(args.nav_csv) if getattr(args, "nav_csv", None) else None,
        "nav_csv_base_capital": (
            read_nav_csv_base_capital(Path(args.nav_csv))
            if getattr(args, "nav_csv", None)
            else None
        ),
        "calib_initial_capital": resolve_initial_capital(calib_n, args),
    }
    out = paths["out_dir"] / "calibration_eta.json"
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame(ok).to_csv(paths["out_dir"] / "calibration_detail.csv", index=False)
    print(f"eta={eta:.6g} | median_raw={median_raw:.4f} bps -> {out}", flush=True)
    return payload


def load_eta(out_dir: Path, eta_override: Optional[float] = None) -> float:
    if eta_override is not None:
        return float(eta_override)
    path = out_dir / "calibration_eta.json"
    if not path.exists():
        raise FileNotFoundError(f"Falta {path}; rode --mode calibrate primeiro ou passe --eta")
    return float(json.loads(path.read_text(encoding="utf-8"))["eta"])


def run_full(
    samples: Dict[int, pd.DataFrame],
    args: argparse.Namespace,
    paths: Dict[str, Path],
    eta: float,
) -> pd.DataFrame:
    flat = args.flat_bps / 10000.0
    nav_wide = None
    if capital_mode_label(args) == "mean_nav":
        nav_wide = load_nav_wide_for_run(args)
    jobs: List[Dict[str, Any]] = []
    for n, sample in samples.items():
        sm = sample
        if args.limit is not None:
            sm = sm.iloc[: int(args.limit)].copy()
        for _, row in sm.iterrows():
            base = dict(
                n_ativos=n,
                strategy=row["strategy"],
                tickers_csv=row["Carteira"],
                args=args,
                nav_wide=nav_wide,
            )
            jobs.append(
                make_job(**base, scenario="gross", cost_mode="gross", flat_tcost=0.0, eta=0.0, rebalance=True)
            )
            jobs.append(
                make_job(**base, scenario="net_flat", cost_mode="flat", flat_tcost=flat, eta=0.0, rebalance=True)
            )
            jobs.append(
                make_job(**base, scenario="net_barra", cost_mode="barra", flat_tcost=0.0, eta=eta, rebalance=True)
            )
            if args.buyhold_barra:
                jobs.append(
                    make_job(
                        **base,
                        scenario="bh_barra",
                        cost_mode="barra",
                        flat_tcost=0.0,
                        eta=eta,
                        rebalance=False,
                    )
                )
    mode = capital_mode_label(args)
    if mode == "per_name":
        cap_msg = f"AUM=N*{args.capital_per_name:g}"
    elif mode == "mean_nav":
        cap_msg = f"NAV_medio_csv={args.nav_csv}"
    else:
        cap_msg = f"NAV={args.capital:g}"
    print(
        f"Rodando {len(jobs)} jobs (eta={eta:.6g}, workers={args.workers}, "
        f"freq={args.rebalance_freq}, {cap_msg}, janela={args.start_y}-{args.start_m:02d}.."
        f"{args.end_y}-{args.end_m:02d})...",
        flush=True,
    )
    results = run_jobs(
        jobs,
        workers=args.workers,
        prices_path=paths["prices"],
        rf_path=paths["rf"],
        volume_cache=paths["volume_cache"],
        sigma_cache=paths["sigma"],
        adv_cache=paths["adv"],
    )
    df = pd.DataFrame(results)
    out = paths["out_dir"] / "painel_cenarios.csv"
    df.to_csv(out, index=False)
    print(f"Painel -> {out} ({len(df)} linhas, ok={(df.status=='ok').sum()})", flush=True)
    return df


def _formation_asof_timestamp(formation_yyyymm: str) -> pd.Timestamp:
    y = int(str(formation_yyyymm)[:4])
    m = int(str(formation_yyyymm)[4:6])
    return month_end(y, m)


def _adv_sigma_asof(
    adv_panel: pd.DataFrame,
    sigma_panel: Optional[pd.DataFrame],
    formation_yyyymm: str,
) -> Tuple[pd.Timestamp, pd.Series, Optional[pd.Series]]:
    asof = _formation_asof_timestamp(formation_yyyymm)
    idx = adv_panel.index[adv_panel.index <= asof]
    if len(idx) == 0:
        raise ValueError(f"ADV panel sem datas <= {asof.date()} (formacao {formation_yyyymm})")
    row_date = idx.max()
    adv_row = adv_panel.loc[row_date]
    sig_row: Optional[pd.Series] = None
    if sigma_panel is not None:
        if row_date in sigma_panel.index:
            sig_row = sigma_panel.loc[row_date]
        else:
            pos = sigma_panel.index.get_indexer([row_date], method="ffill")[0]
            if pos >= 0:
                sig_row = sigma_panel.iloc[pos]
    return pd.Timestamp(row_date), adv_row, sig_row


def _ticker_adv(adv_row: pd.Series, ticker: str) -> float:
    v = float(adv_row[ticker]) if ticker in adv_row.index else np.nan
    if not np.isfinite(v) or v <= 0:
        return ADV_FLOOR_BRL
    return v


def _ticker_sigma(sigma_row: Optional[pd.Series], ticker: str) -> float:
    if sigma_row is None or ticker not in sigma_row.index:
        return 0.0
    sig = float(sigma_row[ticker])
    if not np.isfinite(sig) or sig < 0:
        return 0.0
    return sig


def predicted_marginal_bps(
    tickers: Sequence[str],
    *,
    adv_row: pd.Series,
    sigma_row: Optional[pd.Series],
    q_per_name: float,
    eta: float = 1.0,
    mode: str = "rank_n",
) -> Tuple[float, str, float]:
    """Custo BARRA (bps) do nome marginal na formacao.

    mode:
      - ``rank_n`` (default): ultimo ticker da carteira top-N (CSV ADV↓;
        nome recem-incluido ao subir N).
      - ``min_adv``: menor ADV no painel (diagnostico; sensivel a ADV quebrado).

    Retorna (custo_marginal_bps, ticker_marginal, adv_marginal).
    """
    if not tickers:
        return float("nan"), "", float("nan")
    if mode == "min_adv":
        ranked = sorted(
            ((t, _ticker_adv(adv_row, t)) for t in tickers),
            key=lambda x: x[1],
        )
        t_m, adv_m = ranked[0]
    else:
        # top-N: Carteira ordenada ADV decrescente → ultimo = rank N
        t_m = str(tickers[-1])
        adv_m = _ticker_adv(adv_row, t_m)
    sig_m = _ticker_sigma(sigma_row, t_m)
    return (
        barra_unit_bps(sigma=sig_m, adv=adv_m, q=float(q_per_name), eta=float(eta)),
        t_m,
        float(adv_m),
    )


def predicted_open_bps_aumN(
    tickers: Sequence[str],
    *,
    adv_row: pd.Series,
    sigma_row: pd.Series,
    capital_per_name: float,
    eta: float = 1.0,
) -> float:
    """bps do NAV na abertura com q_i = K (AUM = N*K), sigma/ADV na data."""
    n = len(tickers)
    if n == 0:
        return float("nan")
    nav = float(n) * float(capital_per_name)
    q = float(capital_per_name)
    cost = 0.0
    for t in tickers:
        sig = _ticker_sigma(sigma_row, t)
        adv = _ticker_adv(adv_row, t)
        c_unit = float(eta) * sig * float(np.sqrt(q / adv))
        cost += c_unit * q
    return float(10000.0 * cost / nav)


def compute_formacao_metricas_por_N(
    out_dir: Path,
    *,
    adv_panel: pd.DataFrame,
    formation_yyyymm: str,
    ns: Sequence[int],
    sample_n: int,
    seed: int,
    universo_tag: str,
    sigma_panel: Optional[pd.DataFrame] = None,
    capital_per_name: Optional[float] = None,
    capital_fixed: float = DEFAULT_CAPITAL,
    nav_wide: Optional[pd.DataFrame] = None,
    eta: float = 1.0,
) -> pd.DataFrame:
    """Metricas na data de formacao: ADV medio/p10 + custo marginal BARRA vs N."""
    row_date, adv_row, sig_row = _adv_sigma_asof(adv_panel, sigma_panel, formation_yyyymm)
    form_y = int(str(formation_yyyymm)[:4])
    rows: List[Dict[str, Any]] = []
    for n in ns:
        man = sample_manifest_path(
            out_dir,
            int(n),
            int(sample_n),
            int(seed),
            formation_yyyymm=formation_yyyymm,
            universo_tag=universo_tag,
        )
        if not man.exists():
            continue
        payload = json.loads(man.read_text(encoding="utf-8"))
        carteiras = payload.get("carteiras") or []
        means: List[float] = []
        p10s: List[float] = []
        marg_bps: List[float] = []
        marg_advs: List[float] = []
        open_bps: List[float] = []
        marg_tickers: List[str] = []
        if capital_per_name is not None:
            q = float(capital_per_name)
            nav_ref = float(n) * q
        elif nav_wide is not None and int(n) in nav_wide.columns:
            prior_years = [int(y) for y in nav_wide.index if int(y) < form_y]
            if prior_years:
                nav_ref = float(nav_wide.loc[max(prior_years), int(n)])
            elif form_y in nav_wide.index:
                nav_ref = float(nav_wide.loc[form_y, int(n)])
            else:
                nav_ref = float(capital_fixed)
            q = nav_ref / float(n)
        else:
            nav_ref = float(capital_fixed)
            q = nav_ref / float(n)
        for cart in carteiras:
            tickers = [t.strip() for t in str(cart).split(",") if t.strip()]
            if not tickers:
                continue
            vals = [_ticker_adv(adv_row, t) for t in tickers]
            arr = np.asarray(vals, dtype=float)
            means.append(float(np.mean(arr)))
            p10s.append(float(np.quantile(arr, 0.10)))
            c_m, t_m, adv_m = predicted_marginal_bps(
                tickers,
                adv_row=adv_row,
                sigma_row=sig_row,
                q_per_name=q,
                eta=float(eta),
            )
            marg_bps.append(float(c_m))
            marg_advs.append(float(adv_m))
            marg_tickers.append(t_m)
            if capital_per_name is not None and sig_row is not None:
                open_bps.append(
                    predicted_open_bps_aumN(
                        tickers,
                        adv_row=adv_row,
                        sigma_row=sig_row,
                        capital_per_name=float(capital_per_name),
                        eta=float(eta),
                    )
                )
        if not means:
            continue
        row: Dict[str, Any] = {
            "N": int(n),
            "n_portfolios": len(means),
            "adv_asof": str(pd.Timestamp(row_date).date()),
            "adv_mean": float(np.mean(means)),
            "adv_p10": float(np.mean(p10s)),
            "adv_mean_min_port": float(np.min(means)),
            "adv_mean_max_port": float(np.max(means)),
            "custo_marginal_bps": float(np.mean(marg_bps)),
            "adv_marginal": float(np.mean(marg_advs)),
            "q_per_name": float(q),
            "nav_ref": float(nav_ref),
            "eta": float(eta),
        }
        if len(set(marg_tickers)) == 1:
            row["ticker_marginal"] = marg_tickers[0]
        if open_bps:
            row["pred_open_bps"] = float(np.mean(open_bps))
        rows.append(row)
    return pd.DataFrame(rows).sort_values("N") if rows else pd.DataFrame()


def compute_adv_medio_por_N(
    out_dir: Path,
    *,
    adv_panel: pd.DataFrame,
    formation_yyyymm: str,
    ns: Sequence[int],
    sample_n: int,
    seed: int,
    universo_tag: str,
) -> pd.DataFrame:
    """Compat: ADV medio/p10 na formacao (sem custo marginal)."""
    return compute_formacao_metricas_por_N(
        out_dir,
        adv_panel=adv_panel,
        formation_yyyymm=formation_yyyymm,
        ns=ns,
        sample_n=sample_n,
        seed=seed,
        universo_tag=universo_tag,
        sigma_panel=None,
        capital_per_name=None,
        eta=1.0,
    )


def _plot_formacao_primarias(
    formacao: pd.DataFrame,
    out_dir: Path,
    *,
    univ_tag: str,
    formation: str,
    eta: float,
) -> None:
    """Figuras-ancora Marcelo: custo_marginal_bps e adv_p10 vs N."""
    if formacao.empty:
        return
    fig, ax = plt.subplots(figsize=(7, 4.2))
    ax.plot(
        formacao["N"],
        formacao["custo_marginal_bps"],
        marker="o",
        color="#1f4e79",
        label="nome rank N (top-N)",
    )
    ax.set_xlabel("N (ativos)")
    ax.set_ylabel("Custo marginal (bps do notional)", fontsize=8)
    ax.set_title(
        f"Custo do nome marginal vs N ({univ_tag}, formacao {formation}, eta={eta:g})"
    )
    ax.legend(frameon=False)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig_path = out_dir / "figura_custo_marginal_barra_vs_N.png"
    fig.savefig(fig_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Figura primaria (custo marginal) -> {fig_path}", flush=True)

    fig2, ax2 = plt.subplots(figsize=(7, 4.2))
    ax2.plot(
        formacao["N"],
        formacao["adv_p10"] / 1e6,
        marker="o",
        color="#b85c38",
        label="ADV p10",
    )
    if "adv_mean" in formacao.columns:
        ax2.plot(
            formacao["N"],
            formacao["adv_mean"] / 1e6,
            marker="s",
            color="#1f4e79",
            alpha=0.55,
            ls="--",
            label="ADV medio (ref.)",
        )
    ax2.set_xlabel("N (ativos)")
    ax2.set_ylabel("ADV (R$ milhoes)")
    ax2.set_title(f"Liquidez (p10) vs N ({univ_tag}, formacao {formation})")
    ax2.legend(frameon=False)
    ax2.grid(True, alpha=0.3)
    fig2.tight_layout()
    fig2_path = out_dir / "figura_adv_p10_vs_N.png"
    fig2.savefig(fig2_path, dpi=150)
    plt.close(fig2)
    print(f"Figura primaria (ADV p10) -> {fig2_path}", flush=True)


def run_precheck_aumn(
    samples: Dict[int, pd.DataFrame],
    args: argparse.Namespace,
    paths: Dict[str, Path],
) -> pd.DataFrame:
    """Pré-check: ADV↓ / custo marginal↑ com N (formacao); open-bps medio e robustez."""
    if args.capital_per_name is None:
        raise ValueError("--precheck / modo precheck exige --capital-per-name")
    adv = pd.read_pickle(paths["adv"])
    sigma = pd.read_pickle(paths["sigma"])
    row_date, adv_row, sig_row = _adv_sigma_asof(adv, sigma, args.formation_yyyymm)
    assert sig_row is not None
    rows = []
    for n in sorted(samples.keys()):
        sample = samples[n]
        if args.limit is not None:
            sample = sample.iloc[: int(args.limit)].copy()
        adv_means = []
        adv_p10s = []
        bps_list = []
        marg_list = []
        marg_adv_list = []
        q = float(args.capital_per_name)
        for _, row in sample.iterrows():
            tickers = [t.strip() for t in str(row["Carteira"]).split(",") if t.strip()]
            vals = [_ticker_adv(adv_row, t) for t in tickers]
            arr = np.asarray(vals, dtype=float)
            adv_means.append(float(arr.mean()))
            adv_p10s.append(float(np.quantile(arr, 0.10)))
            bps_list.append(
                predicted_open_bps_aumN(
                    tickers,
                    adv_row=adv_row,
                    sigma_row=sig_row,
                    capital_per_name=q,
                    eta=1.0,
                )
            )
            c_m, _, adv_m = predicted_marginal_bps(
                tickers,
                adv_row=adv_row,
                sigma_row=sig_row,
                q_per_name=q,
                eta=1.0,
            )
            marg_list.append(float(c_m))
            marg_adv_list.append(float(adv_m))
        rows.append(
            {
                "N": int(n),
                "n_portfolios": len(adv_means),
                "adv_asof": str(pd.Timestamp(row_date).date()),
                "adv_mean": float(np.mean(adv_means)),
                "adv_p10": float(np.mean(adv_p10s)),
                "custo_marginal_bps": float(np.mean(marg_list)),
                "adv_marginal": float(np.mean(marg_adv_list)),
                "pred_open_bps_eta1": float(np.mean(bps_list)),
            }
        )
    df = pd.DataFrame(rows).sort_values("N")
    out = paths["out_dir"] / "precheck_aumn.csv"
    df.to_csv(out, index=False)
    formacao_csv = paths["out_dir"] / "formacao_metricas_por_N.csv"
    df.to_csv(formacao_csv, index=False)
    print(f"Precheck -> {out}", flush=True)
    print(f"Formacao -> {formacao_csv}", flush=True)
    print(df.to_string(index=False), flush=True)
    _plot_formacao_primarias(
        df,
        paths["out_dir"],
        univ_tag=str(args.universo_tag),
        formation=str(args.formation_yyyymm),
        eta=1.0,
    )
    if len(df) >= 2:
        adv_up = bool(df["adv_mean"].iloc[-1] > df["adv_mean"].iloc[0])
        p10_up = bool(df["adv_p10"].iloc[-1] > df["adv_p10"].iloc[0])
        marg_up = bool(
            df["custo_marginal_bps"].iloc[-1] > df["custo_marginal_bps"].iloc[0]
        )
        cost_up = bool(df["pred_open_bps_eta1"].iloc[-1] > df["pred_open_bps_eta1"].iloc[0])
        print(
            f"ADV medio Nmin->Nmax {'SOBE' if adv_up else 'CAI'}; "
            f"ADV p10 {'SOBE' if p10_up else 'CAI'}; "
            f"custo_marginal_bps {'SOBE' if marg_up else 'CAI'}; "
            f"open-bps medio eta=1 {'SOBE' if cost_up else 'CAI'}",
            flush=True,
        )
        if args.universo_tag.startswith("liq_top") and adv_up:
            print(
                "AVISO: top-N com ADV medio subindo — revisar ordenacao/dedupe do universo.",
                flush=True,
            )
        if args.universo_tag.startswith("liq_top") and p10_up:
            print(
                "AVISO: top-N com ADV p10 subindo — cauda de liquidez nao esta piorando com N.",
                flush=True,
            )
        if args.universo_tag.startswith("liq_top") and not marg_up:
            print(
                "AVISO: custo_marginal_bps nao sobe com N — gradiente de liquidez pode ser insuficiente.",
                flush=True,
            )
        if args.universo_tag.startswith("liq_top") and not cost_up:
            print(
                "AVISO: slope previsto de custo medio (open-bps) ainda negativo com AUM∝N — "
                "usar custo_marginal_bps / ADV p10 na narrativa.",
                flush=True,
            )
    return df


def _cost_monotone_decreasing(costs: Sequence[float]) -> bool:
    vals = [float(x) for x in costs if np.isfinite(x)]
    if len(vals) < 2:
        return False
    return all(vals[i] >= vals[i + 1] for i in range(len(vals) - 1))


def aggregate(
    out_dir: Path,
    *,
    rebalance_freq: str = DEFAULT_REBALANCE_FREQ,
    args: Optional[argparse.Namespace] = None,
    adv_panel: Optional[pd.DataFrame] = None,
) -> Tuple[pd.DataFrame, Path]:
    painel = pd.read_csv(out_dir / "painel_cenarios.csv")
    ok = painel[painel["status"] == "ok"].copy()
    rows = []
    for n, g in ok.groupby("n_ativos"):
        row: Dict[str, Any] = {"N": int(n), "n_portfolios": int(g["strategy"].nunique())}
        for scen, label in [
            ("gross", "gross"),
            ("net_flat", "net_flat"),
            ("net_barra", "net_barra"),
            ("bh_barra", "bh_barra"),
        ]:
            sg = g[g["scenario"] == scen]
            if sg.empty:
                continue
            row[f"sharpe_{label}"] = float(sg["sharpe_excess"].mean())
            row[f"total_excess_{label}"] = float(sg["total_excess_return"].mean())
            row[f"ceq1_{label}"] = float(sg["ceq_gamma1_ann"].mean())
            row[f"mean_cost_bps_{label}"] = float(sg["mean_cost_bps_nav_reb"].mean())
        rows.append(row)
    resumo = pd.DataFrame(rows).sort_values("N")
    path = out_dir / "resumo_por_N.csv"
    resumo.to_csv(path, index=False)

    freq_from_painel = None
    if "rebalance_freq" in ok.columns and ok["rebalance_freq"].notna().any():
        freq_from_painel = str(ok["rebalance_freq"].dropna().iloc[0])
    freq_plot = freq_from_painel or rebalance_freq
    freq_pt = rebalance_freq_label(freq_plot)

    capital_mode = "fixed"
    univ_tag = "liq_1MM"
    capital_per_name: Optional[float] = None
    capital_fixed = DEFAULT_CAPITAL
    nav_wide_agg: Optional[pd.DataFrame] = None
    meta: Dict[str, Any] = {}
    if (out_dir / "meta.json").exists():
        meta = json.loads((out_dir / "meta.json").read_text(encoding="utf-8"))
    if args is not None:
        capital_mode = capital_mode_label(args)
        univ_tag = str(args.universo_tag)
        if getattr(args, "capital_per_name", None) is not None:
            capital_per_name = float(args.capital_per_name)
        elif meta.get("capital_per_name") is not None:
            capital_per_name = float(meta["capital_per_name"])
            if capital_mode == "fixed" and meta.get("capital_mode") == "per_name":
                capital_mode = "per_name"
        capital_fixed = float(args.capital)
        if capital_mode == "mean_nav" and getattr(args, "nav_csv", None):
            nav_wide_agg = load_nav_wide_for_run(args)
    else:
        capital_mode = str(meta.get("capital_mode", "fixed"))
        univ_tag = str(meta.get("universo_tag", univ_tag))
        if meta.get("capital_per_name") is not None:
            capital_per_name = float(meta["capital_per_name"])
        capital_fixed = float(meta.get("capital", DEFAULT_CAPITAL))
        if capital_mode == "mean_nav" and meta.get("nav_csv"):
            nav_path = Path(str(meta["nav_csv"]))
            if nav_path.exists():
                base = float(meta.get("nav_csv_base_capital") or read_nav_csv_base_capital(nav_path))
                nav_wide_agg = scale_nav_wide_to_capital(
                    load_nav_medio_csv(nav_path),
                    capital=capital_fixed,
                    base_capital=base,
                )

    if capital_mode == "per_name":
        cap_note = "AUM=N*K"
    elif capital_mode == "mean_nav":
        cap_note = "NAV medio (CSV)"
    else:
        cap_note = "NAV fixo"

    # Primarias: custo_marginal_bps + adv_p10 na formacao
    formacao = pd.DataFrame()
    try:
        formation = (
            str(args.formation_yyyymm)
            if args is not None
            else str(meta.get("formation_yyyymm", ""))
        )
        seed = int(args.seed) if args is not None else int(meta.get("seed", DEFAULT_SEED))
        sample_n = (
            int(args.sample_n) if args is not None else int(meta.get("sample_n", DEFAULT_SAMPLE_N))
        )
        ns = list(args.ns) if args is not None else list(meta.get("ns", resumo["N"].tolist()))
        adv_df = adv_panel
        if adv_df is None:
            adv_cache = out_dir / "cache" / "adv_21d.pkl"
            if adv_cache.exists():
                adv_df = pd.read_pickle(adv_cache)
        sigma_df: Optional[pd.DataFrame] = None
        sigma_cache = out_dir / "cache" / "sigma_21d.pkl"
        if sigma_cache.exists():
            sigma_df = pd.read_pickle(sigma_cache)
        eta_form = 1.0
        try:
            eta_form = float(load_eta(out_dir, None if args is None else args.eta))
        except FileNotFoundError:
            if args is not None and args.eta is not None:
                eta_form = float(args.eta)
        if adv_df is not None and formation:
            formacao = compute_formacao_metricas_por_N(
                out_dir,
                adv_panel=adv_df,
                formation_yyyymm=formation,
                ns=ns,
                sample_n=sample_n,
                seed=seed,
                universo_tag=univ_tag,
                sigma_panel=sigma_df,
                capital_per_name=capital_per_name,
                capital_fixed=capital_fixed,
                nav_wide=nav_wide_agg,
                eta=eta_form,
            )
            if not formacao.empty:
                form_csv = out_dir / "formacao_metricas_por_N.csv"
                formacao.to_csv(form_csv, index=False)
                # compat com artefatos anteriores
                formacao.to_csv(out_dir / "adv_medio_por_N.csv", index=False)
                print(f"Formacao metricas -> {form_csv}", flush=True)
                _plot_formacao_primarias(
                    formacao,
                    out_dir,
                    univ_tag=univ_tag,
                    formation=formation,
                    eta=eta_form,
                )
                # ADV medio: robustez secundaria (ja ha p10 primario)
                fig_m, ax_m = plt.subplots(figsize=(7, 4.2))
                ax_m.plot(
                    formacao["N"],
                    formacao["adv_mean"] / 1e6,
                    marker="o",
                    color="#1f4e79",
                )
                ax_m.set_xlabel("N (ativos)")
                ax_m.set_ylabel("ADV medio (R$ milhoes)")
                ax_m.set_title(
                    f"Liquidez media vs N — robustez ({univ_tag}, formacao {formation})"
                )
                ax_m.grid(True, alpha=0.3)
                fig_m.tight_layout()
                fig_m_path = out_dir / "figura_adv_medio_vs_N.png"
                fig_m.savefig(fig_m_path, dpi=150)
                plt.close(fig_m)
                print(f"Figura secundaria (ADV medio) -> {fig_m_path}", flush=True)
    except Exception as exc:  # noqa: BLE001
        print(f"AVISO: nao foi possivel gerar metricas de formacao vs N: {exc}", flush=True)

    # Secundaria: custo medio do backteste (path)
    if "mean_cost_bps_net_barra" in resumo.columns:
        fig, ax = plt.subplots(figsize=(7, 4.2))
        ax.plot(resumo["N"], resumo["mean_cost_bps_net_barra"], marker="o", color="#1f4e79")
        ax.axhline(12.0, color="#888888", ls="--", lw=1, label="baseline 12 bps")
        ax.set_xlabel("N (ativos)")
        ax.set_ylabel("Custo medio (bps do NAV / rebalance)", fontsize=8)
        ax.set_title(
            f"Impacto de mercado medio vs N — robustez ({univ_tag}, 1/N {freq_pt}, {cap_note})"
        )
        ax.legend(frameon=False)
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig_path = out_dir / "figura_custo_barra_vs_N.png"
        fig.savefig(fig_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Figura secundaria (custo medio path) -> {fig_path}", flush=True)

    if args is not None and getattr(args, "require_cost_up_with_n", False):
        if not formacao.empty and "custo_marginal_bps" in formacao.columns:
            costs = formacao["custo_marginal_bps"].tolist()
            label = "custo_marginal_bps"
        else:
            costs = resumo.get("mean_cost_bps_net_barra", pd.Series(dtype=float)).tolist()
            label = "mean_cost_bps_net_barra"
        if _cost_monotone_decreasing(costs):
            msg = (
                f"FAIL --require-cost-up-with-n: {label} "
                f"cai monotonamente com N: {costs}"
            )
            print(msg, flush=True)
            raise RuntimeError(msg)

    latex = latex_table(resumo)
    tex_path = out_dir / "tabela_barra_cap7.tex"
    tex_path.write_text(latex, encoding="utf-8")
    print(f"Resumo -> {path}", flush=True)
    print(f"LaTeX -> {tex_path}", flush=True)
    return resumo, path


def latex_table(resumo: pd.DataFrame) -> str:
    lines = [
        r"% Gerado por run_sensibilidade_barra_pf.py",
        r"\begin{tabular}{rccccccc}",
        r"\hline",
        r"$N$ & Sharpe gross & Sharpe flat & Sharpe BARRA & Exc. gross & Exc. flat & Exc. BARRA & Custo BARRA (bps) \\",
        r"\hline",
    ]
    for _, r in resumo.iterrows():
        lines.append(
            f"{int(r['N'])} & "
            f"{r.get('sharpe_gross', float('nan')):.3f} & "
            f"{r.get('sharpe_net_flat', float('nan')):.3f} & "
            f"{r.get('sharpe_net_barra', float('nan')):.3f} & "
            f"{r.get('total_excess_gross', float('nan')):.3f} & "
            f"{r.get('total_excess_net_flat', float('nan')):.3f} & "
            f"{r.get('total_excess_net_barra', float('nan')):.3f} & "
            f"{r.get('mean_cost_bps_net_barra', float('nan')):.2f} \\\\"
        )
    lines += [r"\hline", r"\end{tabular}", ""]
    return "\n".join(lines)


def write_meta(out_dir: Path, args: argparse.Namespace, extra: Dict[str, Any]) -> None:
    cap_per = (
        float(args.capital_per_name)
        if getattr(args, "capital_per_name", None) is not None
        else None
    )
    nav_csv = str(args.nav_csv) if getattr(args, "nav_csv", None) else None
    hint_extra = ""
    if cap_per is not None:
        hint_extra = f" --capital-per-name {cap_per:g}"
    elif nav_csv:
        hint_extra = f" --nav-csv {nav_csv}"
    else:
        hint_extra = " --no-nav-csv"
    meta = {
        "created_at": pd.Timestamp.now("UTC").isoformat(),
        "seed": args.seed,
        "sample_n": args.sample_n,
        "ns": list(args.ns),
        "window": f"{args.start_y}-{args.start_m:02d} .. {args.end_y}-{args.end_m:02d}",
        "start_y": args.start_y,
        "start_m": args.start_m,
        "end_y": args.end_y,
        "end_m": args.end_m,
        "rebalance_freq": args.rebalance_freq,
        "rebalance_month": args.rebalance_month,
        "universo_tag": args.universo_tag,
        "formation_yyyymm": args.formation_yyyymm,
        "calib_n": args.calib_n,
        "calib_target_bps": args.calib_target_bps,
        "flat_bps": args.flat_bps,
        "capital": args.capital,
        "capital_mode": capital_mode_label(args),
        "capital_per_name": cap_per,
        "nav_csv": nav_csv,
        "nav_csv_base_capital": (
            read_nav_csv_base_capital(Path(nav_csv)) if nav_csv else None
        ),
        "apply_stock_ir": args.apply_stock_ir,
        "vol_window": VOL_WINDOW,
        "adv_floor_brl": ADV_FLOOR_BRL,
        "require_cost_up_with_n": bool(getattr(args, "require_cost_up_with_n", False)),
        "full_run_hint": (
            "python codigo_fonte/run_sensibilidade_barra_pf.py --mode all "
            f"--sample-n {args.sample_n} --ns {' '.join(map(str, args.ns))} "
            f"--rebalance-freq {args.rebalance_freq} "
            f"--start-y {args.start_y} --start-m {args.start_m} "
            f"--end-y {args.end_y} --end-m {args.end_m} "
            f"--formation-yyyymm {args.formation_yyyymm} --workers {args.workers}"
            f"{hint_extra}"
        ),
        **extra,
    }
    (out_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description=(
            "Sensibilidade BARRA market-impact (Cap. 7). "
            "Parametros: amostra (--sample-n), tamanhos (--ns), janela "
            "(--start-y/m --end-y/m), periodicidade (--rebalance-freq), "
            "escala de capital (--nav-csv, --capital ou --capital-per-name)."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument(
        "--mode",
        choices=("calibrate", "run", "aggregate", "all", "precheck"),
        default="all",
    )
    p.add_argument(
        "--ns",
        type=int,
        nargs="+",
        default=list(DEFAULT_NS),
        help="Lista de N (ativos por carteira). Ex.: --ns 8 15 20 30 40",
    )
    p.add_argument(
        "--sample-n",
        type=int,
        default=DEFAULT_SAMPLE_N,
        help="Numero de carteiras amostradas por N (seed fixa)",
    )
    p.add_argument("--seed", type=int, default=DEFAULT_SEED)
    p.add_argument("--workers", type=int, default=DEFAULT_WORKERS)
    p.add_argument("--limit", type=int, default=None, help="Limita carteiras por N (debug)")
    p.add_argument("--eta", type=float, default=None, help="Override eta")
    p.add_argument("--flat-bps", type=float, default=DEFAULT_FLAT_BPS)
    p.add_argument(
        "--nav-csv",
        type=Path,
        default=DEFAULT_NAV_CSV,
        help=(
            "CSV de NAV medio ano a ano × N (R$, capital base R$ 10.000). "
            "Dimensiona notional/custo BARRA (modo mean_nav). "
            "Se --capital ≠ 10000, reescala por capital/10000. "
            "Ignorado com --capital-per-name ou --no-nav-csv."
        ),
    )
    p.add_argument(
        "--no-nav-csv",
        action="store_true",
        help="Desliga o CSV e volta ao NAV inicial fixo (--capital)",
    )
    p.add_argument(
        "--capital",
        type=float,
        default=DEFAULT_CAPITAL,
        help=(
            f"Capital inicial do wealth path em R$ (default {DEFAULT_CAPITAL:g}; "
            "mesmo valor-base do CSV de NAV medio Cap. 7)"
        ),
    )
    p.add_argument(
        "--capital-per-name",
        type=float,
        default=None,
        help="Se setado, AUM = N * K (posicao constante por nome; painel Marcelo)",
    )
    p.add_argument(
        "--require-cost-up-with-n",
        action="store_true",
        help=(
            "Em aggregate, falha se custo_marginal_bps (formacao) cair monotonamente com N; "
            "fallback: mean_cost_bps_net_barra"
        ),
    )
    p.add_argument("--start-y", type=int, default=DEFAULT_START_Y, help="Ano inicio do backtest")
    p.add_argument("--start-m", type=int, default=DEFAULT_START_M, help="Mes inicio do backtest")
    p.add_argument("--end-y", type=int, default=DEFAULT_END_Y, help="Ano fim do backtest")
    p.add_argument("--end-m", type=int, default=DEFAULT_END_M, help="Mes fim do backtest")
    p.add_argument(
        "--rebalance-freq",
        choices=list(REBALANCE_FREQS),
        default=DEFAULT_REBALANCE_FREQ,
        help="Periodicidade de rebalanceamento (buy-and-hold = cenario bh_barra)",
    )
    p.add_argument(
        "--rebalance-month",
        type=int,
        default=DEFAULT_REBALANCE_MONTH,
        help="Mes ancora para annual/semiannual (1-12)",
    )
    p.add_argument(
        "--universo-tag",
        default=DEFAULT_UNIVERSO_TAG,
        help="Tag do CSV de carteiras (ex.: liq_1MM, liq_top_1MM)",
    )
    p.add_argument(
        "--formation-yyyymm",
        default=None,
        help=(
            "YYYYMM do CSV de formacao (ex.: 200106, 201106). "
            "Default: junho do ano de --start-y se --start-m=7"
        ),
    )
    p.add_argument(
        "--calib-n",
        type=int,
        default=DEFAULT_CALIB_N,
        help="N usado na calibracao de eta (deve estar em --ns)",
    )
    p.add_argument(
        "--calib-target-bps",
        type=float,
        default=DEFAULT_CALIB_TARGET_BPS,
        help="Alvo de custo medio (bps do NAV) na mediana das carteiras de --calib-n",
    )
    p.add_argument("--apply-stock-ir", action="store_true", default=True)
    p.add_argument("--no-ir", action="store_true")
    p.add_argument("--buyhold-barra", action="store_true", default=True)
    p.add_argument("--no-buyhold-barra", action="store_true")
    p.add_argument(
        "--benchmark-one",
        action="store_true",
        help="Smoke: 1 carteira no primeiro N de --ns (ou --calib-n)",
    )
    p.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    p.add_argument("--prices", type=Path, default=DEFAULT_PRICES_PATH)
    p.add_argument("--rf", type=Path, default=DEFAULT_RF_PATH)
    p.add_argument("--volume", type=Path, default=DEFAULT_VOLUME_XLSX)
    p.add_argument("--carteiras-dir", type=Path, default=DEFAULT_CARTEIRAS_DIR)
    args = p.parse_args(argv)
    if args.no_ir:
        args.apply_stock_ir = False
    if args.no_buyhold_barra:
        args.buyhold_barra = False
    if not 1 <= int(args.rebalance_month) <= 12:
        p.error("--rebalance-month deve estar em 1..12")
    if args.formation_yyyymm is None:
        args.formation_yyyymm = default_formation_yyyymm(args.start_y, args.start_m)
    else:
        raw = str(args.formation_yyyymm).strip()
        if not (len(raw) == 6 and raw.isdigit()):
            p.error("--formation-yyyymm deve ser YYYYMM (6 digitos)")
        args.formation_yyyymm = raw
    if int(args.calib_n) not in set(int(x) for x in args.ns):
        # allow and warn later only when calibrating; for run with --eta it's ok
        pass
    if int(args.sample_n) < 1:
        p.error("--sample-n deve ser >= 1")
    if any(int(n) < 1 for n in args.ns):
        p.error("--ns deve conter inteiros >= 1")
    if args.capital_per_name is not None and float(args.capital_per_name) <= 0:
        p.error("--capital-per-name deve ser > 0")
    if args.mode == "precheck" and args.capital_per_name is None:
        p.error("--mode precheck exige --capital-per-name")
    if args.no_nav_csv or args.capital_per_name is not None:
        args.nav_csv = None
    elif args.nav_csv is not None:
        args.nav_csv = Path(args.nav_csv)
        if not args.nav_csv.exists():
            p.error(f"--nav-csv nao encontrado: {args.nav_csv}")
        base = read_nav_csv_base_capital(args.nav_csv)
        if abs(float(args.capital) - float(base)) > 1e-6:
            print(
                f"[AVISO] CSV de NAV medio gerado com capital base R${base:g}; "
                f"--capital={args.capital:g} → reescalando NAV por "
                f"{float(args.capital)/float(base):.6g}.",
                flush=True,
            )
    return args


def benchmark_one(args: argparse.Namespace, paths: Dict[str, Path]) -> None:
    n_bench = int(args.calib_n) if int(args.calib_n) in set(args.ns) else int(args.ns[0])
    print(
        f"=== benchmark-one N={n_bench} freq={args.rebalance_freq} "
        f"janela={args.start_y}-{args.start_m:02d}..{args.end_y}-{args.end_m:02d} ===",
        flush=True,
    )
    path = carteiras_path_for_n(
        n_bench,
        args.carteiras_dir,
        universo_tag=args.universo_tag,
        formation_yyyymm=args.formation_yyyymm,
    )
    df = load_carteiras_csv(path)
    sample = build_deterministic_sample(df, n=min(int(args.sample_n), len(df)), seed=args.seed)
    row = sample.iloc[0]
    _init_worker(
        str(paths["prices"]),
        str(paths["rf"]),
        str(paths["volume_cache"]),
        str(paths["sigma"]),
        str(paths["adv"]),
    )
    eta = args.eta if args.eta is not None else 1.0
    flat = args.flat_bps / 10000.0
    last = None
    for scenario, mode, ft, et in [
        ("gross", "gross", 0.0, 0.0),
        ("net_flat", "flat", flat, 0.0),
        ("net_barra", "barra", 0.0, eta),
    ]:
        job = make_job(
            n_ativos=n_bench,
            strategy=row["strategy"],
            tickers_csv=row["Carteira"],
            scenario=scenario,
            cost_mode=mode,
            flat_tcost=ft,
            eta=et,
            rebalance=True,
            args=args,
        )
        last = _worker_one(job)
        print(
            json.dumps(
                {
                    k: last.get(k)
                    for k in (
                        "scenario",
                        "status",
                        "rebalance_freq",
                        "sharpe_excess",
                        "mean_cost_bps_nav_reb",
                        "mean_raw_cost_bps_nav_eta1_reb",
                        "n_rebalance_cost_events",
                        "elapsed_s",
                        "error",
                    )
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
    if last is None or last.get("status") != "ok":
        raise SystemExit(1)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    out_dir = args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    print("Carregando precos/RF/volume...", flush=True)
    t0 = time.perf_counter()
    df_prices = load_prices(args.prices)
    vol_cache = volume_cache_path(out_dir)
    volume_brl = load_volume_brl(args.volume, vol_cache)
    print(
        f"  prices={df_prices.shape} volume={volume_brl.shape} em {time.perf_counter()-t0:.1f}s",
        flush=True,
    )

    sigma_path, adv_path = ensure_sigma_adv_cache(out_dir, df_prices, volume_brl)
    paths = {
        "out_dir": out_dir,
        "prices": args.prices,
        "rf": args.rf,
        "volume_cache": vol_cache,
        "sigma": sigma_path,
        "adv": adv_path,
    }

    if args.benchmark_one:
        benchmark_one(args, paths)
        write_meta(out_dir, args, {"benchmark_one": True})
        return 0

    extra: Dict[str, Any] = {}

    if args.mode == "aggregate":
        adv_panel = pd.read_pickle(adv_path)
        resumo, _ = aggregate(
            out_dir,
            rebalance_freq=args.rebalance_freq,
            args=args,
            adv_panel=adv_panel,
        )
        extra["resumo_N"] = resumo.to_dict(orient="records")
        try:
            extra["eta"] = load_eta(out_dir, args.eta)
        except FileNotFoundError:
            pass
        write_meta(out_dir, args, extra)
        print("Concluido.", flush=True)
        return 0

    print(
        f"Config: sample-n={args.sample_n} ns={list(args.ns)} "
        f"freq={args.rebalance_freq} month={args.rebalance_month} "
        f"janela={args.start_y}-{args.start_m:02d}..{args.end_y}-{args.end_m:02d} "
        f"formacao={args.formation_yyyymm} universo={args.universo_tag} "
        f"calib-n={args.calib_n} capital_mode={capital_mode_label(args)}"
        + (
            f" K={args.capital_per_name:g}"
            if args.capital_per_name is not None
            else (
                f" nav_csv={args.nav_csv}"
                if args.nav_csv is not None
                else f" capital={args.capital:g}"
            )
        ),
        flush=True,
    )

    samples = load_or_build_samples(
        out_dir,
        args.ns,
        args.sample_n,
        args.seed,
        args.carteiras_dir,
        universo_tag=args.universo_tag,
        formation_yyyymm=args.formation_yyyymm,
    )

    if args.mode == "precheck":
        pre = run_precheck_aumn(samples, args, paths)
        extra["precheck_aumn"] = pre.to_dict(orient="records")
        write_meta(out_dir, args, extra)
        print("Concluido (precheck).", flush=True)
        return 0

    if args.mode in ("calibrate", "all"):
        calib = calibrate_eta(samples, args, paths)
        extra["calibration"] = calib
        eta = float(calib["eta"])
    else:
        eta = load_eta(out_dir, args.eta)
        extra["eta"] = eta

    if args.mode in ("run", "all"):
        if args.mode == "run":
            eta = load_eta(out_dir, args.eta)
        run_full(samples, args, paths, eta)
        extra["eta_used"] = eta
        extra["run_sample_n"] = int(args.sample_n)
        if args.limit is not None:
            extra["limit"] = int(args.limit)

    if args.mode in ("aggregate", "all", "run"):
        # run tambem agrega para entregar resumo/figura na mesma saida
        if (out_dir / "painel_cenarios.csv").exists():
            adv_panel = pd.read_pickle(adv_path)
            resumo, _ = aggregate(
                out_dir,
                rebalance_freq=args.rebalance_freq,
                args=args,
                adv_panel=adv_panel,
            )
            extra["resumo_N"] = resumo.to_dict(orient="records")

    write_meta(out_dir, args, extra)
    print("Concluido.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

