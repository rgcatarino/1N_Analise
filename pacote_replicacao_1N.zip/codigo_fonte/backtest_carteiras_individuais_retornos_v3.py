"""Backtest de carteiras individuais (v3) — universo líquido.

Lê carteiras de um CSV (uma carteira por linha, coluna Carteira), executa
Equal Weight com ou sem rebalanceamento e grava resultados no MongoDB
Backtest_Mestrado_PF_LIQUIDEZ_1MM.

Exemplo:
    python codigo_fonte/backtest_carteiras_individuais_retornos_v3.py \\
      --carteiras resultados/carteiras_aleatorias_liquidas/carteiras_8atv.csv \\
      --start-m 7 --start-y 2001 \\
      --end-m 10 --end-y 2025 \\
      --rebalance --rebalance-freq annual \\
      --tcost-bps 122 \\
      --no-apply-stock-ir
"""

from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import bt
import numpy as np
import pandas as pd
from pymongo import MongoClient

sys.path.insert(0, str(Path(__file__).resolve().parent))

import backtest_carteiras_individuais_retornos_v2 as v2  # noqa: E402
from backtest_carteiras_individuais_retornos_v2 import (  # noqa: E402
    DEFAULT_IR_MONTHLY_SALES_EXEMPTION,
    DEFAULT_IR_RATE,
    BatchRunProgress,
    _recompute_return_metrics,
    _smooth_abs_quantity,
    adjust_nav_for_ir_payments,
    compute_stock_ir_on_rebalances,
    load_collection_as_df,
    load_prices,
    save_res_display_only_to_mongo,
    save_series_in_collection,
    upsert_aux_metrics,
)

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_PRICES_PATH = REPO_ROOT / "ibov" / "prices_adjust_close_B3_economatica_1986-out_2025.csv"
DEFAULT_RF_PATH = REPO_ROOT / "nefin_RF.csv"
DEFAULT_DB_NAME = "Backtest_Mestrado_PF_LIQUIDEZ_1MM"
DEFAULT_MONGO_URI = "mongodb://172.23.224.1:27017/"
REBALANCE_FREQS = ("monthly", "quarterly", "semiannual", "annual")

SETUP_SUBSTEPS = (
    "Carregar preços",
    "Carregar taxa livre de risco (RF)",
    "Carregar carteiras do CSV",
    "Conectar ao MongoDB",
    "Verificar estratégias já processadas",
)

PORTFOLIO_SUBSTEPS = (
    "Executar backtest EW",
    "Salvar res.display no MongoDB",
    "Salvar métricas auxiliares",
    "Salvar série de retorno acumulado",
    "Salvar série de retorno em excesso",
)


@dataclass
class LiquidezBacktestConfig:
    carteiras_path: Path
    start_y: int
    start_m: int
    end_y: int
    end_m: int
    rebalance: bool
    rebalance_freq: str
    rebalance_month: int
    tcost: float
    tcost_bps: float
    apply_stock_ir: bool
    ir_rate: float
    ir_monthly_sales_exemption: float
    mongo_uri: str
    db_name: str
    prices_path: Path
    rf_path: Path
    capital: float
    collections_suffix: str
    limit: int
    skip_failed: bool


def bps_to_fraction(bps: float) -> float:
    return float(bps) / 10_000.0


def month_end(year: int, month: int) -> pd.Timestamp:
    return pd.Timestamp(year=year, month=month, day=1) + pd.offsets.MonthEnd(0)


def infer_n_ativos(path: Path, n_from_row: int) -> int:
    match = re.search(r"(\d+)atv", path.stem, flags=re.IGNORECASE)
    if match:
        return int(match.group(1))
    return n_from_row


def build_collections_suffix(config: LiquidezBacktestConfig, n_ativos: int) -> str:
    reb = f"reb-{config.rebalance_freq}" if config.rebalance else "buyhold"
    ir_tag = "ir" if config.apply_stock_ir else "noir"
    t_bps = int(round(config.tcost_bps))
    return (
        f"{n_ativos}atv_{config.start_y}{config.start_m:02d}_"
        f"{config.end_y}{config.end_m:02d}_{reb}_t{t_bps}bps_{ir_tag}"
    )


def load_carteiras_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    if "Carteira" not in df.columns:
        if df.shape[1] == 1:
            df = df.rename(columns={df.columns[0]: "Carteira"})
        else:
            raise ValueError(
                f"{path} precisa ter a coluna 'Carteira' ou uma única coluna de tickers."
            )

    rows: List[dict] = []
    for i, raw in enumerate(df["Carteira"].astype(str), start=1):
        tickers = [t.strip().upper() for t in str(raw).split(",") if t.strip()]
        if not tickers:
            continue
        rows.append(
            {
                "Carteira": ",".join(tickers),
                "tickers": tickers,
                "Base": f"{path.stem}#{i:05d}",
                "Total_papeis": len(tickers),
            }
        )
    if not rows:
        raise ValueError(f"Nenhuma carteira válida em {path}.")
    return pd.DataFrame(rows)


def _first_trading_day(index: pd.DatetimeIndex, year: int, month: int) -> Optional[pd.Timestamp]:
    days = index[(index.year == year) & (index.month == month)]
    if len(days) == 0:
        return None
    return pd.Timestamp(days.min())


def build_rebalance_dates(
    index: pd.DatetimeIndex,
    *,
    freq: str,
    annual_month: int,
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> List[pd.Timestamp]:
    if freq not in REBALANCE_FREQS:
        raise ValueError(f"Periodicidade inválida: {freq}. Use {REBALANCE_FREQS}.")

    if freq == "monthly":
        months: Tuple[int, ...] = tuple(range(1, 13))
    elif freq == "quarterly":
        months = (1, 4, 7, 10)
    elif freq == "semiannual":
        other = annual_month + 6
        if other > 12:
            other -= 12
        months = tuple(sorted({int(annual_month), int(other)}))
    else:
        months = (int(annual_month),)

    dates: List[pd.Timestamp] = []
    for year in range(int(start.year), int(end.year) + 1):
        for month in months:
            day = _first_trading_day(index, year, month)
            if day is not None and start <= day <= end:
                dates.append(day)

    dates = sorted(set(dates))
    start = pd.Timestamp(start)
    if not dates or dates[0] != start:
        dates = [start] + [d for d in dates if d > start]
    return dates


def _safe_get_transactions_from_strategy(strategy) -> Optional[pd.DataFrame]:
    prc = pd.DataFrame({x.name: x.prices for x in strategy.securities}).unstack()

    positions = pd.DataFrame()
    for x in strategy.securities:
        if x.name in positions.columns:
            positions[x.name] = positions[x.name].add(x.positions, fill_value=0.0)
        else:
            positions[x.name] = x.positions

    trades = positions.diff()
    if len(trades) > 0:
        trades.iloc[0, :] = positions.iloc[0, :]

    trades = trades.where(trades != 0).unstack().dropna()
    if getattr(strategy, "_bidoffer_set", False):
        bidoffer = pd.DataFrame({x.name: x.bidoffers_paid for x in strategy.securities}).unstack()
        prc = prc.add(bidoffer.div(trades), fill_value=0.0)

    tx = pd.DataFrame({"price": prc, "quantity": trades}).dropna(subset=["quantity"])
    tx.index.names = ["Security", "Date"]
    return tx.swaplevel().sort_index()


def _turnover_from_tx(tx: Optional[pd.DataFrame], nav: pd.Series, *, zero_first: bool) -> pd.Series:
    turnover_series = pd.Series(0.0, index=nav.index)
    if tx is None or getattr(tx, "empty", True):
        return turnover_series
    try:
        if isinstance(tx.index, pd.MultiIndex):
            dts = pd.to_datetime(tx.index.get_level_values(0))
        else:
            dts = pd.to_datetime(tx.index)

        if ("quantity" in tx.columns) and ("price" in tx.columns):
            traded_line = tx["quantity"].abs() * tx["price"]
        elif "value" in tx.columns:
            traded_line = tx["value"].abs()
        else:
            traded_line = tx.select_dtypes(include=[np.number]).abs().sum(axis=1)

        traded_line = pd.Series(traded_line.values, index=dts).replace([np.inf, -np.inf], np.nan).dropna()
        if traded_line.empty:
            return turnover_series

        traded_value_by_day = traded_line.groupby(traded_line.index).sum()
        nav_on_trade_days = nav.reindex(traded_value_by_day.index)
        turnover_trade_days = (traded_value_by_day / nav_on_trade_days).replace([np.inf, -np.inf], np.nan)
        turnover_series = turnover_trade_days.reindex(nav.index).fillna(0.0)
        if zero_first and not traded_value_by_day.empty:
            first_td = traded_value_by_day.index.min()
            if first_td in turnover_series.index:
                turnover_series.loc[first_td] = 0.0
    except Exception:
        return pd.Series(0.0, index=nav.index)
    return turnover_series


def prepare_price_window(
    df_prices: pd.DataFrame,
    tickers: Sequence[str],
    start_y: int,
    start_m: int,
    end_y: int,
    end_m: int,
) -> pd.DataFrame:
    if "Date" not in df_prices.columns:
        raise ValueError("df_prices precisa ter a coluna 'Date'.")

    missing = [c for c in tickers if c not in df_prices.columns]
    if missing:
        raise ValueError(f"Colunas ausentes no CSV de preços: {missing}")

    px = df_prices.copy()
    px["Date"] = pd.to_datetime(px["Date"])
    px = px.sort_values("Date").set_index("Date")
    prices = px[list(tickers)].apply(pd.to_numeric, errors="coerce").sort_index().ffill()

    end_target = month_end(end_y, end_m)
    prices = prices.loc[:end_target]
    start_month = prices[(prices.index.year == start_y) & (prices.index.month == start_m)]
    if start_month.empty:
        raise ValueError(f"Não há pregão em {start_m:02d}/{start_y} no CSV de preços.")
    start_target = start_month.index.min()
    prices = prices.loc[start_target:].ffill().dropna(how="any")
    if prices.empty:
        raise ValueError("Após limpar NaNs, não restou período com preços para todos os tickers.")
    return prices


def run_bt_backtest_ew(
    df_prices: pd.DataFrame,
    tickers: list,
    tcost: float,
    start_y: int,
    start_m: int,
    end_y: int,
    end_m: int,
    initial_capital: float,
    *,
    rebalance: bool,
    rebalance_freq: str = "annual",
    rebalance_month: int = 7,
    strat_name: str = "EW",
    rf_df: Optional[pd.DataFrame] = None,
    rf_date_col: str = "DATE",
    rf_col: str = "RF",
    rf_align_fill: str = "ffill",
    ann_factor: int = 252,
    integer_positions: bool = False,
    smooth_abs_eps: float = 1e-10,
    apply_stock_ir: bool = False,
    ir_rate: float = DEFAULT_IR_RATE,
    ir_monthly_sales_exemption: float = DEFAULT_IR_MONTHLY_SALES_EXEMPTION,
):
    prices = prepare_price_window(df_prices, tickers, start_y, start_m, end_y, end_m)
    start_target = prices.index.min()
    end_target = prices.index.max()

    if rebalance:
        rebalance_dates = build_rebalance_dates(
            prices.index,
            freq=rebalance_freq,
            annual_month=rebalance_month,
            start=start_target,
            end=end_target,
        )
        if not rebalance_dates:
            raise ValueError("Não foi possível montar datas de rebalanceamento no período.")
        run_algo = bt.algos.RunOnDate(*rebalance_dates)
    else:
        rebalance_dates = [pd.Timestamp(start_target)]
        run_algo = bt.algos.RunOnce()

    def commissions(q, p):
        qf = float(q)
        pf = float(p)
        return _smooth_abs_quantity(qf, smooth_abs_eps) * pf * float(tcost)

    strategy = bt.Strategy(
        strat_name,
        [
            run_algo,
            bt.algos.SelectThese(list(tickers)),
            bt.algos.WeighEqually(),
            bt.algos.Rebalance(),
        ],
    )
    test = bt.Backtest(
        strategy,
        prices,
        initial_capital=float(initial_capital),
        commissions=commissions,
        integer_positions=bool(integer_positions),
    )
    test.name = str(strat_name)
    res = bt.run(test)

    try:
        tx = _safe_get_transactions_from_strategy(res.backtests[test.name].strategy)
    except Exception:
        tx = None

    nav = res.prices[test.name].dropna()
    nav_gross = nav.copy()
    total_return_gross = nav_gross.iloc[-1] / nav_gross.iloc[0] - 1.0
    ir_payments = pd.Series(dtype=float)
    if apply_stock_ir and rebalance:
        ir_payments = compute_stock_ir_on_rebalances(
            tx,
            rebalance_dates,
            ir_rate=ir_rate,
            monthly_sales_exemption=ir_monthly_sales_exemption,
        )
        nav = adjust_nav_for_ir_payments(
            nav,
            ir_payments,
            initial_capital=float(initial_capital),
        )

    rf = None
    if rf_df is not None:
        rf_local = rf_df.copy()
        if rf_date_col not in rf_local.columns:
            for cand in ("Date", "date", "DATA", "data"):
                if cand in rf_local.columns:
                    rf_date_col = cand
                    break
        if rf_col not in rf_local.columns:
            for cand in ("Rf", "rf", "RISKFREE", "risk_free"):
                if cand in rf_local.columns:
                    rf_col = cand
                    break
        if rf_date_col not in rf_local.columns or rf_col not in rf_local.columns:
            raise ValueError(f"RF DF precisa ter colunas de data e RF. Colunas: {list(rf_local.columns)}")
        rf_local[rf_date_col] = pd.to_datetime(rf_local[rf_date_col])
        rf_local = rf_local.sort_values(rf_date_col).set_index(rf_date_col)
        rf = pd.to_numeric(rf_local[rf_col], errors="coerce").sort_index().reindex(nav.index)
        if rf_align_fill == "ffill":
            rf = rf.ffill().bfill()
        elif rf_align_fill == "bfill":
            rf = rf.bfill().ffill()

    metrics = _recompute_return_metrics(nav, rf, ann_factor)
    turnover_series = _turnover_from_tx(tx, nav, zero_first=not rebalance)
    avg_turnover_all_days = float(turnover_series.mean()) if len(turnover_series) else np.nan
    avg_turnover_trade_days = (
        float(turnover_series[turnover_series > 0].mean()) if (turnover_series > 0).any() else 0.0
    )
    total_ir_paid = float(ir_payments.sum()) if len(ir_payments) else 0.0

    aux = {
        "prices": prices,
        "rebalance": bool(rebalance),
        "rebalance_freq": rebalance_freq if rebalance else "none",
        "rebalance_dates": rebalance_dates,
        "nav": nav,
        "returns": metrics["returns"],
        "rf": rf,
        "excess_returns": metrics["excess_returns"],
        "drawdown": metrics["drawdown"],
        "retorno_acumulado_pct": metrics["retorno_acumulado_pct"],
        "retorno_excesso_acumulado_pct": metrics["retorno_excesso_acumulado_pct"],
        "sharpe_excess": metrics["sharpe_excess"],
        "vol_excess_ann": metrics["vol_excess_ann"],
        "cagr": metrics["cagr"],
        "total_return": metrics["total_return"],
        "total_return_gross": float(total_return_gross),
        "total_excess_return": metrics["total_excess_return"],
        "ceq_gamma1_daily": metrics["ceq_gamma1_daily"],
        "ceq_gamma1_ann": metrics["ceq_gamma1_ann"],
        "ceq_base": metrics["ceq_base"],
        "turnover": turnover_series,
        "avg_turnover": avg_turnover_all_days,
        "avg_turnover_trade_days": avg_turnover_trade_days,
        "n_trade_days": int((turnover_series > 0).sum()),
        "bt_test_name": test.name,
        "apply_stock_ir": bool(apply_stock_ir and rebalance),
        "ir_rate": float(ir_rate) if apply_stock_ir and rebalance else None,
        "ir_monthly_sales_exemption": (
            float(ir_monthly_sales_exemption) if apply_stock_ir and rebalance else None
        ),
        "total_ir_paid": total_ir_paid,
        "tcost": float(tcost),
    }
    return res, aux


def parse_args(argv: Optional[Iterable[str]] = None) -> LiquidezBacktestConfig:
    parser = argparse.ArgumentParser(
        description=(
            "Backtest EW de carteiras líquidas (CSV) com rebalanceamento opcional, "
            "custo em bps e IR. Grava em Backtest_Mestrado_PF_LIQUIDEZ_1MM."
        )
    )
    parser.add_argument(
        "--carteiras",
        type=Path,
        required=True,
        help="CSV de carteiras (ex.: resultados/carteiras_aleatorias_liquidas/carteiras_8atv.csv)",
    )
    parser.add_argument("--start-m", type=int, default=7, help="Mês de início (default: 7)")
    parser.add_argument("--start-y", type=int, default=2001, help="Ano de início (default: 2001)")
    parser.add_argument("--end-m", type=int, default=10, help="Mês de fim (default: 10)")
    parser.add_argument("--end-y", type=int, default=2025, help="Ano de fim (default: 2025)")
    parser.add_argument(
        "--rebalance",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Aplica rebalanceamento (default: sim). Use --no-rebalance para buy-and-hold.",
    )
    parser.add_argument(
        "--rebalance-freq",
        choices=REBALANCE_FREQS,
        default="annual",
        help="Periodicidade do rebalanceamento (default: annual)",
    )
    parser.add_argument(
        "--rebalance-month",
        type=int,
        default=7,
        help="Mês âncora do rebalanceamento anual/semestral (default: 7 = julho)",
    )
    parser.add_argument(
        "--tcost-bps",
        type=float,
        default=122.0,
        help="Custo de transação em bps (default: 122 = 1,22%%)",
    )
    parser.add_argument(
        "--tcost",
        type=float,
        default=None,
        help="Custo de transação em fração (ex.: 0.0122). Se informado, substitui --tcost-bps.",
    )
    parser.add_argument(
        "--apply-stock-ir",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Aplica IR de 15%% sobre ganho de capital nas vendas dos rebalanceamentos",
    )
    parser.add_argument("--ir-rate", type=float, default=DEFAULT_IR_RATE)
    parser.add_argument(
        "--ir-monthly-sales-exemption",
        type=float,
        default=DEFAULT_IR_MONTHLY_SALES_EXEMPTION,
    )
    parser.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    parser.add_argument("--db-name", default=DEFAULT_DB_NAME)
    parser.add_argument("--prices-path", type=Path, default=DEFAULT_PRICES_PATH)
    parser.add_argument("--rf-path", type=Path, default=DEFAULT_RF_PATH)
    parser.add_argument("--capital", type=float, default=10_000.0)
    parser.add_argument(
        "--collections-suffix",
        default=None,
        help="Sufixo das collections (default: montado a partir de N, período, rebalance, bps e IR)",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=0,
        help="Processa no máximo N carteiras; 0 = todas",
    )
    parser.add_argument(
        "--skip-failed",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Segue para a próxima carteira se uma falhar (default: sim)",
    )
    args = parser.parse_args(list(argv) if argv is not None else None)

    if not 1 <= args.start_m <= 12 or not 1 <= args.end_m <= 12:
        parser.error("Mês de início/fim deve estar entre 1 e 12.")
    if not 1 <= args.rebalance_month <= 12:
        parser.error("--rebalance-month deve estar entre 1 e 12.")
    if datetime(args.start_y, args.start_m, 1) > datetime(args.end_y, args.end_m, 1):
        parser.error("A data inicial não pode ser posterior à data final.")

    if args.tcost is not None:
        tcost = float(args.tcost)
        tcost_bps = tcost * 10_000.0
    else:
        tcost_bps = float(args.tcost_bps)
        tcost = bps_to_fraction(tcost_bps)

    return LiquidezBacktestConfig(
        carteiras_path=args.carteiras,
        start_y=args.start_y,
        start_m=args.start_m,
        end_y=args.end_y,
        end_m=args.end_m,
        rebalance=bool(args.rebalance),
        rebalance_freq=str(args.rebalance_freq),
        rebalance_month=int(args.rebalance_month),
        tcost=tcost,
        tcost_bps=tcost_bps,
        apply_stock_ir=bool(args.apply_stock_ir),
        ir_rate=float(args.ir_rate),
        ir_monthly_sales_exemption=float(args.ir_monthly_sales_exemption),
        mongo_uri=args.mongo_uri,
        db_name=args.db_name,
        prices_path=args.prices_path,
        rf_path=args.rf_path,
        capital=float(args.capital),
        collections_suffix=args.collections_suffix or "",
        limit=int(args.limit),
        skip_failed=bool(args.skip_failed),
    )


def run_batch_backtests(config: LiquidezBacktestConfig) -> None:
    v2.SETUP_SUBSTEPS = SETUP_SUBSTEPS
    v2.PORTFOLIO_SUBSTEPS = PORTFOLIO_SUBSTEPS

    if not config.carteiras_path.exists():
        raise FileNotFoundError(f"Arquivo de carteiras não encontrado: {config.carteiras_path}")

    progress = BatchRunProgress(len(SETUP_SUBSTEPS), 0, len(PORTFOLIO_SUBSTEPS))
    print("Iniciando batch de backtests (v3 / liquidez 1MM)...", flush=True)

    df_prices = load_prices(config.prices_path)
    progress.tick_setup(1, str(config.prices_path))

    rf_df = pd.read_csv(config.rf_path)
    progress.tick_setup(2, str(config.rf_path))

    df_cb = load_carteiras_csv(config.carteiras_path)
    if config.limit and config.limit > 0:
        df_cb = df_cb.iloc[: config.limit].copy()
    n_ativos = infer_n_ativos(config.carteiras_path, int(df_cb.iloc[0]["Total_papeis"]))
    suffix = config.collections_suffix or build_collections_suffix(config, n_ativos)
    col_res = f"res_{suffix}"
    metrics_collection = f"aux_metrics_{suffix}"
    series_gross = f"ret_acum_pct_{suffix}"
    series_excess = f"ret_excess_acum_pct_{suffix}"
    progress.tick_setup(3, f"{len(df_cb)} carteiras | {config.carteiras_path.name}")

    client = MongoClient(config.mongo_uri, serverSelectionTimeoutMS=15000)
    db = client[config.db_name]
    col = db[metrics_collection]
    n_docs = col.count_documents({})
    progress.tick_setup(4, f"{config.db_name}.{metrics_collection} ({n_docs} docs)")

    df_aux = load_collection_as_df(col)
    existing = set() if df_aux.empty else set(df_aux["strategy"].astype(str).dropna().unique())

    pending: List[pd.Series] = []
    for _, row in df_cb.iterrows():
        strat_name = "-".join(row["tickers"])
        if strat_name not in existing:
            pending.append(row)
    skipped = len(df_cb) - len(pending)
    progress.tick_setup(
        5,
        f"já processadas: {len(existing)} | pendentes: {len(pending)} | ignoradas neste run: {skipped}",
    )
    progress.set_portfolio_workload(len(pending))

    reb_label = (
        f"rebalance={config.rebalance_freq} (mês âncora={config.rebalance_month:02d})"
        if config.rebalance
        else "buy-and-hold"
    )
    print(
        f"Período: {config.start_m:02d}/{config.start_y} a {config.end_m:02d}/{config.end_y} | "
        f"{reb_label} | tcost={config.tcost_bps:.1f} bps ({config.tcost:.4%}) | "
        f"IR={'sim' if config.apply_stock_ir else 'não'}",
        flush=True,
    )
    print(
        "Collections de saída:",
        f"db={config.db_name!r},",
        f"col_res={col_res!r},",
        f"metrics={metrics_collection!r},",
        f"gross={series_gross!r},",
        f"excess={series_excess!r}",
        flush=True,
    )

    if not pending:
        progress.finish(processed=0, skipped=skipped)
        client.close()
        return

    processed = 0
    failed = 0
    for portfolio_index, row in enumerate(pending, start=1):
        tickers = list(row["tickers"])
        strat_name = "-".join(tickers)
        base_name = str(row["Base"])
        detail = f"{base_name} | {strat_name[:80]}"
        try:
            res, aux = run_bt_backtest_ew(
                df_prices=df_prices,
                tickers=tickers,
                tcost=config.tcost,
                start_y=config.start_y,
                start_m=config.start_m,
                end_y=config.end_y,
                end_m=config.end_m,
                initial_capital=config.capital,
                rebalance=config.rebalance,
                rebalance_freq=config.rebalance_freq,
                rebalance_month=config.rebalance_month,
                rf_df=rf_df,
                strat_name=strat_name,
                apply_stock_ir=config.apply_stock_ir,
                ir_rate=config.ir_rate,
                ir_monthly_sales_exemption=config.ir_monthly_sales_exemption,
            )
        except Exception as exc:
            failed += 1
            print(f"    [ERRO] {detail} — {exc}", flush=True)
            if not config.skip_failed:
                raise
            progress.tick_portfolio(portfolio_index, 1, f"{detail} | FALHOU")
            for sub in range(2, 6):
                progress.tick_portfolio(portfolio_index, sub, f"{detail} | ignorado")
            continue

        progress.tick_portfolio(portfolio_index, 1, detail)

        info = save_res_display_only_to_mongo(
            mongo_uri=config.mongo_uri,
            base_name=base_name,
            res=res,
            db_name=config.db_name,
            col_res=col_res,
        )
        progress.tick_portfolio(portfolio_index, 2, f"{detail} | status={info.get('status')}")

        upsert_aux_metrics(
            mongo_uri=config.mongo_uri,
            db_name=config.db_name,
            metrics_collection=metrics_collection,
            aux=aux,
            strategy=strat_name,
            extra_fields={
                "tcost": config.tcost,
                "tcost_bps": config.tcost_bps,
                "tickers": tickers,
                "apply_stock_ir": config.apply_stock_ir,
                "ir_rate": config.ir_rate if config.apply_stock_ir else None,
                "rebalance": config.rebalance,
                "rebalance_freq": config.rebalance_freq if config.rebalance else "none",
                "start_y": config.start_y,
                "start_m": config.start_m,
                "end_y": config.end_y,
                "end_m": config.end_m,
                "carteiras_file": str(config.carteiras_path.name),
            },
        )
        progress.tick_portfolio(portfolio_index, 3, detail)

        n1 = save_series_in_collection(
            mongo_uri=config.mongo_uri,
            db_name=config.db_name,
            series_collection=series_gross,
            series=aux.get("retorno_acumulado_pct"),
            strategy=strat_name,
            overwrite_strategy=True,
            monthly_how="last",
            monthly_rule="ME",
        )
        progress.tick_portfolio(portfolio_index, 4, f"{detail} | pontos={n1}")

        n2 = save_series_in_collection(
            mongo_uri=config.mongo_uri,
            db_name=config.db_name,
            series_collection=series_excess,
            series=aux.get("retorno_excesso_acumulado_pct"),
            strategy=strat_name,
            overwrite_strategy=True,
            monthly_how="last",
            monthly_rule="ME",
        )
        progress.tick_portfolio(portfolio_index, 5, f"{detail} | pontos={n2}")

        processed += 1
        print(
            f"    ↳ res.display: {info.get('status')} | ret_acum={n1} | ret_excess={n2} | "
            f"IR pago={aux.get('total_ir_paid', 0):.2f}",
            flush=True,
        )

    progress.finish(processed=processed, skipped=skipped)
    if failed:
        print(f"Carteiras com falha (puladas): {failed}", flush=True)
    client.close()


def main(config: Optional[LiquidezBacktestConfig] = None) -> None:
    run_batch_backtests(config or parse_args())


if __name__ == "__main__":
    main()
