"""Ranking factível B3 — % de 1/N (EW) em 1ª/2ª posição (Sharpe e multicritério).

Lê collections Mongo DGU_BRASIL.B3_RESULTS_{periodo}, ranqueia por composição de
carteira (ordem dos tickers irrelevante), exclui o oráculo \"MV (in sample)\" e
gera Excel + LaTeX no formato da tabela:

    Ranking Factível - Percentual por Posição de 1/N vs demais estratégias
    Período | Ativos por carteira | Sharpe (1ª, 2ª) | Multicritério (1ª, 2ª) | N carteiras

Collections 2006/2011 podem ainda não existir: o script preenche o que houver
(hoje B3_RESULTS_2001_2025) e deixa células vazias para N/períodos ausentes.

Exemplo:
    python codigo_fonte/mestrado_ranking_factivel_b3.py \\
      --db-name DGU_BRASIL \\
      --collection-name B3_RESULTS_2001_2025 B3_RESULTS_2006_2025 B3_RESULTS_2011_2025 \\
      --output-dir resultados/ranking_factivel_b3

    python codigo_fonte/mestrado_ranking_factivel_b3.py \\
      --db-name DGU_BRASIL \\
      --periodos 2001_2025 2006_2025 2011_2025 \\
      --ativos 8 10 12 15 20 25 30 35 40 \\
      --max-carteiras 1000 \\
      --output-dir resultados/ranking_factivel_b3
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from pymongo import MongoClient

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MONGO_URI = "mongodb://172.23.224.1:27017/"
DEFAULT_DB = "DGU_BRASIL"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "resultados" / "ranking_factivel_b3"
DEFAULT_PERIODOS = ("2001_2025", "2006_2025", "2011_2025")
DEFAULT_COLLECTION_TEMPLATE = "B3_RESULTS_{periodo}"
DEFAULT_ATIVOS = (8, 10, 12, 15, 20, 25, 30, 35, 40)
DEFAULT_EW_STRATEGY = "EW"
DEFAULT_MAX_CARTEIRAS = 1000

SHARPE = "Sharpe (monthly)"
CEQ = "CEQ (monthly, γ=1)"
TURNOVER = "Avg Turnover (abs.)"
ORACLE = "MV (in sample)"
PORTFOLIO_KEY = "portfolio_key"

PERIOD_DISPLAY = {
    "2001_2025": "2001-2025",
    "2006_2025": "2006-2025",
    "2011_2025": "2011-2025",
}

COLUMN_ALIASES = {
    "base": "Base",
    "base_id": "Base",
    "Base_id": "Base",
    "carteira_id": "Base",
    "strategy": "Strategy",
    "total_papeis": "Total_papeis",
    "Total_Papeis": "Total_papeis",
    "n_ativos": "Total_papeis",
}

TITLE = "Ranking Factível - Percentual por Posição de 1/N vs demais estratégias"
LATEX_TITLE = r"Ranking Factível - Percentual por Posição de $1/N$ vs demais estratégias"
DEFAULT_TAB_FONTE = (
    r"\tabfonte{Fonte: Elaboração própria. Notas: (1) Sharpe e CEQ são mensais e brutos. "
    r"O custo de 12 pontos-base é considerado somente no \emph{return-loss}. "
    r"(2) O \emph{ranking} multicritério soma os postos de Sharpe, de CEQ ($\gamma=1$) "
    r"e de \emph{turnover}, com posto melhor para menor giro. "
    r"(3) Não inclui MV (in sample).}"
)

TABLE_COLUMNS = (
    "Período",
    "Ativos por carteira",
    "Sharpe 1ª",
    "Sharpe 2ª",
    "Multicritério 1ª",
    "Multicritério 2ª",
    "N carteiras",
)
EXPORT_COLUMNS = TABLE_COLUMNS + ("periodo",)


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Ranking factível B3: % de 1/N (EW) em 1ª/2ª posição "
            "(Sharpe e multicritério) por N de ativos e período."
        )
    )
    parser.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    parser.add_argument("--db-name", default=DEFAULT_DB)
    parser.add_argument(
        "--collection-name",
        nargs="+",
        default=None,
        help=(
            "Collections explícitas (ex.: B3_RESULTS_2001_2025 "
            "B3_RESULTS_2006_2025_vwN B3_RESULTS_2011_2025). "
            "O período AAAA_AAAA é inferido do nome (sufixo opcional)."
        ),
    )
    parser.add_argument(
        "--collection-template",
        default=DEFAULT_COLLECTION_TEMPLATE,
        help=f"Template sem --collection-name (default: {DEFAULT_COLLECTION_TEMPLATE})",
    )
    parser.add_argument(
        "--periodos",
        nargs="+",
        default=list(DEFAULT_PERIODOS),
        help="Períodos usados com --collection-template",
    )
    parser.add_argument(
        "--ativos",
        type=int,
        nargs="+",
        default=list(DEFAULT_ATIVOS),
        help=(
            "N de ativos por carteira na tabela "
            f"(default: {' '.join(map(str, DEFAULT_ATIVOS))})"
        ),
    )
    parser.add_argument(
        "--max-carteiras",
        type=int,
        default=DEFAULT_MAX_CARTEIRAS,
        help=(
            "Máximo de carteiras distintas por período e N "
            f"(default: {DEFAULT_MAX_CARTEIRAS}; 0 = sem limite)"
        ),
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--ew-strategy", default=DEFAULT_EW_STRATEGY)
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--exclude-oracle",
        dest="exclude_oracle",
        action="store_true",
        default=True,
        help="Exclui 'MV (in sample)' (default)",
    )
    group.add_argument(
        "--include-oracle",
        dest="exclude_oracle",
        action="store_false",
        help="Inclui 'MV (in sample)'",
    )
    parser.add_argument(
        "--stem",
        default="ranking_factivel_b3_1N_pct",
        help="Prefixo dos arquivos de saída (xlsx/tex/csv)",
    )
    parser.add_argument(
        "--allow-missing",
        action="store_true",
        default=True,
        help="Segue com collections ausentes (células vazias; default)",
    )
    parser.add_argument(
        "--require-all",
        dest="allow_missing",
        action="store_false",
        help="Falha se alguma collection solicitada não existir",
    )
    parser.add_argument("--quiet", action="store_true")
    return parser.parse_args(argv)


def infer_periodo_from_collection(name: str) -> str:
    # Aceita sufixo após o período (ex.: B3_RESULTS_2001_2025_vwN).
    match = re.search(r"(\d{4}_\d{4})", name)
    if not match:
        raise ValueError(
            f"Não foi possível inferir período AAAA_AAAA em '{name}'. "
            "Use --periodos com --collection-template."
        )
    return match.group(1)


def resolve_collection_jobs(
    *,
    collection_names: Optional[Sequence[str]],
    periodos: Sequence[str],
    collection_template: str,
) -> List[Tuple[str, str]]:
    if collection_names:
        return [(infer_periodo_from_collection(name), name) for name in collection_names]
    return [(p, collection_template.format(periodo=p)) for p in periodos]


def canonical_carteira_key(value: object) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    text = str(value).strip()
    if not text:
        return ""
    if text.lower().endswith(".csv"):
        return text
    parts = [part.strip() for part in text.split(",") if part.strip()]
    if not parts:
        return text
    return ",".join(sorted(parts))


def add_portfolio_key(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    source = out["Carteira"] if "Carteira" in out.columns else out["Base"]
    out[PORTFOLIO_KEY] = source.map(canonical_carteira_key)
    missing = out[PORTFOLIO_KEY].eq("")
    if missing.any():
        out.loc[missing, PORTFOLIO_KEY] = out.loc[missing, "Base"].astype(str)
    return out


def normalize_results_df(df: pd.DataFrame, *, collection: str) -> pd.DataFrame:
    out = df.copy()
    rename = {
        src: dst
        for src, dst in COLUMN_ALIASES.items()
        if src in out.columns and dst not in out.columns
    }
    if rename:
        out = out.rename(columns=rename)

    if "Base" not in out.columns and "Carteira" in out.columns:
        out["Base"] = out["Carteira"].astype(str)

    required = {"Strategy", "Base", "Total_papeis", SHARPE, CEQ, TURNOVER}
    missing = required - set(out.columns)
    if missing:
        raise RuntimeError(f"Campos ausentes em {collection}: {sorted(missing)}")

    out["Total_papeis"] = pd.to_numeric(out["Total_papeis"], errors="coerce").astype("Int64")
    for col in (SHARPE, CEQ, TURNOVER):
        out[col] = pd.to_numeric(out[col], errors="coerce")

    out = out.dropna(subset=["Strategy", "Base", "Total_papeis", SHARPE, CEQ, TURNOVER])
    out["Total_papeis"] = out["Total_papeis"].astype(int)
    out["Strategy"] = out["Strategy"].astype(str)
    out["Base"] = out["Base"].astype(str)
    return out


def load_collection(
    client: MongoClient,
    *,
    db_name: str,
    collection: str,
    exclude_oracle: bool = True,
) -> pd.DataFrame:
    # Campos com '.' no nome: não projetar via path; carrega documento completo.
    docs = list(client[db_name][collection].find({}, {"_id": 0}))
    if not docs:
        raise RuntimeError(f"Collection vazia: {db_name}.{collection}")
    df = normalize_results_df(pd.DataFrame(docs), collection=collection)
    if exclude_oracle:
        df = df[df["Strategy"] != ORACLE].copy()
    return df


def rank_one_portfolio(group: pd.DataFrame) -> pd.DataFrame:
    g = group.copy()
    g["r_sharpe"] = g[SHARPE].rank(ascending=False, method="min")
    g["r_ceq"] = g[CEQ].rank(ascending=False, method="min")
    g["r_turnover"] = g[TURNOVER].rank(ascending=True, method="min")
    g["r_sum"] = g["r_sharpe"] + g["r_ceq"] + g["r_turnover"]
    g = g.sort_values(
        ["r_sum", SHARPE, CEQ, TURNOVER],
        ascending=[True, False, False, True],
        kind="mergesort",
    )
    g["rank_multi"] = np.arange(1, len(g) + 1)
    return g


def ew_top2_pct(
    ranked: pd.DataFrame,
    rank_col: str,
    ew_strategy: str,
) -> Tuple[float, float, int]:
    key_col = PORTFOLIO_KEY if PORTFOLIO_KEY in ranked.columns else "Base"
    n_portfolios = int(ranked[key_col].nunique())
    ew = ranked[ranked["Strategy"] == ew_strategy]
    if ew.empty or n_portfolios == 0:
        return float("nan"), float("nan"), n_portfolios
    first = ew.drop_duplicates(subset=[key_col], keep="first")
    pct_1st = float((first[rank_col] == 1).mean() * 100.0)
    pct_2nd = float((first[rank_col] == 2).mean() * 100.0)
    return round(pct_1st, 2), round(pct_2nd, 2), n_portfolios


def select_portfolio_keys(
    keys: Sequence[str],
    *,
    max_carteiras: Optional[int],
) -> List[str]:
    """Seleciona até ``max_carteiras`` chaves distintas (ordem lexicográfica)."""
    unique = sorted({k for k in keys if k})
    if max_carteiras is None or max_carteiras <= 0:
        return unique
    return unique[: int(max_carteiras)]


def rebuild_n(
    df: pd.DataFrame,
    *,
    n: int,
    ew_strategy: str,
    max_carteiras: Optional[int] = DEFAULT_MAX_CARTEIRAS,
) -> Dict[str, object]:
    subset = df[df["Total_papeis"] == n].copy()
    if subset.empty:
        raise RuntimeError(f"Sem dados para N={n}")

    subset = add_portfolio_key(subset)
    subset = subset.drop_duplicates(subset=[PORTFOLIO_KEY, "Strategy"], keep="first")

    keep_keys = select_portfolio_keys(
        subset[PORTFOLIO_KEY].tolist(),
        max_carteiras=max_carteiras,
    )
    if not keep_keys:
        raise RuntimeError(f"Sem carteiras distintas para N={n}")
    subset = subset[subset[PORTFOLIO_KEY].isin(keep_keys)].copy()

    ranked_parts = [
        rank_one_portfolio(group) for _, group in subset.groupby(PORTFOLIO_KEY, sort=False)
    ]
    ranked = pd.concat(ranked_parts, ignore_index=True)

    s1, s2, n_port = ew_top2_pct(ranked, "r_sharpe", ew_strategy)
    m1, m2, _ = ew_top2_pct(ranked, "rank_multi", ew_strategy)
    return {
        "sharpe_1st": s1,
        "sharpe_2nd": s2,
        "multi_1st": m1,
        "multi_2nd": m2,
        "n_portfolios": n_port,
    }


def format_pct(value: object) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    return f"{float(value):.2f}"


def empty_row(ativos: int, periodo: str) -> Dict[str, object]:
    return {
        "ativos": ativos,
        "periodo": periodo,
        "Periodo_label": PERIOD_DISPLAY.get(periodo, periodo.replace("_", "-")),
        "sharpe_1st": float("nan"),
        "sharpe_2nd": float("nan"),
        "multi_1st": float("nan"),
        "multi_2nd": float("nan"),
        "n_portfolios": 0,
    }


def build_table_grid(
    results: Dict[Tuple[int, str], Dict[str, object]],
    *,
    ativos: Sequence[int],
    periodos: Sequence[str],
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    for periodo in periodos:
        for n in ativos:
            key = (n, periodo)
            if key in results:
                row = dict(results[key])
                row["ativos"] = n
                row["periodo"] = periodo
                row["Periodo_label"] = PERIOD_DISPLAY.get(
                    periodo, periodo.replace("_", "-")
                )
                rows.append(row)
            else:
                rows.append(empty_row(n, periodo))

    table = pd.DataFrame(rows)
    if table.empty:
        return table

    table["_period_start"] = (
        table["periodo"].astype(str).str.split("_", n=1).str[0].astype(int)
    )
    table = table.sort_values(
        ["_period_start", "ativos"],
        kind="mergesort",
    ).reset_index(drop=True)
    table = table.drop(columns=["_period_start"])
    return table


def _display_table(table: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame(
        {
            "Período": table["Periodo_label"],
            "Ativos por carteira": table["ativos"].astype(int),
            "Sharpe 1ª": table["sharpe_1st"],
            "Sharpe 2ª": table["sharpe_2nd"],
            "Multicritério 1ª": table["multi_1st"],
            "Multicritério 2ª": table["multi_2nd"],
            "N carteiras": table["n_portfolios"].astype("Int64"),
        }
    )
    return out[list(TABLE_COLUMNS)]


def write_excel(table: pd.DataFrame, path: Path, *, title: str) -> None:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, Side
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "openpyxl é necessário para gravar Excel. Instale com: pip install openpyxl"
        ) from exc

    display = _display_table(table)

    wb = Workbook()
    ws = wb.active
    ws.title = "Pct 1N"

    thin = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ncol = len(TABLE_COLUMNS)
    last_col_letter = chr(ord("A") + ncol - 1)
    ws.merge_cells(f"A1:{last_col_letter}1")
    title_cell = ws["A1"]
    title_cell.value = title
    title_cell.font = Font(bold=True, size=12)
    title_cell.alignment = center

    ws.merge_cells("A2:A3")
    ws["A2"] = "Período"
    ws.merge_cells("B2:B3")
    ws["B2"] = "Ativos por carteira"
    ws.merge_cells("C2:D2")
    ws["C2"] = "Sharpe"
    ws.merge_cells("E2:F2")
    ws["E2"] = "Multicritério"
    ws.merge_cells("G2:G3")
    ws["G2"] = "N carteiras"
    ws["C3"] = "1ª"
    ws["D3"] = "2ª"
    ws["E3"] = "1ª"
    ws["F3"] = "2ª"

    for col in range(1, ncol + 1):
        for row in (2, 3):
            c = ws.cell(row=row, column=col)
            c.font = Font(bold=True)
            c.alignment = center
            c.border = thin

    start_row = 4
    for i, rec in enumerate(display.itertuples(index=False)):
        r = start_row + i
        ws.cell(row=r, column=1, value=rec[0]).alignment = center
        ws.cell(row=r, column=2, value=int(rec[1])).alignment = center
        for col in range(3, 7):
            value = rec[col - 1]
            cell = ws.cell(
                row=r,
                column=col,
                value=value if value == value else None,
            )
            cell.alignment = center
            if isinstance(value, (int, float)) and value == value:
                cell.number_format = "0.00"
        n_carteiras = rec[6]
        n_cell = ws.cell(
            row=r,
            column=7,
            value=int(n_carteiras) if pd.notna(n_carteiras) and n_carteiras else None,
        )
        n_cell.alignment = center
        n_cell.number_format = "0"
        for col in range(1, ncol + 1):
            ws.cell(row=r, column=col).border = thin

    for periodo in display["Período"].unique():
        idxs = [i for i, v in enumerate(display["Período"]) if v == periodo]
        if len(idxs) >= 2:
            r0 = start_row + idxs[0]
            r1 = start_row + idxs[-1]
            ws.merge_cells(start_row=r0, start_column=1, end_row=r1, end_column=1)
            ws.cell(row=r0, column=1).alignment = Alignment(
                horizontal="center", vertical="center"
            )

    widths = {
        "A": 14,
        "B": 18,
        "C": 10,
        "D": 10,
        "E": 12,
        "F": 12,
        "G": 12,
    }
    for letter, width in widths.items():
        ws.column_dimensions[letter].width = width

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def write_latex(table: pd.DataFrame, path: Path, *, title: str, label: str) -> None:
    display = _display_table(table)
    lines: List[str] = [
        "% Gerado por mestrado_ranking_factivel_b3.py",
        "% Requer: \\usepackage{booktabs} e \\usepackage{multirow}",
        "\\begin{table}[htbp]",
        "\\centering",
        f"\\caption{{{title}}}",
        f"\\label{{{label}}}",
        "\\begin{tabular}{ccccccc}",
        "\\toprule",
        " &  & \\multicolumn{2}{c}{Sharpe} & \\multicolumn{2}{c}{Multicritério} &  \\\\",
        "\\cmidrule(lr){3-4}\\cmidrule(lr){5-6}",
        "Período & Ativos por carteira & 1\\textsuperscript{a} & 2\\textsuperscript{a} "
        "& 1\\textsuperscript{a} & 2\\textsuperscript{a} & N carteiras \\\\",
        "\\midrule",
    ]

    period_order = list(dict.fromkeys(display["Período"]))
    for periodo in period_order:
        block = display[display["Período"] == periodo]
        n_rows = len(block)
        for j, rec in enumerate(block.itertuples(index=False)):
            periodo_cell = (
                f"\\multirow{{{n_rows}}}{{*}}{{{rec[0]}}}" if j == 0 else ""
            )
            n_carteiras = "" if pd.isna(rec[6]) or int(rec[6]) == 0 else str(int(rec[6]))
            lines.append(
                f"{periodo_cell} & {int(rec[1])} "
                f"& {format_pct(rec[2])} & {format_pct(rec[3])} "
                f"& {format_pct(rec[4])} & {format_pct(rec[5])} & {n_carteiras} \\\\"
            )
        lines.append("\\midrule")

    if lines[-1] == "\\midrule":
        lines[-1] = "\\bottomrule"
    else:
        lines.append("\\bottomrule")

    lines.extend(
        [
            "\\end{tabular}",
            DEFAULT_TAB_FONTE,
            "\\end{table}",
            "",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def main(argv: Optional[Sequence[str]] = None) -> Path:
    args = parse_args(argv)
    jobs = resolve_collection_jobs(
        collection_names=args.collection_name,
        periodos=args.periodos,
        collection_template=args.collection_template,
    )
    # Mantém a ordem de períodos da figura / --periodos
    period_order = [p for p, _ in jobs]
    if args.collection_name is None:
        period_order = list(args.periodos)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    client = MongoClient(args.mongo_uri)
    results: Dict[Tuple[int, str], Dict[str, object]] = {}
    loaded_periodos: List[str] = []

    try:
        for periodo, collection in jobs:
            exists = collection in client[args.db_name].list_collection_names()
            if not exists:
                msg = f"Collection ausente: {args.db_name}.{collection}"
                if args.allow_missing:
                    if not args.quiet:
                        print(f"SKIP {msg} (células vazias na tabela)", flush=True)
                    continue
                raise RuntimeError(msg)

            if not args.quiet:
                print(
                    f"\n=== {periodo} | {args.db_name}.{collection} ===",
                    flush=True,
                )

            df = load_collection(
                client,
                db_name=args.db_name,
                collection=collection,
                exclude_oracle=args.exclude_oracle,
            )
            loaded_periodos.append(periodo)
            available_n = sorted(df["Total_papeis"].unique())
            if not args.quiet:
                print(
                    f"N disponíveis={available_n} | docs={len(df)} | "
                    f"estratégias={sorted(df['Strategy'].unique())}",
                    flush=True,
                )

            for n in args.ativos:
                if n not in available_n:
                    if not args.quiet:
                        print(f"  SKIP N={n}: ausente na collection", flush=True)
                    continue
                try:
                    stats = rebuild_n(
                        df,
                        n=n,
                        ew_strategy=args.ew_strategy,
                        max_carteiras=args.max_carteiras,
                    )
                except RuntimeError as exc:
                    print(f"  SKIP N={n}: {exc}", flush=True)
                    continue

                results[(n, periodo)] = stats
                if not args.quiet:
                    lim = (
                        f" (cap {args.max_carteiras})"
                        if args.max_carteiras and args.max_carteiras > 0
                        else ""
                    )
                    print(
                        f"  N={n} ({stats['n_portfolios']} carteiras{lim}): "
                        f"Sharpe {format_pct(stats['sharpe_1st'])}/"
                        f"{format_pct(stats['sharpe_2nd'])}% | "
                        f"Multi {format_pct(stats['multi_1st'])}/"
                        f"{format_pct(stats['multi_2nd'])}%",
                        flush=True,
                    )
    finally:
        client.close()

    if not results:
        raise RuntimeError(
            "Nenhum ranking B3 gerado. Verifique se B3_RESULTS_* existem em "
            f"{args.db_name} e contêm Total_papeis solicitados."
        )

    # Grade completa da figura (períodos × N solicitados)
    table = build_table_grid(
        results,
        ativos=args.ativos,
        periodos=period_order if period_order else list(DEFAULT_PERIODOS),
    )

    stem = args.stem
    csv_path = args.output_dir / f"{stem}.csv"
    xlsx_path = args.output_dir / f"{stem}.xlsx"
    tex_path = args.output_dir / f"{stem}.tex"

    display = _display_table(table)
    export = display.copy()
    export["periodo"] = table["periodo"].values
    export.to_csv(csv_path, index=False)
    write_excel(table, xlsx_path, title=TITLE)
    write_latex(
        table,
        tex_path,
        title=LATEX_TITLE,
        label="tab:ranking_factivel_b3_1N_pct",
    )

    if not args.quiet:
        print(f"\nPeríodos carregados: {loaded_periodos}", flush=True)
        print(f"CSV:   {csv_path}", flush=True)
        print(f"Excel: {xlsx_path}", flush=True)
        print(f"LaTeX: {tex_path}", flush=True)
        print("\n=== % 1/N (células vazias = N/período ainda sem dados) ===", flush=True)
        print(display.to_string(index=False), flush=True)

    return xlsx_path


if __name__ == "__main__":
    main()
