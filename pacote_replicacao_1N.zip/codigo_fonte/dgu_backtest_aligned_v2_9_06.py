# -*- coding: utf-8 -*-
"""DGU backtest — v2.9.06.

Nova versão de ``dgu_backtest_aligned_v2_8_26.py``. O motor anterior permanece
intacto; este arquivo o carrega e substitui três comportamentos:

1. DM (Pástor–Stambaugh) usa o fator de mercado em ``vw_mkt_m`` (ou ``mktrf_m``)
   quando ``MktRF`` não está nas colunas de ações. Sem fator, o backtest para.
   O fallback que copiava a média-variância amostral foi removido.
2. O giro "paper" deriva ``w_{t-1}`` com o retorno bruto da linha ``t-1``
   (o retorno realizado enquanto esses pesos estavam na carteira).
3. O giro estilo MATLAB de BS, MP e MV-MIN usa o mesmo alinhamento.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd

_BASE_PATH = Path(__file__).resolve().with_name("dgu_backtest_aligned_v2_8_26.py")
_SPEC = importlib.util.spec_from_file_location(
    "dgu_backtest_aligned_v2_8_26", _BASE_PATH
)
if _SPEC is None or _SPEC.loader is None:
    raise ImportError(f"Não foi possível carregar {_BASE_PATH}")
_base = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_base)

_MARKET_ALIASES = (
    "MktRF",
    "MKT_RF",
    "MKT",
    "Mkt-RF",
    "MKT-RF",
    "MktMinusRF",
)

_orig_w_dm_pastor = _base._w_dm_pastor


def _w_dm_pastor(X_excess, F_excess, sigma_alpha_annual: float = 0.01):
    """DM exige fator. Sem fator, não devolve a média-variância."""
    missing = F_excess is None or (
        hasattr(F_excess, "size") and np.size(F_excess) == 0
    )
    if missing:
        raise ValueError(
            "DM (Pástor–Stambaugh) exige o fator de mercado. "
            "Recusa o fallback para a média-variância amostral."
        )
    return _orig_w_dm_pastor(X_excess, F_excess, sigma_alpha_annual=sigma_alpha_annual)


def _turnover_series_paper(W: pd.DataFrame, R: pd.DataFrame, mode: str = "sum") -> pd.Series:
    """Giro com drift de ``w_{t-1}`` por ``R_{t-1}``.

    ``W`` e ``R`` compartilham o índice da data em que o peso é aplicado:
    a linha ``t`` guarda ``w_t`` e o retorno bruto que ``w_t`` aufere.
    O peso pré-rebalanceamento em ``t`` é ``w_{t-1}`` derivado por ``R_{t-1}``.
    """
    if W is None or R is None or W.empty or R.empty:
        return pd.Series(dtype=float)
    R = R.reindex(index=W.index, columns=W.columns).fillna(0.0)
    Wn = _base._norm_weights__paper(W.astype(float), mode=mode)
    Wlag = Wn.shift(1)
    Wpre = _base._norm_weights__paper(Wlag * (1.0 + R.shift(1)), mode=mode)
    idx = Wn.index.intersection(Wpre.index)
    return (Wn.loc[idx].sub(Wpre.loc[idx])).abs().sum(axis=1)


def _turnover_series_matlab_ro(
    alpha_df: pd.DataFrame, rexcess_df: pd.DataFrame, rf_s: pd.Series
) -> pd.Series:
    """Giro risky-only. O buy-and-hold de ``alpha_{t-1}`` usa ``rexcess_{t-1}`` e ``rf_{t-1}``."""
    if alpha_df is None or rexcess_df is None or alpha_df.empty or rexcess_df.empty:
        return pd.Series(dtype=float)
    idx = alpha_df.index
    rexcess_df = rexcess_df.reindex(index=idx, columns=alpha_df.columns).fillna(0.0)
    rf_s = rf_s.reindex(idx).fillna(0.0)

    tau = np.full(len(idx), np.nan, float)
    alpha_vals = alpha_df.to_numpy(float)
    rex_vals = rexcess_df.to_numpy(float)
    rf_vals = rf_s.to_numpy(float)

    for i in range(len(idx)):
        alpha_t = alpha_vals[i, :]
        w_t = _base._alpha_to_w_ro(alpha_t)
        if i == 0:
            alpha_bh = alpha_t.copy()
        else:
            alpha_bh = _base._buyhold_alpha_matlab(
                alpha_vals[i - 1, :], rex_vals[i - 1, :], rf_vals[i - 1]
            )
        s_bh = float(np.sum(alpha_bh))
        if (not np.isfinite(s_bh)) or abs(s_bh) < 1e-16:
            w_bh = alpha_bh.copy()
        else:
            w_bh = alpha_bh / s_bh
        tau[i] = float(np.sum(np.abs(w_t - w_bh)))
    return pd.Series(tau, index=idx)


def _as_market_series(vw_mkt_m, mktrf_m, index: pd.Index) -> pd.Series | None:
    src = vw_mkt_m if vw_mkt_m is not None else mktrf_m
    if src is None:
        return None
    if isinstance(src, pd.DataFrame):
        if "MktRF" in src.columns:
            src = src["MktRF"]
        elif "MKT" in src.columns:
            src = src["MKT"]
        elif src.shape[1] == 1:
            src = src.iloc[:, 0]
        else:
            src = src.iloc[:, 0]
    series = _base._sanitize_index(pd.Series(src, dtype=float))
    return series.reindex(index)


def rolling_backtest(
    rets_m: pd.DataFrame,
    rf_m: pd.Series,
    M: int = 120,
    cost_bps: float = 50.0,
    vw_weights_m=None,
    vw_mkt_m=None,
    mvmin_alpha_override=None,
    drop_mkt_from_universe: bool = False,
    mktrf_m=None,
    returns_are_excess: bool = False,
    ignore_col=None,
):
    """Encaminha ao motor v2.8.26 depois de garantir o fator da DM."""
    rets_in = rets_m.copy()
    has_factor = any(col in rets_in.columns for col in _MARKET_ALIASES)
    if not has_factor:
        market = _as_market_series(vw_mkt_m, mktrf_m, rets_in.index)
        if market is None or int(market.notna().sum()) < 3:
            raise RuntimeError(
                "DM exige fator de mercado: coluna MktRF no painel ou série "
                "vw_mkt_m/mktrf_m alinhada às datas. Sem isso o backtest para, "
                "em vez de repetir a média-variância."
            )
        rets_in["MktRF"] = market

    # MktRF entra como fator, não como ativo investível. No caso FF3 puro o
    # motor ainda o trata como investível pelo ramo only_ff3.
    _base.FACTOR_COLS = set(_base.FACTOR_COLS) | {"MktRF", "MKT_RF", "Mkt-RF", "MKT-RF", "MktMinusRF"}
    _base._w_dm_pastor = _w_dm_pastor
    _base._turnover_series_paper = _turnover_series_paper
    _base._turnover_series_matlab_ro = _turnover_series_matlab_ro

    return _base.rolling_backtest(
        rets_in,
        rf_m,
        M=M,
        cost_bps=cost_bps,
        vw_weights_m=vw_weights_m,
        vw_mkt_m=vw_mkt_m,
        mvmin_alpha_override=mvmin_alpha_override,
        drop_mkt_from_universe=drop_mkt_from_universe,
        mktrf_m=mktrf_m,
        returns_are_excess=returns_are_excess,
        ignore_col=ignore_col,
    )


_base._w_dm_pastor = _w_dm_pastor
_base._turnover_series_paper = _turnover_series_paper
_base._turnover_series_matlab_ro = _turnover_series_matlab_ro
