"""Backtest EW da pessoa investidora (v4.1) — deslistagem corrigida.

Corrige o v4 nos seguintes pontos:

1. **Deslistagem = top-up do produto**, não reset 1/N da carteira inteira.
   Vende o papel morto e reinveste o valor líquido igualmente nos vivos,
   **sem vender** as posições sobreviventes (preserva pesos relativos).
2. Alinha o código ao texto de ``TRATAMENTO_DESLISTAGEM.md``
   (“reinveste o produto em pesos iguais nos N−1”).
3. **IR antes de reinvestir**: apura o imposto sobre a venda da deslistagem
   (e, no rebalance periódico, sobre as vendas do rebalance) e só então
   aloca o caixa — evita caixa negativo / alavancagem implícita do v4.

Rebalance periódico (``--rebalance``) continua sendo 1/N completo nas datas
do calendário; a correção do item 1 aplica-se aos eventos de deslistagem
(e ao buy-and-hold entre datas).

Collections: mesmo schema do v4 com sufixo final ``_v41`` (não sobrescreve v4).

Exemplo::

    python codigo_fonte/backtest_carteiras_individuais_retornos_v4_1.py \\
      --carteiras resultados/carteiras_aleatorias_liquidas/carteiras_8atv_liq_1MM_200106.csv \\
      --no-rebalance --cost-mode gross --apply-stock-ir --liquidate-at-end \\
      --limit 1 --dry-run
"""

from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass, replace
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from pymongo import MongoClient

sys.path.insert(0, str(Path(__file__).resolve().parent))

import backtest_carteiras_individuais_retornos_v2 as v2  # noqa: E402
from backtest_carteiras_individuais_retornos_v2 import (  # noqa: E402
    DEFAULT_IR_MONTHLY_SALES_EXEMPTION,
    DEFAULT_IR_RATE,
    BatchRunProgress,
    _recompute_return_metrics,
    load_collection_as_df,
    load_prices,
    save_res_display_only_to_mongo,
    save_series_in_collection,
    upsert_aux_metrics,
)
from backtest_carteiras_individuais_retornos_v3 import (  # noqa: E402
    _turnover_from_tx,
    build_rebalance_dates,
    load_carteiras_csv,
    month_end,
)
from ticker_continuacao import chain_portfolio_prices, padronizar_ticker  # noqa: E402
from barra_market_impact import (  # noqa: E402
    ADV_FLOOR_BRL,
    VOL_WINDOW,
    barra_unit_cost,
    build_sigma_adv_panels,
    load_eta_from_json,
    load_volume_brl,
    portfolio_barra_cost,
    prices_df_to_wide,
    volume_cache_path,
)

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_PRICES_PATH = REPO_ROOT / "ibov" / "prices_adjust_close_B3_economatica_1986-out_2025.csv"
DEFAULT_RF_PATH = REPO_ROOT / "nefin_RF.csv"
DEFAULT_VOLUME_XLSX = REPO_ROOT / "ibov" / "economaticavolumeNegociado.xlsx"
DEFAULT_DB_NAME = "Backtest_Mestrado_PF_LIQUIDEZ_1MM"
DEFAULT_MONGO_URI = "mongodb://172.23.224.1:27017/"
REBALANCE_FREQS = ("monthly", "quarterly", "semiannual", "annual")
COST_MODES = ("flat", "barra", "barra_raw", "flat_barra", "gross")
ALL_COST_SCENARIOS = ("gross", "flat", "barra", "barra_raw", "flat_barra")
EPS = 1e-12


def cost_mode_needs_barra(mode: str) -> bool:
    return str(mode).lower() in ("barra", "barra_raw", "flat_barra")


def cost_mode_needs_eta(mode: str) -> bool:
    """η calibrado só em ``barra``; ``barra_raw`` / ``flat_barra`` usam η≡1."""
    return str(mode).lower() == "barra"


def cost_mode_uses_flat(mode: str) -> bool:
    return str(mode).lower() in ("flat", "flat_barra")


def effective_eta(mode: str, eta: float) -> float:
    """η efetivo: 1.0 em barra_raw e flat_barra (flat + σ√(q/ADV))."""
    if str(mode).lower() in ("barra_raw", "flat_barra"):
        return 1.0
    return float(eta)

SETUP_SUBSTEPS = (
    "Carregar preços",
    "Carregar taxa livre de risco (RF)",
    "Carregar carteiras do CSV",
    "Conectar ao MongoDB",
    "Verificar estratégias já processadas",
)

PORTFOLIO_SUBSTEPS = (
    "Executar backtest EW (v4.1)",
    "Salvar res.display no MongoDB",
    "Salvar métricas auxiliares",
    "Salvar série de retorno acumulado",
    "Salvar série de retorno em excesso",
)
ENGINE_TAG = "v4_1_delist_topup"


@dataclass
class DelistBacktestConfig:
    carteiras_path: Path
    start_y: int
    start_m: int
    end_y: int
    end_m: int
    rebalance: bool
    rebalance_freq: str
    rebalance_month: int
    tcost: float
    tcost_bps: float
    cost_mode: str
    eta: float
    volume_path: Path
    apply_stock_ir: bool
    ir_rate: float
    ir_monthly_sales_exemption: float
    mongo_uri: str
    db_name: str
    prices_path: Path
    rf_path: Path
    capital: float
    collections_suffix: str
    universo_tag: str
    limit: int
    skip_failed: bool
    max_gap_days: int
    delist_terminal_return: float
    liquidate_at_end: bool = False
    dry_run: bool = False
    all_cost_modes: bool = False


class SimpleRes:
    """Objeto mínimo compatível com ``save_res_display_only_to_mongo``."""

    def __init__(self, strat_name: str, stats: pd.Series, nav: pd.Series):
        self.stats = pd.DataFrame({strat_name: stats})
        self.prices = pd.DataFrame({strat_name: nav})

    def display(self) -> None:
        print(self.stats.to_string())


def bps_to_fraction(bps: float) -> float:
    return float(bps) / 10_000.0


def infer_n_ativos(path: Path, n_from_row: int) -> int:
    match = re.search(r"(\d+)atv", path.stem, flags=re.IGNORECASE)
    if match:
        return int(match.group(1))
    return n_from_row


def infer_universo_tag(path: Path) -> str:
    """Tag do universo a partir do CSV.

    ``carteiras_12atv_liq_1MM_200106.csv`` → ``liq_1MM``
    (descarta o YYYYMM de formação; a janela do backtest vai no sufixo).
    """
    match = re.match(r"carteiras_\d+atv_(.+)$", path.stem, flags=re.IGNORECASE)
    if not match:
        return ""
    tag = match.group(1)
    tag = re.sub(r"_\d{6}$", "", tag)
    return tag


def build_collections_suffix(config: DelistBacktestConfig, n_ativos: int) -> str:
    reb = f"reb-{config.rebalance_freq}" if config.rebalance else "buyhold"
    ir_tag = "ir" if config.apply_stock_ir else "noir"
    tag = f"{config.universo_tag}_" if config.universo_tag else ""
    mode = str(config.cost_mode).lower()
    t_bps = int(round(config.tcost_bps))
    eta_tag = f"{float(config.eta):.4g}".replace(".", "p")
    if mode == "barra":
        t_tag = f"tbarra_eta{eta_tag}"
    elif mode == "barra_raw":
        t_tag = "tbarra_raw"
    elif mode == "flat_barra":
        t_tag = f"t{t_bps}bps_barra_raw"
    elif mode == "gross":
        t_tag = "tgross"
    else:
        t_tag = f"t{t_bps}bps"
    return (
        f"{n_ativos}atv_{tag}{config.start_y}{config.start_m:02d}_"
        f"{config.end_y}{config.end_m:02d}_{reb}_{t_tag}_{ir_tag}_v41"
    )


def _drawdown_durations(drawdown: pd.Series) -> pd.Series:
    in_dd = drawdown < 0
    durations: List[int] = []
    run = 0
    for flag in in_dd.tolist():
        if flag:
            run += 1
        elif run:
            durations.append(run)
            run = 0
    if run:
        durations.append(run)
    return pd.Series(durations, dtype=float)


def nav_to_res_stats(nav: pd.Series) -> pd.Series:
    nav = nav.dropna()
    if nav.empty:
        raise ValueError("NAV vazio.")
    daily = nav.pct_change().dropna()
    monthly = nav.resample("ME").last().pct_change().dropna()
    yearly = nav.resample("YE").last().pct_change().dropna()
    total_return = float(nav.iloc[-1] / nav.iloc[0] - 1.0)
    years = (nav.index[-1] - nav.index[0]).days / 365.25
    cagr = float((1.0 + total_return) ** (1.0 / years) - 1.0) if years > 0 else np.nan
    dd = nav / nav.cummax() - 1.0
    max_dd = float(dd.min()) if len(dd) else np.nan
    neg_dd = dd[dd < 0]
    avg_dd = float(neg_dd.mean()) if len(neg_dd) else 0.0
    dd_days = _drawdown_durations(dd)
    avg_dd_days = float(dd_days.mean()) if len(dd_days) else 0.0
    calmar = float(cagr / abs(max_dd)) if max_dd and np.isfinite(max_dd) and max_dd != 0 else np.nan
    roll12 = monthly.rolling(12).apply(lambda x: np.prod(1.0 + x) - 1.0, raw=True).dropna()
    twelve_win = float((roll12 > 0).mean()) if len(roll12) else np.nan
    win_year = float((yearly > 0).mean()) if len(yearly) else np.nan
    m_std = float(monthly.std(ddof=1)) if len(monthly) > 1 else np.nan
    m_mean = float(monthly.mean()) if len(monthly) else np.nan
    down = monthly[monthly < 0]
    down_std = float(down.std(ddof=1)) if len(down) > 1 else np.nan
    monthly_sharpe = (
        (m_mean / m_std) * np.sqrt(12.0) if m_std and m_std > 0 else np.nan
    )
    monthly_sortino = (
        (m_mean / down_std) * np.sqrt(12.0) if down_std and down_std > 0 else np.nan
    )
    stats = {
        "cagr": cagr,
        "total_return": total_return,
        "monthly_mean": m_mean * 12.0 if np.isfinite(m_mean) else np.nan,
        "monthly_vol": m_std * np.sqrt(12.0) if np.isfinite(m_std) else np.nan,
        "yearly_mean": float(yearly.mean()) if len(yearly) else np.nan,
        "yearly_vol": float(yearly.std(ddof=1)) if len(yearly) > 1 else np.nan,
        "monthly_sharpe": monthly_sharpe,
        "monthly_sortino": monthly_sortino,
        "calmar": calmar,
        "max_drawdown": max_dd,
        "avg_drawdown": avg_dd,
        "avg_drawdown_days": avg_dd_days,
        "twelve_month_win_perc": twelve_win,
        "win_year_perc": win_year,
        "monthly_skew": float(monthly.skew()) if len(monthly) > 2 else np.nan,
        "monthly_kurt": float(monthly.kurt()) if len(monthly) > 3 else np.nan,
        "yearly_skew": float(yearly.skew()) if len(yearly) > 2 else np.nan,
        "yearly_kurt": float(yearly.kurt()) if len(yearly) > 3 else np.nan,
        "best_month": float(monthly.max()) if len(monthly) else np.nan,
        "worst_month": float(monthly.min()) if len(monthly) else np.nan,
        "best_year": float(yearly.max()) if len(yearly) else np.nan,
        "worst_year": float(yearly.min()) if len(yearly) else np.nan,
        "daily_mean": float(daily.mean()) if len(daily) else np.nan,
        "daily_vol": float(daily.std(ddof=1)) if len(daily) > 1 else np.nan,
    }
    return pd.Series(stats)


def _tx_from_records(records: List[Tuple[pd.Timestamp, str, float, float]]) -> pd.DataFrame:
    if not records:
        return pd.DataFrame(columns=["quantity", "price"])
    index = pd.MultiIndex.from_tuples(
        [(pd.Timestamp(dt), str(ticker)) for dt, ticker, _, _ in records],
        names=["Date", "Security"],
    )
    return pd.DataFrame(
        {"quantity": [q for _, _, q, _ in records], "price": [p for _, _, _, p in records]},
        index=index,
    )


def _prepare_panel(
    df_prices: pd.DataFrame,
    start_y: int,
    start_m: int,
    end_y: int,
    end_m: int,
) -> pd.DataFrame:
    if "Date" not in df_prices.columns:
        raise ValueError("df_prices precisa ter a coluna 'Date'.")
    px = df_prices.copy()
    px["Date"] = pd.to_datetime(px["Date"])
    px = px.sort_values("Date").set_index("Date")
    numeric = px.apply(pd.to_numeric, errors="coerce").sort_index()
    end_target = month_end(end_y, end_m)
    numeric = numeric.loc[:end_target]
    start_month = numeric[(numeric.index.year == start_y) & (numeric.index.month == start_m)]
    if start_month.empty:
        raise ValueError(f"Não há pregão em {start_m:02d}/{start_y} no CSV de preços.")
    start_target = start_month.index.min()
    return numeric.loc[start_target:]


def _empty_exit_info() -> dict:
    return {
        "liquidate_at_end": False,
        "final_wealth_brl": None,
        "exit_sales_notional_brl": None,
        "exit_net_gain_brl": None,
        "exit_cost_brl": None,
        "exit_ir_brl": None,
        "total_ir_paid_incl_exit": None,
    }


def simulate_ew_nav(
    prices: pd.DataFrame,
    *,
    tcost: float,
    initial_capital: float,
    rebalance: bool,
    rebalance_dates: Sequence[pd.Timestamp],
    apply_stock_ir: bool,
    ir_rate: float,
    ir_monthly_sales_exemption: float,
    delist_terminal_return: float,
    cost_mode: str = "flat",
    eta: float = 0.0,
    sigma_panel: Optional[pd.DataFrame] = None,
    adv_panel: Optional[pd.DataFrame] = None,
    adv_floor: float = ADV_FLOOR_BRL,
    liquidate_at_end: bool = False,
) -> Tuple[pd.Series, pd.DataFrame, List[dict], float, List[dict], dict]:
    """Simula 1/N com N variável (v4.1: top-up do produto na deslistagem).

    ``cost_mode``: ``flat`` (tcost), ``barra`` (η·σ·√(q/ADV)),
    ``barra_raw`` (σ·√(q/ADV), η≡1), ``flat_barra`` (tcost + barra_raw),
    ``gross`` (0).
    Devolve ``(nav_bt, tx, events, total_ir, cost_events, exit_info)``.
    Se ``liquidate_at_end``, calcula patrimônio após venda forçada no último
    pregão (custos + IR) sem alterar a série ``nav_bt``.
    """
    mode = str(cost_mode).lower()
    if mode not in COST_MODES:
        raise ValueError(f"cost_mode invalido: {cost_mode!r}; use {COST_MODES}")
    if cost_mode_needs_barra(mode) and (sigma_panel is None or adv_panel is None):
        raise ValueError(f"{mode} requer sigma_panel e adv_panel")
    eta_use = effective_eta(mode, eta)

    tickers = [str(c) for c in prices.columns]
    px = prices.to_numpy(dtype=float)
    dates = pd.DatetimeIndex(prices.index)
    t_count, n_count = px.shape
    if t_count == 0 or n_count == 0:
        raise ValueError("Painel de preços vazio.")

    sig_arr = None
    adv_arr = None
    if cost_mode_needs_barra(mode):
        sig = sigma_panel.reindex(index=dates, columns=tickers)
        adv = adv_panel.reindex(index=dates, columns=tickers)
        sig_arr = sig.to_numpy(dtype=float)
        adv_arr = adv.to_numpy(dtype=float)

    all_live = np.all(np.isfinite(px) & (px > 0), axis=1)
    start_i = int(np.argmax(all_live)) if all_live.any() else 0
    px = px[start_i:]
    dates = dates[start_i:]
    t_count = px.shape[0]
    if sig_arr is not None:
        sig_arr = sig_arr[start_i:]
        adv_arr = adv_arr[start_i:]

    last_end = np.array(
        [
            int(pd.Timestamp(prices[c].dropna().index.max()).value)
            if prices[c].notna().any()
            else 0
            for c in prices.columns
        ],
        dtype=np.int64,
    )

    shares = np.zeros(n_count, dtype=float)
    cash = float(initial_capital)
    last_px = np.full(n_count, np.nan)
    nav_brl = np.zeros(t_count, dtype=float)
    records: List[Tuple[pd.Timestamp, str, float, float]] = []
    events: List[dict] = []
    cost_events: List[dict] = []
    cost_qty = np.zeros(n_count, dtype=float)
    cost_avg = np.zeros(n_count, dtype=float)
    total_ir = 0.0
    reb_set = {pd.Timestamp(d).normalize() for d in rebalance_dates}
    already_delisted = np.zeros(n_count, dtype=bool)

    def still_listed(t: int) -> np.ndarray:
        return (int(pd.Timestamp(dates[t]).value) <= last_end) & (~already_delisted)

    def mark_prices(t: int) -> np.ndarray:
        p = np.array(px[t], dtype=float, copy=True)
        missing = ~np.isfinite(p) | (p <= 0)
        p[missing] = last_px[missing]
        p[~still_listed(t)] = np.nan
        return p

    def mark_value(t: int) -> float:
        p = mark_prices(t)
        live = np.isfinite(p) & (p > 0)
        return cash + float(np.nansum(shares * np.where(live, p, 0.0)))

    def record_trade(t: int, i: int, qty: float, price: float) -> None:
        if abs(qty) <= EPS or not np.isfinite(price) or price <= 0:
            return
        records.append((pd.Timestamp(dates[t]), tickers[i], float(qty), float(price)))
        if qty > 0:
            new_qty = cost_qty[i] + qty
            if new_qty > 0:
                cost_avg[i] = (cost_qty[i] * cost_avg[i] + qty * price) / new_qty
                cost_qty[i] = new_qty
        else:
            sold = min(abs(qty), cost_qty[i])
            cost_qty[i] = max(0.0, cost_qty[i] - sold)
            if cost_qty[i] <= EPS:
                cost_qty[i] = 0.0
                cost_avg[i] = 0.0

    def compute_ir(sales_notional: float, net_gain: float) -> float:
        if not apply_stock_ir or sales_notional <= EPS:
            return 0.0
        if sales_notional <= float(ir_monthly_sales_exemption):
            return 0.0
        return float(ir_rate) * max(0.0, net_gain)

    def apply_ir(sales_notional: float, net_gain: float) -> float:
        """Debita IR do caixa e devolve o valor do imposto."""
        nonlocal cash, total_ir
        ir = compute_ir(sales_notional, net_gain)
        if ir > 0:
            cash -= ir
            total_ir += ir
        return ir

    def asset_unit_cost(t: int, i: int, q_i: float) -> float:
        if mode == "gross" or q_i <= EPS:
            return 0.0
        flat_part = float(tcost) if cost_mode_uses_flat(mode) else 0.0
        if not cost_mode_needs_barra(mode):
            return flat_part
        assert sig_arr is not None and adv_arr is not None
        sig_i = sig_arr[t, i]
        if not np.isfinite(sig_i) or sig_i < 0:
            live = still_listed(t)
            live_sig = sig_arr[t][live & np.isfinite(sig_arr[t])]
            sig_i = float(np.nanmedian(live_sig)) if live_sig.size else 0.0
            if not np.isfinite(sig_i):
                sig_i = 0.0
        adv_i = adv_arr[t, i]
        barra_part = barra_unit_cost(
            sig_i, adv_i, q_i, eta=float(eta_use), adv_floor=float(adv_floor)
        )
        return flat_part + barra_part

    def _event_cost_brl(t: int, live: np.ndarray, q: np.ndarray) -> Tuple[float, float, float]:
        """Devolve (cost, flat_cost, barra_cost) sobre notionals ``q``."""
        flat_cost = float(np.nansum(q)) * float(tcost) if cost_mode_uses_flat(mode) else 0.0
        raw_cost = 0.0
        barra_cost = 0.0
        if cost_mode_needs_barra(mode):
            assert sig_arr is not None and adv_arr is not None
            barra_cost, raw_cost = portfolio_barra_cost(
                sig_arr[t],
                adv_arr[t],
                q,
                live,
                eta=float(eta_use),
                adv_floor=float(adv_floor),
            )
        if mode == "gross":
            return 0.0, 0.0, 0.0
        return flat_cost + barra_cost, flat_cost, barra_cost

    def top_up_live_from_cash(
        t: int,
        live: np.ndarray,
        p: np.ndarray,
        *,
        event_tag: str,
    ) -> None:
        """Reinveste o caixa disponível igualmente nos vivos (só compras)."""
        nonlocal cash, shares
        k = int(live.sum())
        if k <= 0 or cash <= EPS:
            return
        # Custo estimado sobre o notional a comprar (= caixa atual).
        q_est = np.where(live, cash / k, 0.0)
        cost, flat_cost, barra_cost = _event_cost_brl(t, live, q_est)
        investable = max(0.0, float(cash) - float(cost))
        if investable <= EPS:
            cash = max(0.0, float(cash) - float(cost))
            return
        per = investable / k
        spent = 0.0
        for i in range(n_count):
            if not live[i]:
                continue
            price = float(p[i])
            if not np.isfinite(price) or price <= 0:
                continue
            qty = per / price
            record_trade(t, i, qty, price)
            shares[i] = float(shares[i] + qty)
            spent += per
        cash = float(cash) - spent - float(cost)
        if cash < 0 and abs(cash) < 1e-6:
            cash = 0.0
        nav_pre = max(spent + cost, EPS)
        cost_events.append(
            {
                "date": str(pd.Timestamp(dates[t]).date()),
                "event": event_tag,
                "nav_pre": float(nav_pre),
                "cost_brl": float(cost),
                "cost_bps_nav": float(10000.0 * cost / nav_pre),
                "flat_cost_brl": float(flat_cost),
                "barra_cost_brl": float(barra_cost),
                "raw_cost_brl_eta1": 0.0,
                "raw_cost_bps_nav_eta1": 0.0,
                "traded_notional": float(spent),
            }
        )

    def rebalance_to_live(
        t: int, live: np.ndarray, p: np.ndarray, event_tag: str
    ) -> Tuple[float, float]:
        """Aloca 1/N nos vivos; IR é debitado **antes** de dimensionar as compras.

        Devolve (volume vendido, ganho das vendas) já usados no IR.
        """
        nonlocal cash, shares, total_ir
        equity = cash + float(
            np.nansum(shares * np.where(np.isfinite(p) & (p > 0), p, 0.0))
        )
        k = int(live.sum())
        sales_notional = 0.0
        net_gain = 0.0
        if k == 0:
            for i in range(n_count):
                if shares[i] > EPS and np.isfinite(last_px[i]) and last_px[i] > 0:
                    price = float(last_px[i])
                    qty = shares[i]
                    avg = cost_avg[i] if cost_qty[i] > 0 else price
                    q_i = qty * price
                    proceeds = q_i * (1.0 - asset_unit_cost(t, i, q_i))
                    cash += proceeds
                    sales_notional += q_i
                    net_gain += (price - avg) * qty
                    record_trade(t, i, -qty, price)
                    shares[i] = 0.0
            ir = apply_ir(sales_notional, net_gain)
            return sales_notional, net_gain

        old_shares = shares.copy()
        # 1) Estima turnover/custo e vendas no alvo pré-IR.
        raw_target = equity / k
        raw_shares = np.where(live, raw_target / np.where(p > 0, p, np.nan), 0.0)
        q = np.abs(raw_shares - old_shares) * np.where(live, p, 0.0)
        q = np.where(np.isfinite(q), q, 0.0)
        cost, flat_cost, barra_cost = _event_cost_brl(t, live, q)

        # Vendas e ganhos implícitos no caminho para o alvo pré-custo/IR.
        tentative = np.where(live, (equity - cost) / k / np.where(p > 0, p, np.nan), 0.0)
        for i in range(n_count):
            if not live[i]:
                continue
            delta = float(tentative[i] - old_shares[i])
            price = float(p[i])
            if delta < -EPS and np.isfinite(price) and price > 0:
                sold = -delta
                avg = cost_avg[i] if cost_qty[i] > 0 else price
                sales_notional += sold * price
                net_gain += (price - avg) * sold

        ir = compute_ir(sales_notional, net_gain)
        equity_net = max(0.0, equity - cost - ir)
        if ir > 0:
            total_ir += ir

        target = equity_net / k
        new_shares = np.where(live, target / np.where(live, p, np.nan), 0.0)
        # Zera mortos / não-vivos
        new_shares = np.where(live, new_shares, 0.0)

        # Aplica trades definitivos (custos médios).
        for i in range(n_count):
            delta = float(new_shares[i] - old_shares[i])
            price = (
                float(p[i])
                if live[i]
                else (float(last_px[i]) if np.isfinite(last_px[i]) else np.nan)
            )
            if abs(delta) <= EPS or not np.isfinite(price) or price <= 0:
                shares[i] = float(new_shares[i]) if live[i] else 0.0
                continue
            record_trade(t, i, delta, price)
            shares[i] = float(new_shares[i])

        cash = equity_net - float(np.nansum(shares * np.where(live, p, 0.0)))
        if cash < 0 and abs(cash) < 1e-6:
            cash = 0.0
        nav_pre = max(equity, EPS)
        cost_events.append(
            {
                "date": str(pd.Timestamp(dates[t]).date()),
                "event": event_tag,
                "nav_pre": float(nav_pre),
                "cost_brl": float(cost),
                "cost_bps_nav": float(10000.0 * cost / nav_pre),
                "flat_cost_brl": float(flat_cost),
                "barra_cost_brl": float(barra_cost),
                "raw_cost_brl_eta1": 0.0,
                "raw_cost_bps_nav_eta1": 0.0,
                "traded_notional": float(np.nansum(q)),
                "ir_brl": float(ir),
            }
        )
        return sales_notional, net_gain

    for t in range(t_count):
        finite = np.isfinite(px[t]) & (px[t] > 0)
        last_px[finite] = px[t][finite]
        still = still_listed(t)
        dead = (shares > EPS) & (~still) & (~already_delisted)
        is_reb = pd.Timestamp(dates[t]).normalize() in reb_set
        scheduled_reb = bool(rebalance and is_reb)
        must_open = t == 0
        p_mark = mark_prices(t)

        day_sales = 0.0
        day_gain = 0.0
        if dead.any():
            for i in np.where(dead)[0]:
                price = float(last_px[i]) * (1.0 + float(delist_terminal_return))
                if not np.isfinite(price) or price <= 0:
                    shares[i] = 0.0
                    already_delisted[i] = True
                    continue
                qty = float(shares[i])
                avg = cost_avg[i] if cost_qty[i] > 0 else price
                q_i = qty * price
                proceeds = q_i * (1.0 - asset_unit_cost(t, i, q_i))
                cash += proceeds
                day_sales += q_i
                day_gain += (price - avg) * qty
                record_trade(t, i, -qty, price)
                events.append(
                    {
                        "date": str(pd.Timestamp(dates[t]).date()),
                        "ticker": tickers[i],
                        "event": "delist",
                        "price": price,
                        "quantity": qty,
                    }
                )
                shares[i] = 0.0
                already_delisted[i] = True

            # IR da deslistagem ANTES de reinvestir o produto.
            apply_ir(day_sales, day_gain)
            live = still_listed(t) & np.isfinite(p_mark) & (p_mark > 0)
            if scheduled_reb or must_open:
                # Dia de rebalance periódico: 1/N completo (já com IR interno).
                rebalance_to_live(t, live, p_mark, "rebalance" if scheduled_reb else "open")
            else:
                # Só top-up do caixa líquido nos vivos (não vende sobreviventes).
                top_up_live_from_cash(t, live, p_mark, event_tag="delist_topup")
        elif must_open or scheduled_reb:
            live = still_listed(t) & np.isfinite(p_mark) & (p_mark > 0)
            tag = "open" if must_open else "rebalance"
            rebalance_to_live(t, live, p_mark, tag)

        nav_brl[t] = mark_value(t)

    nav = pd.Series(nav_brl, index=dates, name="nav")
    if float(nav.iloc[0]) == 0.0:
        raise ValueError("NAV inicial nulo.")
    nav_bt = nav / float(nav.iloc[0]) * 100.0
    tx = _tx_from_records(records)

    exit_info = _empty_exit_info()
    exit_info["total_ir_paid_incl_exit"] = float(total_ir)
    if liquidate_at_end and t_count > 0:
        t_exit = t_count - 1
        p_exit = mark_prices(t_exit)
        cash_exit = float(cash)
        sales_notional = 0.0
        net_gain = 0.0
        exit_cost = 0.0
        for i in range(n_count):
            if shares[i] <= EPS:
                continue
            if np.isfinite(p_exit[i]) and p_exit[i] > 0:
                price = float(p_exit[i])
            elif np.isfinite(last_px[i]) and last_px[i] > 0:
                price = float(last_px[i])
            else:
                continue
            qty = float(shares[i])
            avg = float(cost_avg[i]) if cost_qty[i] > 0 else price
            q_i = qty * price
            unit = asset_unit_cost(t_exit, i, q_i)
            proceeds = q_i * (1.0 - unit)
            cash_exit += proceeds
            exit_cost += q_i * unit
            sales_notional += q_i
            net_gain += (price - avg) * qty

        exit_ir = 0.0
        if apply_stock_ir and sales_notional > EPS:
            if sales_notional > float(ir_monthly_sales_exemption):
                exit_ir = float(ir_rate) * max(0.0, net_gain)
            if exit_ir > 0:
                cash_exit -= exit_ir

        exit_info = {
            "liquidate_at_end": True,
            "final_wealth_brl": float(cash_exit),
            "exit_sales_notional_brl": float(sales_notional),
            "exit_net_gain_brl": float(net_gain),
            "exit_cost_brl": float(exit_cost),
            "exit_ir_brl": float(exit_ir),
            "total_ir_paid_incl_exit": float(total_ir) + float(exit_ir),
        }

    return nav_bt, tx, events, total_ir, cost_events, exit_info


def run_delist_backtest_ew(
    df_prices: pd.DataFrame,
    tickers: list,
    tcost: float,
    start_y: int,
    start_m: int,
    end_y: int,
    end_m: int,
    initial_capital: float,
    *,
    rebalance: bool,
    rebalance_freq: str = "annual",
    rebalance_month: int = 7,
    strat_name: str = "EW",
    rf_df: Optional[pd.DataFrame] = None,
    rf_date_col: str = "DATE",
    rf_col: str = "RF",
    rf_align_fill: str = "ffill",
    ann_factor: int = 252,
    apply_stock_ir: bool = False,
    ir_rate: float = DEFAULT_IR_RATE,
    ir_monthly_sales_exemption: float = DEFAULT_IR_MONTHLY_SALES_EXEMPTION,
    max_gap_days: int = 5,
    delist_terminal_return: float = 0.0,
    cost_mode: str = "flat",
    eta: float = 0.0,
    sigma_panel: Optional[pd.DataFrame] = None,
    adv_panel: Optional[pd.DataFrame] = None,
    liquidate_at_end: bool = False,
):
    tickers = [padronizar_ticker(t) for t in tickers]
    panel = _prepare_panel(df_prices, start_y, start_m, end_y, end_m)
    missing = [t for t in tickers if t not in panel.columns]
    if missing:
        raise ValueError(f"Colunas ausentes no CSV de preços: {missing}")

    prices, chain_audit = chain_portfolio_prices(
        panel, tickers, max_gap_days=max_gap_days
    )
    prices = prices[tickers]
    if prices.empty:
        raise ValueError("Após o encadeamento, não restou período com preços.")

    start_target = prices.index.min()
    end_target = prices.index.max()
    if rebalance:
        rebalance_dates = build_rebalance_dates(
            prices.index,
            freq=rebalance_freq,
            annual_month=rebalance_month,
            start=start_target,
            end=end_target,
        )
        if not rebalance_dates:
            raise ValueError("Não foi possível montar datas de rebalanceamento no período.")
    else:
        rebalance_dates = [pd.Timestamp(start_target)]

    # Painéis BARRA alinhados às colunas do painel encadeado (tickers de formação).
    sig_use = None
    adv_use = None
    if cost_mode_needs_barra(cost_mode):
        if sigma_panel is None or adv_panel is None:
            raise ValueError(f"cost_mode={cost_mode} requer sigma_panel e adv_panel")
        sig_use = sigma_panel.reindex(columns=list(prices.columns))
        adv_use = adv_panel.reindex(columns=list(prices.columns))

    nav, tx, events, total_ir_paid, cost_events, exit_info = simulate_ew_nav(
        prices,
        tcost=tcost,
        initial_capital=initial_capital,
        rebalance=rebalance,
        rebalance_dates=rebalance_dates,
        apply_stock_ir=apply_stock_ir,
        ir_rate=ir_rate,
        ir_monthly_sales_exemption=ir_monthly_sales_exemption,
        delist_terminal_return=delist_terminal_return,
        cost_mode=cost_mode,
        eta=eta,
        sigma_panel=sig_use,
        adv_panel=adv_use,
        liquidate_at_end=liquidate_at_end,
    )
    nav_gross = nav.copy()
    total_return_gross = float(nav_gross.iloc[-1] / nav_gross.iloc[0] - 1.0)

    rf = None
    if rf_df is not None:
        rf_local = rf_df.copy()
        if rf_date_col not in rf_local.columns:
            for cand in ("Date", "date", "DATA", "data"):
                if cand in rf_local.columns:
                    rf_date_col = cand
                    break
        if rf_col not in rf_local.columns:
            for cand in ("Rf", "rf", "RISKFREE", "risk_free"):
                if cand in rf_local.columns:
                    rf_col = cand
                    break
        if rf_date_col not in rf_local.columns or rf_col not in rf_local.columns:
            raise ValueError(f"RF DF precisa ter colunas de data e RF. Colunas: {list(rf_local.columns)}")
        rf_local[rf_date_col] = pd.to_datetime(rf_local[rf_date_col])
        rf_local = rf_local.sort_values(rf_date_col).set_index(rf_date_col)
        rf = pd.to_numeric(rf_local[rf_col], errors="coerce").sort_index().reindex(nav.index)
        if rf_align_fill == "ffill":
            rf = rf.ffill().bfill()
        elif rf_align_fill == "bfill":
            rf = rf.bfill().ffill()

    metrics = _recompute_return_metrics(nav, rf, ann_factor)
    turnover_series = _turnover_from_tx(tx, nav, zero_first=not rebalance)
    avg_turnover_all_days = float(turnover_series.mean()) if len(turnover_series) else np.nan
    avg_turnover_trade_days = (
        float(turnover_series[turnover_series > 0].mean()) if (turnover_series > 0).any() else 0.0
    )
    stats = nav_to_res_stats(nav)
    res = SimpleRes(strat_name, stats, nav)

    n_delist = sum(1 for e in events if e.get("event") == "delist")
    n_conv = sum(1 for a in chain_audit if a.get("conversao"))
    reb_costs = [
        e
        for e in cost_events
        if e.get("event") in ("rebalance", "open", "delist_topup", "delist_reb")
    ]
    mean_cost_bps = (
        float(np.mean([e["cost_bps_nav"] for e in reb_costs])) if reb_costs else np.nan
    )
    aux = {
        "prices": prices,
        "rebalance": bool(rebalance),
        "rebalance_freq": rebalance_freq if rebalance else "none",
        "rebalance_dates": rebalance_dates,
        "nav": nav,
        "returns": metrics["returns"],
        "rf": rf,
        "excess_returns": metrics["excess_returns"],
        "drawdown": metrics["drawdown"],
        "retorno_acumulado_pct": metrics["retorno_acumulado_pct"],
        "retorno_excesso_acumulado_pct": metrics["retorno_excesso_acumulado_pct"],
        "sharpe_excess": metrics["sharpe_excess"],
        "vol_excess_ann": metrics["vol_excess_ann"],
        "cagr": metrics["cagr"],
        "total_return": metrics["total_return"],
        "total_return_gross": total_return_gross,
        "total_excess_return": metrics["total_excess_return"],
        "ceq_gamma1_daily": metrics["ceq_gamma1_daily"],
        "ceq_gamma1_ann": metrics["ceq_gamma1_ann"],
        "ceq_base": metrics["ceq_base"],
        "turnover": turnover_series,
        "avg_turnover": avg_turnover_all_days,
        "avg_turnover_trade_days": avg_turnover_trade_days,
        "n_trade_days": int((turnover_series > 0).sum()),
        "bt_test_name": strat_name,
        "apply_stock_ir": bool(apply_stock_ir),
        "ir_rate": float(ir_rate) if apply_stock_ir else None,
        "ir_monthly_sales_exemption": (
            float(ir_monthly_sales_exemption) if apply_stock_ir else None
        ),
        "total_ir_paid": float(total_ir_paid),
        "tcost": float(tcost),
        "cost_mode": str(cost_mode).lower(),
        "eta": float(effective_eta(cost_mode, eta)) if cost_mode_needs_barra(cost_mode) else None,
        "cost_events": cost_events,
        "mean_cost_bps_reb": mean_cost_bps,
        "n_cost_events": len(cost_events),
        "n_delist": n_delist,
        "n_conversoes": n_conv,
        "chain_audit": chain_audit,
        "delist_events": events,
        "delist_terminal_return": float(delist_terminal_return),
        "engine": ENGINE_TAG,
        "liquidate_at_end": bool(exit_info.get("liquidate_at_end")),
        "final_wealth_brl": exit_info.get("final_wealth_brl"),
        "exit_sales_notional_brl": exit_info.get("exit_sales_notional_brl"),
        "exit_net_gain_brl": exit_info.get("exit_net_gain_brl"),
        "exit_cost_brl": exit_info.get("exit_cost_brl"),
        "exit_ir_brl": exit_info.get("exit_ir_brl"),
        "total_ir_paid_incl_exit": exit_info.get("total_ir_paid_incl_exit"),
    }
    return res, aux


def parse_args(argv: Optional[Iterable[str]] = None) -> DelistBacktestConfig:
    parser = argparse.ArgumentParser(
        description=(
            "Backtest EW v4: conversão de ticker e liquidação 1/(N-1) na "
            "deslistagem. Custo flat (bps) ou BARRA (η·σ·√(q/ADV)). "
            "Grava em Backtest_Mestrado_PF_LIQUIDEZ_1MM."
        )
    )
    parser.add_argument("--carteiras", type=Path, required=True)
    parser.add_argument("--start-m", type=int, default=7)
    parser.add_argument("--start-y", type=int, default=2001)
    parser.add_argument("--end-m", type=int, default=10)
    parser.add_argument("--end-y", type=int, default=2025)
    parser.add_argument(
        "--rebalance",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Rebalanceamento periódico (default: sim). --no-rebalance = buy-and-hold + top-up na deslistagem (v4.1).",
    )
    parser.add_argument("--rebalance-freq", choices=REBALANCE_FREQS, default="annual")
    parser.add_argument("--rebalance-month", type=int, default=7)
    parser.add_argument(
        "--cost-mode",
        choices=COST_MODES,
        default="flat",
        help=(
            "flat=tcost; barra=η·σ·√(q/ADV); barra_raw=σ·√(q/ADV) (η≡1); "
            "flat_barra=flat+barra_raw; gross=sem custo. "
            "Ignorado se --all-cost-modes."
        ),
    )
    parser.add_argument(
        "--all-cost-modes",
        action="store_true",
        help=(
            "Roda e grava os cenários em sequência: "
            f"{', '.join(ALL_COST_SCENARIOS)} (collections distintas)."
        ),
    )
    parser.add_argument(
        "--tcost-bps",
        type=float,
        default=12.0,
        help="Custo flat em bps (flat e flat_barra). Default Cap. 7: 12.",
    )
    parser.add_argument("--tcost", type=float, default=None)
    parser.add_argument(
        "--eta",
        type=float,
        default=None,
        help=(
            "Escala BARRA (obrigatório se barra/--all-cost-modes sem --eta-from; "
            "barra_raw e flat_barra usam η=1)."
        ),
    )
    parser.add_argument(
        "--eta-from",
        type=Path,
        default=None,
        help="JSON calibration_eta.json (chave 'eta') do run de sensibilidade BARRA.",
    )
    parser.add_argument("--volume", type=Path, default=DEFAULT_VOLUME_XLSX)
    parser.add_argument(
        "--apply-stock-ir",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    parser.add_argument("--ir-rate", type=float, default=DEFAULT_IR_RATE)
    parser.add_argument(
        "--ir-monthly-sales-exemption",
        type=float,
        default=DEFAULT_IR_MONTHLY_SALES_EXEMPTION,
    )
    parser.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    parser.add_argument("--db-name", default=DEFAULT_DB_NAME)
    parser.add_argument("--prices-path", type=Path, default=DEFAULT_PRICES_PATH)
    parser.add_argument("--rf-path", type=Path, default=DEFAULT_RF_PATH)
    parser.add_argument("--capital", type=float, default=10_000.0)
    parser.add_argument("--collections-suffix", default=None)
    parser.add_argument(
        "--universo-tag",
        default=None,
        help=(
            "Tag do universo no nome da collection (ex.: liq_1MM, liq_divliq_1MM). "
            "Default: inferida do CSV, sem o YYYYMM de formação."
        ),
    )
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument(
        "--skip-failed",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    parser.add_argument(
        "--max-gap-days",
        type=int,
        default=5,
        help="Pregões de ffill para suspensão temporária (default: 5). Não preenche após a última cotação.",
    )
    parser.add_argument(
        "--delist-terminal-return",
        type=float,
        default=0.0,
        help="Retorno extra na liquidação sem sucessor (ex.: -0.30 no espírito de Shumway). Default: 0.",
    )
    parser.add_argument(
        "--liquidate-at-end",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "No último pregão, calcula patrimônio após venda forçada de todas as "
            "posições (custos do cost_mode + IR PF), sem alterar a série de NAV."
        ),
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Não grava no Mongo; só executa o backtest e imprime métricas.",
    )
    args = parser.parse_args(list(argv) if argv is not None else None)

    if not 1 <= args.start_m <= 12 or not 1 <= args.end_m <= 12:
        parser.error("Mês de início/fim deve estar entre 1 e 12.")
    if not 1 <= args.rebalance_month <= 12:
        parser.error("--rebalance-month deve estar entre 1 e 12.")
    if datetime(args.start_y, args.start_m, 1) > datetime(args.end_y, args.end_m, 1):
        parser.error("A data inicial não pode ser posterior à data final.")

    cost_mode = str(args.cost_mode).lower()
    all_cost_modes = bool(args.all_cost_modes)
    if args.tcost is not None:
        tcost = float(args.tcost)
        tcost_bps = tcost * 10_000.0
    else:
        tcost_bps = float(args.tcost_bps)
        tcost = bps_to_fraction(tcost_bps)
    if cost_mode == "gross" and not all_cost_modes:
        tcost = 0.0
        tcost_bps = 0.0

    eta = 0.0
    needs_eta = all_cost_modes or cost_mode_needs_eta(cost_mode)
    if needs_eta:
        if args.eta is None and args.eta_from is None:
            parser.error(
                "barra / --all-cost-modes exige --eta ou --eta-from "
                "(barra_raw e flat_barra usam η=1)"
            )
        eta = (
            load_eta_from_json(args.eta_from, args.eta)
            if args.eta_from
            else float(args.eta)
        )
        if not np.isfinite(eta) or eta < 0:
            parser.error(f"eta invalido: {eta}")

    universo_tag = (
        str(args.universo_tag) if args.universo_tag else infer_universo_tag(args.carteiras)
    )

    return DelistBacktestConfig(
        carteiras_path=args.carteiras,
        start_y=args.start_y,
        start_m=args.start_m,
        end_y=args.end_y,
        end_m=args.end_m,
        rebalance=bool(args.rebalance),
        rebalance_freq=str(args.rebalance_freq),
        rebalance_month=int(args.rebalance_month),
        tcost=tcost,
        tcost_bps=tcost_bps,
        cost_mode=cost_mode,
        eta=float(eta),
        volume_path=Path(args.volume),
        apply_stock_ir=bool(args.apply_stock_ir),
        ir_rate=float(args.ir_rate),
        ir_monthly_sales_exemption=float(args.ir_monthly_sales_exemption),
        mongo_uri=args.mongo_uri,
        db_name=args.db_name,
        prices_path=args.prices_path,
        rf_path=args.rf_path,
        capital=float(args.capital),
        collections_suffix=args.collections_suffix or "",
        universo_tag=universo_tag,
        limit=int(args.limit),
        skip_failed=bool(args.skip_failed),
        max_gap_days=int(args.max_gap_days),
        delist_terminal_return=float(args.delist_terminal_return),
        liquidate_at_end=bool(args.liquidate_at_end),
        dry_run=bool(args.dry_run),
        all_cost_modes=all_cost_modes,
    )


def run_batch_backtests(
    config: DelistBacktestConfig,
    *,
    df_prices: Optional[pd.DataFrame] = None,
    rf_df: Optional[pd.DataFrame] = None,
    sigma_panel: Optional[pd.DataFrame] = None,
    adv_panel: Optional[pd.DataFrame] = None,
) -> None:
    v2.SETUP_SUBSTEPS = SETUP_SUBSTEPS
    v2.PORTFOLIO_SUBSTEPS = PORTFOLIO_SUBSTEPS

    if not config.carteiras_path.exists():
        raise FileNotFoundError(f"Arquivo de carteiras não encontrado: {config.carteiras_path}")

    progress = BatchRunProgress(len(SETUP_SUBSTEPS), 0, len(PORTFOLIO_SUBSTEPS))
    print(
        f"Iniciando batch v4 | cost_mode={config.cost_mode} ...",
        flush=True,
    )

    if df_prices is None:
        df_prices = load_prices(config.prices_path)
    progress.tick_setup(1, str(config.prices_path))

    if rf_df is None:
        rf_df = pd.read_csv(config.rf_path)
    progress.tick_setup(2, str(config.rf_path))

    df_cb = load_carteiras_csv(config.carteiras_path)
    if config.limit and config.limit > 0:
        df_cb = df_cb.iloc[: config.limit].copy()
    n_ativos = infer_n_ativos(config.carteiras_path, int(df_cb.iloc[0]["Total_papeis"]))
    suffix = config.collections_suffix or build_collections_suffix(config, n_ativos)
    col_res = f"res_{suffix}"
    metrics_collection = f"aux_metrics_{suffix}"
    series_gross = f"ret_acum_pct_{suffix}"
    series_excess = f"ret_excess_acum_pct_{suffix}"
    progress.tick_setup(3, f"{len(df_cb)} carteiras | {config.carteiras_path.name}")

    if cost_mode_needs_barra(config.cost_mode) and (sigma_panel is None or adv_panel is None):
        cache_dir = REPO_ROOT / "resultados" / "sensibilidade_barra"
        vol_cache = volume_cache_path(cache_dir)
        print(f"Carregando volume/sigma/ADV (window={VOL_WINDOW})...", flush=True)
        volume_brl = load_volume_brl(config.volume_path, vol_cache)
        prices_wide = prices_df_to_wide(df_prices)
        common = [c for c in prices_wide.columns if c in volume_brl.columns]
        vol = volume_brl.reindex(columns=prices_wide.columns)
        sigma_panel, adv_panel = build_sigma_adv_panels(
            prices_wide, vol, window=VOL_WINDOW
        )
        print(
            f"  sigma/ADV OK | tickers_preco={prices_wide.shape[1]} "
            f"overlap_volume={len(common)}",
            flush=True,
        )

    client = None
    if config.dry_run:
        progress.tick_setup(4, "dry-run (sem Mongo)")
        pending = [row for _, row in df_cb.iterrows()]
        skipped = 0
        progress.tick_setup(5, f"pendentes (dry-run): {len(pending)}")
    else:
        client = MongoClient(config.mongo_uri, serverSelectionTimeoutMS=15000)
        db = client[config.db_name]
        col = db[metrics_collection]
        n_docs = col.count_documents({})
        progress.tick_setup(4, f"{config.db_name}.{metrics_collection} ({n_docs} docs)")

        df_aux = load_collection_as_df(col)
        existing = set() if df_aux.empty else set(df_aux["strategy"].astype(str).dropna().unique())
        need_exit = set()
        if config.liquidate_at_end and not df_aux.empty and "strategy" in df_aux.columns:
            if "final_wealth_brl" in df_aux.columns:
                missing_fw = df_aux["final_wealth_brl"].isna()
            else:
                missing_fw = pd.Series(True, index=df_aux.index)
            if "liquidate_at_end" in df_aux.columns:
                not_flag = ~df_aux["liquidate_at_end"].fillna(False).astype(bool)
            else:
                not_flag = pd.Series(True, index=df_aux.index)
            need_exit = set(
                df_aux.loc[missing_fw | not_flag, "strategy"].astype(str).dropna().unique()
            )

        pending = []
        for _, row in df_cb.iterrows():
            strat_name = "-".join(row["tickers"])
            if strat_name not in existing or strat_name in need_exit:
                pending.append(row)
        skipped = len(df_cb) - len(pending)
        progress.tick_setup(
            5,
            f"já processadas: {len(existing)} | pendentes: {len(pending)} | "
            f"ignoradas neste run: {skipped}"
            + (f" | reprocessar_exit: {len(need_exit)}" if config.liquidate_at_end else ""),
        )
    progress.set_portfolio_workload(len(pending))

    reb_label = (
        f"rebalance={config.rebalance_freq} (mês âncora={config.rebalance_month:02d})"
        if config.rebalance
        else "buy-and-hold + top-up do produto na deslistagem (v4.1)"
    )
    if config.cost_mode == "barra":
        cost_label = f"cost=barra eta={config.eta:.6g}"
    elif config.cost_mode == "barra_raw":
        cost_label = "cost=barra_raw (eta=1, σ·√(q/ADV))"
    elif config.cost_mode == "flat_barra":
        cost_label = (
            f"cost=flat_barra {config.tcost_bps:.1f} bps + barra_raw (eta=1)"
        )
    elif config.cost_mode == "gross":
        cost_label = "cost=gross (0)"
    else:
        cost_label = f"cost=flat {config.tcost_bps:.1f} bps ({config.tcost:.4%})"
    print(
        f"Período: {config.start_m:02d}/{config.start_y} a {config.end_m:02d}/{config.end_y} | "
        f"{reb_label} | {cost_label} | "
        f"IR={'sim' if config.apply_stock_ir else 'não'} | "
        f"liquidate_at_end={'sim' if config.liquidate_at_end else 'não'} | "
        f"distress={config.delist_terminal_return:.0%}",
        flush=True,
    )
    print(
        "Collections de saída:",
        f"db={config.db_name!r},",
        f"col_res={col_res!r},",
        f"metrics={metrics_collection!r},",
        f"gross={series_gross!r},",
        f"excess={series_excess!r}",
        flush=True,
    )

    if not pending:
        progress.finish(processed=0, skipped=skipped)
        if client is not None:
            client.close()
        return

    processed = 0
    failed = 0
    for portfolio_index, row in enumerate(pending, start=1):
        tickers = list(row["tickers"])
        strat_name = "-".join(tickers)
        base_name = str(row["Base"])
        detail = f"{base_name} | {strat_name[:80]}"
        try:
            res, aux = run_delist_backtest_ew(
                df_prices=df_prices,
                tickers=tickers,
                tcost=config.tcost,
                start_y=config.start_y,
                start_m=config.start_m,
                end_y=config.end_y,
                end_m=config.end_m,
                initial_capital=config.capital,
                rebalance=config.rebalance,
                rebalance_freq=config.rebalance_freq,
                rebalance_month=config.rebalance_month,
                rf_df=rf_df,
                strat_name=strat_name,
                apply_stock_ir=config.apply_stock_ir,
                ir_rate=config.ir_rate,
                ir_monthly_sales_exemption=config.ir_monthly_sales_exemption,
                max_gap_days=config.max_gap_days,
                delist_terminal_return=config.delist_terminal_return,
                cost_mode=config.cost_mode,
                eta=config.eta,
                sigma_panel=sigma_panel,
                adv_panel=adv_panel,
                liquidate_at_end=config.liquidate_at_end,
            )
        except Exception as exc:
            failed += 1
            print(f"    [ERRO] {detail} — {exc}", flush=True)
            if not config.skip_failed:
                raise
            progress.tick_portfolio(portfolio_index, 1, f"{detail} | FALHOU")
            for sub in range(2, 6):
                progress.tick_portfolio(portfolio_index, sub, f"{detail} | ignorado")
            continue

        progress.tick_portfolio(portfolio_index, 1, detail)

        if config.dry_run:
            fw = aux.get("final_wealth_brl")
            fw_s = f"{fw:.2f}" if fw is not None else "n/a"
            print(
                f"    [dry-run] Sharpe={aux.get('sharpe_excess')} | "
                f"total_ret={aux.get('total_return'):.4f} | "
                f"mean_cost_bps={aux.get('mean_cost_bps_reb')} | "
                f"n_cost_events={aux.get('n_cost_events')} | "
                f"IR pago={aux.get('total_ir_paid', 0):.2f} | "
                f"final_wealth={fw_s} | exit_ir={aux.get('exit_ir_brl')}",
                flush=True,
            )
            for sub in range(2, 6):
                progress.tick_portfolio(portfolio_index, sub, f"{detail} | dry-run")
            processed += 1
            continue

        info = save_res_display_only_to_mongo(
            mongo_uri=config.mongo_uri,
            base_name=base_name,
            res=res,
            db_name=config.db_name,
            col_res=col_res,
        )
        progress.tick_portfolio(portfolio_index, 2, f"{detail} | status={info.get('status')}")

        upsert_aux_metrics(
            mongo_uri=config.mongo_uri,
            db_name=config.db_name,
            metrics_collection=metrics_collection,
            aux=aux,
            strategy=strat_name,
            extra_fields={
                "tcost": config.tcost,
                "tcost_bps": config.tcost_bps,
                "cost_mode": config.cost_mode,
                "eta": (
                    float(effective_eta(config.cost_mode, config.eta))
                    if cost_mode_needs_barra(config.cost_mode)
                    else None
                ),
                "mean_cost_bps_reb": aux.get("mean_cost_bps_reb"),
                "n_cost_events": aux.get("n_cost_events"),
                "tickers": tickers,
                "apply_stock_ir": config.apply_stock_ir,
                "ir_rate": config.ir_rate if config.apply_stock_ir else None,
                "rebalance": config.rebalance,
                "rebalance_freq": config.rebalance_freq if config.rebalance else "none",
                "start_y": config.start_y,
                "start_m": config.start_m,
                "end_y": config.end_y,
                "end_m": config.end_m,
                "carteiras_file": str(config.carteiras_path.name),
                "universo_tag": config.universo_tag,
                "engine": ENGINE_TAG,
                "n_delist": aux.get("n_delist"),
                "n_conversoes": aux.get("n_conversoes"),
                "delist_terminal_return": config.delist_terminal_return,
                "liquidate_at_end": bool(aux.get("liquidate_at_end")),
                "final_wealth_brl": aux.get("final_wealth_brl"),
                "exit_sales_notional_brl": aux.get("exit_sales_notional_brl"),
                "exit_net_gain_brl": aux.get("exit_net_gain_brl"),
                "exit_cost_brl": aux.get("exit_cost_brl"),
                "exit_ir_brl": aux.get("exit_ir_brl"),
                "total_ir_paid_incl_exit": aux.get("total_ir_paid_incl_exit"),
            },
        )
        progress.tick_portfolio(portfolio_index, 3, detail)

        n1 = save_series_in_collection(
            mongo_uri=config.mongo_uri,
            db_name=config.db_name,
            series_collection=series_gross,
            series=aux.get("retorno_acumulado_pct"),
            strategy=strat_name,
            overwrite_strategy=True,
            monthly_how="last",
            monthly_rule="ME",
        )
        progress.tick_portfolio(portfolio_index, 4, f"{detail} | pontos={n1}")

        n2 = save_series_in_collection(
            mongo_uri=config.mongo_uri,
            db_name=config.db_name,
            series_collection=series_excess,
            series=aux.get("retorno_excesso_acumulado_pct"),
            strategy=strat_name,
            overwrite_strategy=True,
            monthly_how="last",
            monthly_rule="ME",
        )
        progress.tick_portfolio(portfolio_index, 5, f"{detail} | pontos={n2}")

        processed += 1
        fw = aux.get("final_wealth_brl")
        fw_s = f"{fw:.2f}" if fw is not None else "n/a"
        print(
            f"    ↳ res.display: {info.get('status')} | ret_acum={n1} | ret_excess={n2} | "
            f"IR pago={aux.get('total_ir_paid', 0):.2f} | "
            f"final_wealth={fw_s} | exit_ir={aux.get('exit_ir_brl')} | "
            f"mean_cost_bps={aux.get('mean_cost_bps_reb')} | "
            f"delist={aux.get('n_delist', 0)} | conv={aux.get('n_conversoes', 0)}",
            flush=True,
        )

    progress.finish(processed=processed, skipped=skipped)
    if failed:
        print(f"Carteiras com falha (puladas): {failed}", flush=True)
    if client is not None:
        client.close()


def config_for_cost_mode(base: DelistBacktestConfig, mode: str) -> DelistBacktestConfig:
    """Copia o config com um cost_mode e tcost coerente (gross zera flat)."""
    mode = str(mode).lower()
    if mode not in COST_MODES:
        raise ValueError(f"cost_mode invalido: {mode}")
    tcost = 0.0 if mode == "gross" else float(base.tcost)
    tcost_bps = 0.0 if mode == "gross" else float(base.tcost_bps)
    # Se base veio de gross-only, tcost pode estar 0 — restaura do default Cap.7.
    if mode != "gross" and tcost_bps <= 0:
        tcost_bps = 12.0
        tcost = bps_to_fraction(tcost_bps)
    eta = 1.0 if mode in ("barra_raw", "flat_barra") else float(base.eta)
    return replace(
        base,
        cost_mode=mode,
        tcost=tcost,
        tcost_bps=tcost_bps,
        eta=eta,
        collections_suffix="",
        all_cost_modes=False,
    )


def load_sigma_adv_for_config(
    config: DelistBacktestConfig,
    df_prices: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    cache_dir = REPO_ROOT / "resultados" / "sensibilidade_barra"
    vol_cache = volume_cache_path(cache_dir)
    print(f"Carregando volume/sigma/ADV (window={VOL_WINDOW}) [shared]...", flush=True)
    volume_brl = load_volume_brl(config.volume_path, vol_cache)
    prices_wide = prices_df_to_wide(df_prices)
    common = [c for c in prices_wide.columns if c in volume_brl.columns]
    vol = volume_brl.reindex(columns=prices_wide.columns)
    sigma, adv = build_sigma_adv_panels(prices_wide, vol, window=VOL_WINDOW)
    print(
        f"  sigma/ADV OK | tickers_preco={prices_wide.shape[1]} "
        f"overlap_volume={len(common)}",
        flush=True,
    )
    return sigma, adv


def run_all_cost_mode_scenarios(base: DelistBacktestConfig) -> None:
    """Grava todos os cenários de ALL_COST_SCENARIOS reusando preços/painéis."""
    print(
        "=== --all-cost-modes: "
        + ", ".join(ALL_COST_SCENARIOS)
        + " ===",
        flush=True,
    )
    df_prices = load_prices(base.prices_path)
    rf_df = pd.read_csv(base.rf_path)
    sigma_panel, adv_panel = load_sigma_adv_for_config(base, df_prices)
    for mode in ALL_COST_SCENARIOS:
        cfg = config_for_cost_mode(base, mode)
        print(f"\n######## cenário: {mode} ########", flush=True)
        run_batch_backtests(
            cfg,
            df_prices=df_prices,
            rf_df=rf_df,
            sigma_panel=sigma_panel if cost_mode_needs_barra(mode) else None,
            adv_panel=adv_panel if cost_mode_needs_barra(mode) else None,
        )


def main(config: Optional[DelistBacktestConfig] = None) -> None:
    cfg = config or parse_args()
    if cfg.all_cost_modes:
        run_all_cost_mode_scenarios(cfg)
    else:
        run_batch_backtests(cfg)


if __name__ == "__main__":
    main()
