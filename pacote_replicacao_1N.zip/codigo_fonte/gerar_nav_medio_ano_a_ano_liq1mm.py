#!/usr/bin/env python3
"""Gera CSV com NAV médio ano a ano × N de ativos (collections liq_1MM).

Lê as séries mensais ``ret_acum_pct_{N}atv_<suffix>`` do MongoDB
``Backtest_Mestrado_PF_LIQUIDEZ_1MM``, reconstrói o NAV a partir do retorno
acumulado percentual:

    NAV_index = 100 + ret_acum_pct
    NAV_BRL   = capital * (1 + ret_acum_pct / 100)

Para cada carteira, toma o último ponto de cada ano-calendário (dezembro,
exceto 2025 → out/2025) e calcula a média cross-section por (ano, N).

Exemplo::

    python codigo_fonte/gerar_nav_medio_ano_a_ano_liq1mm.py

    python codigo_fonte/gerar_nav_medio_ano_a_ano_liq1mm.py \\
        --suffix atv_liq_1MM_200107_202510_reb-annual_t12bps_ir \\
        --capital 10000 \\
        --output-csv resultados/liquidez_1mm_delist/nav_medio_ano_a_ano_t12bps_ir.csv
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Optional, Sequence

import pandas as pd
from pymongo import MongoClient
from pymongo.database import Database

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MONGO_URI = "mongodb://172.23.224.1:27017/"
DEFAULT_DB_NAME = "Backtest_Mestrado_PF_LIQUIDEZ_1MM"
DEFAULT_SUFFIX = "atv_liq_1MM_200107_202510_reb-annual_t12bps_ir"
DEFAULT_CAPITAL = 10_000.0
DEFAULT_OUTPUT_CSV = (
    REPO_ROOT
    / "resultados"
    / "liquidez_1mm_delist"
    / "nav_medio_ano_a_ano_liq_1MM_200107_202510_reb-annual_t12bps_ir.csv"
)

def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description=(
            "NAV médio ano a ano por N de ativos a partir de "
            "ret_acum_pct_* no MongoDB."
        )
    )
    p.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    p.add_argument("--db-name", default=DEFAULT_DB_NAME)
    p.add_argument(
        "--suffix",
        default=DEFAULT_SUFFIX,
        help=(
            "Sufixo comum das collections (sem o prefixo ret_acum_pct_ "
            "nem o N). Default: %(default)s"
        ),
    )
    p.add_argument(
        "--ativos",
        type=int,
        nargs="*",
        default=None,
        help="Filtrar N (ex.: --ativos 8 10 20). Default: todos encontrados.",
    )
    p.add_argument(
        "--capital",
        type=float,
        default=DEFAULT_CAPITAL,
        help=(
            "Capital inicial em R$ para NAV em reais "
            f"(default: {DEFAULT_CAPITAL:g}). Use 100 para índice NAV=100."
        ),
    )
    p.add_argument(
        "--output-csv",
        type=Path,
        default=DEFAULT_OUTPUT_CSV,
        help=f"CSV de saída (default: {DEFAULT_OUTPUT_CSV})",
    )
    p.add_argument(
        "--long",
        action="store_true",
        help="Exportar formato longo (ano, n_ativos, nav_medio, ...) em vez de wide.",
    )
    p.add_argument(
        "--list-collections",
        action="store_true",
        help="Só lista collections matching e sai.",
    )
    return p.parse_args(argv)


def _col_pattern(suffix: str) -> re.Pattern[str]:
    return re.compile(rf"^ret_acum_pct_(?P<n>\d+){re.escape(suffix)}$")


def find_ret_acum_collections(
    db: Database,
    suffix: str,
    ativos: Optional[Iterable[int]] = None,
) -> list[tuple[int, str]]:
    pat = _col_pattern(suffix)
    wanted = set(ativos) if ativos is not None else None
    found: list[tuple[int, str]] = []
    for name in db.list_collection_names():
        m = pat.match(name)
        if not m:
            continue
        n = int(m.group("n"))
        if wanted is not None and n not in wanted:
            continue
        found.append((n, name))
    return sorted(found, key=lambda x: x[0])


def year_end_nav_means(
    db: Database,
    collection_name: str,
    n_ativos: int,
    capital: float,
) -> pd.DataFrame:
    """Média cross-section do NAV no último mês de cada ano-calendário."""
    # ret_acum_pct = (NAV/NAV0 - 1) * 100  →  NAV = capital * (1 + value/100)
    pipeline = [
        {
            "$project": {
                "strategy": 1,
                "date": 1,
                "value": 1,
                "ano": {"$toInt": {"$substr": ["$date", 0, 4]}},
            }
        },
        {"$sort": {"strategy": 1, "date": 1}},
        {
            "$group": {
                "_id": {"strategy": "$strategy", "ano": "$ano"},
                "date": {"$last": "$date"},
                "ret_acum_pct": {"$last": "$value"},
            }
        },
        {
            "$project": {
                "_id": 0,
                "ano": "$_id.ano",
                "date": 1,
                "nav": {
                    "$multiply": [
                        float(capital),
                        {"$add": [1.0, {"$divide": ["$ret_acum_pct", 100.0]}]},
                    ]
                },
            }
        },
        {
            "$group": {
                "_id": "$ano",
                "nav_medio": {"$avg": "$nav"},
                "nav_desvio": {"$stdDevSamp": "$nav"},
                "n_carteiras": {"$sum": 1},
                "data_ref": {"$max": "$date"},
            }
        },
        {"$sort": {"_id": 1}},
    ]

    rows = []
    for doc in db[collection_name].aggregate(pipeline, allowDiskUse=True):
        rows.append(
            {
                "ano": int(doc["_id"]),
                "n_ativos": int(n_ativos),
                "nav_medio": float(doc["nav_medio"]),
                "nav_desvio": (
                    float(doc["nav_desvio"])
                    if doc.get("nav_desvio") is not None
                    else float("nan")
                ),
                "n_carteiras": int(doc["n_carteiras"]),
                "data_ref": str(doc.get("data_ref", ""))[:10],
                "collection": collection_name,
            }
        )
    return pd.DataFrame(rows)


def to_wide(df: pd.DataFrame) -> pd.DataFrame:
    """Pivot: linhas=ano, colunas=N, valores=nav_medio (+ data_ref)."""
    if df.empty:
        return df
    wide = (
        df.pivot(index="ano", columns="n_ativos", values="nav_medio")
        .sort_index()
        .sort_index(axis=1)
    )
    wide.columns = [f"N{int(c)}" for c in wide.columns]
    data_ref = (
        df.groupby("ano")["data_ref"]
        .agg(lambda s: s.mode().iloc[0] if not s.mode().empty else s.iloc[0])
        .rename("data_ref")
    )
    n_cart = (
        df.groupby("ano")["n_carteiras"]
        .max()
        .rename("n_carteiras")
    )
    out = wide.join(data_ref).join(n_cart)
    out = out.reset_index()
    return out


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=15000)
    try:
        client.admin.command("ping")
    except Exception as exc:
        print(f"Falha ao conectar no MongoDB: {exc}", file=sys.stderr)
        return 1

    db = client[args.db_name]
    found = find_ret_acum_collections(db, args.suffix, args.ativos)

    if args.list_collections or not found:
        all_match = [
            c
            for c in sorted(db.list_collection_names())
            if args.suffix in c
        ]
        print(f"DB={args.db_name} suffix={args.suffix!r}")
        print(f"collections com suffix ({len(all_match)}):")
        for c in all_match:
            print(f"  {c}  docs={db[c].estimated_document_count()}")
        print(f"ret_acum_pct usadas ({len(found)}): {[n for n, _ in found]}")
        if not found:
            client.close()
            return 1 if not args.list_collections else 0
        if args.list_collections:
            client.close()
            return 0

    frames: list[pd.DataFrame] = []
    for n_ativos, col_name in found:
        print(f"[N={n_ativos}] agregando {col_name} ...", flush=True)
        part = year_end_nav_means(db, col_name, n_ativos, capital=args.capital)
        if part.empty:
            print(f"  [AVISO] sem dados em {col_name}", flush=True)
            continue
        print(
            f"  anos={part['ano'].min()}–{part['ano'].max()} "
            f"carteiras≈{int(part['n_carteiras'].median())} "
            f"NAV_final_medio={part.loc[part['ano'].idxmax(), 'nav_medio']:.2f}",
            flush=True,
        )
        frames.append(part)

    client.close()

    if not frames:
        print("Nenhum dado agregado.", file=sys.stderr)
        return 1

    long_df = pd.concat(frames, ignore_index=True).sort_values(
        ["ano", "n_ativos"]
    )
    out_df = long_df if args.long else to_wide(long_df)

    out_path = Path(args.output_csv)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(out_path, index=False, float_format="%.6f")
    meta_path = out_path.with_name(out_path.stem + ".meta.json")
    meta = {
        "base_capital": float(args.capital),
        "capital": float(args.capital),
        "unit": "BRL",
        "note": (
            "NAV_BRL = capital * (1 + ret_acum_pct/100); "
            "capital inicial do backtest Cap. 7 (pessoa fisica)."
        ),
        "suffix": args.suffix,
        "db_name": args.db_name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "csv": str(out_path),
        "n_ativos": sorted({int(x) for x in long_df["n_ativos"].unique()}),
        "anos": [int(long_df["ano"].min()), int(long_df["ano"].max())],
    }
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nCSV escrito: {out_path}  ({len(out_df)} linhas)")
    print(f"Meta escrito: {meta_path}  (base_capital={args.capital:g})")
    print(out_df.head(3).to_string(index=False))
    print("...")
    print(out_df.tail(3).to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
