"""Filtro reutilizável de DivLiq/EBITDA (Economática)."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd

TICKER_RENAME = {
    "AXIA3": "ELET3",
    "AXIA6": "ELET6",
    "EMBJ3": "EMBR3",
    "GOLL4": "GOLL54",
    "GOLL53": "GOLL54",
    "GOL": "GOLL54",
}

BANK_COMPANY_PREFIXES = {
    "ITUB",
    "BBDC",
    "BBAS",
    "SANB",
    "BPAC",
    "BPAN",
    "BRSR",
    "ABCB",
    "BIDI",
    "BMGB",
    "BNCA",
    "UBBR",
    "BMEF",
    "BEES",
    "PINE",
    "MODL",
    "BRBI",
    "BAZA",
    "BGIP",
    "IDVL",
    "DAYC",
    "BCAP",
}

HOLDING_COMPANY_PREFIXES = {
    "ITSA",
}

INSURANCE_COMPANY_PREFIXES = {
    "BBSE",
    "SULA",
    "PSSA",
    "IRBR",
    "CXSE",
    "WIZC",
}


def company_key(ticker: str) -> str:
    match = re.match(r"^([A-Z]{4})", str(ticker).strip().upper())
    return match.group(1) if match else str(ticker).strip().upper()


def sector_exempt_kind(ticker: str) -> str | None:
    key = company_key(ticker)
    if key in BANK_COMPANY_PREFIXES:
        return "banco"
    if key in HOLDING_COMPANY_PREFIXES:
        return "holding"
    if key in INSURANCE_COMPANY_PREFIXES:
        return "seguradora"
    return None


def excel_candidates(ticker: str) -> list[str]:
    t = ticker.strip().upper()
    cands = [t]
    for old, new in TICKER_RENAME.items():
        if t == old:
            cands.append(new)
        if t == new:
            cands.append(old)
    return list(dict.fromkeys(cands))


def load_divliq_frame(xlsx: Path) -> pd.DataFrame:
    raw = pd.read_excel(xlsx, sheet_name=0)
    if "Data" not in raw.columns:
        raise ValueError("Coluna 'Data' não encontrada no Excel de DivLiq/EBITDA.")
    raw = raw.copy()
    raw["Data"] = pd.to_datetime(raw["Data"], errors="coerce")
    return raw


def cutoff_timestamp(year: int, cutoff_month: int) -> pd.Timestamp:
    if not 1 <= cutoff_month <= 12:
        raise ValueError(f"Mês de corte inválido: {cutoff_month}.")
    return pd.Timestamp(year=year, month=cutoff_month, day=1) + pd.offsets.MonthEnd(0)


def _last_metric_before_cutoff(
    frame: pd.DataFrame,
    ticker: str,
    cutoff: pd.Timestamp,
) -> tuple[str | None, float | None, str | None]:
    col = next((c for c in excel_candidates(ticker) if c in frame.columns), None)
    if col is None:
        return None, None, None

    window = frame.loc[frame["Data"] <= cutoff, ["Data", col]].copy()
    series = pd.to_numeric(window[col].replace("-", np.nan), errors="coerce")
    valid = series.dropna()
    if valid.empty:
        return col, None, None

    idx = valid.index[-1]
    value = float(valid.iloc[-1])
    data_ref = str(window.loc[idx, "Data"].date())
    return col, value, data_ref


def filter_divliq(
    tickers: Sequence[str],
    divliq_frame: pd.DataFrame,
    *,
    year: int,
    cutoff_month: int = 6,
    thr: float = 1.5,
    year_window_only: bool = False,
) -> tuple[list[str], pd.DataFrame]:
    """Filtra tickers por DivLiq/EBITDA <= thr.

    Por padrão usa o último valor não nulo com Data <= fim de cutoff_month/year
    (sem look-ahead). Com year_window_only=True, restringe à janela do ano
    (comportamento legado de filtrar_ativos_divliq_ebitda.py).
    """
    cutoff = cutoff_timestamp(year, cutoff_month)
    frame = divliq_frame.copy()
    if year_window_only:
        frame = frame.loc[
            (frame["Data"] >= pd.Timestamp(f"{year}-01-01"))
            & (frame["Data"] <= pd.Timestamp(f"{year}-12-31"))
        ]
    else:
        frame = frame.loc[frame["Data"] <= cutoff]

    if year_window_only:
        sem_dado_motivo = f"sem_dado_{year}"
    else:
        sem_dado_motivo = f"sem_dado_ate_{year:04d}{cutoff_month:02d}"

    audit_rows: list[dict] = []
    kept: list[str] = []

    for ticker in tickers:
        t = str(ticker).strip().upper()
        kind = sector_exempt_kind(t)
        col, value, data_ref = _last_metric_before_cutoff(frame, t, cutoff)

        if kind is not None:
            kept.append(t)
            audit_rows.append(
                {
                    "ticker": t,
                    "col_excel": col,
                    "divliq_ebitda": value,
                    "divliq_data_ref": data_ref,
                    "setor_isento": kind,
                    "divliq_motivo": f"{kind}_isento",
                    "mantido": True,
                }
            )
            continue

        if col is None:
            audit_rows.append(
                {
                    "ticker": t,
                    "col_excel": None,
                    "divliq_ebitda": np.nan,
                    "divliq_data_ref": None,
                    "setor_isento": None,
                    "divliq_motivo": "sem_coluna_excel",
                    "mantido": False,
                }
            )
            continue

        if value is None:
            audit_rows.append(
                {
                    "ticker": t,
                    "col_excel": col,
                    "divliq_ebitda": np.nan,
                    "divliq_data_ref": None,
                    "setor_isento": None,
                    "divliq_motivo": sem_dado_motivo,
                    "mantido": False,
                }
            )
            continue

        ok = value <= thr
        if ok:
            kept.append(t)
        audit_rows.append(
            {
                "ticker": t,
                "col_excel": col,
                "divliq_ebitda": value,
                "divliq_data_ref": data_ref,
                "setor_isento": None,
                "divliq_motivo": "ok" if ok else f"acima_de_{thr}",
                "mantido": ok,
            }
        )

    audit = pd.DataFrame(audit_rows)
    return kept, audit


def merge_divliq_audit(universo: pd.DataFrame, audit: pd.DataFrame) -> pd.DataFrame:
    kept = audit.loc[audit["mantido"], "ticker"].tolist()
    filtered = universo[universo["ticker"].isin(kept)].copy()
    info = audit.set_index("ticker")[
        ["col_excel", "divliq_ebitda", "divliq_data_ref", "setor_isento", "divliq_motivo"]
    ]
    return filtered.merge(info, left_on="ticker", right_index=True, how="left").reset_index(
        drop=True
    )
