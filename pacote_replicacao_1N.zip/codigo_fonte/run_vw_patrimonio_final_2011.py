#!/usr/bin/env python3
"""Orquestra backtests VW para patrimônio final (coortes 2001 / 2006 / 2011).

Default: motor **v4.1** (deslistagem com top-up VW do produto líquido + IR antes
de reinvestir; collections ``*_v41_vw``). Use ``--engine v4`` para o legado
(reset VW completo na deslistagem; ``*_vw``).

Espelha o loop: coorte × N × {annual, buyhold} × 5 cost modes, com IR e
liquidação terminal. Cada coorte usa o CSV de formação ``YYYY06`` e backtest
a partir de ``YYYY-07`` até ``2025-10``.

Exemplo::

    # só 2011 (default), motor v4.1
    python codigo_fonte/run_vw_patrimonio_final_2011.py

    # as três janelas
    python codigo_fonte/run_vw_patrimonio_final_2011.py --cohorts 2001 2006 2011

    # legado v4
    python codigo_fonte/run_vw_patrimonio_final_2011.py --engine v4 --cohorts 2011

    # smoke
    python codigo_fonte/run_vw_patrimonio_final_2011.py --cohorts 2001 2006 --limit 1 --dry-run
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

REPO_ROOT = Path(__file__).resolve().parent.parent
CODIGO = REPO_ROOT / "codigo_fonte"
VW_SCRIPTS = {
    "v41": CODIGO / "backtest_carteiras_individuais_retornos_vw_v4_1.py",
    "v4": CODIGO / "backtest_carteiras_individuais_retornos_vw_v4.py",
}
DEFAULT_ETA = (
    REPO_ROOT
    / "resultados"
    / "sensibilidade_barra"
    / "reb_annual_2001_500carteiras_liq_n_8_10_12_15_20_25_30_35_40"
    / "calibration_eta.json"
)
DEFAULT_MKTCAP = REPO_ROOT / "ibov" / "economatica_valorMercado.xlsx"
CART_DIR = REPO_ROOT / "resultados" / "carteiras_aleatorias_liquidas"
NS_DEFAULT = [8, 10, 12, 15, 20, 25, 30, 35, 40]
MODES_DEFAULT = ["gross", "flat", "barra", "barra_raw", "flat_barra"]
HS_DEFAULT = ["annual", "buyhold"]
END_Y, END_M = 2025, 10

# coorte → (formação CSV YYYYMM, start_y, start_m)
COHORTS: Dict[int, Tuple[str, int, int]] = {
    2001: ("200106", 2001, 7),
    2006: ("200606", 2006, 7),
    2011: ("201106", 2011, 7),
}


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--cohorts",
        type=int,
        nargs="+",
        default=[2011],
        choices=sorted(COHORTS.keys()),
        help="Anos de início do backtest (default: 2011). Formação = junho do mesmo ano.",
    )
    p.add_argument(
        "--engine",
        choices=sorted(VW_SCRIPTS.keys()),
        default="v41",
        help=(
            "Motor de deslistagem: v41 = top-up VW + IR-antes, collections *_v41_vw "
            "(default); v4 = legado reset VW, *_vw."
        ),
    )
    p.add_argument("--ns", type=int, nargs="+", default=NS_DEFAULT)
    p.add_argument(
        "--hs",
        nargs="+",
        default=HS_DEFAULT,
        choices=["annual", "buyhold", "monthly", "quarterly", "semiannual"],
    )
    p.add_argument("--modes", nargs="+", default=MODES_DEFAULT, choices=MODES_DEFAULT)
    p.add_argument("--eta-from", type=Path, default=DEFAULT_ETA)
    p.add_argument("--mktcap-path", type=Path, default=DEFAULT_MKTCAP)
    p.add_argument("--tcost-bps", type=float, default=12.0)
    p.add_argument("--capital", type=float, default=10_000.0)
    p.add_argument("--limit", type=int, default=0)
    p.add_argument("--python", default=sys.executable)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument(
        "--continue-on-error",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    return p.parse_args(list(argv) if argv is not None else None)


def carteira_path(n: int, formacao: str) -> Path:
    return CART_DIR / f"carteiras_{n}atv_liq_1MM_{formacao}.csv"


def build_cmd(
    args: argparse.Namespace,
    *,
    vw_script: Path,
    n: int,
    h: str,
    mode: str,
    formacao: str,
    start_y: int,
    start_m: int,
) -> List[str]:
    cart = carteira_path(n, formacao)
    cmd = [
        str(args.python),
        str(vw_script),
        "--carteiras",
        str(cart),
        "--start-y",
        str(start_y),
        "--start-m",
        str(start_m),
        "--end-y",
        str(END_Y),
        "--end-m",
        str(END_M),
        "--cost-mode",
        mode,
        "--apply-stock-ir",
        "--liquidate-at-end",
        "--capital",
        str(args.capital),
        "--mktcap-path",
        str(args.mktcap_path),
        "--universo-tag",
        "liq_1MM",
    ]
    if args.limit and args.limit > 0:
        cmd.extend(["--limit", str(args.limit)])
    if h == "buyhold":
        cmd.append("--no-rebalance")
    else:
        cmd.extend(["--rebalance", "--rebalance-freq", h])
    if mode in ("flat", "flat_barra"):
        cmd.extend(["--tcost-bps", str(args.tcost_bps)])
    elif mode == "barra":
        cmd.extend(["--eta-from", str(args.eta_from)])
    return cmd


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    vw_script = VW_SCRIPTS[str(args.engine)]
    if not vw_script.exists():
        raise SystemExit(f"Script VW ausente: {vw_script}")
    if not args.mktcap_path.exists():
        raise SystemExit(f"Market cap ausente: {args.mktcap_path}")

    delist_txt = (
        "top-up VW + IR-antes (*_v41_vw)"
        if args.engine == "v41"
        else "reset VW na deslistagem (*_vw)"
    )
    print(
        f"Motor VW={args.engine} | deslistagem={delist_txt} | script={vw_script.name}",
        flush=True,
    )

    jobs: List[Tuple[str, List[str]]] = []
    for cohort in args.cohorts:
        formacao, start_y, start_m = COHORTS[cohort]
        for n in args.ns:
            cart = carteira_path(n, formacao)
            if not cart.exists():
                print(f"[SKIP] CSV ausente: {cart}", flush=True)
                continue
            for h in args.hs:
                for mode in args.modes:
                    label = f"VW-{args.engine} cohort={cohort} N={n} H={h} mode={mode}"
                    jobs.append(
                        (
                            label,
                            build_cmd(
                                args,
                                vw_script=vw_script,
                                n=n,
                                h=h,
                                mode=mode,
                                formacao=formacao,
                                start_y=start_y,
                                start_m=start_m,
                            ),
                        )
                    )

    print(f"Jobs VW planejados: {len(jobs)} (cohorts={args.cohorts})", flush=True)
    failed = 0
    for i, (label, cmd) in enumerate(jobs, start=1):
        print(f"\n======== [{i}/{len(jobs)}] {label} ========", flush=True)
        print(" ".join(cmd), flush=True)
        if args.dry_run:
            continue
        rc = subprocess.call(cmd)
        if rc != 0:
            failed += 1
            print(f"[ERRO] {label} exit={rc}", flush=True)
            if not args.continue_on_error:
                return rc
    print(f"\nConcluído. jobs={len(jobs)} failed={failed}", flush=True)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
