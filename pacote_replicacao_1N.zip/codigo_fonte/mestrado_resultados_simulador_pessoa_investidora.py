"""Resultados do simulador Pessoa Investidora.

Convertido e refatorado a partir do notebook:
    Mestrado_Resultados_Simulador_PessoaInvestidora.ipynb

Gera tabelas descritivas (9.1), comparação com vs sem rebalanceamento, comparação EW vs BOVA11 (9.2),
teste pareado com robustez temporal HAC + stationary bootstrap (9.3) e texto acadêmico.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple, Literal

import numpy as np
import pandas as pd
from pymongo import MongoClient
from pymongo.database import Database
from scipy import stats

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_OUTPUT_DIR = REPO_ROOT / "resultados"
DEFAULT_MONGO_URI = "mongodb://172.23.224.1:27017/"
DEFAULT_DB_NAME_CARTEIRAS_COM_REBALANCEAMENTO = "Backtest_Mestrado_PF_ExcessAjustado"
DEFAULT_DB_NAME_CARTEIRAS_SEM_REBALANCEAMENTO = "Backtest_Mestrado_PF_ExcessAjustado"
DEFAULT_DB_NAME_BOVA11 = "Backtest_Mestrado_PF_ExcessAjustado"
DEFAULT_REBALANCEAMENTO = "com"
RebalanceamentoModo = Literal["com", "sem", "ambos"]
DEFAULT_ATIVOS_CARTEIRA = "20"
DEFAULT_PERIODO_SUFFIX = "2011_2025"
DEFAULT_SUFFIX_BUYHOLD = "_buyhold"
DEFAULT_HAC_LAGS = (3, 4, 6, 12)
DEFAULT_AVG_BLOCKS = (3, 6, 12)
DEFAULT_BOOT_B = 2000
DEFAULT_BOOT_SEED = 123

STAT_COLUMNS = ["n", "mean", "median", "p10", "p25", "p75", "p90"]
VALUE_COLUMNS = ["mean", "median", "p10", "p25", "p75", "p90"]

AUX_METRICS_FIELDS = [
    "strategy",
    "avg_turnover",
    "avg_turnover_trade_days",
    "cagr",
    "ceq_base",
    "ceq_gamma1_ann",
    "ceq_gamma1_daily",
    "n_trade_days",
    "sharpe_excess",
    "tcost",
    "tickers",
    "total_excess_return",
    "total_return",
    "vol_excess_ann",
]

AUX_METRICS_TABLE = [
    "cagr",
    "total_return",
    "total_excess_return",
    "vol_excess_ann",
    "sharpe_excess",
    "ceq_gamma1_ann",
    "avg_turnover",
    "avg_turnover_trade_days",
    "n_trade_days",
]

RES_METRICS = [
    "cagr",
    "total_return",
    "monthly_mean",
    "monthly_vol",
    "yearly_mean",
    "yearly_vol",
    "monthly_sharpe",
    "monthly_sortino",
    "calmar",
    "max_drawdown",
    "avg_drawdown",
    "avg_drawdown_days",
    "twelve_month_win_perc",
    "win_year_perc",
    "monthly_skew",
    "monthly_kurt",
    "yearly_skew",
    "yearly_kurt",
    "best_month",
    "worst_month",
    "best_year",
    "worst_year",
]

RES_PERCENT_METRICS = {
    "cagr",
    "total_return",
    "monthly_mean",
    "monthly_vol",
    "yearly_mean",
    "yearly_vol",
    "max_drawdown",
    "avg_drawdown",
    "twelve_month_win_perc",
    "win_year_perc",
    "best_month",
    "worst_month",
    "best_year",
    "worst_year",
}

# Rótulos alinhados às definições do ffn/bt (res.stats / res.display):
# - monthly_mean = mean(r_mensal) * 12  (anualizado)
# - monthly_vol  = std(r_mensal) * sqrt(12)  (anualizado)
# - monthly_sharpe/sortino usam retornos mensais com nperiods=12
# - yearly_mean/vol = média/desvio dos retornos anuais (não são a vol mensal anualizada)
RES_PRETTY_NAMES = {
    "cagr": "CAGR (%)",
    "total_return": "Retorno total (%)",
    "monthly_mean": "Retorno médio mensal anualizado (%)",
    "monthly_vol": "Volatilidade mensal anualizada (%)",
    "yearly_mean": "Retorno médio dos anos-calendário (%)",
    "yearly_vol": "Desvio-padrão dos retornos anuais (%)",
    "monthly_sharpe": "Sharpe (retornos mensais, an.)",
    "monthly_sortino": "Sortino (retornos mensais, an.)",
    "calmar": "Calmar (CAGR / |MaxDD|)",
    "max_drawdown": "Max Drawdown - queda máxima (%)",
    "avg_drawdown": "Queda média (%)",
    "avg_drawdown_days": "Duração média das quedas (dias)",
    "twelve_month_win_perc": "% meses positivos (janela 12m)",
    "win_year_perc": "% anos positivos",
    "monthly_skew": "Assimetria (mensal)",
    "monthly_kurt": "Curtose (mensal)",
    "yearly_skew": "Assimetria (anual)",
    "yearly_kurt": "Curtose (anual)",
    "best_month": "Melhor mês (%)",
    "worst_month": "Pior mês (%)",
    "best_year": "Melhor ano (%)",
    "worst_year": "Pior ano (%)",
}

RES_TABLE_METRIC_NOTES = (
    "Notas (definições ffn/bt em res.stats): "
    "CAGR = taxa geométrica anual; "
    "retorno médio mensal anualizado = mean(r_m)*12; "
    "volatilidade mensal anualizada = std(r_m)*sqrt(12); "
    "Sharpe/Sortino mensais usam retornos mensais com nperiods=12; "
    "retorno médio / desvio-padrão anuais referem-se à série de retornos ano-calendário "
    "(não coincidem, por construção, com a volatilidade mensal anualizada)."
)

TABLE_92_METRICS = [
    "cagr",
    "total_return",
    "total_excess_return",
    "vol_excess_ann",
    "sharpe_excess",
    "ceq_gamma1_ann",
    "avg_turnover",
    "avg_turnover_trade_days",
]

TABLE_92_PRETTY = {
    "cagr": "CAGR (anual)",
    "total_return": "Retorno total (acumulado)",
    "total_excess_return": "Retorno total em excesso (acumulado)",
    "vol_excess_ann": "Volatilidade anual (excesso)",
    "sharpe_excess": "Sharpe (excesso)",
    "ceq_gamma1_ann": "CEQ anual (γ=1, excesso)",
    "avg_turnover": "Turnover médio",
    "avg_turnover_trade_days": "Dias com trade (médio)",
}

TABLE_92_PERCENT_METRICS = {
    "cagr",
    "total_return",
    "total_excess_return",
    "vol_excess_ann",
}

TABLE_92_EXPORT_LABELS = [
    "CAGR (anual)",
    "Retorno total (acumulado)",
    "Retorno total em excesso (acumulado)",
    "Volatilidade anual (excesso)",
    "Sharpe (excesso)",
    "CEQ anual (γ=1 excesso)",
    "Turnover médio",
    "Dias com trade (médio)",
]

LOWER_IS_BETTER_METRICS = {"avg_turnover", "avg_turnover_trade_days", "vol_excess_ann"}


@dataclass(frozen=True)
class ComVsSemMetric:
    """Métrica na tabela comparativa com vs sem rebalanceamento."""

    key: str
    label: str
    source: str  # "aux" | "res"
    scale: float = 1.0
    lower_is_better: bool = False
    ndigits: int = 2
    aliases: Tuple[str, ...] = ()

    @property
    def lookup_keys(self) -> Tuple[str, ...]:
        return (self.key,) + self.aliases


COM_VS_SEM_METRICS: Tuple[ComVsSemMetric, ...] = (
    ComVsSemMetric("avg_turnover", "Turnover Médio (%)", "aux", 100.0, True),
    ComVsSemMetric("cagr", "CAGR (%)", "aux", 100.0),
    ComVsSemMetric(
        "calmar",
        "Calmar",
        "res",
        1.0,
        aliases=("calmar_ratio",),
    ),
    ComVsSemMetric("ceq_gamma1_ann", "CEQ (γ = 1) Anual (%)", "aux", 100.0),
    ComVsSemMetric(
        "monthly_sharpe",
        "Sharpe anualizado",
        "res",
        1.0,
        # Preferir monthly_sharpe (ffn: nperiods=12). daily_* só como fallback
        # legado — valores tipicamente ausentes e, se usados, eram rotulados à força.
        aliases=("daily_sharpe",),
    ),
    ComVsSemMetric(
        "monthly_vol",
        "Volatilidade anualizada (%)",
        "res",
        100.0,
        True,
        # monthly_vol do ffn = std(r_mensal)*√12 (anualizado). Não é vol diária.
        aliases=("daily_vol",),
    ),
    ComVsSemMetric(
        "max_drawdown",
        "Queda máxima (%)",
        "res",
        100.0,
        aliases=("avg_drawdown",),
    ),
    ComVsSemMetric("sharpe_excess", "Sharpe em excesso", "aux", 1.0),
    ComVsSemMetric("total_excess_return", "Retorno Total em excesso (%)", "aux", 100.0),
    ComVsSemMetric("vol_excess_ann", "Vol. anual em excesso (%)", "aux", 100.0, True),
)

COM_VS_SEM_COLUMNS = [
    "Média Rebalanc.",
    "Média S/Rebalanc.",
    "Diferença Médias",
    "Mediana Rebalanc.",
    "Mediana S/Rebalanc.",
    "Diferença Medianas",
    "winrate",
]


@dataclass
class RunConfig:
    """Parâmetros de execução do pipeline de resultados."""

    mongo_uri: str = DEFAULT_MONGO_URI
    mongo_uri_bova11: str = DEFAULT_MONGO_URI
    db_name_carteiras_com_rebalanceamento: str = DEFAULT_DB_NAME_CARTEIRAS_COM_REBALANCEAMENTO
    db_name_carteiras_sem_rebalanceamento: str = DEFAULT_DB_NAME_CARTEIRAS_SEM_REBALANCEAMENTO
    db_name_bova11: str = DEFAULT_DB_NAME_BOVA11
    rebalanceamento: RebalanceamentoModo = DEFAULT_REBALANCEAMENTO
    ativos_carteira: str = DEFAULT_ATIVOS_CARTEIRA
    periodo_suffix: str = DEFAULT_PERIODO_SUFFIX
    suffix_buyhold: str = DEFAULT_SUFFIX_BUYHOLD
    output_dir: Path = field(default_factory=lambda: DEFAULT_OUTPUT_DIR)
    hac_lags: Tuple[int, ...] = DEFAULT_HAC_LAGS
    avg_blocks: Tuple[int, ...] = DEFAULT_AVG_BLOCKS
    boot_b: int = DEFAULT_BOOT_B
    boot_seed: int = DEFAULT_BOOT_SEED
    export_csv: bool = True
    export_latex: bool = True
    print_tables: bool = True
    write_dissertation_text: bool = True
    steps: Tuple[str, ...] = ("all",)

    @property
    def sufixo_carteiras_base(self) -> str:
        return f"{self.ativos_carteira}atv_{self.periodo_suffix}"

    @property
    def sufixo_carteiras_com(self) -> str:
        return self.sufixo_carteiras_base

    @property
    def sufixo_carteiras_sem(self) -> str:
        return f"{self.sufixo_carteiras_base}{self.suffix_buyhold}"

    @property
    def sufixo_carteiras(self) -> str:
        if self.rebalanceamento == "sem":
            return self.sufixo_carteiras_sem
        return self.sufixo_carteiras_com

    @property
    def sufixo_bova11(self) -> str:
        return f"BOVA11_{self.periodo_suffix}"

    @property
    def db_name_carteiras(self) -> str:
        """Banco das carteiras EW conforme o modo de rebalanceamento ativo."""
        if self.rebalanceamento == "sem":
            return self.db_name_carteiras_sem_rebalanceamento
        return self.db_name_carteiras_com_rebalanceamento

    @property
    def rebalanceamento_label(self) -> str:
        if self.rebalanceamento == "sem":
            return "sem rebalanceamento (buy-and-hold)"
        return "com rebalanceamento anual (julho)"

    def should_run(self, step: str) -> bool:
        if "all" in self.steps:
            return True
        return step in self.steps


def print_table(df: pd.DataFrame, title: str = "") -> None:
    if title:
        print(title)
    print(df.to_string())


def summary_stats(series: pd.Series) -> pd.Series:
    values = pd.to_numeric(series, errors="coerce").dropna()
    if values.empty:
        return pd.Series(
            {
                "n": 0,
                "mean": np.nan,
                "median": np.nan,
                "p10": np.nan,
                "p25": np.nan,
                "p75": np.nan,
                "p90": np.nan,
            }
        )
    return pd.Series(
        {
            "n": int(values.shape[0]),
            "mean": float(values.mean()),
            "median": float(values.median()),
            "p10": float(values.quantile(0.10)),
            "p25": float(values.quantile(0.25)),
            "p75": float(values.quantile(0.75)),
            "p90": float(values.quantile(0.90)),
        }
    )


def build_descriptive_table(df: pd.DataFrame, metrics: Sequence[str]) -> pd.DataFrame:
    available = [metric for metric in metrics if metric in df.columns]
    missing = [metric for metric in metrics if metric not in df.columns]
    if missing:
        raise RuntimeError(f"Métricas ausentes no DataFrame: {missing}")
    table = pd.DataFrame({metric: summary_stats(df[metric]) for metric in available}).T
    return table[STAT_COLUMNS]


def round_value_columns(table: pd.DataFrame, ndigits: int = 2) -> pd.DataFrame:
    formatted = table.copy()
    for column in VALUE_COLUMNS:
        if column in formatted.columns:
            formatted[column] = pd.to_numeric(formatted[column], errors="coerce").round(ndigits)
    if "n" in formatted.columns:
        formatted["n"] = formatted["n"].astype("Int64")
    return formatted


def _format_latex_cell(value: Any, float_format: str) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    if isinstance(value, (float, np.floating)):
        return float_format % float(value)
    text = str(value)
    for char, escaped in (("\\", r"\\"), ("_", r"\_"), ("%", r"\%"), ("&", r"\&"), ("#", r"\#")):
        text = text.replace(char, escaped)
    return text


def dataframe_to_latex(
    table: pd.DataFrame,
    *,
    float_format: str = "%.2f",
    index: bool = True,
) -> str:
    """Exporta DataFrame para LaTeX; fallback simples se jinja2 não estiver instalado."""
    try:
        return table.to_latex(float_format=float_format, index=index)
    except ImportError:
        ncol = len(table.columns) + (1 if index else 0)
        col_spec = "l" * ncol
        lines = [
            f"\\begin{{tabular}}{{{col_spec}}}",
            "\\toprule",
        ]
        header = [""] + [str(col) for col in table.columns] if index else [str(col) for col in table.columns]
        lines.append(" & ".join(header) + r" \\")
        lines.append("\\midrule")
        for idx, row in table.iterrows():
            cells = [_format_latex_cell(idx, float_format)] if index else []
            cells.extend(_format_latex_cell(value, float_format) for value in row)
            lines.append(" & ".join(cells) + r" \\")
        lines.extend(["\\bottomrule", "\\end{tabular}"])
        return "\n".join(lines)


def export_table(
    table: pd.DataFrame,
    stem: str,
    output_dir: Path,
    *,
    export_csv: bool,
    export_latex: bool,
    latex_float_format: str = "%.2f",
    csv_index: bool = True,
    csv_encoding: str = "utf-8-sig",
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    if export_csv:
        table.to_csv(output_dir / f"{stem}.csv", index=csv_index, encoding=csv_encoding)
    if export_latex:
        latex = dataframe_to_latex(table, float_format=latex_float_format, index=csv_index)
        (output_dir / f"{stem}.tex").write_text(latex, encoding="utf-8")


def load_collection_documents(
    db: Database,
    collection_name: str,
    fields: Sequence[str],
    query: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    projection = {field: 1 for field in fields}
    projection["_id"] = 0
    docs = list(db[collection_name].find(query or {}, projection))
    if not docs:
        raise RuntimeError(f"Nenhum documento encontrado em {db.name}.{collection_name}")
    return docs


def connect_databases(config: RunConfig) -> Tuple[Database, Database]:
    client = MongoClient(config.mongo_uri)
    client_bova11 = MongoClient(config.mongo_uri_bova11)
    return client[config.db_name_carteiras], client_bova11[config.db_name_bova11]


def iter_run_configs(config: RunConfig) -> Iterator[RunConfig]:
    """Expande config e direciona saída para subpasta por regime de rebalanceamento."""
    if config.rebalanceamento == "ambos":
        modos: Tuple[RebalanceamentoModo, ...] = ("com", "sem")
    else:
        modos = (config.rebalanceamento,)

    for modo in modos:
        yield replace(
            config,
            rebalanceamento=modo,
            output_dir=config.output_dir / f"{modo}_rebalanceamento",
        )


def connect_com_sem_databases(config: RunConfig) -> Tuple[Database, Database]:
    client = MongoClient(config.mongo_uri)
    return (
        client[config.db_name_carteiras_com_rebalanceamento],
        client[config.db_name_carteiras_sem_rebalanceamento],
    )


def _normalize_metric_columns(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    renamed = {
        column: str(column).strip().lower().replace(" ", "_")
        for column in df.columns
        if column != "strategy"
    }
    return df.rename(columns=renamed)


def _load_aux_metrics_by_strategy(db: Database, sufixo: str, fields: Sequence[str]) -> pd.DataFrame:
    projection_fields = list(dict.fromkeys(["strategy", *fields]))
    docs = load_collection_documents(db, f"aux_metrics_{sufixo}", projection_fields)
    df = pd.DataFrame(docs)
    if "strategy" not in df.columns:
        raise RuntimeError(f"Campo strategy ausente em aux_metrics_{sufixo} ({db.name}).")
    df = df.set_index("strategy")
    for field in fields:
        if field in df.columns:
            df[field] = pd.to_numeric(df[field], errors="coerce")
    return df


def _load_res_metrics_by_strategy(db: Database, sufixo: str) -> pd.DataFrame:
    collection = db[f"res_{sufixo}"]
    docs = list(collection.find({"type": "res_display"}, {"_id": 0}))
    if not docs:
        docs = list(collection.find({}, {"_id": 0}))
    if not docs:
        raise RuntimeError(f"Nenhum documento encontrado em {db.name}.res_{sufixo}")

    df = pd.DataFrame(docs)
    if "strategy" not in df.columns:
        raise RuntimeError(f"Campo strategy ausente em res_{sufixo} ({db.name}).")

    meta_cols = {
        "base_name",
        "type",
        "generated_at_utc",
        "strategy",
    }
    value_cols = [column for column in df.columns if column not in meta_cols and not str(column).endswith("__text")]
    df = df[["strategy", *value_cols]].copy()
    df = _normalize_metric_columns(df)
    df = df.set_index("strategy")
    for column in df.columns:
        df[column] = pd.to_numeric(df[column], errors="coerce")
    return df


def _pick_metric_column(df: pd.DataFrame, metric: ComVsSemMetric) -> Optional[str]:
    for key in metric.lookup_keys:
        normalized = key.lower().replace(" ", "_")
        if normalized in df.columns:
            return normalized
    return None


def _paired_com_vs_sem_row(
    com_values: pd.Series,
    sem_values: pd.Series,
    metric: ComVsSemMetric,
) -> Dict[str, Any]:
    aligned = pd.concat(
        [com_values.rename("com"), sem_values.rename("sem")],
        axis=1,
        join="inner",
    ).dropna()

    if aligned.empty:
        return {
            "Média Rebalanc.": np.nan,
            "Média S/Rebalanc.": np.nan,
            "Diferença Médias": np.nan,
            "Mediana Rebalanc.": np.nan,
            "Mediana S/Rebalanc.": np.nan,
            "Diferença Medianas": np.nan,
            "winrate": np.nan,
            "n": 0,
        }

    com_scaled = aligned["com"] * metric.scale
    sem_scaled = aligned["sem"] * metric.scale
    diff = com_scaled - sem_scaled

    if metric.lower_is_better:
        winrate = float((diff < 0).mean() * 100.0)
    else:
        winrate = float((diff > 0).mean() * 100.0)

    ndigits = metric.ndigits
    return {
        "Média Rebalanc.": round(float(com_scaled.mean()), ndigits),
        "Média S/Rebalanc.": round(float(sem_scaled.mean()), ndigits),
        "Diferença Médias": round(float(diff.mean()), ndigits),
        "Mediana Rebalanc.": round(float(com_scaled.median()), ndigits),
        "Mediana S/Rebalanc.": round(float(sem_scaled.median()), ndigits),
        "Diferença Medianas": round(float(diff.median()), ndigits),
        "winrate": round(winrate, 2),
        "n": int(len(aligned)),
    }


def run_table_com_vs_sem_rebalanceamento(config: RunConfig) -> pd.DataFrame:
    """Tabela comparativa: cenários com vs sem rebalanceamento anual (pareado por strategy)."""
    db_com, db_sem = connect_com_sem_databases(config)
    try:
        aux_fields = sorted(
            {
                metric.key
                for metric in COM_VS_SEM_METRICS
                if metric.source == "aux"
            }
        )

        df_com_aux = _load_aux_metrics_by_strategy(db_com, config.sufixo_carteiras_com, aux_fields)
        df_sem_aux = _load_aux_metrics_by_strategy(db_sem, config.sufixo_carteiras_sem, aux_fields)
        df_com_res = _load_res_metrics_by_strategy(db_com, config.sufixo_carteiras_com)
        df_sem_res = _load_res_metrics_by_strategy(db_sem, config.sufixo_carteiras_sem)

        rows: List[Dict[str, Any]] = []
        paired_n: Optional[int] = None
        skipped: List[str] = []

        for metric in COM_VS_SEM_METRICS:
            if metric.source == "aux":
                df_com = df_com_aux
                df_sem = df_sem_aux
            else:
                df_com = df_com_res
                df_sem = df_sem_res

            column = _pick_metric_column(df_com, metric)
            if column is None or column not in df_sem.columns:
                skipped.append(metric.label)
                continue

            summary = _paired_com_vs_sem_row(df_com[column], df_sem[column], metric)
            if paired_n is None and summary["n"] > 0:
                paired_n = summary["n"]
            row = {"Métrica": metric.label}
            row.update({key: summary[key] for key in COM_VS_SEM_COLUMNS})
            rows.append(row)

        if not rows:
            raise RuntimeError(
                "Nenhuma métrica pôde ser calculada na comparação com vs sem rebalanceamento."
            )

        if skipped and config.print_tables:
            print(
                "Métricas ignoradas (ausentes em com e/ou sem rebalanceamento): "
                + ", ".join(skipped),
                flush=True,
            )

        table = pd.DataFrame(rows).set_index("Métrica")
        periodo_label = config.periodo_suffix.replace("_", " a ")
        n_carteiras = paired_n or 0
        title = (
            f"Tabela — Comparativo entre cenários com e sem rebalanceamento anual — "
            f"Carteiras aleatórias com {config.ativos_carteira} ativos — {periodo_label}\n"
            f"Fonte: Elaboração própria. Total de {n_carteiras} carteiras analisadas individualmente."
        )

        if config.print_tables:
            print_table(table, title)

        export_table(
            table,
            f"tabela_com_vs_sem_rebalanceamento_{config.sufixo_carteiras_base}",
            config.output_dir,
            export_csv=config.export_csv,
            export_latex=config.export_latex,
        )
        return table
    finally:
        db_com.client.close()
        db_sem.client.close()


def run_aux_metrics_table_91(config: RunConfig, db: Database) -> pd.DataFrame:
    docs = load_collection_documents(
        db,
        f"aux_metrics_{config.sufixo_carteiras}",
        AUX_METRICS_FIELDS,
    )
    df = pd.DataFrame(docs)

    if "tickers" in df.columns:
        df["N"] = df["tickers"].apply(
            lambda tickers: len(tickers) if isinstance(tickers, (list, tuple)) else np.nan
        )
        print("Resumo de N (len(tickers)):")
        print(df["N"].describe())
    else:
        df["N"] = np.nan

    table = build_descriptive_table(df, AUX_METRICS_TABLE)
    formatted = round_value_columns(table)

    title = (
        f"\nTabela 9.1 — Estatísticas descritivas "
        f"(collection aux_metrics_{config.sufixo_carteiras})"
    )
    if config.print_tables:
        print_table(formatted, title)

    export_table(
        formatted,
        f"tabela_9_1_aux_metrics_{config.sufixo_carteiras}",
        config.output_dir,
        export_csv=config.export_csv,
        export_latex=config.export_latex,
        latex_float_format="%.6f",
    )
    return formatted


def run_res_table_91(config: RunConfig, db: Database) -> pd.DataFrame:
    collection = db[f"res_{config.sufixo_carteiras}"]
    projection = {metric: 1 for metric in RES_METRICS}
    projection["_id"] = 0

    docs = list(collection.find({"type": "res_display"}, projection))
    if not docs:
        docs = list(collection.find({}, projection))
    if not docs:
        raise RuntimeError(
            f"Nenhum documento encontrado em {db.name}.res_{config.sufixo_carteiras}"
        )

    df_res = pd.DataFrame(docs)
    table = build_descriptive_table(df_res, RES_METRICS)

    for metric in RES_PERCENT_METRICS:
        if metric in table.index:
            table.loc[metric, VALUE_COLUMNS] = table.loc[metric, VALUE_COLUMNS] * 100.0

    table.index = [RES_PRETTY_NAMES.get(index, index) for index in table.index]
    formatted = round_value_columns(table)

    title = (
        f"Tabela 9.1 — res_{config.sufixo_carteiras} "
        f"(n={int(formatted['n'].max())} backtests)"
    )
    if config.print_tables:
        print_table(formatted, title)
        print(RES_TABLE_METRIC_NOTES)

    stem = f"tabela_9_1_res_{config.sufixo_carteiras}"
    export_table(
        formatted,
        stem,
        config.output_dir,
        export_csv=config.export_csv,
        export_latex=config.export_latex,
    )
    config.output_dir.mkdir(parents=True, exist_ok=True)
    (config.output_dir / f"{stem}_notas.txt").write_text(
        RES_TABLE_METRIC_NOTES + "\n",
        encoding="utf-8",
    )
    return formatted


def diff_summary(
    series: pd.Series,
    benchmark_value: float,
    *,
    higher_is_better: bool = True,
) -> Dict[str, float]:
    values = pd.to_numeric(series, errors="coerce")
    diff = (values - benchmark_value).dropna()
    if diff.empty:
        return {
            "n": 0,
            "win_rate": np.nan,
            "mean": np.nan,
            "median": np.nan,
            "p10": np.nan,
            "p25": np.nan,
            "p75": np.nan,
            "p90": np.nan,
            "t_pvalue": np.nan,
            "wilcoxon_pvalue": np.nan,
        }

    win_rate = float((diff > 0).mean()) if higher_is_better else float((diff < 0).mean())
    t_pvalue = float(stats.ttest_1samp(diff.values, 0.0, nan_policy="omit").pvalue)

    diff_nonzero = diff[diff != 0]
    if diff_nonzero.shape[0] >= 10:
        try:
            wilcoxon_pvalue = float(stats.wilcoxon(diff_nonzero.values, zero_method="wilcox").pvalue)
        except Exception:
            wilcoxon_pvalue = np.nan
    else:
        wilcoxon_pvalue = np.nan

    return {
        "n": int(diff.shape[0]),
        "win_rate": win_rate,
        "mean": float(diff.mean()),
        "median": float(diff.median()),
        "p10": float(diff.quantile(0.10)),
        "p25": float(diff.quantile(0.25)),
        "p75": float(diff.quantile(0.75)),
        "p90": float(diff.quantile(0.90)),
        "t_pvalue": t_pvalue,
        "wilcoxon_pvalue": wilcoxon_pvalue,
    }


def run_table_92(config: RunConfig, db: Database, db_bova11: Database) -> pd.DataFrame:
    col_ew = db[f"aux_metrics_{config.sufixo_carteiras}"]
    col_bm = db_bova11[f"aux_metrics_{config.sufixo_bova11}"]

    projection = {metric: 1 for metric in TABLE_92_METRICS}
    projection["_id"] = 0

    bm_doc = col_bm.find_one({}, projection)
    if not bm_doc:
        raise RuntimeError(
            f"Não encontrei o documento do benchmark em aux_metrics_{config.sufixo_bova11}."
        )

    ew_docs = list(col_ew.find({}, projection))
    if not ew_docs:
        raise RuntimeError(f"Não encontrei documentos em aux_metrics_{config.sufixo_carteiras}.")

    benchmark = pd.Series(bm_doc, dtype="float64")
    ew_df = pd.DataFrame(ew_docs)

    rows: List[Dict[str, Any]] = []
    for metric in TABLE_92_METRICS:
        if metric not in benchmark.index or pd.isna(benchmark[metric]):
            continue
        benchmark_value = float(benchmark[metric])
        higher_is_better = metric not in LOWER_IS_BETTER_METRICS
        row = diff_summary(ew_df[metric], benchmark_value, higher_is_better=higher_is_better)
        row["metric_key"] = metric
        row["metric"] = TABLE_92_PRETTY.get(metric, metric)
        row["benchmark"] = "BOVA11"
        rows.append(row)

    table = pd.DataFrame(rows).set_index("metric")
    mask_pct = table["metric_key"].isin(TABLE_92_PERCENT_METRICS)
    table.loc[mask_pct, VALUE_COLUMNS] = table.loc[mask_pct, VALUE_COLUMNS] * 100.0

    table["win_rate_%"] = (table["win_rate"] * 100.0).round(1)
    table = table.drop(columns=["win_rate"])

    for column in VALUE_COLUMNS:
        table[column] = pd.to_numeric(table[column], errors="coerce").round(2)
    for column in ["t_pvalue", "wilcoxon_pvalue"]:
        table[column] = table[column].apply(
            lambda value: np.nan if pd.isna(value) else float(value)
        ).round(6)

    display_cols = [
        "n",
        "win_rate_%",
        "mean",
        "median",
        "p10",
        "p25",
        "p75",
        "p90",
        "t_pvalue",
        "wilcoxon_pvalue",
    ]
    table = table[["metric_key"] + display_cols]

    title = (
        "Tabela 9.2 — Diferenças (EW aleatória) − BOVA11 | "
        f"Período {config.periodo_suffix.replace('_', '–')}"
    )
    if config.print_tables:
        print_table(table.drop(columns=["metric_key"]), title)

    export_df = table.drop(columns=["metric_key"]).copy()
    export_df.insert(0, "Métrica", TABLE_92_EXPORT_LABELS[: len(export_df)])

    stem = f"tabela_9_2_aux_metrics_{config.sufixo_carteiras}_vs_{config.sufixo_bova11}"
    config.output_dir.mkdir(parents=True, exist_ok=True)
    if config.export_csv:
        export_df.to_csv(
            config.output_dir / f"{stem}.csv",
            index=False,
            encoding="utf-8-sig",
        )
    if config.export_latex:
        latex = dataframe_to_latex(export_df, float_format="%.6f", index=False)
        (config.output_dir / f"tabela_9_2_aux_metrics__{config.sufixo_carteiras}_vs_{config.sufixo_bova11}.tex").write_text(
            latex,
            encoding="utf-8",
        )

    return table


def _nw_lag(sample_size: int) -> int:
    return int(np.floor(4 * (sample_size / 100) ** (2 / 9))) if sample_size > 0 else 0


def _hac_se_mean(x: np.ndarray | pd.Series, lag: int | None = None) -> Dict[str, float]:
    values = pd.to_numeric(pd.Series(x), errors="coerce").dropna().astype(float).values
    sample_size = int(len(values))

    if sample_size < 10:
        return {
            "T": sample_size,
            "L": np.nan,
            "mean": np.nan,
            "se": np.nan,
            "tstat": np.nan,
            "pvalue": np.nan,
        }

    mean_value = float(values.mean())
    residuals = values - mean_value
    if lag is None:
        lag = _nw_lag(sample_size)
    lag = int(min(max(lag, 0), sample_size - 1))

    gamma0 = float(np.dot(residuals, residuals) / sample_size)
    long_run_var = gamma0
    for lag_index in range(1, lag + 1):
        weight = 1.0 - lag_index / (lag + 1.0)
        gamma = float(np.dot(residuals[lag_index:], residuals[:-lag_index]) / sample_size)
        long_run_var += 2.0 * weight * gamma

    long_run_var = max(long_run_var, 0.0)
    standard_error = np.sqrt(long_run_var / sample_size) if long_run_var >= 0 else np.nan
    tstat = mean_value / standard_error if (np.isfinite(standard_error) and standard_error > 0) else np.nan
    pvalue = 2 * (1 - stats.norm.cdf(abs(tstat))) if np.isfinite(tstat) else np.nan

    return {
        "T": sample_size,
        "L": lag,
        "mean": mean_value,
        "se": float(standard_error) if np.isfinite(standard_error) else np.nan,
        "tstat": float(tstat) if np.isfinite(tstat) else np.nan,
        "pvalue": float(pvalue) if np.isfinite(pvalue) else np.nan,
    }


def stationary_bootstrap_indices(
    sample_size: int,
    avg_block: float,
    rng: np.random.Generator,
) -> np.ndarray:
    if sample_size <= 0:
        raise ValueError("sample_size deve ser positivo.")
    if avg_block <= 0:
        raise ValueError("avg_block deve ser positivo.")

    restart_probability = 1.0 / float(avg_block)
    indices = np.empty(sample_size, dtype=int)
    indices[0] = rng.integers(0, sample_size)
    for index in range(1, sample_size):
        if rng.random() < restart_probability:
            indices[index] = rng.integers(0, sample_size)
        else:
            indices[index] = (indices[index - 1] + 1) % sample_size
    return indices


def stationary_bootstrap_pvalue_mean(
    series: pd.Series,
    *,
    bootstrap_samples: int = DEFAULT_BOOT_B,
    avg_block: int = 6,
    seed: int = DEFAULT_BOOT_SEED,
    hac_lag: int = 6,
) -> float:
    values = pd.to_numeric(series, errors="coerce").dropna().astype(float).values
    sample_size = len(values)
    if sample_size < 10:
        return np.nan

    rng = np.random.default_rng(seed)
    observed = _hac_se_mean(values, lag=hac_lag)
    observed_t = observed["tstat"]
    if not np.isfinite(observed_t):
        return np.nan

    null_series = values - observed["mean"]
    boot_t = np.empty(bootstrap_samples, dtype=float)
    for index in range(bootstrap_samples):
        indices = stationary_bootstrap_indices(sample_size, avg_block=avg_block, rng=rng)
        boot_t[index] = _hac_se_mean(null_series[indices], lag=hac_lag)["tstat"]

    boot_t = boot_t[np.isfinite(boot_t)]
    if len(boot_t) == 0:
        return np.nan
    return float(np.mean(np.abs(boot_t) >= abs(observed_t)))


def acum_pct_to_periodic_ret(df: pd.DataFrame, group_col: str = "strategy") -> pd.DataFrame:
    data = df.copy().sort_values([group_col, "date"])
    cumulative = pd.to_numeric(data["value"], errors="coerce") / 100.0
    data["ret"] = (1.0 + cumulative) / (1.0 + cumulative.groupby(data[group_col]).shift(1)) - 1.0
    return data.dropna(subset=["ret"])[[group_col, "date", "ret"]]


def run_paired_hac_test(
    config: RunConfig,
    db: Database,
    db_bova11: Database,
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    projection = {"_id": 0, "strategy": 1, "date": 1, "value": 1}

    ew_docs = list(db[f"ret_excess_acum_pct_{config.sufixo_carteiras}"].find({}, projection))
    bm_docs = list(db_bova11[f"ret_excess_acum_pct_{config.sufixo_bova11}"].find({}, projection))

    if not ew_docs:
        raise RuntimeError(f"Collection ret_excess_acum_pct_{config.sufixo_carteiras} está vazia.")
    if not bm_docs:
        raise RuntimeError(f"Collection ret_excess_acum_pct_{config.sufixo_bova11} está vazia.")

    ew_df = pd.DataFrame(ew_docs)
    bm_df = pd.DataFrame(bm_docs)
    ew_df["date"] = pd.to_datetime(ew_df["date"])
    bm_df["date"] = pd.to_datetime(bm_df["date"])

    ew_ret = acum_pct_to_periodic_ret(ew_df, "strategy")
    bm_ret = acum_pct_to_periodic_ret(bm_df, "strategy")

    benchmark_names = bm_ret["strategy"].unique()
    if len(benchmark_names) > 1:
        print("Benchmark tem mais de uma strategy. Usando a primeira:", benchmark_names[0])
        bm_ret = bm_ret[bm_ret["strategy"] == benchmark_names[0]].copy()

    bm_ret = (
        bm_ret.rename(columns={"ret": "ret_bm"})[["date", "ret_bm"]]
        .drop_duplicates(subset=["date"])
    )

    merged = ew_ret.merge(bm_ret, on="date", how="inner")
    merged["diff"] = merged["ret"] - merged["ret_bm"]
    dbar = merged.groupby("date")["diff"].mean().sort_index()
    n_strat_by_month = merged.groupby("date")["strategy"].nunique().reindex(dbar.index)

    diff_by_strategy = merged.groupby("strategy")["diff"].mean().dropna()
    cs_summary = {
        "N_strategies": int(diff_by_strategy.shape[0]),
        "win_rate_% (mean diff > 0)": float((diff_by_strategy > 0).mean() * 100.0),
        "median_mean_diff_m": float(diff_by_strategy.median()),
        "p10_mean_diff_m": float(diff_by_strategy.quantile(0.10)),
        "p90_mean_diff_m": float(diff_by_strategy.quantile(0.90)),
    }

    rows: List[Dict[str, Any]] = []
    for avg_block in config.avg_blocks:
        for lag in config.hac_lags:
            hac = _hac_se_mean(dbar, lag=lag)
            p_boot = stationary_bootstrap_pvalue_mean(
                dbar,
                bootstrap_samples=config.boot_b,
                avg_block=avg_block,
                seed=config.boot_seed,
                hac_lag=lag,
            )
            mu_m = hac["mean"]
            rows.append(
                {
                    "Ativos por Carteira": config.ativos_carteira,
                    "T (meses)": hac["T"],
                    "HAC *": hac["L"],
                    "E[d̄_t] (mês)": hac["mean"],
                    "E[d̄_t] **": mu_m * 12.0 if pd.notna(mu_m) else np.nan,
                    "E[d̄_t] ***": (1.0 + mu_m) ** 12 - 1.0 if pd.notna(mu_m) else np.nan,
                    "SE_HAC": hac["se"],
                    "t_HAC": hac["tstat"],
                    "p_HAC": hac["pvalue"],
                    "Block (meses)": avg_block,
                    "p_boot ****": p_boot,
                    "N_strat_mes": float(n_strat_by_month.mean()),
                }
            )

    result = pd.DataFrame(rows).sort_values(["Block (meses)", "HAC *"]).reset_index(drop=True)
    formatted = result.copy()
    float_cols = formatted.select_dtypes(include=[np.number]).columns
    formatted[float_cols] = formatted[float_cols].round(6)
    formatted["N_strat_mes"] = result["N_strat_mes"].round(1)

    stem = f"tabela_9_3_HAC_bootstrap_metrics_{config.sufixo_carteiras}_vs_{config.sufixo_bova11}"
    config.output_dir.mkdir(parents=True, exist_ok=True)
    if config.export_csv:
        formatted.to_csv(config.output_dir / f"{stem}.csv", index=False, encoding="utf-8-sig")
    if config.export_latex:
        latex = dataframe_to_latex(formatted, float_format="%.6f", index=False)
        (config.output_dir / f"{stem}.tex").write_text(latex, encoding="utf-8")

    if config.print_tables:
        print("Teste pareado com robustez temporal (HAC + stationary bootstrap)")
        print_table(formatted)
        print("\nResumo cross-sectional (média do diferencial por carteira):")
        print_table(pd.DataFrame([cs_summary]).round(6))

    return formatted, cs_summary


def _fmt_pct(value: Any, ndigits: int = 2) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "NA"
    return f"{100 * value:.{ndigits}f}%"


def _fmt_num(value: Any, ndigits: int = 4) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "NA"
    return f"{value:.{ndigits}f}"


def generate_dissertation_text(
    out_fmt: pd.DataFrame,
    cs_summary: Dict[str, Any],
    config: RunConfig,
) -> str:
    row = out_fmt.iloc[0].to_dict()

    mu_m = row.get("E[d̄_t] (mês)", np.nan)
    mu_a12 = row.get("E[d̄_t] **", np.nan)
    mu_ac = row.get("E[d̄_t] ***", np.nan)
    se_hac = row.get("SE_HAC", np.nan)
    t_hac = row.get("t_HAC", np.nan)
    p_hac = row.get("p_HAC", np.nan)
    p_boot = row.get("p_boot ****", np.nan)
    n_avg = row.get("N_strat_mes", np.nan)

    n_strat = cs_summary.get("N_strategies")
    win_cs = cs_summary.get("win_rate_% (mean diff > 0)", np.nan)
    med_cs = cs_summary.get("median_mean_diff_m", np.nan)
    p10_cs = cs_summary.get("p10_mean_diff_m", np.nan)
    p90_cs = cs_summary.get("p90_mean_diff_m", np.nan)

    periodo = config.periodo_suffix.replace("_", "–")
    regime = config.rebalanceamento_label

    return f"""
Os resultados do teste pareado de diferenças entre a estratégia EW (carteiras aleatórias com {n_strat} composições)
e o benchmark BOVA11 foram obtidos a partir da série mensal do diferencial médio cross-sectional,
\\(\\bar{{d}}_t = \\mathbb{{E}}_j[r^{{EW}}_{{j,t}} - r^{{BM}}_t]\\), construída para o período de {periodo}.
A estratégia EW foi avaliada no regime de {regime}.
O teste de hipótese considera \\(H_0: \\mathbb{{E}}[\\bar{{d}}_t]=0\\) e utiliza erro-padrão robusto a autocorrelação
(Newey–West/HAC), de forma a acomodar dependências temporais típicas em séries de retornos.

Em média, o diferencial mensal estimado foi de {_fmt_num(mu_m, ndigits=6)}, o que corresponde aproximadamente a
{_fmt_pct(mu_a12, ndigits=2)} ao ano (aproximação linear, \\(12\\times\\mu\\)) e {_fmt_pct(mu_ac, ndigits=2)} ao ano
(aproximação composta). O erro-padrão HAC estimado foi {_fmt_num(se_hac, ndigits=6)}, resultando em um estatístico t de
{_fmt_num(t_hac, ndigits=3)} e p-valor de {_fmt_num(p_hac, ndigits=4)}. Como verificação adicional de robustez temporal,
o p-valor via stationary bootstrap (blocos com comprimento médio definido na rotina) foi {_fmt_num(p_boot, ndigits=4)}.

Do ponto de vista de cobertura amostral, cada observação mensal de \\(\\bar{{d}}_t\\) agregou em média
{_fmt_num(n_avg, ndigits=1)} carteiras.
Complementarmente, ao se olhar a distribuição cross-sectional das diferenças médias por carteira,
observa-se que a estratégia EW supera o benchmark (diferença média mensal positiva) em {win_cs:.1f}% das carteiras.
A mediana da diferença média mensal por carteira foi {_fmt_num(med_cs, ndigits=6)}, com intervalo interpercentil
(p10–p90) entre {_fmt_num(p10_cs, ndigits=6)} e {_fmt_num(p90_cs, ndigits=6)}.

Em conjunto, esses resultados sugerem que, no regime de {regime}
e no horizonte {periodo}, a estratégia EW apresenta desempenho competitivo frente ao BOVA11 quando avaliada
pela diferença de retornos em excesso, mesmo sob inferência robusta à dependência temporal (HAC e bootstrap).
""".strip()


def run_pipeline_once(config: RunConfig) -> None:
    db, db_bova11 = connect_databases(config)
    paired_result: Optional[pd.DataFrame] = None
    cs_summary: Optional[Dict[str, Any]] = None

    print(
        f"\n=== Modo: {config.rebalanceamento_label} ===\n"
        f"MongoDB carteiras: {config.mongo_uri} / {config.db_name_carteiras}\n"
        f"Collections:       aux_metrics_{config.sufixo_carteiras}, res_{config.sufixo_carteiras}, "
        f"ret_excess_acum_pct_{config.sufixo_carteiras}\n"
        f"MongoDB BOVA11:    {config.mongo_uri_bova11} / {config.db_name_bova11}\n"
        f"Saída:             {config.output_dir}",
        flush=True,
    )

    try:
        if config.should_run("aux-metrics"):
            run_aux_metrics_table_91(config, db)

        if config.should_run("res"):
            run_res_table_91(config, db)

        if config.should_run("vs-benchmark"):
            run_table_92(config, db, db_bova11)

        if config.should_run("paired-test"):
            paired_result, cs_summary = run_paired_hac_test(config, db, db_bova11)

        if config.should_run("text"):
            if paired_result is None or cs_summary is None:
                paired_result, cs_summary = run_paired_hac_test(config, db, db_bova11)
            text = generate_dissertation_text(paired_result, cs_summary, config)
            print(text)
            if config.write_dissertation_text:
                config.output_dir.mkdir(parents=True, exist_ok=True)
                reb_tag = "_sem_rebalanceamento" if config.rebalanceamento == "sem" else ""
                output_path = (
                    config.output_dir
                    / f"texto_teste_pareado_EW_vs_BOVA11_{config.sufixo_carteiras}{reb_tag}.txt"
                )
                output_path.write_text(text, encoding="utf-8")
                print(f"\nTexto salvo em: {output_path}")
    finally:
        db.client.close()
        db_bova11.client.close()


def run_pipeline(config: RunConfig) -> None:
    if config.should_run("com-vs-sem"):
        print(
            f"\n=== Comparativo com vs sem rebalanceamento ===\n"
            f"MongoDB com reb.:  {config.mongo_uri} / {config.db_name_carteiras_com_rebalanceamento}\n"
            f"  collections:     aux_metrics_{config.sufixo_carteiras_com}, res_{config.sufixo_carteiras_com}\n"
            f"MongoDB sem reb.:  {config.mongo_uri} / {config.db_name_carteiras_sem_rebalanceamento}\n"
            f"  collections:     aux_metrics_{config.sufixo_carteiras_sem}, res_{config.sufixo_carteiras_sem}\n"
            f"Saída:             {config.output_dir}",
            flush=True,
        )
        run_table_com_vs_sem_rebalanceamento(config)

    for run_config in iter_run_configs(config):
        run_pipeline_once(run_config)


def parse_args(argv: Optional[Sequence[str]] = None) -> RunConfig:
    parser = argparse.ArgumentParser(
        description="Gera tabelas e texto dos resultados do simulador Pessoa Investidora."
    )
    parser.add_argument(
        "--mongo-uri",
        default=DEFAULT_MONGO_URI,
        help="URI MongoDB para carteiras EW",
    )
    parser.add_argument(
        "--mongo-uri-bova11",
        default=None,
        help="URI MongoDB para benchmark BOVA11 (default: igual a --mongo-uri)",
    )
    parser.add_argument(
        "--db-name",
        "--db-name-carteiras",
        "--db-name-carteiras-com-rebalanceamento",
        dest="db_name_carteiras_com_rebalanceamento",
        default=DEFAULT_DB_NAME_CARTEIRAS_COM_REBALANCEAMENTO,
        help=(
            "Banco MongoDB das carteiras EW com rebalanceamento "
            "(aux_metrics, res_*, ret_excess_acum_pct_*)"
        ),
    )
    parser.add_argument(
        "--db-name-carteiras-sem-rebalanceamento",
        default=DEFAULT_DB_NAME_CARTEIRAS_SEM_REBALANCEAMENTO,
        help="Banco MongoDB das carteiras EW sem rebalanceamento (buy-and-hold)",
    )
    parser.add_argument(
        "--db-name-bova11",
        default=None,
        help="Banco MongoDB do benchmark BOVA11 (default: banco das carteiras do modo ativo)",
    )
    parser.add_argument(
        "--rebalanceamento",
        choices=["com", "sem", "ambos"],
        default=DEFAULT_REBALANCEAMENTO,
        help=(
            "Regime das carteiras EW: com rebalanceamento, sem rebalanceamento "
            "ou ambos (executa os dois pipelines)"
        ),
    )
    parser.add_argument(
        "--ativos-carteira",
        default=DEFAULT_ATIVOS_CARTEIRA,
        help="Quantidade de ativos por carteira (ex.: 20)",
    )
    parser.add_argument(
        "--periodo-suffix",
        default=DEFAULT_PERIODO_SUFFIX,
        help="Sufixo do período (ex.: 2011_2025)",
    )
    parser.add_argument(
        "--suffix-buyhold",
        default=DEFAULT_SUFFIX_BUYHOLD,
        help="Sufixo das collections buy-and-hold sem rebalanceamento (default: _buyhold)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="Diretório de saída para CSV/LaTeX/txt",
    )
    parser.add_argument(
        "--step",
        action="append",
        choices=["all", "aux-metrics", "res", "com-vs-sem", "vs-benchmark", "paired-test", "text"],
        default=None,
        help="Etapas a executar (pode repetir; default: all)",
    )
    parser.add_argument(
        "--hac-lag",
        type=int,
        action="append",
        dest="hac_lags",
        help="Lags HAC para o grid (default: 3 4 6 12)",
    )
    parser.add_argument(
        "--avg-block",
        type=int,
        action="append",
        dest="avg_blocks",
        help="Comprimento médio de bloco do bootstrap (default: 3 6 12)",
    )
    parser.add_argument("--boot-b", type=int, default=DEFAULT_BOOT_B, help="Reamostragens bootstrap")
    parser.add_argument("--boot-seed", type=int, default=DEFAULT_BOOT_SEED, help="Semente bootstrap")
    parser.add_argument(
        "--no-csv",
        action="store_true",
        help="Não exportar arquivos CSV",
    )
    parser.add_argument(
        "--no-latex",
        action="store_true",
        help="Não exportar arquivos LaTeX",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Não imprimir tabelas no console",
    )
    parser.add_argument(
        "--no-text-file",
        action="store_true",
        help="Não salvar o texto acadêmico em arquivo",
    )

    args = parser.parse_args(argv)
    rebalanceamento: RebalanceamentoModo = args.rebalanceamento
    db_carteiras_com = args.db_name_carteiras_com_rebalanceamento
    db_carteiras_sem = args.db_name_carteiras_sem_rebalanceamento
    if rebalanceamento == "sem":
        default_bova11_db = db_carteiras_sem
    else:
        default_bova11_db = db_carteiras_com

    return RunConfig(
        mongo_uri=args.mongo_uri,
        mongo_uri_bova11=args.mongo_uri_bova11 or args.mongo_uri,
        db_name_carteiras_com_rebalanceamento=db_carteiras_com,
        db_name_carteiras_sem_rebalanceamento=db_carteiras_sem,
        db_name_bova11=args.db_name_bova11 or default_bova11_db,
        rebalanceamento=rebalanceamento,
        ativos_carteira=args.ativos_carteira,
        periodo_suffix=args.periodo_suffix,
        suffix_buyhold=args.suffix_buyhold,
        output_dir=args.output_dir,
        hac_lags=tuple(args.hac_lags) if args.hac_lags else DEFAULT_HAC_LAGS,
        avg_blocks=tuple(args.avg_blocks) if args.avg_blocks else DEFAULT_AVG_BLOCKS,
        boot_b=args.boot_b,
        boot_seed=args.boot_seed,
        export_csv=not args.no_csv,
        export_latex=not args.no_latex,
        print_tables=not args.quiet,
        write_dissertation_text=not args.no_text_file,
        steps=tuple(args.step) if args.step else ("all",),
    )


def main(config: Optional[RunConfig] = None) -> None:
    run_pipeline(config or parse_args())


if __name__ == "__main__":
    main()
