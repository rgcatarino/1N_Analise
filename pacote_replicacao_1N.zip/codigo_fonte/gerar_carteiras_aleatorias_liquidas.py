"""Gera CSVs de carteiras aleatórias a partir de ações líquidas.

Fontes possíveis: JSON de tickers (--universo-json), CSV de universo, ou Excel
de volume Economática. Padroniza tickers (AXIA→ELET, EMBJ→EMBR, GOL→GOLL54).
Cada carteira tem no máximo um código por empresa (prefixo de 4 letras).
``--exclude-tickers`` tira códigos do universo antes do sorteio (ex.: GSHP3).
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from divliq_ebitda import filter_divliq, load_divliq_frame, merge_divliq_audit
from ticker_formacao import apply_formation_ticker_rules, load_price_bounds, summarize_audit

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_VOLUME_XLSX = REPO_ROOT / "ibov" / "economaticavolumeNegociado.xlsx"
DEFAULT_DIVLIQ_XLSX = REPO_ROOT / "ibov" / "economatica_DivLiq_EBTIDA.xlsx"
DEFAULT_PRICES_PATH = REPO_ROOT / "ibov" / "prices_adjust_close_B3_economatica_1986-out_2025.csv"
DEFAULT_OUT_DIR = REPO_ROOT / "resultados" / "carteiras_aleatorias_liquidas"
DEFAULT_UNIVERSO_JSON = DEFAULT_OUT_DIR / "ativos_liquidos.json"
DEFAULT_SEED = 20250725
DEFAULT_N_CARTEIRAS = 10000
DEFAULT_ADV_MIN = 1000.0
DEFAULT_MIN_OBS_MONTH = 10
DEFAULT_DIVLIQ_MAX = 1.5
DEFAULT_DIVLIQ_CUTOFF_MONTH = 6
DEFAULT_START = "2001-01-01"
DEFAULT_END = "2025-10-31"
DEFAULT_SIZES = (8, 10, 12, 15, 20)

TICKER_RENAME = {
    "AXIA3": "ELET3",
    "AXIA6": "ELET6",
    "EMBJ3": "EMBR3",
    "GOLL4": "GOLL54",
    "GOLL53": "GOLL54",
    "GOL": "GOLL54",
}
OLD_SERIES_RE = re.compile(r"-OLD$", re.IGNORECASE)


def company_key(ticker: str) -> str:
    """Código da empresa na B3: quatro letras iniciais (ITUB4 → ITUB, GOLL54 → GOLL)."""
    match = re.match(r"^([A-Z]{4})", str(ticker).strip().upper())
    return match.group(1) if match else str(ticker).strip().upper()


def padronizar_ticker(ticker: str) -> str:
    t = str(ticker).strip().upper()
    return TICKER_RENAME.get(t, t)


def is_old_series_ticker(*tickers: str) -> bool:
    """True se algum código for série histórica Economática (sufixo -old)."""
    return any(OLD_SERIES_RE.search(str(t).strip()) for t in tickers)


def format_adv_min_tag(adv_min: float) -> str:
    """Sufixo a partir de --adv-min (mil R$ no Excel) em termos de R$/dia.

    Exemplos: 1000 → 1MM; 1500 → 1p5MM; 1488.25 → 1p48825MM; 500 → 500k.
    """
    # Volume Economática está em mil R$; o tag expressa o limiar em reais.
    value = float(adv_min) * 1_000.0
    if value <= 0:
        return "0"

    def _fmt(n: float) -> str:
        if abs(n - round(n)) < 1e-9:
            return str(int(round(n)))
        return f"{n:.6f}".rstrip("0").rstrip(".").replace(".", "p")

    if value >= 1_000_000:
        return f"{_fmt(value / 1_000_000)}MM"
    if value >= 1_000:
        return f"{_fmt(value / 1_000)}k"
    return _fmt(value)


def parse_year_month(raw: str) -> Tuple[int, int]:
    text = str(raw).strip()
    match = re.match(r"^(\d{4})-(\d{1,2})$", text)
    if not match:
        raise ValueError(f"Mês inválido {raw!r}; use YYYY-MM (ex.: 2001-06).")
    year, month = int(match.group(1)), int(match.group(2))
    if not 1 <= month <= 12:
        raise ValueError(f"Mês inválido em {raw!r}.")
    return year, month


def parse_formation_months(raw: str) -> List[Tuple[int, int]]:
    items = [x.strip() for x in str(raw).split(",") if str(x).strip()]
    if not items:
        raise ValueError("Informe ao menos um mês em --formation-months.")
    return [parse_year_month(item) for item in items]


def load_volume_frame(volume_xlsx: Path) -> Tuple[pd.Series, pd.DataFrame]:
    raw = pd.read_excel(volume_xlsx, sheet_name=0, engine="openpyxl")
    if "Data" not in raw.columns:
        raise ValueError("Coluna 'Data' não encontrada no Excel de volume.")
    dates = pd.to_datetime(raw["Data"], errors="coerce")
    tickers = [c for c in raw.columns if c != "Data"]
    vol = raw[tickers].apply(pd.to_numeric, errors="coerce")
    return dates, vol


def tickers_with_price_in_month(prices_path: Path, year: int, month: int) -> set[str]:
    prices = pd.read_csv(prices_path, usecols=lambda c: True)
    date_col = "Date" if "Date" in prices.columns else "Data"
    dates = pd.to_datetime(prices[date_col], errors="coerce")
    mask = (dates.dt.year == year) & (dates.dt.month == month)
    window = prices.loc[mask].drop(columns=[date_col], errors="ignore")
    numeric = window.apply(pd.to_numeric, errors="coerce")
    present = numeric.notna().any(axis=0)
    names: set[str] = set()
    for col, ok in present.items():
        if not bool(ok):
            continue
        raw = str(col).strip().upper()
        names.add(raw)
        names.add(padronizar_ticker(raw))
    return names


def load_liquid_universe_month(
    dates: pd.Series,
    vol: pd.DataFrame,
    *,
    year: int,
    month: int,
    adv_min: float,
    min_obs: int,
    price_tickers: Optional[set[str]] = None,
) -> pd.DataFrame:
    mask = (dates.dt.year == year) & (dates.dt.month == month)
    window = vol.loc[mask]
    n_days = int(len(window))
    if n_days == 0:
        raise ValueError(f"Nenhuma data de volume em {year:04d}-{month:02d}.")

    n_obs = window.notna().sum(axis=0)
    adv = window.fillna(0.0).mean(axis=0)
    keep = adv[(adv > adv_min) & (n_obs >= min_obs)]
    rows = []
    seen: Dict[str, float] = {}
    skipped_price = 0
    skipped_old = 0
    for ticker, value in keep.items():
        mapped = padronizar_ticker(str(ticker))
        if is_old_series_ticker(str(ticker), mapped):
            skipped_old += 1
            continue
        if price_tickers is not None and mapped not in price_tickers:
            skipped_price += 1
            continue
        if mapped in seen and seen[mapped] >= float(value):
            continue
        seen[mapped] = float(value)
        rows.append(
            {
                "ticker": mapped,
                "ticker_origem": str(ticker),
                "empresa": company_key(mapped),
                "adv_mil_reais": float(value),
                "n_obs": int(n_obs[ticker]),
                "n_dias_janela": n_days,
                "adv_ano": year,
                "adv_mes": month,
                "preco_ano": year,
                "preco_mes": 7,
            }
        )
    universo = (
        pd.DataFrame(rows)
        .sort_values(["adv_mil_reais", "ticker"], ascending=[False, True])
        .drop_duplicates(subset=["ticker"])
        .reset_index(drop=True)
        if rows
        else pd.DataFrame(
            columns=[
                "ticker",
                "ticker_origem",
                "empresa",
                "adv_mil_reais",
                "n_obs",
                "n_dias_janela",
                "adv_ano",
                "adv_mes",
                "preco_ano",
                "preco_mes",
            ]
        )
    )
    if skipped_old:
        print(
            f"  {year:04d}-{month:02d}: {skipped_old} papéis com sufixo -old excluídos.",
            flush=True,
        )
    if skipped_price:
        print(
            f"  {year:04d}-{month:02d}: {skipped_price} papéis com "
            f"ADV>{format_adv_min_tag(adv_min)} sem preço em julho.",
            flush=True,
        )
    return universo


def load_universe_from_json(path: Path) -> pd.DataFrame:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, list):
        raw_tickers = payload
    elif isinstance(payload, dict) and "tickers" in payload:
        raw_tickers = payload["tickers"]
    else:
        raise ValueError(f"{path} precisa ser uma lista ou um objeto com chave 'tickers'.")

    rows = []
    seen: set[str] = set()
    for ticker in raw_tickers:
        origem = str(ticker).strip().upper()
        mapped = padronizar_ticker(origem)
        if is_old_series_ticker(origem, mapped):
            continue
        if mapped in seen:
            continue
        seen.add(mapped)
        rows.append(
            {
                "ticker": mapped,
                "ticker_origem": origem,
                "empresa": company_key(mapped),
            }
        )
    return pd.DataFrame(rows).sort_values("ticker").reset_index(drop=True)


def load_liquid_universe(
    volume_xlsx: Path,
    *,
    start: str,
    end: str,
    adv_min: float,
) -> pd.DataFrame:
    dates, vol = load_volume_frame(volume_xlsx)
    mask = (dates >= pd.Timestamp(start)) & (dates <= pd.Timestamp(end))
    window = vol.loc[mask]
    n_days = int(len(window))
    if n_days == 0:
        raise ValueError(f"Nenhuma data entre {start} e {end}.")

    adv = window.fillna(0.0).mean(axis=0)
    n_obs = window.notna().sum(axis=0)
    keep = adv[adv > adv_min]
    rows = []
    seen: Dict[str, float] = {}
    for ticker, value in keep.items():
        mapped = padronizar_ticker(str(ticker))
        if is_old_series_ticker(str(ticker), mapped):
            continue
        if mapped in seen and seen[mapped] >= float(value):
            continue
        seen[mapped] = float(value)
        rows.append(
            {
                "ticker": mapped,
                "ticker_origem": str(ticker),
                "empresa": company_key(mapped),
                "adv_mil_reais": float(value),
                "n_obs": int(n_obs[ticker]),
                "n_dias_janela": n_days,
            }
        )
    universo = pd.DataFrame(rows).sort_values(
        ["adv_mil_reais", "ticker"], ascending=[False, True]
    ).drop_duplicates(subset=["ticker"]).reset_index(drop=True)
    return universo


def group_by_company(tickers: Sequence[str]) -> Dict[str, List[str]]:
    groups: Dict[str, List[str]] = defaultdict(list)
    for t in tickers:
        groups[company_key(t)].append(t)
    for key in groups:
        groups[key] = sorted(set(groups[key]))
    return dict(groups)


def sample_portfolios(
    groups: Mapping[str, Sequence[str]],
    n_assets: int,
    n_portfolios: int,
    rng: np.random.Generator,
) -> List[tuple[str, ...]]:
    companies = np.array(sorted(groups.keys()))
    if n_assets > len(companies):
        raise ValueError(
            f"N={n_assets} exige {n_assets} empresas; o universo tem {len(companies)}."
        )

    seen: set[tuple[str, ...]] = set()
    portfolios: List[tuple[str, ...]] = []
    attempts = 0
    max_attempts = n_portfolios * 50
    while len(portfolios) < n_portfolios:
        attempts += 1
        if attempts > max_attempts:
            raise RuntimeError(
                f"Não foi possível gerar {n_portfolios} carteiras distintas com N={n_assets}."
            )
        chosen = rng.choice(companies, size=n_assets, replace=False)
        ticks = []
        for company in chosen:
            classes = groups[str(company)]
            ticks.append(str(classes[int(rng.integers(0, len(classes)))]))
        key = tuple(sorted(ticks))
        if key in seen:
            continue
        seen.add(key)
        portfolios.append(key)
    return portfolios


def write_portfolios(path: Path, portfolios: Sequence[Sequence[str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as fh:
        writer = csv.writer(fh, lineterminator="\n", quoting=csv.QUOTE_MINIMAL)
        writer.writerow(["Carteira"])
        for row in portfolios:
            writer.writerow([",".join(row)])


def parse_exclude_tickers(raw: str | None) -> set[str]:
    """Tickers separados por vírgula, já padronizados."""
    if not raw or not str(raw).strip():
        return set()
    out: set[str] = set()
    for part in str(raw).replace(";", ",").split(","):
        token = part.strip()
        if token:
            out.add(padronizar_ticker(token))
    return out


def parse_sizes(raw: str) -> List[int]:
    sizes = [int(x.strip()) for x in str(raw).split(",") if str(x).strip()]
    if not sizes:
        raise ValueError("Informe ao menos um tamanho em --sizes.")
    return sizes


def parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Gera CSVs de carteiras aleatórias com ações líquidas, sem repetir empresa."
    )
    parser.add_argument("--volume-xlsx", type=Path, default=DEFAULT_VOLUME_XLSX)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    parser.add_argument("--start", default=DEFAULT_START)
    parser.add_argument("--end", default=DEFAULT_END)
    parser.add_argument(
        "--adv-min",
        type=float,
        default=DEFAULT_ADV_MIN,
        help=(
            "ADV mínimo em mil R$ (unidade do Excel Economática). "
            "R$ 1 milhão/dia = 1000; R$ 1,5 milhão/dia = 1500 (default: 1000)."
        ),
    )
    parser.add_argument("--n-carteiras", type=int, default=DEFAULT_N_CARTEIRAS)
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    parser.add_argument(
        "--sizes",
        default=",".join(str(n) for n in DEFAULT_SIZES),
        help="Tamanhos de carteira separados por vírgula (default: 8,10,12,15,20)",
    )
    parser.add_argument(
        "--universo-json",
        type=Path,
        default=None,
        help="JSON com lista de tickers (chave 'tickers' ou array raiz).",
    )
    parser.add_argument(
        "--universo-csv",
        type=Path,
        default=None,
        help="Se informado e existir, reutiliza o universo (não relê o Excel).",
    )
    parser.add_argument(
        "--suffix",
        default="",
        help="Sufixo no nome do CSV de carteiras (ex.: _divliq_10k → carteiras_8atv_divliq_10k.csv).",
    )
    parser.add_argument(
        "--universo-csv-out",
        type=Path,
        default=None,
        help="Caminho do CSV de universo a gravar (default: out-dir/universo_ativos_liquidos.csv).",
    )
    parser.add_argument(
        "--formation-months",
        default=None,
        help=(
            "Meses de formação do ADV, YYYY-MM separados por vírgula "
            "(ex.: 2001-06,2006-06,2011-06). Gera um universo e CSVs por mês, "
            "sem sobrescrever universo_ativos_liquidos.csv."
        ),
    )
    parser.add_argument(
        "--min-obs-month",
        type=int,
        default=DEFAULT_MIN_OBS_MONTH,
        help="Mínimo de pregões com volume no mês de ADV (default: 10)",
    )
    parser.add_argument(
        "--prices-path",
        type=Path,
        default=DEFAULT_PRICES_PATH,
        help="CSV de preços para exigir cotação em julho do ano de formação",
    )
    parser.add_argument(
        "--no-price-filter",
        action="store_true",
        help="Não exige preço em julho (só o ADV de junho)",
    )
    parser.add_argument(
        "--divliq-xlsx",
        type=Path,
        default=DEFAULT_DIVLIQ_XLSX,
        help="Excel Economática DivLiq/EBITDA (default: ibov/economatica_DivLiq_EBTIDA.xlsx)",
    )
    parser.add_argument(
        "--divliq-max",
        type=float,
        default=DEFAULT_DIVLIQ_MAX,
        help="Limite máximo DivLiq/EBITDA (default: 1.5)",
    )
    parser.add_argument(
        "--divliq-cutoff-month",
        type=int,
        default=DEFAULT_DIVLIQ_CUTOFF_MONTH,
        help="Mês de corte da métrica sem look-ahead (default: 6 = junho)",
    )
    parser.add_argument(
        "--no-formation-ticker-rules",
        action="store_true",
        help=(
            "Não aplica remapeamento temporal (CONTINUACAO_EXPLICITA reverso) nem "
            "filtro de primeira cotação na formação ponto-a-ponto."
        ),
    )
    parser.add_argument(
        "--no-divliq-filter",
        action="store_true",
        help="Não aplica filtro DivLiq/EBITDA (só liquidez)",
    )
    parser.add_argument(
        "--exclude-tickers",
        default="",
        help=(
            "Tickers que não entram no universo investível, separados por vírgula "
            "(ex.: GSHP3 ou GSHP3,XYZ3). A comparação usa o ticker já padronizado."
        ),
    )
    return parser.parse_args(argv)


def drop_old_series(universo: pd.DataFrame) -> pd.DataFrame:
    if universo.empty:
        return universo
    cols = [c for c in ("ticker", "ticker_origem") if c in universo.columns]
    if not cols:
        return universo
    mask = pd.Series(False, index=universo.index)
    for col in cols:
        mask = mask | universo[col].astype(str).str.contains(OLD_SERIES_RE)
    dropped = universo.loc[mask, "ticker"].astype(str).tolist() if "ticker" in universo.columns else []
    if dropped:
        print(f"Excluídos por sufixo -old: {', '.join(dropped)}", flush=True)
    return universo.loc[~mask].reset_index(drop=True)


def drop_excluded_tickers(universo: pd.DataFrame, excluded: set[str]) -> pd.DataFrame:
    """Remove do universo os tickers pedidos em ``--exclude-tickers``."""
    if universo.empty or not excluded or "ticker" not in universo.columns:
        if excluded and (universo.empty or "ticker" not in universo.columns):
            print(
                "Nenhum ticker de --exclude-tickers estava neste universo "
                f"({', '.join(sorted(excluded))}).",
                flush=True,
            )
        return universo
    mapped = universo["ticker"].astype(str).map(padronizar_ticker)
    mask = mapped.isin(excluded)
    if "ticker_origem" in universo.columns:
        origem = universo["ticker_origem"].astype(str).map(padronizar_ticker)
        mask = mask | origem.isin(excluded)
    dropped = sorted(set(mapped.loc[mask].tolist()))
    if dropped:
        print(f"Excluídos do universo investível: {', '.join(dropped)}", flush=True)
    else:
        print(
            "Nenhum ticker de --exclude-tickers estava neste universo "
            f"({', '.join(sorted(excluded))}).",
            flush=True,
        )
    return universo.loc[~mask].reset_index(drop=True)


def emit_portfolios(
    universo: pd.DataFrame,
    *,
    out_dir: Path,
    suffix: str,
    n_carteiras: int,
    seed: int,
    sizes: Sequence[int],
) -> None:
    universo = drop_old_series(universo)
    tickers = universo["ticker"].astype(str).tolist()
    groups = group_by_company(tickers)
    print(
        f"Ativos líquidos: {len(tickers)} | empresas distintas: {len(groups)} | "
        f"seed={seed} | carteiras por N={n_carteiras}"
    )
    if not tickers:
        raise ValueError(
            "Universo vazio; não é possível sortear carteiras. "
            "Lembrete: --adv-min está em mil R$ (R$ 1MM/dia = 1000, não 1000000)."
        )
    multi = {k: v for k, v in groups.items() if len(v) > 1}
    if multi:
        exemplos = ", ".join(f"{k}({','.join(v)})" for k, v in sorted(multi.items())[:12])
        print(f"Empresas com mais de um código: {len(multi)} — ex.: {exemplos}")

    mapped_ok = [t for t in ("ELET3", "ELET6", "EMBR3", "GOLL54") if t in set(tickers)]
    old_absent = [t for t in ("AXIA3", "AXIA6", "EMBJ3", "GOL") if t not in set(tickers)]
    print(f"Mapeados presentes: {mapped_ok} | nomes antigos ausentes: {old_absent}")

    rng = np.random.default_rng(seed)
    n_empresas = len(groups)
    for n_assets in sizes:
        if n_assets > n_empresas:
            print(
                f"N={n_assets:>2}: pulado — universo tem só {n_empresas} empresas "
                f"(precisa de {n_assets}).",
                flush=True,
            )
            continue
        portfolios = sample_portfolios(groups, n_assets, n_carteiras, rng)
        out_path = out_dir / f"carteiras_{n_assets}atv{suffix}.csv"
        write_portfolios(out_path, portfolios)
        n_unique = len({tuple(p) for p in portfolios})
        print(f"N={n_assets:>2}: {n_unique} carteiras distintas → {out_path}")


def run_formation_months(args: argparse.Namespace) -> None:
    months = parse_formation_months(args.formation_months)
    out_dir = args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    sizes = parse_sizes(args.sizes)
    use_divliq = not args.no_divliq_filter
    divliq_frame = None
    if use_divliq:
        print(f"Lendo DivLiq/EBITDA em {args.divliq_xlsx} ...", flush=True)
        divliq_frame = load_divliq_frame(args.divliq_xlsx)
    print(f"Lendo volumes em {args.volume_xlsx} ...", flush=True)
    dates, vol = load_volume_frame(args.volume_xlsx)
    prices_cache: Dict[Tuple[int, int], set[str]] = {}
    bounds_cache = None
    for year, month in months:
        price_year, price_month = year, 7
        price_tickers = None
        if not args.no_price_filter:
            key = (price_year, price_month)
            if key not in prices_cache:
                print(
                    f"Lendo preços com cotação em {price_year:04d}-{price_month:02d} ...",
                    flush=True,
                )
                prices_cache[key] = tickers_with_price_in_month(
                    args.prices_path, price_year, price_month
                )
            price_tickers = prices_cache[key]
        universo = load_liquid_universe_month(
            dates,
            vol,
            year=year,
            month=month,
            adv_min=args.adv_min,
            min_obs=args.min_obs_month,
            price_tickers=price_tickers,
        )
        tag = f"{year:04d}{month:02d}"
        n_liq = len(universo)
        if not args.no_formation_ticker_rules:
            if bounds_cache is None:
                print(
                    f"Carregando calendário de cotações em {args.prices_path} ...",
                    flush=True,
                )
                bounds_cache = load_price_bounds(
                    args.prices_path,
                    universo["ticker"].astype(str).tolist(),
                    sample_end=args.end,
                )
            else:
                extra = load_price_bounds(
                    args.prices_path,
                    universo["ticker"].astype(str).tolist(),
                    sample_end=args.end,
                )
                bounds_cache.update(extra)
            universo, audit_formacao = apply_formation_ticker_rules(
                universo,
                year=year,
                month=month,
                bounds=bounds_cache,
            )
            audit_formacao_path = out_dir / f"audit_anacronismos_{tag}.csv"
            audit_formacao.to_csv(audit_formacao_path, index=False, date_format="%Y-%m-%d")
            print(f"  {summarize_audit(audit_formacao)} → {audit_formacao_path}", flush=True)
            n_liq = len(universo)
            if price_tickers is not None and not universo.empty:
                before = len(universo)
                universo = universo[
                    universo["ticker"].astype(str).isin(price_tickers)
                ].reset_index(drop=True)
                dropped = before - len(universo)
                if dropped:
                    print(
                        f"  {year:04d}-{month:02d}: {dropped} papéis removidos após "
                        "regras temporais (sem preço em julho).",
                        flush=True,
                    )
                n_liq = len(universo)
        if use_divliq:
            assert divliq_frame is not None
            tickers = universo["ticker"].astype(str).tolist()
            _, audit = filter_divliq(
                tickers,
                divliq_frame,
                year=year,
                cutoff_month=args.divliq_cutoff_month,
                thr=args.divliq_max,
            )
            audit_path = out_dir / f"audit_divliq_{tag}.csv"
            audit.to_csv(audit_path, index=False)
            universo = merge_divliq_audit(universo, audit)
            adv_tag = format_adv_min_tag(args.adv_min)
            universo_tag = f"liq_divliq_{adv_tag}_{tag}"
            n_ok = int((audit["divliq_motivo"] == "ok").sum())
            n_isento = int(audit["mantido"].sum()) - n_ok
            n_acima = int(audit["divliq_motivo"].astype(str).str.startswith("acima_de").sum())
            print(
                f"  DivLiq até {year:04d}-{args.divliq_cutoff_month:02d}: "
                f"{len(universo)}/{n_liq} mantidos "
                f"(ok={n_ok}, isentos={n_isento}, acima={n_acima}) → {audit_path}",
                flush=True,
            )
        else:
            adv_tag = format_adv_min_tag(args.adv_min)
            universo_tag = f"liq_{adv_tag}_{tag}"
        universo = drop_old_series(universo)
        universo = drop_excluded_tickers(universo, parse_exclude_tickers(args.exclude_tickers))
        universo_path = out_dir / f"universo_{universo_tag}.csv"
        universo.to_csv(universo_path, index=False)
        print(
            f"Formação ADV {year:04d}-{month:02d}: {len(universo)} ativos → {universo_path}",
            flush=True,
        )
        emit_portfolios(
            universo,
            out_dir=out_dir,
            suffix=f"_{universo_tag}",
            n_carteiras=args.n_carteiras,
            seed=args.seed,
            sizes=sizes,
        )


def main(argv: Iterable[str] | None = None) -> None:
    args = parse_args(argv)
    out_dir = args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    if args.formation_months:
        run_formation_months(args)
        return

    universo_csv_path = (
        args.universo_csv_out
        or args.universo_csv
        or (out_dir / "universo_ativos_liquidos.csv")
    )
    universo_json = args.universo_json
    if universo_json is None and DEFAULT_UNIVERSO_JSON.exists() and args.universo_csv is None:
        universo_json = DEFAULT_UNIVERSO_JSON

    if universo_json is not None:
        if not universo_json.exists():
            raise FileNotFoundError(f"JSON de universo não encontrado: {universo_json}")
        universo = load_universe_from_json(universo_json)
        universo = drop_old_series(universo)
        universo = drop_excluded_tickers(universo, parse_exclude_tickers(args.exclude_tickers))
        universo.to_csv(universo_csv_path, index=False)
        print(f"Universo lido de {universo_json} e salvo em {universo_csv_path}")
    elif Path(args.universo_csv or universo_csv_path).exists():
        src_csv = Path(args.universo_csv) if args.universo_csv else universo_csv_path
        universo = drop_old_series(pd.read_csv(src_csv))
        universo = drop_excluded_tickers(universo, parse_exclude_tickers(args.exclude_tickers))
        universo.to_csv(src_csv, index=False)
        print(f"Universo lido de {src_csv} ({len(universo)} ativos, sem -old)")
    else:
        print(f"Lendo volumes em {args.volume_xlsx} ...")
        universo = load_liquid_universe(
            args.volume_xlsx,
            start=args.start,
            end=args.end,
            adv_min=args.adv_min,
        )
        universo = drop_old_series(universo)
        universo = drop_excluded_tickers(universo, parse_exclude_tickers(args.exclude_tickers))
        universo.to_csv(universo_csv_path, index=False)
        print(f"Universo salvo em {universo_csv_path}")

    emit_portfolios(
        universo,
        out_dir=out_dir,
        suffix=str(args.suffix or ""),
        n_carteiras=args.n_carteiras,
        seed=args.seed,
        sizes=parse_sizes(args.sizes),
    )


if __name__ == "__main__":
    main()
