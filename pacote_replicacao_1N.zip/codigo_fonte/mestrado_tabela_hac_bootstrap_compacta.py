"""Tabela compacta de robustez temporal (HAC + stationary bootstrap).

Consolida, por período e por número de ativos, o diferencial mensal médio
1/N − Ibovespa (BOVA11) com:

- p_HAC na especificação-base (default L=6);
- faixa [mín.; máx.] de p_boot no grid de lags × blocos;
- veredito (Rejeita H0 / Parcial / Não rejeita).

Stationary bootstrap com B=3.000 reamostragens por padrão.

Lê ``ret_excess_acum_pct_*`` do banco de carteiras e do banco do BOVA11.

Exemplo::

    cd ~/mestrado
    source .venv/bin/activate

    # Inventário
    python3 codigo_fonte/mestrado_tabela_hac_bootstrap_compacta.py --list-collections

    # Tabela compacta (liq_1MM, 12 bps, IR, rebalanceamento anual)
    python3 codigo_fonte/mestrado_tabela_hac_bootstrap_compacta.py \\
      --universo-tag liq_1MM \\
      --tcost-bps 12 \\
      --ir sim \\
      --rebalanceamento com \\
      --ativos 8 10 12 15 20 25 30 35 40

Saída (ex.): ``hac_bootstrap_compacta_1n_vs_ibovespa_com_reb.csv``;
com ``--rebalanceamento sem``: ``..._sem_reb.csv``.
"""

from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from pymongo import MongoClient
from pymongo.database import Database

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

from mestrado_resultados_simulador_pessoa_investidora import (  # noqa: E402
    DEFAULT_AVG_BLOCKS,
    DEFAULT_BOOT_SEED,
    DEFAULT_HAC_LAGS,
    DEFAULT_MONGO_URI,
    _hac_se_mean,
    acum_pct_to_periodic_ret,
    stationary_bootstrap_pvalue_mean,
)
from mestrado_resultados_simulador_pessoa_investidora_v2 import (  # noqa: E402
    DEFAULT_DB_BOVA11,
    DEFAULT_DB_LIQUIDEZ,
    REBALANCE_FREQS,
    liquidez_suffix,
)
from mestrado_resultados_simulador_pessoa_investidora_v5 import (  # noqa: E402
    _resolve_exclude_universo_tags,
    build_output_stem,
    rebalanceamento_legenda_text,
)

SUFFIX_RE = re.compile(
    r"^(?P<n>\d+)atv_"
    r"(?P<head>.*?)"
    r"(?P<start>\d{6})_(?P<end>\d{6})_"
    r"(?P<reb>reb-[\w]+|buyhold|buy-hold)_"
    r"t(?P<tcost>\d+)bps_(?P<ir>ir|noir)"
    r"(?P<engine>_v41)?$"
)
ENGINE_CHOICES = ("v4", "v41", "all")

DEFAULT_OUTPUT_DIR = REPO_ROOT / "resultados" / "liquidez_1mm_delist"
DEFAULT_ATIVOS = (8, 10, 12, 15, 20, 25, 30, 35, 40)
DEFAULT_PERIODS = (
    ("2001-2025", 2001, 7, 2025, 10),
    ("2006-2025", 2006, 7, 2025, 10),
    ("2011-2025", 2011, 7, 2025, 10),
)
DEFAULT_ALPHA = 0.05
DEFAULT_BASE_LAG = 6
DEFAULT_BOOT_B = 3000
RODAPE_UNIVERSO = {
    "liq_1MM": "ações com liquidez diária maior que 1 milhão de reais",
}
DEFAULT_STEM = "hac_bootstrap_compacta_1n_vs_ibovespa"
DEFAULT_LABEL = "tab:hac-bootstrap-compacta"
DEFAULT_TITLE = (
    r"Teste temporal do diferencial agregado $\bar{d}_t$ de $1/N$ versus Ibovespa "
    r"(HAC e \emph{stationary bootstrap}): resumo consolidado"
)


@dataclass(frozen=True)
class ParsedExcessCollection:
    collection: str
    suffix: str
    n_ativos: int
    universo_tag: str
    start_y: int
    start_m: int
    end_y: int
    end_m: int
    reb_tag: str
    tcost_bps: int
    ir_tag: str
    engine: str = "v4"

    @property
    def period_label(self) -> str:
        return f"{self.start_y}-{self.end_y}"


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Gera tabela compacta de robustez temporal (HAC + bootstrap) "
            "por período e número de ativos, lendo collections do MongoDB."
        )
    )
    parser.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    parser.add_argument("--db-name", default=DEFAULT_DB_LIQUIDEZ)
    parser.add_argument("--db-name-bova11", default=DEFAULT_DB_BOVA11)
    parser.add_argument(
        "--ativos",
        type=int,
        nargs="+",
        default=None,
        help=f"N por carteira (default: {' '.join(map(str, DEFAULT_ATIVOS))})",
    )
    parser.add_argument(
        "--periodos",
        nargs="+",
        default=None,
        help="Janelas nominais (ex.: 2001_2025 2006_2025). Default: 2001/2006/2011–2025.",
    )
    parser.add_argument("--start-m", type=int, default=7)
    parser.add_argument("--end-m", type=int, default=10)
    parser.add_argument("--end-y", type=int, default=2025)
    parser.add_argument("--universo-tag", default="liq_1MM")
    parser.add_argument(
        "--exclude-universo-tag",
        nargs="+",
        default=None,
        help=(
            "Tags de universo a ignorar (default: liq_divliq_1MM). "
            "Use --exclude-universo-tag '' para não excluir nenhuma."
        ),
    )
    parser.add_argument("--tcost-bps", type=float, default=12.0)
    parser.add_argument("--ir", choices=("sim", "nao"), default="sim")
    parser.add_argument(
        "--rebalanceamento",
        choices=("com", "sem"),
        default="com",
    )
    parser.add_argument(
        "--rebalance-freq",
        choices=REBALANCE_FREQS,
        default="annual",
    )
    parser.add_argument("--sem-reb-tag", default="buyhold")
    parser.add_argument(
        "--engine",
        choices=ENGINE_CHOICES,
        default="v41",
        help=(
            "Motor das collections ret_excess_acum_pct_*: "
            "v41 = sufixo *_v41 (default); v4 = legado; all = ambos "
            "(preferindo v41 se houver duplicata)."
        ),
    )
    parser.add_argument(
        "--hac-lags",
        type=int,
        nargs="+",
        default=list(DEFAULT_HAC_LAGS),
        help="Grid de lags HAC para a faixa de p_boot (default: 3 4 6 12)",
    )
    parser.add_argument(
        "--avg-blocks",
        type=int,
        nargs="+",
        default=list(DEFAULT_AVG_BLOCKS),
        help="Grid de blocos do bootstrap (default: 3 6 12)",
    )
    parser.add_argument(
        "--base-lag",
        type=int,
        default=DEFAULT_BASE_LAG,
        help="Lag HAC reportado na coluna p_HAC (default: 6)",
    )
    parser.add_argument(
        "--boot-b",
        type=int,
        default=DEFAULT_BOOT_B,
        help=f"Reamostragens do stationary bootstrap (default: {DEFAULT_BOOT_B})",
    )
    parser.add_argument("--boot-seed", type=int, default=DEFAULT_BOOT_SEED)
    parser.add_argument(
        "--alpha",
        type=float,
        default=DEFAULT_ALPHA,
        help="Nível de significância para a coluna Conclusão (default: 0.05)",
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--stem", default=DEFAULT_STEM)
    parser.add_argument("--label", default=DEFAULT_LABEL)
    parser.add_argument("--title", default=DEFAULT_TITLE)
    parser.add_argument(
        "--allow-missing",
        action="store_true",
        default=True,
        help="Segue com combinações ausentes (default)",
    )
    parser.add_argument(
        "--require-all",
        dest="allow_missing",
        action="store_false",
        help="Falha se faltar alguma collection solicitada",
    )
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument(
        "--list-collections",
        action="store_true",
        help="Lista collections ret_excess_acum_pct_* reconhecidas e sai",
    )
    return parser.parse_args(list(argv) if argv is not None else None)


def parse_excess_suffix(suffix: str) -> Optional[ParsedExcessCollection]:
    match = SUFFIX_RE.match(suffix)
    if not match:
        return None
    start = match.group("start")
    end = match.group("end")
    engine = "v41" if match.group("engine") == "_v41" else "v4"
    return ParsedExcessCollection(
        collection=f"ret_excess_acum_pct_{suffix}",
        suffix=suffix,
        n_ativos=int(match.group("n")),
        universo_tag=match.group("head").rstrip("_"),
        start_y=int(start[:4]),
        start_m=int(start[4:6]),
        end_y=int(end[:4]),
        end_m=int(end[4:6]),
        reb_tag=match.group("reb"),
        tcost_bps=int(match.group("tcost")),
        ir_tag=match.group("ir"),
        engine=engine,
    )


def discover_excess_collections(db: Database) -> List[ParsedExcessCollection]:
    parsed: List[ParsedExcessCollection] = []
    for name in sorted(db.list_collection_names()):
        if not name.startswith("ret_excess_acum_pct_"):
            continue
        item = parse_excess_suffix(name[len("ret_excess_acum_pct_") :])
        if item is not None:
            parsed.append(item)
    return parsed


def _reb_matches(
    item: ParsedExcessCollection,
    *,
    rebalance: bool,
    rebalance_freq: str,
    sem_reb_tag: str,
) -> bool:
    if rebalance:
        return item.reb_tag == f"reb-{rebalance_freq}"
    return item.reb_tag in {sem_reb_tag, "buyhold", "buy-hold"}


def filter_excess_for_args(
    index: Sequence[ParsedExcessCollection],
    args: argparse.Namespace,
) -> List[ParsedExcessCollection]:
    """Aplica os mesmos filtros de universo/reb/custo/IR usados na execução."""
    rebalance = args.rebalanceamento == "com"
    sem_reb_tag = str(getattr(args, "sem_reb_tag", None) or "buyhold")
    exclude = _resolve_exclude_universo_tags(args)
    requested_tag = str(args.universo_tag or "").strip()
    tcost_bps = int(round(float(args.tcost_bps)))
    ir_tag = "ir" if args.ir == "sim" else "noir"
    engine = str(getattr(args, "engine", "v41")).lower()

    out: List[ParsedExcessCollection] = []
    for item in index:
        if item.tcost_bps != tcost_bps or item.ir_tag != ir_tag:
            continue
        if engine != "all" and item.engine != engine:
            continue
        if not _reb_matches(
            item,
            rebalance=rebalance,
            rebalance_freq=args.rebalance_freq,
            sem_reb_tag=sem_reb_tag,
        ):
            continue
        if item.universo_tag in exclude:
            continue
        if requested_tag and item.universo_tag != requested_tag:
            continue
        out.append(item)
    return out


def filter_index(
    index: Sequence[ParsedExcessCollection],
    *,
    rebalance: bool,
    rebalance_freq: str,
    sem_reb_tag: str,
    universo_tag: str,
    tcost_bps: int,
    ir_tag: str,
    exclude_universo_tags: frozenset[str] = frozenset(),
    engine: str = "v41",
) -> List[ParsedExcessCollection]:
    requested = str(universo_tag or "").strip()
    eng = str(engine or "v41").lower()
    out: List[ParsedExcessCollection] = []
    for item in index:
        if item.tcost_bps != tcost_bps or item.ir_tag != ir_tag:
            continue
        if eng != "all" and item.engine != eng:
            continue
        if not _reb_matches(
            item,
            rebalance=rebalance,
            rebalance_freq=rebalance_freq,
            sem_reb_tag=sem_reb_tag,
        ):
            continue
        if item.universo_tag in exclude_universo_tags:
            continue
        if requested and item.universo_tag != requested:
            continue
        out.append(item)
    return out


def period_windows_from_args(
    periodos: Optional[Sequence[str]],
    *,
    start_m: int,
    end_m: int,
    end_y: int,
) -> Tuple[Tuple[str, int, int, int, int], ...]:
    if not periodos:
        return DEFAULT_PERIODS
    windows: List[Tuple[str, int, int, int, int]] = []
    for token in periodos:
        sep = "_" if "_" in token else "-"
        start_s, end_s = token.split(sep, 1)
        start_y = int(start_s)
        end_y_token = int(end_s)
        windows.append(
            (f"{start_y}-{end_y_token}", start_y, start_m, end_y_token, end_m)
        )
    return tuple(windows)


def bova11_suffix(start_y: int, end_y: int) -> str:
    return f"BOVA11_{start_y}_{end_y}"


def resolve_collection(
    index: Sequence[ParsedExcessCollection],
    *,
    n_ativos: int,
    start_y: int,
    start_m: int,
    end_y: int,
    end_m: int,
) -> Optional[ParsedExcessCollection]:
    exact = [
        item
        for item in index
        if item.n_ativos == n_ativos
        and item.start_y == start_y
        and item.start_m == start_m
        and item.end_y == end_y
        and item.end_m == end_m
    ]
    if exact:
        return sorted(
            exact,
            key=lambda x: (1 if x.engine == "v41" else 0, x.collection),
            reverse=True,
        )[0]

    same_year = [
        item
        for item in index
        if item.n_ativos == n_ativos
        and item.start_y == start_y
        and item.start_m == start_m
        and item.end_y == end_y
    ]
    if same_year:
        return sorted(
            same_year,
            key=lambda x: (1 if x.engine == "v41" else 0, x.end_m, x.collection),
            reverse=True,
        )[0]
    return None


def print_inventory(
    index: Sequence[ParsedExcessCollection],
    *,
    db_name: str,
    filters: Optional[Dict[str, object]] = None,
) -> None:
    if filters:
        print("Filtros:", flush=True)
        for key, value in filters.items():
            print(f"  {key}: {value}", flush=True)
        print(flush=True)
    print(f"{db_name}: {len(index)} collections ret_excess_acum_pct_* reconhecidas", flush=True)
    if not index:
        return
    print(
        f"{'N':>3}  {'Período':<12} {'Universo':<16} {'IR':<5} {'Reb':<12} {'bps':>4}  Collection",
        flush=True,
    )
    for item in index:
        print(
            f"{item.n_ativos:>3}  {item.period_label:<12} "
            f"{(item.universo_tag or '-'):<16} {item.ir_tag:<5} {item.reb_tag:<12} "
            f"{item.tcost_bps:>4}  {item.collection}",
            flush=True,
        )


def load_dbar_series(
    db: Database,
    db_bova11: Database,
    *,
    carteiras_suffix: str,
    bova_suffix: str,
) -> Tuple[pd.Series, float]:
    projection = {"_id": 0, "strategy": 1, "date": 1, "value": 1}
    ew_name = f"ret_excess_acum_pct_{carteiras_suffix}"
    bm_name = f"ret_excess_acum_pct_{bova_suffix}"

    ew_docs = list(db[ew_name].find({}, projection))
    bm_docs = list(db_bova11[bm_name].find({}, projection))
    if not ew_docs:
        raise RuntimeError(f"Collection vazia: {db.name}.{ew_name}")
    if not bm_docs:
        raise RuntimeError(f"Collection vazia: {db_bova11.name}.{bm_name}")

    ew_df = pd.DataFrame(ew_docs)
    bm_df = pd.DataFrame(bm_docs)
    ew_df["date"] = pd.to_datetime(ew_df["date"])
    bm_df["date"] = pd.to_datetime(bm_df["date"])

    ew_ret = acum_pct_to_periodic_ret(ew_df, "strategy")
    bm_ret = acum_pct_to_periodic_ret(bm_df, "strategy")

    benchmark_names = bm_ret["strategy"].unique()
    if len(benchmark_names) > 1:
        bm_ret = bm_ret[bm_ret["strategy"] == benchmark_names[0]].copy()

    bm_ret = (
        bm_ret.rename(columns={"ret": "ret_bm"})[["date", "ret_bm"]]
        .drop_duplicates(subset=["date"])
    )
    merged = ew_ret.merge(bm_ret, on="date", how="inner")
    merged["diff"] = merged["ret"] - merged["ret_bm"]
    dbar = merged.groupby("date")["diff"].mean().sort_index()
    n_strat = float(merged.groupby("date")["strategy"].nunique().mean())
    return dbar, n_strat


def verdict(p_hac: float, p_boot_min: float, p_boot_max: float, alpha: float) -> str:
    if not np.isfinite(p_hac) or not np.isfinite(p_boot_min) or not np.isfinite(p_boot_max):
        return "Indeterminado"
    if p_hac < alpha and p_boot_max < alpha:
        return "Rejeita H0"
    if p_hac < alpha and p_boot_min < alpha <= p_boot_max:
        return "Parcial"
    return "Não rejeita"


def compute_compact_row(
    dbar: pd.Series,
    *,
    period_label: str,
    n_ativos: int,
    n_strat: float,
    hac_lags: Sequence[int],
    avg_blocks: Sequence[int],
    base_lag: int,
    boot_b: int,
    boot_seed: int,
    alpha: float,
) -> Dict[str, object]:
    lags = tuple(sorted({int(x) for x in hac_lags}))
    blocks = tuple(sorted({int(x) for x in avg_blocks}))
    if base_lag not in lags:
        lags = tuple(sorted(set(lags) | {int(base_lag)}))

    hac_base = _hac_se_mean(dbar, lag=int(base_lag))
    mu_m = float(hac_base["mean"]) if np.isfinite(hac_base["mean"]) else np.nan
    d_aa = (1.0 + mu_m) ** 12 - 1.0 if np.isfinite(mu_m) else np.nan

    p_boots: List[float] = []
    for block in blocks:
        for lag in lags:
            p_boot = stationary_bootstrap_pvalue_mean(
                dbar,
                bootstrap_samples=boot_b,
                avg_block=block,
                seed=boot_seed,
                hac_lag=lag,
            )
            if np.isfinite(p_boot):
                p_boots.append(float(p_boot))

    p_boot_min = float(np.min(p_boots)) if p_boots else np.nan
    p_boot_max = float(np.max(p_boots)) if p_boots else np.nan
    p_hac = float(hac_base["pvalue"]) if np.isfinite(hac_base["pvalue"]) else np.nan

    return {
        "Período": period_label,
        "N": int(n_ativos),
        "T": int(hac_base["T"]) if np.isfinite(hac_base["T"]) else np.nan,
        "d_bar_%_aa": 100.0 * d_aa if np.isfinite(d_aa) else np.nan,
        "p_HAC": p_hac,
        "p_boot_min": p_boot_min,
        "p_boot_max": p_boot_max,
        "Conclusão": verdict(p_hac, p_boot_min, p_boot_max, alpha),
        "t_HAC": float(hac_base["tstat"]) if np.isfinite(hac_base["tstat"]) else np.nan,
        "N_strat": round(float(n_strat), 1),
        "L_base": int(base_lag),
    }


def build_compact_table(
    db: Database,
    db_bova11: Database,
    *,
    index: Sequence[ParsedExcessCollection],
    ativos: Sequence[int],
    period_windows: Sequence[Tuple[str, int, int, int, int]],
    hac_lags: Sequence[int],
    avg_blocks: Sequence[int],
    base_lag: int,
    boot_b: int,
    boot_seed: int,
    alpha: float,
    allow_missing: bool,
    quiet: bool,
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []

    for period_label, start_y, start_m, end_y, end_m in period_windows:
        bova_suf = bova11_suffix(start_y, end_y)
        for n_ativos in ativos:
            parsed = resolve_collection(
                index,
                n_ativos=int(n_ativos),
                start_y=int(start_y),
                start_m=int(start_m),
                end_y=int(end_y),
                end_m=int(end_m),
            )
            if parsed is None:
                message = (
                    f"{period_label} | N={n_ativos}: collection ret_excess_acum_pct_* "
                    "não encontrada"
                )
                if allow_missing:
                    if not quiet:
                        print(f"  SKIP {message}", flush=True)
                    rows.append(
                        {
                            "Período": period_label,
                            "N": int(n_ativos),
                            "T": np.nan,
                            "d_bar_%_aa": np.nan,
                            "p_HAC": np.nan,
                            "p_boot_min": np.nan,
                            "p_boot_max": np.nan,
                            "Conclusão": "Ausente",
                            "t_HAC": np.nan,
                            "N_strat": np.nan,
                            "L_base": int(base_lag),
                        }
                    )
                    continue
                raise RuntimeError(message)

            if not quiet:
                print(
                    f"{period_label} | N={n_ativos:>2} | {parsed.collection} "
                    f"vs ret_excess_acum_pct_{bova_suf}",
                    flush=True,
                )
            try:
                dbar, n_strat = load_dbar_series(
                    db,
                    db_bova11,
                    carteiras_suffix=parsed.suffix,
                    bova_suffix=bova_suf,
                )
                row = compute_compact_row(
                    dbar,
                    period_label=period_label,
                    n_ativos=n_ativos,
                    n_strat=n_strat,
                    hac_lags=hac_lags,
                    avg_blocks=avg_blocks,
                    base_lag=base_lag,
                    boot_b=boot_b,
                    boot_seed=boot_seed,
                    alpha=alpha,
                )
            except Exception as exc:
                if allow_missing:
                    if not quiet:
                        print(f"  SKIP {parsed.collection}: {exc}", flush=True)
                    rows.append(
                        {
                            "Período": period_label,
                            "N": int(n_ativos),
                            "T": np.nan,
                            "d_bar_%_aa": np.nan,
                            "p_HAC": np.nan,
                            "p_boot_min": np.nan,
                            "p_boot_max": np.nan,
                            "Conclusão": "Erro",
                            "t_HAC": np.nan,
                            "N_strat": np.nan,
                            "L_base": int(base_lag),
                        }
                    )
                    continue
                raise
            rows.append(row)

    table = pd.DataFrame(rows)
    if table.empty:
        return table
    table["_period_start"] = (
        table["Período"].astype(str).str.split("-", n=1).str[0].astype(int)
    )
    table = table.sort_values(["_period_start", "N"], kind="mergesort").reset_index(
        drop=True
    )
    return table.drop(columns=["_period_start"])


def _fmt_num(value: object, ndigits: int = 4) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    return f"{float(value):.{ndigits}f}"


def _fmt_pct(value: object, ndigits: int = 2) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    return f"{float(value):.{ndigits}f}"


def _fmt_p_range(p_min: object, p_max: object) -> str:
    if (
        p_min is None
        or p_max is None
        or (isinstance(p_min, float) and np.isnan(p_min))
        or (isinstance(p_max, float) and np.isnan(p_max))
    ):
        return ""
    return f"[{_fmt_num(p_min, 4)}; {_fmt_num(p_max, 4)}]"


def display_frame(table: pd.DataFrame) -> pd.DataFrame:
    out_rows: List[Dict[str, object]] = []
    for _, row in table.iterrows():
        out_rows.append(
            {
                "Período": row["Período"],
                "N": int(row["N"]) if pd.notna(row["N"]) else "",
                "T": int(row["T"]) if pd.notna(row["T"]) else "",
                r"$\bar{d}$ (% a.a.)": _fmt_pct(row["d_bar_%_aa"], 2),
                r"$p_{\mathrm{HAC}}$": _fmt_num(row["p_HAC"], 4),
                r"Faixa $p_{\mathrm{boot}}$": _fmt_p_range(
                    row["p_boot_min"], row["p_boot_max"]
                ),
                "Conclusão": row["Conclusão"],
            }
        )
    return pd.DataFrame(out_rows)


def write_latex(
    table: pd.DataFrame,
    path: Path,
    *,
    title: str,
    label: str,
    base_lag: int,
    hac_lags: Sequence[int],
    avg_blocks: Sequence[int],
    alpha: float,
    tcost_bps: float,
    ir: bool,
    universo_tag: str,
    boot_b: int = DEFAULT_BOOT_B,
    rebalanceamento: str = "com",
    universo_legenda: Optional[str] = None,
) -> None:
    display = display_frame(table)
    lines: List[str] = [
        "% Gerado por mestrado_tabela_hac_bootstrap_compacta.py",
        "% Requer: \\usepackage{booktabs}",
        "\\begin{table}[htbp]",
        "\\centering",
        f"\\caption{{{title}}}",
        f"\\label{{{label}}}",
        "\\footnotesize",
        "\\begin{tabular}{@{}lcrrllc@{}}",
        "\\toprule",
        "Período & $N$ & $T$ & "
        r"$\bar{d}$ (\% a.a.) & $p_{\mathrm{HAC}}$ & "
        r"Faixa $p_{\mathrm{boot}}$ & Conclusão \\",
        "\\midrule",
    ]

    prev_period = None
    for _, row in display.iterrows():
        period = str(row["Período"])
        if prev_period is not None and period != prev_period:
            lines.append("\\midrule")
        prev_period = period
        lines.append(
            f"{period} & {row['N']} & {row['T']} & "
            f"{row[r'$\bar{d}$ (% a.a.)']} & {row[r'$p_{\mathrm{HAC}}$']} & "
            f"{row[r'Faixa $p_{\mathrm{boot}}$']} & {row['Conclusão']} \\\\"
        )

    ir_txt = "imposto de renda de 15\\%" if ir else "sem IR"
    reb_txt = rebalanceamento_legenda_text(rebalanceamento, tcost_bps=tcost_bps)
    if rebalanceamento == "com":
        reb_txt = reb_txt.replace("Rebalanceamento", "rebalanceamento", 1)
    if universo_legenda is None:
        universo_legenda = RODAPE_UNIVERSO.get(
            universo_tag,
            universo_tag.replace("_", r"\_"),
        )
    lags_txt = ", ".join(str(int(x)) for x in hac_lags)
    blocks_txt = ", ".join(str(int(x)) for x in avg_blocks)
    boot_b_txt = f"{boot_b:,}".replace(",", ".")
    fonte = (
        r"\tabfonte{Fonte: Elaboração própria. Diferencial mensal médio "
        r"$\bar{d}_t=\overline{r}^{1/N}_t-r^{\mathrm{Ibov}}_t$. "
        f"$p_{{\\mathrm{{HAC}}}}$ com $L={base_lag}$. "
        r"Faixa $p_{\mathrm{boot}}$: mínimo e máximo no grid de lags "
        f"$\\{{{lags_txt}\\}}$ e blocos $\\{{{blocks_txt}\\}}$ "
        f"({boot_b_txt} reamostragens do \\emph{{stationary bootstrap}}). "
        f"Conclusão a $\\alpha={alpha:g}$: "
        r"Rejeita $H_0$ se $p_{\mathrm{HAC}}<\alpha$ e "
        r"$\max p_{\mathrm{boot}}<\alpha$; Parcial se "
        r"$p_{\mathrm{HAC}}<\alpha$ e a faixa de $p_{\mathrm{boot}}$ "
        r"cruza $\alpha$. "
        f"Universo {universo_legenda}, "
        f"{reb_txt}, {ir_txt}.}}"
    )
    lines.extend(
        [
            "\\bottomrule",
            "\\end{tabular}",
            fonte,
            "\\end{table}",
            "",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def main(argv: Optional[Sequence[str]] = None) -> Path:
    args = parse_args(argv)
    rebalance = args.rebalanceamento == "com"
    ir_tag = "ir" if args.ir == "sim" else "noir"
    tcost_bps = int(round(float(args.tcost_bps)))
    ativos = tuple(args.ativos) if args.ativos is not None else DEFAULT_ATIVOS
    period_windows = period_windows_from_args(
        args.periodos,
        start_m=args.start_m,
        end_m=args.end_m,
        end_y=args.end_y,
    )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=15000)

    try:
        db = client[args.db_name]
        db_bova11 = client[args.db_name_bova11]
        all_collections = discover_excess_collections(db)

        if args.list_collections:
            filtered = filter_excess_for_args(all_collections, args)
            print_inventory(
                filtered,
                db_name=args.db_name,
                filters={
                    "engine": args.engine,
                    "rebalanceamento": args.rebalanceamento,
                    "universo-tag": args.universo_tag or "(qualquer)",
                    "exclude-universo-tag": sorted(_resolve_exclude_universo_tags(args)),
                    "tcost-bps": tcost_bps,
                    "ir": args.ir,
                },
            )
            print(
                "\n(Inventário filtrado — remova --list-collections para gerar a tabela.)",
                flush=True,
            )
            return args.output_dir

        filtered = filter_excess_for_args(all_collections, args)
        if not filtered:
            # Ajuda o usuário: mostra o que o filtro esperaria como sufixo.
            exemplo = liquidez_suffix(
                n_ativos=ativos[0],
                start_y=period_windows[0][1],
                start_m=period_windows[0][2],
                end_y=period_windows[0][3],
                end_m=period_windows[0][4],
                rebalance=rebalance,
                rebalance_freq=args.rebalance_freq,
                tcost_bps=tcost_bps,
                apply_stock_ir=(ir_tag == "ir"),
                universo_tag=args.universo_tag,
                sem_reb_tag=args.sem_reb_tag,
            )
            engine_suf = "_v41" if str(args.engine).lower() == "v41" else ""
            raise RuntimeError(
                "Nenhuma collection ret_excess_acum_pct_* compatível com o filtro. "
                f"Exemplo esperado: ret_excess_acum_pct_{exemplo}{engine_suf}"
            )

        if not args.quiet:
            print(
                f"Filtro: engine={args.engine}, universo={args.universo_tag!r}, "
                f"tcost={tcost_bps} bps, "
                f"IR={ir_tag}, reb={args.rebalanceamento}/{args.rebalance_freq}",
                flush=True,
            )
            print(f"Collections elegíveis: {len(filtered)}", flush=True)
            print(
                f"Grid bootstrap: lags={list(args.hac_lags)}, "
                f"blocos={list(args.avg_blocks)}, B={args.boot_b}, "
                f"L_base={args.base_lag}",
                flush=True,
            )

        table = build_compact_table(
            db,
            db_bova11,
            index=filtered,
            ativos=ativos,
            period_windows=period_windows,
            hac_lags=args.hac_lags,
            avg_blocks=args.avg_blocks,
            base_lag=args.base_lag,
            boot_b=args.boot_b,
            boot_seed=args.boot_seed,
            alpha=args.alpha,
            allow_missing=args.allow_missing,
            quiet=args.quiet,
        )
    finally:
        client.close()

    if table.empty:
        raise RuntimeError("Nenhuma linha gerada.")

    export_stem = build_output_stem(
        args.stem,
        rebalanceamento=args.rebalanceamento,
    )
    csv_path = args.output_dir / f"{export_stem}.csv"
    tex_path = args.output_dir / f"{export_stem}.tex"
    from mestrado_resultados_simulador_pessoa_investidora_v6 import (  # noqa: E402
        hac_temporal_caption,
    )

    export_title = hac_temporal_caption(
        args.title,
        args.rebalanceamento,
        default_title=DEFAULT_TITLE,
    )
    export_label = (
        args.label
        if args.label != DEFAULT_LABEL
        else f"{args.label}_{'com' if args.rebalanceamento == 'com' else 'sem'}_reb"
    )
    table.to_csv(csv_path, index=False, encoding="utf-8-sig")
    write_latex(
        table,
        tex_path,
        title=export_title,
        label=export_label,
        base_lag=args.base_lag,
        hac_lags=args.hac_lags,
        avg_blocks=args.avg_blocks,
        alpha=args.alpha,
        tcost_bps=tcost_bps,
        ir=(ir_tag == "ir"),
        universo_tag=args.universo_tag,
        boot_b=args.boot_b,
        rebalanceamento=args.rebalanceamento,
    )

    if not args.quiet:
        print("\nTabela compacta:", flush=True)
        print(display_frame(table).to_string(index=False), flush=True)
        print(f"\nCSV:   {csv_path}", flush=True)
        print(f"LaTeX: {tex_path}", flush=True)

    return tex_path


if __name__ == "__main__":
    main()
