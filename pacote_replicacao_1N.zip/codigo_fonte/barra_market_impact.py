"""Market impact BARRA (square-root / Torre–Ferrari) — helpers compartilhados.

Proxy:
    c_unit = eta * sigma * sqrt(|q| / ADV)
    cost_brl = c_unit * |q|

Usado por ``backtest_carteiras_individuais_retornos_v4`` e
``run_sensibilidade_barra_pf``.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd

from ticker_continuacao import padronizar_ticker

ADV_FLOOR_BRL = 1_000_000.0
VOL_WINDOW = 21
EPS = 1e-12


def volume_cache_path(out_dir: Path) -> Path:
    return Path(out_dir) / "cache" / "volume_brl.pkl"


def load_volume_brl(volume_xlsx: Path, cache_path: Path) -> pd.DataFrame:
    """Painel Date x ticker em BRL (Economatica milhares * 1000).

    Colunas padronizadas com ``padronizar_ticker``; duplicatas (ex. AXIA3/ELET3)
    agregadas por max dia a dia para alinhar ao painel de preços.
    """
    cache_path = Path(cache_path)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    if cache_path.exists():
        return pd.read_pickle(cache_path)
    df = pd.read_excel(volume_xlsx)
    df = df.rename(columns={df.columns[0]: "Date"})
    df["Date"] = pd.to_datetime(df["Date"])
    tickers = [c for c in df.columns if c != "Date"]
    for c in tickers:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df[tickers] = df[tickers] * 1000.0
    df = df.sort_values("Date").set_index("Date")

    mapped: Dict[str, pd.Series] = {}
    for c in tickers:
        name = padronizar_ticker(str(c))
        series = df[c]
        if name in mapped:
            mapped[name] = mapped[name].combine(series, func=np.fmax)
        else:
            mapped[name] = series
    out = pd.DataFrame(mapped).sort_index()
    out.to_pickle(cache_path)
    return out


def build_sigma_adv_panels(
    prices_wide: pd.DataFrame,
    volume_brl: pd.DataFrame,
    *,
    window: int = VOL_WINDOW,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """sigma: std retornos diarios janela window terminando em t-1.
    ADV: media volume financeiro janela window terminando em t-1.
    """
    px = prices_wide.sort_index()
    rets = px.pct_change()
    sigma = rets.rolling(window=window, min_periods=max(5, window // 3)).std().shift(1)
    vol = volume_brl.reindex(px.index).reindex(columns=px.columns)
    adv = vol.rolling(window=window, min_periods=max(5, window // 3)).mean().shift(1)
    return sigma, adv


def prices_df_to_wide(df_prices: pd.DataFrame) -> pd.DataFrame:
    if "Date" not in df_prices.columns:
        raise ValueError("df_prices precisa ter coluna Date")
    px = df_prices.copy()
    px["Date"] = pd.to_datetime(px["Date"])
    px = px.sort_values("Date").set_index("Date")
    return px.apply(pd.to_numeric, errors="coerce").sort_index()


def barra_unit_cost(
    sigma: float,
    adv: float,
    q: float,
    *,
    eta: float,
    adv_floor: float = ADV_FLOOR_BRL,
) -> float:
    """Custo unitario BARRA (fracao do notional)."""
    if q <= EPS:
        return 0.0
    sig = float(sigma) if np.isfinite(sigma) and sigma >= 0 else 0.0
    adv_i = float(adv) if np.isfinite(adv) and adv > 0 else float(adv_floor)
    if adv_i <= 0:
        return 0.0
    return float(eta) * sig * float(np.sqrt(q / adv_i))


def barra_unit_bps(
    *,
    sigma: float,
    adv: float,
    q: float,
    eta: float = 1.0,
    adv_floor: float = ADV_FLOOR_BRL,
) -> float:
    """Custo unitario BARRA em bps do notional."""
    if q <= 0:
        return float("nan")
    adv_i = float(adv) if np.isfinite(adv) and adv > 0 else float(adv_floor)
    if adv_i <= 0:
        return float("nan")
    unit = barra_unit_cost(sigma, adv_i, q, eta=eta, adv_floor=adv_floor)
    return float(10000.0 * unit)


def portfolio_barra_cost(
    sig_row: np.ndarray,
    adv_row: np.ndarray,
    q: np.ndarray,
    live: np.ndarray,
    *,
    eta: float,
    adv_floor: float = ADV_FLOOR_BRL,
) -> Tuple[float, float]:
    """Custo BARRA agregado da carteira.

    Returns
    -------
    cost_brl :
        Σ eta * sigma * sqrt(q/ADV) * q  (com eta)
    raw_cost_brl_eta1 :
        idem com eta=1 (para calibracao)
    """
    sig = np.asarray(sig_row, dtype=float).copy()
    adv = np.asarray(adv_row, dtype=float).copy()
    q_arr = np.asarray(q, dtype=float)
    live_m = np.asarray(live, dtype=bool)

    live_sig = sig[live_m & np.isfinite(sig) & (sig >= 0)]
    med_sig = float(np.nanmedian(live_sig)) if live_sig.size else 0.0
    if not np.isfinite(med_sig):
        med_sig = 0.0
    sig = np.where(np.isfinite(sig), sig, med_sig)
    sig = np.where(sig < 0, 0.0, sig)
    adv = np.where(np.isfinite(adv) & (adv > 0), adv, float(adv_floor))

    mask = live_m & (q_arr > EPS)
    c_unit = np.zeros(q_arr.shape[0], dtype=float)
    raw_unit = np.zeros(q_arr.shape[0], dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        c_unit[mask] = float(eta) * sig[mask] * np.sqrt(q_arr[mask] / adv[mask])
        raw_unit[mask] = sig[mask] * np.sqrt(q_arr[mask] / adv[mask])
    c_unit = np.where(np.isfinite(c_unit), c_unit, 0.0)
    raw_unit = np.where(np.isfinite(raw_unit), raw_unit, 0.0)
    cost = float(np.nansum(c_unit * q_arr))
    raw_cost = float(np.nansum(raw_unit * q_arr))
    return cost, raw_cost


def load_eta_from_json(path: Path, eta_override: Optional[float] = None) -> float:
    """Le ``eta`` de calibration_eta.json; ``eta_override`` tem prioridade."""
    if eta_override is not None:
        return float(eta_override)
    import json

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Falta {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if "eta" not in payload:
        raise KeyError(f"{path} nao contem chave 'eta'")
    return float(payload["eta"])
