"""Regras temporais de ticker na formação do universo de liquidez.

1. Exige primeira cotação <= fim do mês de formação.
2. Aplica o mapa reverso de ``CONTINUACAO_EXPLICITA`` (ex.: BBAS* -> BNCA3 antes do IPO).
3. Gera auditoria de anacronismos e remapeamentos.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

import pandas as pd

from ticker_continuacao import CONTINUACAO_EXPLICITA, company_key, padronizar_ticker

# Datas oficiais de conversão quando a Economática retroage o sucessor (ex.: BBAS desde 2000).
CONVERSAO_OFICIAL: Dict[Tuple[str, str], str] = {
    ("BNCA3", "BBAS3"): "2004-04-19",
}


@dataclass(frozen=True)
class PriceBounds:
    primeira_cotacao: pd.Timestamp
    ultima_cotacao: pd.Timestamp
    no_painel: bool


def formation_month_end(year: int, month: int) -> pd.Timestamp:
    return pd.Timestamp(year=year, month=month, day=1) + pd.offsets.MonthEnd(0)


def build_successor_to_predecessors() -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    for old, new in CONTINUACAO_EXPLICITA.items():
        old_u = padronizar_ticker(old)
        new_u = padronizar_ticker(new)
        out.setdefault(new_u, [])
        if old_u not in out[new_u]:
            out[new_u].append(old_u)
    for preds in out.values():
        preds.sort()
    return out


def canonical_successors_by_company() -> Dict[str, str]:
    """Sucessor canônico por empresa (prefixo de quatro letras)."""
    succs = sorted({padronizar_ticker(v) for v in CONTINUACAO_EXPLICITA.values()})
    out: Dict[str, str] = {}
    for succ in succs:
        key = company_key(succ)
        out.setdefault(key, succ)
    return out


def expand_tickers_for_bounds(tickers: Iterable[str]) -> List[str]:
    needed = {padronizar_ticker(t) for t in tickers}
    for old, new in CONTINUACAO_EXPLICITA.items():
        needed.add(padronizar_ticker(old))
        needed.add(padronizar_ticker(new))
    return sorted(needed)


def load_price_bounds(
    prices_path,
    tickers: Iterable[str],
    *,
    sample_end: Optional[str] = None,
) -> Dict[str, PriceBounds]:
    """Primeira e última cotação para os tickers solicitados (+ mapa de continuação)."""
    from pathlib import Path

    path = Path(prices_path)
    header = pd.read_csv(path, nrows=0)
    date_col = "Date" if "Date" in header.columns else "Data"
    wanted = expand_tickers_for_bounds(tickers)
    cols = [date_col] + [t for t in wanted if t in header.columns]
    prices = pd.read_csv(path, usecols=cols, parse_dates=[date_col])
    prices = prices.rename(columns={date_col: "date"}).set_index("date").sort_index()
    if sample_end:
        prices = prices.loc[: pd.Timestamp(sample_end)]

    out: Dict[str, PriceBounds] = {}
    for t in wanted:
        if t not in prices.columns:
            out[t] = PriceBounds(pd.NaT, pd.NaT, False)
            continue
        s = pd.to_numeric(prices[t], errors="coerce").dropna()
        if s.empty:
            out[t] = PriceBounds(pd.NaT, pd.NaT, True)
        else:
            out[t] = PriceBounds(
                pd.Timestamp(s.index.min()),
                pd.Timestamp(s.index.max()),
                True,
            )
    return out


def _listed_at(bounds: Dict[str, PriceBounds], ticker: str, as_of: pd.Timestamp) -> bool:
    b = bounds.get(padronizar_ticker(ticker))
    if b is None or not b.no_painel or pd.isna(b.primeira_cotacao):
        return False
    return b.primeira_cotacao <= as_of


def conversion_effective_date(
    predecessor: str,
    successor: str,
    bounds: Dict[str, PriceBounds],
) -> pd.Timestamp:
    pred = padronizar_ticker(predecessor)
    succ = padronizar_ticker(successor)
    official = CONVERSAO_OFICIAL.get((pred, succ))
    if official:
        return pd.Timestamp(official)

    pred_b = bounds.get(pred)
    succ_b = bounds.get(succ)
    pred_first = pred_b.primeira_cotacao if pred_b else pd.NaT
    succ_first = succ_b.primeira_cotacao if succ_b else pd.NaT

    if pd.notna(pred_first) and pd.notna(succ_first):
        if succ_first < pred_first:
            # Economática retroage o sucessor: sem data oficial, usa o início do predecessor.
            return pd.Timestamp(pred_first)
        return pd.Timestamp(succ_first)
    if pd.notna(succ_first):
        return pd.Timestamp(succ_first)
    if pd.notna(pred_first):
        return pd.Timestamp(pred_first)
    return pd.Timestamp.max


def _retrofit_detected(
    predecessor: str,
    successor: str,
    bounds: Dict[str, PriceBounds],
) -> bool:
    pred = bounds.get(padronizar_ticker(predecessor))
    succ = bounds.get(padronizar_ticker(successor))
    if pred is None or succ is None:
        return False
    if pd.isna(pred.primeira_cotacao) or pd.isna(succ.primeira_cotacao):
        return False
    return succ.primeira_cotacao < pred.primeira_cotacao


def resolve_ticker_for_formation(
    ticker: str,
    *,
    formation_end: pd.Timestamp,
    bounds: Dict[str, PriceBounds],
    successor_to_predecessors: Dict[str, List[str]],
    canonical_by_company: Dict[str, str],
) -> Tuple[Optional[str], str, Dict[str, object]]:
    """Resolve o ticker vigente na data de formação."""
    original = padronizar_ticker(ticker)
    meta: Dict[str, object] = {
        "predecessor": "",
        "sucessor_canonico": "",
        "conversao_efetiva": pd.NaT,
        "retrofit_economatica": False,
    }

    orig_b = bounds.get(original)
    primeira = orig_b.primeira_cotacao if orig_b else pd.NaT
    ultima = orig_b.ultima_cotacao if orig_b else pd.NaT
    meta["primeira_cotacao"] = primeira
    meta["ultima_cotacao"] = ultima

    if orig_b is None or not orig_b.no_painel:
        return None, "excluido_ausente_no_painel", meta
    if pd.isna(primeira) or primeira > formation_end:
        return None, "excluido_lista_futura", meta

    empresa = company_key(original)
    canonical = canonical_by_company.get(empresa, "")
    meta["sucessor_canonico"] = canonical

    successors_to_check: List[str] = []
    if original in successor_to_predecessors:
        successors_to_check.append(original)
    if canonical and canonical != original and canonical not in successors_to_check:
        successors_to_check.append(canonical)

    # Mesma empresa com sucessor explícito (ex.: BBAS4 quando o mapa aponta para BBAS3).
    if not successors_to_check and canonical and company_key(canonical) == empresa:
        successors_to_check.append(canonical)

    for successor in successors_to_check:
        for predecessor in successor_to_predecessors.get(successor, []):
            conv = conversion_effective_date(predecessor, successor, bounds)
            meta["predecessor"] = predecessor
            meta["conversao_efetiva"] = conv
            meta["retrofit_economatica"] = _retrofit_detected(predecessor, successor, bounds)
            if formation_end < conv:
                if _listed_at(bounds, predecessor, formation_end):
                    return (
                        padronizar_ticker(predecessor),
                        f"remapeado_{predecessor}_antes_{successor}",
                        meta,
                    )
                if canonical and _listed_at(bounds, canonical, formation_end):
                    return (
                        padronizar_ticker(canonical),
                        f"sucessor_canonico_{canonical}_predecessor_inativo",
                        meta,
                    )
                return None, f"excluido_predecessor_{predecessor}_inativo", meta

    if canonical and original != canonical and company_key(original) == company_key(canonical):
        if _listed_at(bounds, canonical, formation_end):
            return (
                padronizar_ticker(canonical),
                f"consolidado_classe_{canonical}",
                meta,
            )

    return original, "ok", meta


def apply_formation_ticker_rules(
    universo: pd.DataFrame,
    *,
    year: int,
    month: int,
    bounds: Dict[str, PriceBounds],
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Aplica regras temporais e devolve (universo ajustado, auditoria)."""
    if universo.empty:
        return universo.copy(), pd.DataFrame()

    formation_end = formation_month_end(year, month)
    successor_to_predecessors = build_successor_to_predecessors()
    canonical_by_company = canonical_successors_by_company()

    audit_rows: List[dict] = []
    resolved_rows: List[dict] = []

    for row in universo.to_dict(orient="records"):
        ticker_in = str(row.get("ticker", "")).strip().upper()
        resolved, motivo, meta = resolve_ticker_for_formation(
            ticker_in,
            formation_end=formation_end,
            bounds=bounds,
            successor_to_predecessors=successor_to_predecessors,
            canonical_by_company=canonical_by_company,
        )
        audit_rows.append(
            {
                "ticker_entrada": ticker_in,
                "ticker_resolvido": resolved or "",
                "empresa": company_key(ticker_in),
                "formacao_ano": year,
                "formacao_mes": month,
                "primeira_cotacao": meta.get("primeira_cotacao", pd.NaT),
                "ultima_cotacao": meta.get("ultima_cotacao", pd.NaT),
                "predecessor": meta.get("predecessor", ""),
                "sucessor_canonico": meta.get("sucessor_canonico", ""),
                "conversao_efetiva": meta.get("conversao_efetiva", pd.NaT),
                "retrofit_economatica": bool(meta.get("retrofit_economatica", False)),
                "motivo": motivo,
                "mantido": resolved is not None,
            }
        )
        if resolved is None:
            continue
        new_row = dict(row)
        new_row["ticker"] = resolved
        new_row["ticker_origem"] = ticker_in
        if "empresa" in new_row:
            new_row["empresa"] = company_key(resolved)
        resolved_rows.append(new_row)

    audit = pd.DataFrame(audit_rows)
    if not resolved_rows:
        empty = universo.iloc[0:0].copy()
        return empty, audit

    out = pd.DataFrame(resolved_rows)
    sort_cols = [c for c in ("adv_mil_reais", "ticker") if c in out.columns]
    # Mantém o papel com maior ADV quando o remapeamento colapsa tickers.
    if sort_cols:
        out = out.sort_values(sort_cols, ascending=[False, True])
    out = out.drop_duplicates(subset=["ticker"], keep="first").reset_index(drop=True)
    return out, audit


def summarize_audit(audit: pd.DataFrame) -> str:
    if audit.empty:
        return "auditoria vazia"
    n_in = len(audit)
    n_out = int(audit["mantido"].sum())
    n_remap = int(audit["motivo"].astype(str).str.startswith("remapeado_").sum())
    n_changed = int(
        (
            audit["mantido"]
            & (audit["ticker_entrada"].astype(str) != audit["ticker_resolvido"].astype(str))
        ).sum()
    )
    n_retro = int(audit["retrofit_economatica"].sum())
    n_excl = n_in - n_out
    return (
        f"auditoria formação: {n_in} entradas -> {n_out} mantidos "
        f"({n_changed} alterados, {n_remap} remapeados por predecessor, "
        f"{n_excl} excluídos, {n_retro} com retrofit Economática)"
    )
