#!/usr/bin/env python3
"""Gera métricas do benchmark Ibovespa (proxy BOVA11) no MongoDB.

Roda buy-and-hold sobre a série de retorno total do índice (coluna IBOV de
``diario_BOVA11_IBOV.csv``), com RF NEFIN para métricas em excesso, e grava:

- ``aux_metrics_BOVA11_{YYYY}_{YYYY}``
- ``ret_acum_pct_BOVA11_{YYYY}_{YYYY}``
- ``ret_excess_acum_pct_BOVA11_{YYYY}_{YYYY}``
- ``res_BOVA11_{YYYY}_{YYYY}`` (res.display)

Banco default: ``Backtest_Mestrado_PF_ExcessAjustado`` — o mesmo lido por
``mestrado_resultados_simulador_pessoa_investidora_v6.py``.

Exemplo::

    python codigo_fonte/gerar_benchmark_ibovespa_mongo.py \\
      --periodos 2001_2025 2006_2025 2011_2025

    python codigo_fonte/gerar_benchmark_ibovespa_mongo.py \\
      --periodos 2001_2025 --dry-run
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import pandas as pd

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

from backtest_carteiras_individuais_retornos_v2 import (  # noqa: E402
    run_bt_backtest_ew_buyhold,
    save_res_display_only_to_mongo,
    save_series_in_collection,
    upsert_aux_metrics,
)

DEFAULT_MONGO_URI = "mongodb://172.23.224.1:27017/"
DEFAULT_DB = "Backtest_Mestrado_PF_ExcessAjustado"
DEFAULT_PRICES = REPO_ROOT / "diario_BOVA11_IBOV.csv"
DEFAULT_RF = REPO_ROOT / "nefin_RF.csv"
DEFAULT_PREFIX = "BOVA11"
DEFAULT_TICKER = "BOVA11"
DEFAULT_PRICE_COL = "IBOV"
DEFAULT_PERIODS = ("2001_2025", "2006_2025", "2011_2025")
DEFAULT_START_M = 7
DEFAULT_END_M = 10
DEFAULT_CAPITAL = 10_000.0


def parse_period(label: str) -> Tuple[str, int, int]:
    text = str(label).strip().replace("-", "_")
    parts = text.split("_")
    if len(parts) != 2:
        raise ValueError(f"Período inválido {label!r}; use AAAA_AAAA (ex.: 2001_2025).")
    start_y, end_y = int(parts[0]), int(parts[1])
    if start_y > end_y:
        raise ValueError(f"Período invertido: {label!r}")
    return f"{start_y}_{end_y}", start_y, end_y


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    p.add_argument("--db-name", default=DEFAULT_DB)
    p.add_argument(
        "--prices",
        type=Path,
        default=DEFAULT_PRICES,
        help=f"CSV diário Date,BOVA11,IBOV (default: {DEFAULT_PRICES.name})",
    )
    p.add_argument("--rf", type=Path, default=DEFAULT_RF)
    p.add_argument(
        "--price-col",
        default=DEFAULT_PRICE_COL,
        choices=("IBOV", "BOVA11"),
        help="Coluna de preço/nível do CSV (default: IBOV = retorno total do índice)",
    )
    p.add_argument(
        "--ticker",
        default=DEFAULT_TICKER,
        help="Nome do ativo na estratégia / strategy Mongo (default: BOVA11)",
    )
    p.add_argument("--prefix", default=DEFAULT_PREFIX, help="Prefixo das collections")
    p.add_argument(
        "--periodos",
        nargs="+",
        default=list(DEFAULT_PERIODS),
        help="Janelas AAAA_AAAA (default: 2001_2025 2006_2025 2011_2025)",
    )
    p.add_argument("--start-m", type=int, default=DEFAULT_START_M)
    p.add_argument("--end-m", type=int, default=DEFAULT_END_M)
    p.add_argument(
        "--tcost-bps",
        type=float,
        default=0.0,
        help="Custo de transação em bps (default: 0 — índice teórico)",
    )
    p.add_argument("--capital", type=float, default=DEFAULT_CAPITAL)
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Calcula métricas e imprime; não grava no Mongo",
    )
    p.add_argument("--quiet", action="store_true")
    return p.parse_args(list(argv) if argv is not None else None)


def load_index_prices(path: Path, *, price_col: str, ticker: str) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"CSV de preços ausente: {path}")
    raw = pd.read_csv(path)
    if "Date" not in raw.columns:
        raise ValueError(f"{path} precisa da coluna Date. Colunas: {list(raw.columns)}")
    if price_col not in raw.columns:
        raise ValueError(
            f"{path} não tem coluna {price_col!r}. Colunas: {list(raw.columns)}"
        )
    out = pd.DataFrame(
        {
            "Date": pd.to_datetime(raw["Date"], dayfirst=True, errors="coerce"),
            ticker: pd.to_numeric(raw[price_col], errors="coerce"),
        }
    )
    out = out.dropna(subset=["Date"]).sort_values("Date")
    # Remove níveis nulos/zero no início da série
    out = out[out[ticker].notna() & (out[ticker] > 0)].reset_index(drop=True)
    if out.empty:
        raise ValueError(f"Nenhum preço válido em {path} ({price_col}).")
    return out


def load_rf(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"CSV de RF ausente: {path}")
    return pd.read_csv(path)


def end_date_str(end_y: int, end_m: int) -> str:
    # Último dia civil do mês; o backtest corta pelo último pregão ≤ end.
    last_day = pd.Timestamp(year=end_y, month=end_m, day=1) + pd.offsets.MonthEnd(0)
    return last_day.strftime("%Y-%m-%d")


def collection_names(prefix: str, period_tag: str) -> Dict[str, str]:
    suffix = f"{prefix}_{period_tag}"
    return {
        "suffix": suffix,
        "aux": f"aux_metrics_{suffix}",
        "ret_acum": f"ret_acum_pct_{suffix}",
        "ret_excess": f"ret_excess_acum_pct_{suffix}",
        "res": f"res_{suffix}",
    }


def run_one_period(
    *,
    args: argparse.Namespace,
    df_prices: pd.DataFrame,
    rf_df: pd.DataFrame,
    period_tag: str,
    start_y: int,
    end_y: int,
) -> Dict[str, object]:
    cols = collection_names(args.prefix, period_tag)
    end_s = end_date_str(end_y, args.end_m)
    tcost = float(args.tcost_bps) / 10_000.0
    strat_name = str(args.ticker)

    res, aux = run_bt_backtest_ew_buyhold(
        df_prices=df_prices,
        tickers=[strat_name],
        tcost=tcost,
        start_y=int(start_y),
        start_m=int(args.start_m),
        end_date_str=end_s,
        initial_capital=float(args.capital),
        strat_name=strat_name,
        rf_df=rf_df,
        rf_date_col="DATE",
        rf_col="RF",
        ignore_initial_trade_for_turnover=True,
    )

    summary = {
        "period": period_tag,
        "collections": cols,
        "cagr": aux.get("cagr"),
        "total_return": aux.get("total_return"),
        "total_excess_return": aux.get("total_excess_return"),
        "sharpe_excess": aux.get("sharpe_excess"),
        "vol_excess_ann": aux.get("vol_excess_ann"),
        "n_days": int(len(res.prices[strat_name].dropna())) if hasattr(res, "prices") else None,
    }

    if not args.quiet:
        print(
            f"\n=== {period_tag} | {args.start_m:02d}/{start_y} → {args.end_m:02d}/{end_y} ===",
            flush=True,
        )
        print(
            f"  Sharpe excess={summary['sharpe_excess']:.4f} | "
            f"total_excess={summary['total_excess_return']:.4f} | "
            f"vol_ann={summary['vol_excess_ann']:.4f} | "
            f"CAGR={summary['cagr']:.4f}",
            flush=True,
        )
        print(
            f"  → {args.db_name}.{cols['aux']} | {cols['ret_excess']}",
            flush=True,
        )

    if args.dry_run:
        return summary

    base_name = f"{args.prefix.lower()}_{period_tag}"
    save_res_display_only_to_mongo(
        mongo_uri=args.mongo_uri,
        base_name=base_name,
        res=res,
        db_name=args.db_name,
        col_res=cols["res"],
    )
    upsert_aux_metrics(
        mongo_uri=args.mongo_uri,
        db_name=args.db_name,
        metrics_collection=cols["aux"],
        aux=aux,
        strategy=strat_name,
        extra_fields={
            "tcost": tcost,
            "tcost_bps": float(args.tcost_bps),
            "tickers": [strat_name],
            "price_source": str(args.prices),
            "price_col": str(args.price_col),
            "benchmark": True,
            "start_y": int(start_y),
            "start_m": int(args.start_m),
            "end_y": int(end_y),
            "end_m": int(args.end_m),
            "apply_stock_ir": False,
        },
    )
    n1 = save_series_in_collection(
        mongo_uri=args.mongo_uri,
        db_name=args.db_name,
        series_collection=cols["ret_acum"],
        series=aux.get("retorno_acumulado_pct"),
        strategy=strat_name,
        overwrite_strategy=True,
        monthly_how="last",
        monthly_rule="ME",
    )
    n2 = save_series_in_collection(
        mongo_uri=args.mongo_uri,
        db_name=args.db_name,
        series_collection=cols["ret_excess"],
        series=aux.get("retorno_excesso_acumulado_pct"),
        strategy=strat_name,
        overwrite_strategy=True,
        monthly_how="last",
        monthly_rule="ME",
    )
    if not args.quiet:
        print(f"  gravado: ret_acum={n1} pts | ret_excess={n2} pts", flush=True)
    summary["n_ret_acum"] = n1
    summary["n_ret_excess"] = n2
    return summary


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    if not 1 <= args.start_m <= 12 or not 1 <= args.end_m <= 12:
        raise SystemExit("Mês de início/fim deve estar entre 1 e 12.")

    periods: List[Tuple[str, int, int]] = [parse_period(p) for p in args.periodos]
    df_prices = load_index_prices(
        args.prices, price_col=str(args.price_col), ticker=str(args.ticker)
    )
    rf_df = load_rf(args.rf)

    if not args.quiet:
        print(
            f"Benchmark Ibovespa → Mongo {args.db_name!r} | "
            f"série={args.prices.name}:{args.price_col} → ticker={args.ticker} | "
            f"tcost={args.tcost_bps:g} bps | dry_run={args.dry_run}",
            flush=True,
        )
        print(
            f"Preços: {len(df_prices)} pregões "
            f"({df_prices['Date'].iloc[0].date()} … {df_prices['Date'].iloc[-1].date()})",
            flush=True,
        )

    results = []
    for period_tag, start_y, end_y in periods:
        results.append(
            run_one_period(
                args=args,
                df_prices=df_prices,
                rf_df=rf_df,
                period_tag=period_tag,
                start_y=start_y,
                end_y=end_y,
            )
        )

    if not args.quiet:
        print(f"\nConcluído: {len(results)} período(s).", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
