"""Backtests rolling DGU (2009) — versão local.

Convertido a partir de:
    DGU_2009_General_Backtests_v_2_0.ipynb

Correções em relação ao notebook:
  - Paths relativos ao repositório (execução local no WSL, sem /content)
  - Ledoit–Wolf bootstrap executado e salvo em *_pvalledoitwolf.csv
  - RETURNS_EXCESS como bool (sem vírgula que criava tupla)

Exemplos:
    # Uma base CSV local
    python codigo_fonte/dgu_2009_general_backtests_v2_0.py \\
        --input-file bases_dgu/minha_base.csv \\
        --base-id minha_base

    # Lote de CSVs em pasta
    python codigo_fonte/dgu_2009_general_backtests_v2_0.py \\
        --bases-dir bases_dgu \\
        --output-dir resultados/dgu_backtest
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import re
import shutil
import sys
import traceback
import warnings
from datetime import datetime
from math import erf, isfinite, sqrt
from pathlib import Path
from typing import Dict, Optional

import numpy as np
import pandas as pd

warnings.simplefilter(action="ignore", category=FutureWarning)

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
DEFAULT_DGU_MODULE = SCRIPT_DIR / "dgu_backtest_aligned_v2_8_26.py"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "resultados" / "dgu_backtest"
DEFAULT_BASES_DIR = REPO_ROOT / "bases_dgu"
DEFAULT_START = "2011-01-04"
DEFAULT_END = "2025-11-30"
DEFAULT_M = 60
DEFAULT_COST_BPS = 122.0

DRIVE_PASTA_RESULTADOS = "1bi0Y4d3F4FAr4iKc6D7cyLeU8YmLvKB2"
DRIVE_PASTA_BASES = "1LNm8lUEiE4W86bQY0QzmaFgHVfoEgiGg"
DRIVE_PASTA_BASES_ERRO = "1G5LS-qXqg55Or3yfOn2TfAbX4HNHvlmO"
DRIVE_PASTA_BASES_PROCESSADAS = "1rQsnd3R7vPCbtzGOerH_JfEAf4XhXqmn"


def load_dgu_module(path_py: Path):
    path_py = path_py.resolve()
    if not path_py.exists():
        raise FileNotFoundError(f"Módulo DGU não encontrado: {path_py}")
    spec = importlib.util.spec_from_file_location("dgu_backtest", path_py)
    dgu = importlib.util.module_from_spec(spec)
    sys.modules["dgu_backtest"] = dgu
    spec.loader.exec_module(dgu)
    return dgu


def load_base(START: str, END: str, path_panel: Path, sel_cols: list[str]):
    base_data = pd.read_csv(path_panel)
    base_data["DATE"] = (
        pd.to_datetime(base_data["DATE"].astype(str).str.slice(0, 6), format="%Y%m")
        + pd.offsets.MonthEnd(0)
    )
    base_data = base_data.set_index("DATE").sort_index()
    base_data = base_data.loc[START:END]

    rets = base_data[sel_cols].copy()
    rf = base_data["RF"].copy()
    mkt_vm = base_data["MktRF"].copy()
    returns_excess = True
    drop_mkt_from_universe = False
    return rets, rf, mkt_vm, returns_excess, drop_mkt_from_universe


def load_base_df(START: str, END: str, base_data: pd.DataFrame, sel_cols: list[str]):
    base_data = base_data.copy()
    base_data["DATE"] = (
        pd.to_datetime(base_data["DATE"].astype(str).str.slice(0, 6), format="%Y%m")
        + pd.offsets.MonthEnd(0)
    )
    base_data = base_data.set_index("DATE").sort_index()
    base_data = base_data.loc[START:END]

    rets = base_data[sel_cols].copy()
    rf = base_data["RF"].copy()
    mkt_vm = base_data["MktRF"].copy()
    returns_excess = True
    drop_mkt_from_universe = False
    return rets, rf, mkt_vm, returns_excess, drop_mkt_from_universe


def compute_turnover(results):
    ew = results["EW"].turnover.mean(skipna=True)
    df_turn = pd.DataFrame(
        {
            "turnover_abs": {k: results[k].turnover.mean(skipna=True) for k in results.keys()},
            "turnover_rel_to_EW": {
                k: results[k].turnover.mean(skipna=True) / ew for k in results.keys()
            },
        }
    )
    return df_turn.replace([np.inf, -np.inf], np.nan).sort_values(
        "turnover_rel_to_EW", ascending=False
    )


def _ann_factors(freq: str = "M"):
    f = freq.upper()
    if f in ("M", "ME"):
        k = 12
    elif f in ("W", "WEEK"):
        k = 52
    elif f in ("D", "B", "BD"):
        k = 252
    else:
        k = 12
    return k, np.sqrt(k)


def _as_series(x) -> pd.Series:
    if x is None:
        return pd.Series(dtype=float)
    if isinstance(x, pd.Series):
        return x
    try:
        return pd.Series(x)
    except Exception:
        return pd.Series(dtype=float)


def build_summary(
    results: Dict[str, object],
    df_turn: Optional[pd.DataFrame] = None,
    gamma: float = 1.0,
    freq: str = "M",
    as_percent: bool = False,
) -> pd.DataFrame:
    k, sqrt_k = _ann_factors(freq)

    turn_abs_map = {}
    turn_rel_map = {}
    if df_turn is not None and isinstance(df_turn, pd.DataFrame) and not df_turn.empty:
        if "turnover_abs" in df_turn.columns:
            turn_abs_map = df_turn["turnover_abs"].to_dict()
        if "turnover_rel_to_EW" in df_turn.columns:
            turn_rel_map = df_turn["turnover_rel_to_EW"].to_dict()

    rows = []
    for name, res in results.items():
        r = _as_series(getattr(res, "rets_net_excess", None)).dropna()
        if len(r) == 0:
            sr_m = sr_a = ceq_m = ceq_a = np.nan
        else:
            mu = float(r.mean())
            var_m = float(r.var(ddof=1))
            sd = var_m**0.5
            sr_m = np.nan if (sd == 0 or np.isnan(sd)) else (mu / sd)
            sr_a = sr_m * sqrt_k if np.isfinite(sr_m) else np.nan
            ceq_m = mu - 0.5 * gamma * var_m
            ceq_a = k * mu - 0.5 * gamma * (k * var_m)

        t_abs = turn_abs_map.get(name, np.nan)
        t_rel = turn_rel_map.get(name, np.nan)

        if not np.isfinite(t_abs) and hasattr(res, "turnover") and res.turnover is not None:
            ts = _as_series(res.turnover).dropna()
            t_abs = float(ts.mean()) if len(ts) else np.nan
        if (
            not np.isfinite(t_rel)
            and hasattr(res, "turnover_rel_to_EW")
            and res.turnover_rel_to_EW is not None
        ):
            t_rel = float(res.turnover_rel_to_EW)

        row = {
            "Strategy": name,
            "Sharpe (monthly)": sr_m,
            "Sharpe (annual)": sr_a,
            "CEQ (monthly, γ=%.0f)" % gamma: ceq_m,
            "CEQ (annual, γ=%.0f)" % gamma: ceq_a,
            "Avg Turnover (abs.)": t_abs,
            "Turnover / 1/N": t_rel,
            "T (OOS)": int(len(r)) if len(r) else 0,
        }
        if as_percent:
            row["CEQ (monthly, γ=%.0f)" % gamma] *= 100.0
            row["CEQ (annual, γ=%.0f)" % gamma] *= 100.0
        rows.append(row)

    return pd.DataFrame(rows).set_index("Strategy").sort_index()


def serialize_result_object(result_obj):
    serialized_data = {}
    if hasattr(result_obj, "rets_net_excess") and result_obj.rets_net_excess is not None:
        serialized_data["rets_net_excess"] = result_obj.rets_net_excess.rename(index=str).to_dict()
    if hasattr(result_obj, "turnover") and result_obj.turnover is not None:
        serialized_data["turnover"] = result_obj.turnover.rename(index=str).to_dict()
    if hasattr(result_obj, "diag") and result_obj.diag is not None:
        serialized_data["diag"] = result_obj.diag.to_dict(orient="records")
    return serialized_data


def _normcdf(x):
    return 0.5 * (1.0 + erf(x / sqrt(2.0)))


def _as_1d(s):
    return np.asarray(pd.Series(s).dropna().values, float).reshape(-1)


def pval_sharpe_eq_zero(r):
    r = _as_1d(r)
    T = len(r)
    if T < 2:
        return np.nan, np.nan, T
    mu = float(np.mean(r))
    sd = float(np.std(r, ddof=1))
    if not (isfinite(sd) and sd > 0):
        return np.nan, np.nan, T
    sr = mu / sd
    se = sqrt((1.0 + 0.5 * sr * sr) / T)
    z = sr / se
    p = 1.0 - _normcdf(abs(z))
    return sr, p, T


def jk_pvalue_vs_bench(r_bench, r):
    r1 = _as_1d(r_bench)
    r2 = _as_1d(r)
    T = min(len(r1), len(r2))
    if T < 2:
        return np.nan, np.nan, T
    r1, r2 = r1[-T:], r2[-T:]
    mu1, mu2 = float(np.mean(r1)), float(np.mean(r2))
    sd1, sd2 = float(np.std(r1, ddof=1)), float(np.std(r2, ddof=1))
    if not (isfinite(sd1) and sd1 > 0 and isfinite(sd2) and sd2 > 0):
        return np.nan, np.nan, T
    cov12 = float(np.mean((r1 - mu1) * (r2 - mu2)))
    theta = (1.0 / T) * (
        2 * sd1**2 * sd2**2
        - 2 * sd1 * sd2 * cov12
        + 0.5 * (mu1**2) * (sd2**2)
        + 0.5 * (mu2**2) * (sd1**2)
        - (mu1 * mu2 / (sd1 * sd2)) * cov12**2
    )
    if not (isfinite(theta) and theta > 0):
        return np.nan, np.nan, T
    zjk = (sd2 * mu1 - sd1 * mu2) / sqrt(theta)
    pjk = 1.0 - _normcdf(abs(zjk))
    return zjk, pjk, T


def _get_rets_net_excess(obj):
    if hasattr(obj, "rets_net_excess"):
        return getattr(obj, "rets_net_excess")
    return obj["rets_net_excess"]


def ceq_value(r, gamma=1.0):
    r = _as_1d(r)
    if len(r) < 2:
        return np.nan, len(r)
    mu = float(np.mean(r))
    var = float(np.var(r, ddof=1))
    return (mu - 0.5 * gamma * var), len(r)


def ceq_pvalue_vs_bench(r_bench, r, gamma=1.0):
    r1 = _as_1d(r_bench)
    r2 = _as_1d(r)
    T = min(len(r1), len(r2))
    if T < 2:
        return np.nan, np.nan, T
    r1, r2 = r1[-T:], r2[-T:]
    mu1, mu2 = float(np.mean(r1)), float(np.mean(r2))
    C = np.cov(r1, r2, ddof=0)
    var1, var2 = float(C[0, 0]), float(C[1, 1])
    diff_ceq = (mu1 - 0.5 * gamma * var1) - (mu2 - 0.5 * gamma * var2)
    Z = np.zeros((2, 2), float)
    B = 2.0 * np.square(C)
    Omega = np.block([[C, Z], [Z, B]])
    R = np.array([1.0, -1.0, -0.5 * gamma, 0.5 * gamma], float)
    denom2 = float(R @ Omega @ R.T)
    if not (isfinite(denom2) and denom2 > 0.0):
        return np.nan, np.nan, T
    z = (diff_ceq * sqrt(T)) / sqrt(denom2)
    p = 1.0 - _normcdf(abs(z))
    return z, p, T


def to_series(d):
    s = pd.Series(d, dtype="float64")
    s.index = pd.to_datetime(s.index)
    return s.sort_index()


def _as_pd_series(x):
    if x is None:
        return None
    if isinstance(x, pd.Series):
        s = x.copy()
        try:
            s.index = pd.to_datetime(s.index)
        except Exception:
            pass
        return s.sort_index()
    if isinstance(x, dict):
        return to_series(x)
    try:
        return pd.Series(x).astype(float)
    except Exception:
        return None


def _get(res, name, default=None):
    if isinstance(res, dict):
        return res.get(name, default)
    return getattr(res, name, default)


def _turnover_paper_from_weights(
    weights_oos: pd.DataFrame, asset_rets_oos: pd.DataFrame, mode: str = "abssum"
) -> pd.Series:
    if weights_oos is None or asset_rets_oos is None or len(weights_oos) == 0:
        return pd.Series(dtype=float)

    Wt = weights_oos.astype(float)
    R = asset_rets_oos.reindex(index=Wt.index, columns=Wt.columns).astype(float).fillna(0.0)
    den_w = Wt.sum(axis=1)
    if mode == "abssum":
        den_w = den_w.abs()
    Wn = Wt.div(den_w.replace(0, np.nan), axis=0)

    Wlag = Wn.shift(1)
    num = Wlag * (1.0 + R)
    den = num.sum(axis=1)
    if mode == "abssum":
        den = den.abs()
    Wpre = num.div(den.replace(0, np.nan), axis=0)

    I = Wn.index.intersection(Wpre.index)
    return (Wn.loc[I].sub(Wpre.loc[I])).abs().sum(axis=1)


def _pick_rex(res) -> pd.Series | None:
    s = _as_pd_series(_get(res, "rets_net_excess"))
    if isinstance(s, pd.Series) and not s.empty:
        return s
    s = _as_pd_series(_get(res, "rets_excess"))
    if isinstance(s, pd.Series) and not s.empty:
        return s
    return None


def _tau_for(res) -> pd.Series:
    tau = _as_pd_series(_get(res, "turnover_paper"))
    if isinstance(tau, pd.Series) and not tau.empty:
        return tau

    W = _get(res, "weights_oos")
    R = _get(res, "asset_rets_oos")
    if isinstance(W, pd.DataFrame) and isinstance(R, pd.DataFrame) and (not W.empty) and (not R.empty):
        tau = _turnover_paper_from_weights(W, R, mode="abssum")
        if isinstance(tau, pd.Series) and not tau.empty:
            return tau

    tau = _as_pd_series(_get(res, "turnover"))
    if isinstance(tau, pd.Series) and not tau.empty:
        return tau

    rex = _pick_rex(res)
    if isinstance(rex, pd.Series) and not rex.empty:
        return pd.Series(0.0, index=rex.index)
    return pd.Series(dtype=float)


def compute_return_loss_exact_compat(
    results: dict, rf_m: pd.Series | None = None, cost_bps: float = 50.0
):
    c = cost_bps / 1e4
    ew = results["EW"]
    rex_ew = _pick_rex(ew)
    if rex_ew is None:
        raise ValueError("Não consegui recuperar a série de retornos do EW.")

    rex_ew = rex_ew.astype(float).dropna()
    tau_ew = _tau_for(ew).reindex(rex_ew.index).fillna(0.0).astype(float)
    ew_net_excess = (1.0 + rex_ew) * (1.0 - c * tau_ew) - 1.0
    ew_net_excess = ew_net_excess.dropna()

    sd_ew = float(ew_net_excess.std(ddof=1))
    SR_EW = float(ew_net_excess.mean() / sd_ew) if (np.isfinite(sd_ew) and sd_ew > 0) else np.nan
    idx_oos = ew_net_excess.index

    rows = []
    for name, res in results.items():
        rex = _pick_rex(res)
        if rex is None:
            continue
        rex = rex.astype(float)
        tau = _tau_for(res).reindex(rex.index).fillna(0.0).astype(float)
        net_excess = (1.0 + rex) * (1.0 - c * tau) - 1.0
        net_excess = net_excess.reindex(idx_oos).dropna()
        mu = float(net_excess.mean())
        sd = float(net_excess.std(ddof=1))
        rl = (SR_EW * sd - mu) if (np.isfinite(SR_EW) and np.isfinite(sd)) else np.nan
        rows.append([name, len(net_excess), mu, sd, SR_EW, rl, 1e4 * rl])

    cols = [
        "strategy",
        "n_obs",
        "mu_net_excess",
        "sd_net_excess",
        "SR_EW_net_excess",
        "return_loss",
        "return_loss_bps",
    ]
    return (
        pd.DataFrame(rows, columns=cols)
        .set_index("strategy")
        .sort_values("return_loss_bps")
    )


def gerar_pval_sharpe_lw(results, *, M_boot: int = 4999, seed: int = 123) -> pd.DataFrame:
    """Ledoit & Wolf (2008) bootstrap studentizado para Sharpe e diferença vs EW."""

    def _as_clean_series(x):
        s = pd.Series(x).astype(float)
        return s.replace([np.inf, -np.inf], np.nan).dropna()

    def _align_two(a, b):
        a = _as_clean_series(a)
        b = _as_clean_series(b)
        df = pd.concat([a, b], axis=1, join="inner").dropna()
        return df.iloc[:, 0], df.iloc[:, 1]

    def _mu_gamma(r):
        r = np.asarray(r, float)
        mu = float(np.mean(r))
        ga = float(np.mean(r * r))
        return mu, ga

    def _sharpe_from_mu_gamma(mu, ga):
        v = ga - mu * mu
        if not np.isfinite(v) or v <= 0:
            return np.nan
        return mu / np.sqrt(v)

    def _grad_single(mu, ga):
        v = ga - mu * mu
        if not np.isfinite(v) or v <= 0:
            return None
        den = v**1.5
        return np.array([ga / den, -0.5 * mu / den], float)

    def _grad_diff(mu_i, ga_i, mu_n, ga_n):
        v1 = ga_i - mu_i * mu_i
        v2 = ga_n - mu_n * mu_n
        if (not np.isfinite(v1)) or (not np.isfinite(v2)) or (v1 <= 0) or (v2 <= 0):
            return None
        den1 = v1**1.5
        den2 = v2**1.5
        return np.array([ga_i / den1, -ga_n / den2, 0.5 * mu_i / den1, -0.5 * mu_n / den2], float)

    def _qs_kernel(x):
        x = float(x)
        if x == 0.0:
            return 1.0
        ax = abs(x)
        z = 6.0 * np.pi * ax / 5.0
        return (25.0 / (12.0 * np.pi**2 * ax**2)) * (np.sin(z) / z - np.cos(z))

    def _long_run_cov_kernel(y, nlags):
        y = np.asarray(y, float)
        if y.ndim == 1:
            y = y.reshape(-1, 1)
        T, k = y.shape
        nlags = int(max(0, min(nlags, T - 1)))
        ST = float(max(1, nlags + 1))
        S = y.T @ y
        for j in range(1, nlags + 1):
            w = _qs_kernel(j / ST)
            if w == 0:
                continue
            Gj = y[j:].T @ y[:-j]
            S = S + w * (Gj + Gj.T)
        return S / float(T)

    def _hac_psd(y, nlags=None, prewhite=True):
        y = np.asarray(y, float)
        if y.ndim == 1:
            y = y.reshape(-1, 1)
        T, k = y.shape
        if nlags is None:
            nlags = int(np.floor(4 * (T / 100.0) ** (2.0 / 9.0)))
            nlags = max(1, min(nlags, T - 1))
        nlags = int(nlags)

        if prewhite and T >= 3:
            X = y[:-1, :]
            Y = y[1:, :]
            A, *_ = np.linalg.lstsq(X, Y, rcond=None)
            E = Y - X @ A
            Psi_e = _long_run_cov_kernel(E, nlags=min(nlags, E.shape[0] - 1))
            I = np.eye(k)
            try:
                F = np.linalg.pinv(I - A)
                Psi = F @ Psi_e @ F.T
            except Exception:
                Psi = Psi_e
        else:
            Psi = _long_run_cov_kernel(y, nlags=nlags)

        if T > k:
            Psi = (T / float(T - k)) * Psi
        return Psi

    def _cbb_indices(T, b, rng):
        b = int(max(1, b))
        nblocks = int(np.ceil(T / b))
        starts = rng.integers(0, T, size=nblocks)
        idx = np.empty(nblocks * b, dtype=int)
        pos = 0
        for s in starts:
            block = (s + np.arange(b)) % T
            idx[pos : pos + b] = block
            pos += b
        return idx[:T]

    def _se_single(r, nlags=None):
        r = np.asarray(r, float)
        T = len(r)
        mu, ga = _mu_gamma(r)
        g = _grad_single(mu, ga)
        if g is None:
            return np.nan, mu, ga
        y = np.column_stack([r - mu, r * r - ga])
        Psi = _hac_psd(y, nlags=nlags, prewhite=True)
        var = float(g @ Psi @ g)
        if (not np.isfinite(var)) or var <= 0:
            return np.nan, mu, ga
        return np.sqrt(var / T), mu, ga

    def _se_diff(r_i, r_n, nlags=None):
        r_i = np.asarray(r_i, float)
        r_n = np.asarray(r_n, float)
        T = min(len(r_i), len(r_n))
        r_i = r_i[:T]
        r_n = r_n[:T]
        mu_i, ga_i = _mu_gamma(r_i)
        mu_n, ga_n = _mu_gamma(r_n)
        g = _grad_diff(mu_i, ga_i, mu_n, ga_n)
        if g is None:
            return np.nan, (mu_i, ga_i, mu_n, ga_n)
        y = np.column_stack([r_i - mu_i, r_n - mu_n, r_i * r_i - ga_i, r_n * r_n - ga_n])
        Psi = _hac_psd(y, nlags=nlags, prewhite=True)
        var = float(g @ Psi @ g)
        if (not np.isfinite(var)) or var <= 0:
            return np.nan, (mu_i, ga_i, mu_n, ga_n)
        return np.sqrt(var / T), (mu_i, ga_i, mu_n, ga_n)

    def _psi_star_from_blocks(y_star, b):
        y_star = np.asarray(y_star, float)
        if y_star.ndim == 1:
            y_star = y_star.reshape(-1, 1)
        T, k = y_star.shape
        b = int(max(1, b))
        l = int(T // b)
        if l <= 0:
            return np.nan
        y_use = y_star[: l * b, :].reshape(l, b, k)
        f = y_use.sum(axis=1) / np.sqrt(float(b))
        return (f.T @ f) / float(l)

    def _pval_boot_single(r, M=4999, block_len=None, nlags=None, seed=123):
        r = _as_clean_series(r).values
        T = len(r)
        if T < 5:
            return np.nan, np.nan, T
        if block_len is None:
            block_len = max(1, int(round(T ** (1 / 3))))
        se0, mu0, ga0 = _se_single(r, nlags=nlags)
        sr0 = _sharpe_from_mu_gamma(mu0, ga0)
        if not np.isfinite(se0) or se0 <= 0 or not np.isfinite(sr0):
            return sr0, np.nan, T

        d = abs(sr0) / se0
        rng = np.random.default_rng(seed)
        ge = 0
        for _ in range(int(M)):
            idx = _cbb_indices(T, block_len, rng)
            rb = r[idx]
            mu1, ga1 = _mu_gamma(rb)
            sr1 = _sharpe_from_mu_gamma(mu1, ga1)
            g1 = _grad_single(mu1, ga1)
            if (g1 is None) or (not np.isfinite(sr1)):
                continue
            yb = np.column_stack([rb - mu1, rb * rb - ga1])
            Psi_star = _psi_star_from_blocks(yb, block_len)
            if isinstance(Psi_star, float) and np.isnan(Psi_star):
                continue
            var1 = float(g1 @ Psi_star @ g1)
            if (not np.isfinite(var1)) or var1 <= 0:
                continue
            se1 = np.sqrt(var1 / T)
            if not np.isfinite(se1) or se1 <= 0:
                continue
            d_star = abs(sr1 - sr0) / se1
            if d_star >= d:
                ge += 1
        pval = (ge + 1) / float(int(M) + 1)
        return sr0, pval, T

    def _pval_boot_diff(r_bench, r_strat, M=4999, block_len=None, nlags=None, seed=123):
        r_b, r_s = _align_two(r_bench, r_strat)
        rb = r_b.values
        rs = r_s.values
        T = len(rs)
        if T < 5:
            return np.nan, np.nan, T
        if block_len is None:
            block_len = max(1, int(round(T ** (1 / 3))))

        mu_b, ga_b = _mu_gamma(rb)
        mu_s, ga_s = _mu_gamma(rs)
        sr_b = _sharpe_from_mu_gamma(mu_b, ga_b)
        sr_s = _sharpe_from_mu_gamma(mu_s, ga_s)
        D0 = sr_s - sr_b

        se0, _ = _se_diff(rs, rb, nlags=nlags)
        if (not np.isfinite(D0)) or (not np.isfinite(se0)) or se0 <= 0:
            return D0, np.nan, T

        d = abs(D0) / se0
        rng = np.random.default_rng(seed)
        ge = 0
        for _ in range(int(M)):
            idx = _cbb_indices(T, block_len, rng)
            rsb = rs[idx]
            rbb = rb[idx]
            mu_b1, ga_b1 = _mu_gamma(rbb)
            mu_s1, ga_s1 = _mu_gamma(rsb)
            sr_b1 = _sharpe_from_mu_gamma(mu_b1, ga_b1)
            sr_s1 = _sharpe_from_mu_gamma(mu_s1, ga_s1)
            D1 = sr_s1 - sr_b1
            g1 = _grad_diff(mu_s1, ga_s1, mu_b1, ga_b1)
            if (g1 is None) or (not np.isfinite(D1)):
                continue
            yb = np.column_stack(
                [rsb - mu_s1, rbb - mu_b1, rsb * rsb - ga_s1, rbb * rbb - ga_b1]
            )
            Psi_star = _psi_star_from_blocks(yb, block_len)
            if isinstance(Psi_star, float) and np.isnan(Psi_star):
                continue
            var1 = float(g1 @ Psi_star @ g1)
            if (not np.isfinite(var1)) or var1 <= 0:
                continue
            se1 = np.sqrt(var1 / T)
            if not np.isfinite(se1) or se1 <= 0:
                continue
            d_star = abs(D1 - D0) / se1
            if d_star >= d:
                ge += 1
        pval = (ge + 1) / float(int(M) + 1)
        return D0, pval, T

    bench = "EW"
    r_bench = _get_rets_net_excess(results[bench])
    block_len = None
    nlags_hac = None

    rows = []
    for k, res in results.items():
        r = _get_rets_net_excess(res)
        sr, p0, T0 = _pval_boot_single(
            r, M=M_boot, block_len=block_len, nlags=nlags_hac, seed=seed
        )
        if k == bench:
            rows.append(
                dict(
                    strategy=k,
                    T=T0,
                    Sharpe=sr,
                    pval_LW_SR_eq_0=p0,
                    dSR_vs_EW=np.nan,
                    pval_LW_dSR_vs_EW=np.nan,
                )
            )
        else:
            d_sr, p_diff, Tdiff = _pval_boot_diff(
                r_bench, r, M=M_boot, block_len=block_len, nlags=nlags_hac, seed=seed
            )
            rows.append(
                dict(
                    strategy=k,
                    T=min(T0, Tdiff),
                    Sharpe=sr,
                    pval_LW_SR_eq_0=p0,
                    dSR_vs_EW=d_sr,
                    pval_LW_dSR_vs_EW=p_diff,
                )
            )

    return pd.DataFrame(rows).sort_values("strategy").reset_index(drop=True)


def _save_df_local(df: pd.DataFrame, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, float_format="%.6f")
    return path


def _save_json_local(data: dict, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)
    return path


def executa_backtest(
    *,
    dgu,
    start: str,
    end: str,
    df_base: pd.DataFrame,
    sel_cols: list[str],
    base_id: str,
    output_dir: Path,
    M: int,
    cost_bps: float,
    use_drive: bool = False,
    drive_creds: str | None = None,
    drive_pasta_resultados: str = DRIVE_PASTA_RESULTADOS,
) -> None:
    rets, rf, mkt_vm, returns_excess, _ = load_base_df(start, end, df_base, sel_cols)

    results = dgu.rolling_backtest(
        rets_m=rets,
        rf_m=rf,
        M=M,
        returns_are_excess=returns_excess,
        vw_mkt_m=mkt_vm,
        ignore_col=None,
        drop_mkt_from_universe=True,
    )
    print(
        "Período aplicado:",
        rets.index.min().date(),
        "→",
        rets.index.max().date(),
        "| #meses:",
        len(rets),
    )
    print("Estratégias:", sorted(list(results.keys())))

    tbl = build_summary(results, gamma=1.0, freq="M", as_percent=False).round(4)

    bench = "EW"
    r_bench = _get_rets_net_excess(results[bench])

    rows = []
    for k, res in results.items():
        r = _get_rets_net_excess(res)
        sr, p0, T0 = pval_sharpe_eq_zero(r)
        if k == bench:
            rows.append(
                dict(
                    strategy=k,
                    T=T0,
                    Sharpe=sr,
                    pval_SR_eq_0=p0,
                    z_JK_vs_EW=np.nan,
                    pval_JK_vs_EW=np.nan,
                )
            )
        else:
            zjk, pjk, Tjk = jk_pvalue_vs_bench(r_bench, r)
            rows.append(
                dict(
                    strategy=k,
                    T=min(T0, Tjk),
                    Sharpe=sr,
                    pval_SR_eq_0=p0,
                    z_JK_vs_EW=zjk,
                    pval_JK_vs_EW=pjk,
                )
            )
    pvalsharpe_jobkormem_df = pd.DataFrame(rows).sort_values("strategy").reset_index(drop=True)
    pvalsharpe_ledoitwolf_df = gerar_pval_sharpe_lw(results)

    gamma = 1.0
    rows = []
    for k, res in results.items():
        r = _get_rets_net_excess(res)
        ceq_k, T_k = ceq_value(r, gamma=gamma)
        if k == bench:
            rows.append(
                dict(strategy=k, T=T_k, CEQ=ceq_k, z_CEQ_vs_EW=np.nan, pval_CEQ_vs_EW=np.nan)
            )
        else:
            z, p, T = ceq_pvalue_vs_bench(r_bench, r, gamma=gamma)
            rows.append(
                dict(
                    strategy=k,
                    T=min(T_k, T),
                    CEQ=ceq_k,
                    z_CEQ_vs_EW=z,
                    pval_CEQ_vs_EW=p,
                )
            )
    pvalceq_df = pd.DataFrame(rows).sort_values("strategy").reset_index(drop=True)

    rl_df = compute_return_loss_exact_compat(results, rf_m=rf, cost_bps=cost_bps)
    rl_to_save = rl_df.reset_index()
    tbl_to_save = tbl.reset_index()

    serialized_results = {
        strategy_name: serialize_result_object(result_obj)
        for strategy_name, result_obj in results.items()
    }

    if use_drive:
        import mestrado_tools_v_0_2_oauth_humano_timeout as mestrado_tools

        mestrado_tools.salvar_df_no_google_drive(
            drive_creds,
            pvalsharpe_jobkormem_df,
            f"DGU_2009_{base_id}_pvaljob.xlsx",
            drive_pasta_resultados,
        )
        mestrado_tools.salvar_df_no_google_drive(
            drive_creds,
            pvalsharpe_ledoitwolf_df,
            f"DGU_2009_{base_id}_pvalledoitwolf.xlsx",
            drive_pasta_resultados,
        )
        mestrado_tools.salvar_df_no_google_drive(
            drive_creds, pvalceq_df, f"DGU_2009_{base_id}_pvalceq.xlsx", drive_pasta_resultados
        )
        mestrado_tools.salvar_df_no_google_drive(
            drive_creds, rl_to_save, f"DGU_2009_{base_id}_returnloss.xlsx", drive_pasta_resultados
        )
        mestrado_tools.salvar_df_no_google_drive(
            drive_creds, tbl_to_save, f"DGU_2009_{base_id}_Summary_latest.xlsx", drive_pasta_resultados
        )
        mestrado_tools.gravar_txt_no_google_drive(
            drive_creds,
            f"results_export_{base_id}_.txt",
            drive_pasta_resultados,
            serialized_results,
            "utf-8",
        )
        print(f"Resultados gravados no Drive para base {base_id}")
        return

    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    paths = {
        "pvaljob": output_dir / f"DGU_2009_{base_id}_pvaljob.csv",
        "pvalledoitwolf": output_dir / f"DGU_2009_{base_id}_pvalledoitwolf.csv",
        "pvalceq": output_dir / f"DGU_2009_{base_id}_pvalceq.csv",
        "returnloss": output_dir / f"DGU_2009_{base_id}_returnloss.csv",
        "summary": output_dir / f"DGU_2009_{base_id}_Summary_latest.csv",
        "export": output_dir / f"results_export_{base_id}_.txt",
    }

    _save_df_local(pvalsharpe_jobkormem_df, paths["pvaljob"])
    _save_df_local(pvalsharpe_ledoitwolf_df, paths["pvalledoitwolf"])
    _save_df_local(pvalceq_df, paths["pvalceq"])
    _save_df_local(rl_to_save, paths["returnloss"])
    _save_df_local(tbl_to_save, paths["summary"])
    _save_json_local(serialized_results, paths["export"])

    for label, path in paths.items():
        print(f"  {label}: {path}")


def _sel_cols_from_df(df: pd.DataFrame) -> list[str]:
    cols = [col for col in df.columns if col not in ["DATE", "RF", "MktRF"]]
    # Pandas renomeia duplicatas ao ler CSV (GOLL54, GOLL54.1, …)
    exploded = [c for c in cols if re.search(r"\.\d+$", str(c))]
    if exploded:
        raise ValueError(
            "Base com colunas de ativo duplicadas/explodidas "
            f"(ex.: {exploded[:5]}). Regenere com collapse pós-padronizar_ticker."
        )
    return cols


def process_one_base(
    *,
    dgu,
    df_base: pd.DataFrame,
    base_id: str,
    start: str,
    end: str,
    output_dir: Path,
    M: int,
    cost_bps: float,
    use_drive: bool,
    drive_creds: str | None,
    drive_pasta_resultados: str,
) -> None:
    sel_cols = _sel_cols_from_df(df_base)
    executa_backtest(
        dgu=dgu,
        start=start,
        end=end,
        df_base=df_base,
        sel_cols=sel_cols,
        base_id=base_id,
        output_dir=output_dir,
        M=M,
        cost_bps=cost_bps,
        use_drive=use_drive,
        drive_creds=drive_creds,
        drive_pasta_resultados=drive_pasta_resultados,
    )


def process_local_file(
    path: Path,
    *,
    dgu,
    base_id: str | None,
    start: str,
    end: str,
    output_dir: Path,
    processed_dir: Path | None,
    error_dir: Path | None,
    M: int,
    cost_bps: float,
) -> None:
    base_id = base_id or path.stem
    try:
        df_base = pd.read_csv(path)
        process_one_base(
            dgu=dgu,
            df_base=df_base,
            base_id=base_id,
            start=start,
            end=end,
            output_dir=output_dir,
            M=M,
            cost_bps=cost_bps,
            use_drive=False,
            drive_creds=None,
            drive_pasta_resultados=DRIVE_PASTA_RESULTADOS,
        )
        if processed_dir is not None:
            processed_dir.mkdir(parents=True, exist_ok=True)
            shutil.move(str(path), str(processed_dir / path.name))
    except Exception as e:
        err_msg = f"{type(e).__name__}: {e}\n\nTRACEBACK:\n{traceback.format_exc()}"
        print(f"Erro ao processar {path.name}:\n{err_msg}")
        if error_dir is not None:
            error_dir.mkdir(parents=True, exist_ok=True)
            log_path = error_dir / f"ERRO_{path.stem}_{datetime.now():%Y%m%d_%H%M%S}.txt"
            log_path.write_text(err_msg, encoding="utf-8")
            shutil.move(str(path), str(error_dir / path.name))
        raise


def process_local_batch(
    bases_dir: Path,
    *,
    dgu,
    start: str,
    end: str,
    output_dir: Path,
    processed_dir: Path | None,
    error_dir: Path | None,
    M: int,
    cost_bps: float,
) -> int:
    files = sorted(bases_dir.glob("*.csv"))
    print(f"Total de arquivos encontrados: {len(files)}")
    ok = 0
    for path in files:
        try:
            process_local_file(
                path,
                dgu=dgu,
                base_id=None,
                start=start,
                end=end,
                output_dir=output_dir,
                processed_dir=processed_dir,
                error_dir=error_dir,
                M=M,
                cost_bps=cost_bps,
            )
            ok += 1
        except Exception:
            pass
        finally:
            print("Fim do processamento")
    return ok


def process_drive_batch(
    *,
    dgu,
    start: str,
    end: str,
    M: int,
    cost_bps: float,
    drive_creds: str | None,
    pasta_bases: str,
    pasta_resultados: str,
    pasta_processadas: str,
    pasta_erro: str,
) -> int:
    import mestrado_tools_v_0_2_oauth_humano_timeout as mestrado_tools

    ids = mestrado_tools.listar_ids_arquivos_na_pasta(drive_creds, pasta_bases)
    print(f"Total de arquivos encontrados: {len(ids)}")
    ok = 0
    for id_arquivo in ids:
        try:
            df_base = mestrado_tools.drive_arquivo_para_dataframe(drive_creds, id_arquivo)
            base_id = mestrado_tools.obter_nome_arquivo_por_id(drive_creds, id_arquivo)[:-4]
            process_one_base(
                dgu=dgu,
                df_base=df_base,
                base_id=base_id,
                start=start,
                end=end,
                output_dir=DEFAULT_OUTPUT_DIR,
                M=M,
                cost_bps=cost_bps,
                use_drive=True,
                drive_creds=drive_creds,
                drive_pasta_resultados=pasta_resultados,
            )
            mestrado_tools.move_file(id_arquivo, pasta_processadas, drive_creds)
            ok += 1
        except Exception as e:
            err_msg = f"{type(e).__name__}: {e}\n\nTRACEBACK:\n{traceback.format_exc()}"
            try:
                nome_arquivo_base = mestrado_tools.obter_nome_arquivo_por_id(drive_creds, id_arquivo)
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                mestrado_tools.gravar_txt_no_google_drive(
                    drive_creds,
                    f"ERRO_{nome_arquivo_base}_{ts}.txt",
                    pasta_resultados,
                    err_msg,
                    "utf-8",
                )
            except Exception:
                pass
            mestrado_tools.move_file(id_arquivo, pasta_erro, drive_creds)
            print(f"Erro ao processar arquivo: {id_arquivo}")
        finally:
            print("Fim do processamento")
    return ok


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Backtests rolling DGU (2009) — versão local do notebook General Backtests v2.0"
    )
    p.add_argument("--dgu-module", type=Path, default=DEFAULT_DGU_MODULE, help="Caminho do motor DGU")
    p.add_argument("--start", default=DEFAULT_START, help="Data inicial (YYYY-MM-DD)")
    p.add_argument("--end", default=DEFAULT_END, help="Data final (YYYY-MM-DD)")
    p.add_argument("--M", type=int, default=DEFAULT_M, help="Janela rolling (meses)")
    p.add_argument("--cost-bps", type=float, default=DEFAULT_COST_BPS, help="Custo para return-loss (bps)")
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR, help="Pasta de saída (modo local)")

    src = p.add_mutually_exclusive_group(required=False)
    src.add_argument("--input-file", type=Path, help="CSV único de base DGU")
    src.add_argument("--bases-dir", type=Path, help="Pasta com CSVs para processamento em lote")

    p.add_argument("--base-id", help="Identificador da base (default: stem do arquivo)")
    p.add_argument("--processed-dir", type=Path, help="Mover bases processadas com sucesso")
    p.add_argument("--error-dir", type=Path, help="Mover bases com erro + gravar log")

    p.add_argument("--use-drive", action="store_true", help="Usar Google Drive em vez de disco local")
    p.add_argument("--drive-creds", help="JSON OAuth Desktop (obrigatório fora do Colab com --use-drive)")
    p.add_argument("--drive-bases", default=DRIVE_PASTA_BASES)
    p.add_argument("--drive-resultados", default=DRIVE_PASTA_RESULTADOS)
    p.add_argument("--drive-processadas", default=DRIVE_PASTA_BASES_PROCESSADAS)
    p.add_argument("--drive-erro", default=DRIVE_PASTA_BASES_ERRO)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    dgu = load_dgu_module(args.dgu_module)
    print(
        "Módulo importado:",
        args.dgu_module,
        "| funções:",
        [x for x in dir(dgu) if not x.startswith("_")],
    )

    if args.use_drive:
        n = process_drive_batch(
            dgu=dgu,
            start=args.start,
            end=args.end,
            M=args.M,
            cost_bps=args.cost_bps,
            drive_creds=args.drive_creds,
            pasta_bases=args.drive_bases,
            pasta_resultados=args.drive_resultados,
            pasta_processadas=args.drive_processadas,
            pasta_erro=args.drive_erro,
        )
        print(f"Concluído: {n} base(s) processada(s) via Drive")
        return 0

    if args.input_file:
        process_local_file(
            args.input_file,
            dgu=dgu,
            base_id=args.base_id,
            start=args.start,
            end=args.end,
            output_dir=args.output_dir,
            processed_dir=args.processed_dir,
            error_dir=args.error_dir,
            M=args.M,
            cost_bps=args.cost_bps,
        )
        return 0

    bases_dir = args.bases_dir or DEFAULT_BASES_DIR
    if not bases_dir.exists():
        print(
            f"Pasta de bases não encontrada: {bases_dir}\n"
            "Use --input-file ou --bases-dir para indicar os CSVs."
        )
        return 1

    n = process_local_batch(
        bases_dir,
        dgu=dgu,
        start=args.start,
        end=args.end,
        output_dir=args.output_dir,
        processed_dir=args.processed_dir,
        error_dir=args.error_dir,
        M=args.M,
        cost_bps=args.cost_bps,
    )
    print(f"Concluído: {n} base(s) processada(s) localmente")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
