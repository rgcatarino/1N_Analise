"""Resultados do simulador Pessoa Investidora — v2 (universo líquido 1 MM).

Monta as tabelas a partir das collections do banco
``Backtest_Mestrado_PF_LIQUIDEZ_1MM``, no sufixo gerado pelo backtest v3:

    {N}atv_{AAAAMM}_{AAAAMM}_{reb|buyhold}_t{bps}bps_{ir|noir}

Os tipos (IR, N, rebalanceamento, custo) entram por parâmetro e selecionam
qual família de collections ler.

Exemplo:
    python codigo_fonte/mestrado_resultados_simulador_pessoa_investidora_v2.py \\
      --ativos 8 \\
      --ir nao \\
      --rebalanceamento com \\
      --rebalance-freq annual \\
      --tcost-bps 122 \\
      --start-m 7 --start-y 2001 \\
      --end-m 10 --end-y 2025
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Tuple

from pymongo import MongoClient

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

from mestrado_resultados_simulador_pessoa_investidora import (  # noqa: E402
    DEFAULT_AVG_BLOCKS,
    DEFAULT_BOOT_B,
    DEFAULT_BOOT_SEED,
    DEFAULT_HAC_LAGS,
    DEFAULT_MONGO_URI,
    DEFAULT_OUTPUT_DIR,
    RunConfig,
    run_pipeline,
)

DEFAULT_DB_LIQUIDEZ = "Backtest_Mestrado_PF_LIQUIDEZ_1MM"
DEFAULT_DB_BOVA11 = "Backtest_Mestrado_PF_ExcessAjustado"
REBALANCE_FREQS = ("monthly", "quarterly", "semiannual", "annual")


def liquidez_suffix(
    *,
    n_ativos: int | str,
    start_y: int,
    start_m: int,
    end_y: int,
    end_m: int,
    rebalance: bool,
    rebalance_freq: str,
    tcost_bps: float,
    apply_stock_ir: bool,
    universo_tag: str = "",
    sem_reb_tag: str = "buyhold",
) -> str:
    reb = f"reb-{rebalance_freq}" if rebalance else sem_reb_tag
    ir_tag = "ir" if apply_stock_ir else "noir"
    t_bps = int(round(float(tcost_bps)))
    tag = f"{universo_tag}_" if universo_tag else ""
    return (
        f"{n_ativos}atv_{tag}{start_y}{start_m:02d}_"
        f"{end_y}{end_m:02d}_{reb}_t{t_bps}bps_{ir_tag}"
    )


@dataclass
class LiquidezRunConfig(RunConfig):
    """RunConfig com sufixo no padrão do backtest v3 (liquidez 1 MM)."""

    start_y: int = 2001
    start_m: int = 7
    end_y: int = 2025
    end_m: int = 10
    tcost_bps: float = 122.0
    apply_stock_ir: bool = False
    rebalance_freq: str = "annual"
    universo_tag: str = ""
    sem_reb_tag: str = "buyhold"

    def _period_tag(self) -> str:
        return f"{self.start_y}{self.start_m:02d}_{self.end_y}{self.end_m:02d}"

    def _ir_tag(self) -> str:
        return "ir" if self.apply_stock_ir else "noir"

    def liquidez_suffix(self, *, rebalance: bool) -> str:
        return liquidez_suffix(
            n_ativos=self.ativos_carteira,
            start_y=self.start_y,
            start_m=self.start_m,
            end_y=self.end_y,
            end_m=self.end_m,
            rebalance=rebalance,
            rebalance_freq=self.rebalance_freq,
            tcost_bps=self.tcost_bps,
            apply_stock_ir=self.apply_stock_ir,
            universo_tag=self.universo_tag,
            sem_reb_tag=self.sem_reb_tag,
        )

    @property
    def sufixo_carteiras_base(self) -> str:
        return self.liquidez_suffix(rebalance=True)

    @property
    def sufixo_carteiras_com(self) -> str:
        return self.liquidez_suffix(rebalance=True)

    @property
    def sufixo_carteiras_sem(self) -> str:
        return self.liquidez_suffix(rebalance=False)

    @property
    def rebalanceamento_label(self) -> str:
        ir = "com IR" if self.apply_stock_ir else "sem IR"
        custo = f"{self.tcost_bps:g} bps"
        if self.rebalanceamento == "sem":
            return f"sem rebalanceamento (buy-and-hold), {custo}, {ir}"
        return f"com rebalanceamento {self.rebalance_freq}, {custo}, {ir}"

    def should_run(self, step: str) -> bool:
        # Comparativo com vs sem só faz sentido quando as duas families existem.
        if step == "com-vs-sem" and self.rebalanceamento != "ambos":
            return False
        return super().should_run(step)


def list_liquidez_collections(mongo_uri: str, db_name: str) -> List[str]:
    client = MongoClient(mongo_uri, serverSelectionTimeoutMS=15000)
    try:
        names = sorted(
            n
            for n in client[db_name].list_collection_names()
            if n.startswith(("aux_metrics_", "res_", "ret_acum_pct_", "ret_excess_acum_pct_"))
        )
    finally:
        client.close()
    return names


def combo_output_dir(
    base: Path,
    *,
    n_ativos: int,
    tcost_bps: float,
    apply_stock_ir: bool,
    universo_tag: str = "",
) -> Path:
    ir_tag = "ir" if apply_stock_ir else "noir"
    tag = f"_{universo_tag}" if universo_tag else ""
    return base / f"{n_ativos}atv{tag}_t{int(round(tcost_bps))}bps_{ir_tag}"


def parse_ir_modes(raw: str) -> Tuple[bool, ...]:
    if raw == "sim":
        return (True,)
    if raw == "nao":
        return (False,)
    return (False, True)


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Gera tabelas do simulador Pessoa Investidora a partir das collections "
            "de Backtest_Mestrado_PF_LIQUIDEZ_1MM (IR, N, rebalanceamento e custo)."
        )
    )
    parser.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    parser.add_argument("--db-name", default=DEFAULT_DB_LIQUIDEZ, help="Banco das carteiras líquidas")
    parser.add_argument(
        "--db-name-bova11",
        default=DEFAULT_DB_BOVA11,
        help="Banco do BOVA11 (default: Backtest_Mestrado_PF_ExcessAjustado)",
    )
    parser.add_argument(
        "--ativos",
        type=int,
        nargs="+",
        default=[8],
        help="Total de ativos por carteira (um ou mais, ex.: 8 10 12)",
    )
    parser.add_argument(
        "--ir",
        choices=("sim", "nao", "ambos"),
        default="nao",
        help="Imposto de renda nas collections: sim, nao ou ambos (default: nao)",
    )
    parser.add_argument(
        "--rebalanceamento",
        choices=("com", "sem", "ambos"),
        default="com",
        help=(
            "Com rebalanceamento, buy-and-hold, ou os dois. "
            "Use ambos somente se as collections buyhold já existirem "
            "(tabela comparativa com vs sem)."
        ),
    )
    parser.add_argument(
        "--rebalance-freq",
        choices=REBALANCE_FREQS,
        default="annual",
        help="Periodicidade quando --rebalanceamento é com/ambos (default: annual)",
    )
    parser.add_argument(
        "--tcost-bps",
        type=float,
        nargs="+",
        default=[122.0],
        help="Custo de transação em bps (um ou mais, ex.: 50 122)",
    )
    parser.add_argument("--start-m", type=int, default=7)
    parser.add_argument("--start-y", type=int, default=2001)
    parser.add_argument("--end-m", type=int, default=10)
    parser.add_argument("--end-y", type=int, default=2025)
    parser.add_argument(
        "--universo-tag",
        default="",
        help=(
            "Tag do universo no sufixo das collections (ex.: divliq_10k → "
            "8atv_divliq_10k_200107_202510_...). Default: vazio (liquidez 1 MM)."
        ),
    )
    parser.add_argument(
        "--sem-reb-tag",
        default="buyhold",
        help="Nome do regime sem rebalanceamento no sufixo (default: buyhold; use buy-hold se aplicável)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR / "liquidez_1mm",
        help="Diretório-base de saída (default: resultados/liquidez_1mm)",
    )
    parser.add_argument(
        "--step",
        action="append",
        choices=["all", "aux-metrics", "res", "com-vs-sem", "vs-benchmark", "paired-test", "text"],
        default=None,
        help="Etapas a executar (pode repetir; default: all)",
    )
    parser.add_argument("--hac-lag", type=int, action="append", dest="hac_lags")
    parser.add_argument("--avg-block", type=int, action="append", dest="avg_blocks")
    parser.add_argument("--boot-b", type=int, default=DEFAULT_BOOT_B)
    parser.add_argument("--boot-seed", type=int, default=DEFAULT_BOOT_SEED)
    parser.add_argument("--no-csv", action="store_true")
    parser.add_argument("--no-latex", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--no-text-file", action="store_true")
    parser.add_argument(
        "--list-collections",
        action="store_true",
        help="Lista collections do banco de liquidez e sai",
    )
    args = parser.parse_args(list(argv) if argv is not None else None)
    if not 1 <= args.start_m <= 12 or not 1 <= args.end_m <= 12:
        parser.error("Mês de início/fim deve estar entre 1 e 12.")
    return args


def build_configs(args: argparse.Namespace) -> List[LiquidezRunConfig]:
    ir_modes = parse_ir_modes(args.ir)
    periodo_suffix = f"{args.start_y}_{args.end_y}"
    steps = tuple(args.step) if args.step else ("all",)
    configs: List[LiquidezRunConfig] = []
    for n_ativos, tcost_bps, apply_ir in product(args.ativos, args.tcost_bps, ir_modes):
        out_dir = combo_output_dir(
            args.output_dir,
            n_ativos=int(n_ativos),
            tcost_bps=float(tcost_bps),
            apply_stock_ir=bool(apply_ir),
            universo_tag=str(args.universo_tag or ""),
        )
        configs.append(
            LiquidezRunConfig(
                mongo_uri=args.mongo_uri,
                mongo_uri_bova11=args.mongo_uri,
                db_name_carteiras_com_rebalanceamento=args.db_name,
                db_name_carteiras_sem_rebalanceamento=args.db_name,
                db_name_bova11=args.db_name_bova11,
                rebalanceamento=args.rebalanceamento,
                ativos_carteira=str(int(n_ativos)),
                periodo_suffix=periodo_suffix,
                suffix_buyhold="",
                output_dir=out_dir,
                hac_lags=tuple(args.hac_lags) if args.hac_lags else DEFAULT_HAC_LAGS,
                avg_blocks=tuple(args.avg_blocks) if args.avg_blocks else DEFAULT_AVG_BLOCKS,
                boot_b=args.boot_b,
                boot_seed=args.boot_seed,
                export_csv=not args.no_csv,
                export_latex=not args.no_latex,
                print_tables=not args.quiet,
                write_dissertation_text=not args.no_text_file,
                steps=steps,
                start_y=args.start_y,
                start_m=args.start_m,
                end_y=args.end_y,
                end_m=args.end_m,
                tcost_bps=float(tcost_bps),
                apply_stock_ir=bool(apply_ir),
                rebalance_freq=args.rebalance_freq,
                universo_tag=str(args.universo_tag or ""),
                sem_reb_tag=str(args.sem_reb_tag or "buyhold"),
            )
        )
    return configs


def main(argv: Optional[Iterable[str]] = None) -> None:
    args = parse_args(argv)
    if args.list_collections:
        names = list_liquidez_collections(args.mongo_uri, args.db_name)
        print(f"{args.db_name}: {len(names)} collections")
        for name in names:
            print(name)
        return

    configs = build_configs(args)
    print(
        f"Banco carteiras: {args.db_name}\n"
        f"Banco BOVA11:    {args.db_name_bova11}\n"
        f"Combinações:     {len(configs)} "
        f"(N={args.ativos}, bps={args.tcost_bps}, IR={args.ir}, "
        f"rebalanceamento={args.rebalanceamento}, freq={args.rebalance_freq})",
        flush=True,
    )
    for config in configs:
        print(
            f"\n>>> N={config.ativos_carteira} | {config.tcost_bps:g} bps | "
            f"{'IR' if config.apply_stock_ir else 'sem IR'}\n"
            f"    com : aux_metrics_{config.sufixo_carteiras_com}\n"
            f"    sem : aux_metrics_{config.sufixo_carteiras_sem}",
            flush=True,
        )
        run_pipeline(config)


if __name__ == "__main__":
    main()
