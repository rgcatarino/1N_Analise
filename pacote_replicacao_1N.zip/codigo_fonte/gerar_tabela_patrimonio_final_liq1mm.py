#!/usr/bin/env python3
"""Tabela de patrimônio final mediano pós-IR (liquidação no último dia).

Lê ``aux_metrics_*`` em ``Backtest_Mestrado_PF_LIQUIDEZ_1MM`` com
``final_wealth_brl`` / ``liquidate_at_end``, agrega mediana cross-section e
grava ``.tex`` + ``.xlsx`` (+ CSV).

Exemplo::

    python codigo_fonte/gerar_tabela_patrimonio_final_liq1mm.py \\
      --periodos 2001-2025
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import pandas as pd
from pymongo import MongoClient

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_URI = "mongodb://172.23.224.1:27017/"
DEFAULT_DB = "Backtest_Mestrado_PF_LIQUIDEZ_1MM"
DEFAULT_OUT = REPO_ROOT / "resultados" / "patrimonio_final"
DEFAULT_TEX = REPO_ROOT / "texto" / "dissertacao" / "tabelas"
NS = [8, 10, 12, 15, 20, 25, 30, 35, 40]
# Chaves internas (= cost_mode no Mongo / tabelas wide).
# Sem ``barra`` (impacto_merc. η calibrado): pedido para a tabela da dissertação.
# Ordem de exibição (LaTeX/Excel): bruto | fixo | Impacto de Mercado (η=1) | Fixo + …
COST_COLS = ["gross", "flat", "barra_raw", "flat_barra"]
# Rótulos de exibição (Excel / CSV wide). No LaTeX, η vira $\eta$ em write_tex.
COST_COL_LABELS = {
    "gross": "bruto",
    "flat": "fixo",
    "barra_raw": "Impacto de Mercado (η=1)",
    "flat_barra": "Fixo + Impacto de Mercado (η=1)",
}
H_COL = "H (rebalanceamento)"
H_ORDER = [
    ("reb-annual", "Anual"),
    ("reb-semiannual", "Semestral"),
    ("reb-quarterly", "Trimestral"),
    ("reb-monthly", "Mensal"),
    ("buyhold", "Buy-and-hold"),
]

PERIOD_TO_START = {
    "2001-2025": ("200107", "202510"),
    "2006-2025": ("200607", "202510"),
    "2011-2025": ("201107", "202510"),
}

SUFFIX_RE = re.compile(
    r"^aux_metrics_"
    r"(?P<n>\d+)atv_"
    r"(?P<universo>.+?)_"
    r"(?P<start>\d{6})_(?P<end>\d{6})_"
    r"(?P<reb>reb-(?:monthly|quarterly|semiannual|annual)|buyhold)_"
    r"(?P<tcost>tgross|t\d+bps_barra_raw|tbarra_raw|tbarra_eta[\dp]+|t\d+bps)_"
    r"(?P<ir>ir|noir)"
    r"(?P<engine>_v41)?$"  # v4.1 grava sufixo _v41; v4 omite
)
ENGINE_CHOICES = ("v4", "v41", "all")


def cost_mode_from_tag(tag: str) -> Optional[str]:
    if tag == "tgross":
        return "gross"
    if tag == "tbarra_raw":
        return "barra_raw"
    if re.fullmatch(r"t\d+bps_barra_raw", tag):
        return "flat_barra"
    if tag.startswith("tbarra_eta"):
        return "barra"
    if re.fullmatch(r"t\d+bps", tag):
        return "flat"
    return None


def parse_period(label: str) -> Tuple[str, str, str]:
    key = label.strip()
    if key not in PERIOD_TO_START:
        raise ValueError(
            f"Período desconhecido: {label!r}. Use um de {list(PERIOD_TO_START)}"
        )
    start, end = PERIOD_TO_START[key]
    return key, start, end


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--periodos",
        nargs="+",
        required=True,
        help="Ex.: 2001-2025 2006-2025 2011-2025",
    )
    p.add_argument("--mongo-uri", default=DEFAULT_URI)
    p.add_argument("--db-name", default=DEFAULT_DB)
    p.add_argument("--universo-tag", default="liq_1MM")
    p.add_argument("--capital", type=float, default=10_000.0)
    p.add_argument("--require-ir", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    p.add_argument("--tex-dir", type=Path, default=DEFAULT_TEX)
    p.add_argument(
        "--tex-name",
        default=None,
        help=(
            "Nome do arquivo .tex de saída (com ou sem extensão). "
            "Padrão: tabela_patrimonio_final_liq_1MM_<periodo>.tex. "
            "Com vários --periodos, grava <stem>_<periodo>.tex para evitar sobrescrita."
        ),
    )
    p.add_argument(
        "--engine",
        choices=ENGINE_CHOICES,
        default="v41",
        help=(
            "Qual motor ler: v41 = collections *_v41 (default); "
            "v4 = sem sufixo _v41; all = ambos (prefira v41 se houver duplicata)."
        ),
    )
    p.add_argument(
        "--allow-missing",
        action="store_true",
        help="Gera tabela mesmo com células ausentes (NaN).",
    )
    p.add_argument(
        "--min-obs",
        type=int,
        default=1,
        help="Mínimo de carteiras com final_wealth_brl para incluir a célula.",
    )
    return p.parse_args(list(argv) if argv is not None else None)


def engine_from_match(m: re.Match) -> str:
    return "v41" if m.group("engine") == "_v41" else "v4"


def list_matching_collections(
    db,
    *,
    universo: str,
    start: str,
    end: str,
    require_ir: bool,
    engine: str = "v41",
) -> List[Tuple[str, re.Match]]:
    out = []
    for name in db.list_collection_names():
        if not name.startswith("aux_metrics_"):
            continue
        # Ignora VW e outros sufixos extras (ex.: _vw) — só EW v4/v4.1.
        if name.endswith("_vw") or "_vw_" in name:
            continue
        m = SUFFIX_RE.match(name)
        if not m:
            continue
        if m.group("universo") != universo:
            continue
        if m.group("start") != start or m.group("end") != end:
            continue
        if require_ir and m.group("ir") != "ir":
            continue
        eng = engine_from_match(m)
        if engine == "v41" and eng != "v41":
            continue
        if engine == "v4" and eng != "v4":
            continue
        mode = cost_mode_from_tag(m.group("tcost"))
        if mode is None:
            continue
        out.append((name, m))
    return out


def median_final_wealth(col) -> Tuple[float, int]:
    vals = []
    for doc in col.find(
        {"final_wealth_brl": {"$exists": True, "$ne": None}},
        {"final_wealth_brl": 1, "_id": 0},
    ):
        v = doc.get("final_wealth_brl")
        if v is None:
            continue
        try:
            fv = float(v)
        except (TypeError, ValueError):
            continue
        if fv == fv:  # not NaN
            vals.append(fv)
    if not vals:
        return float("nan"), 0
    return float(pd.Series(vals, dtype="float64").median()), len(vals)


def build_long_table(
    db,
    periods: Iterable[str],
    *,
    universo: str,
    require_ir: bool,
    min_obs: int = 1,
    engine: str = "v41",
) -> pd.DataFrame:
    rows: List[dict] = []
    # chave → (row_dict, prefer_v41)
    best: Dict[Tuple[str, int, str, str], dict] = {}
    for label in periods:
        period, start, end = parse_period(label)
        matches = list_matching_collections(
            db,
            universo=universo,
            start=start,
            end=end,
            require_ir=require_ir,
            engine=engine,
        )
        print(
            f"  [{period}] collections casadas ({engine}): {len(matches)}",
            flush=True,
        )
        for name, m in matches:
            mode = cost_mode_from_tag(m.group("tcost"))
            if mode not in COST_COLS:
                continue
            n = int(m.group("n"))
            if n not in NS:
                continue
            reb = m.group("reb")
            if reb not in {h for h, _ in H_ORDER}:
                continue
            median_fw, n_obs = median_final_wealth(db[name])
            if n_obs < int(min_obs):
                continue
            eng = engine_from_match(m)
            row = {
                "periodo": period,
                "N": n,
                "H_key": reb,
                "H": dict(H_ORDER)[reb],
                "cost_mode": mode,
                "median_final_wealth_brl": median_fw,
                "n_obs": n_obs,
                "collection": name,
                "engine": eng,
            }
            key = (period, n, reb, mode)
            prev = best.get(key)
            if prev is None:
                best[key] = row
            elif engine == "all" and prev.get("engine") == "v4" and eng == "v41":
                best[key] = row  # preferir v4.1 em duplicata
            # se já há v41, manter; se ambos v4, manter o primeiro
    rows = list(best.values())
    return pd.DataFrame(rows)


def pivot_wide(long_df: pd.DataFrame, period: str) -> pd.DataFrame:
    if long_df is None or long_df.empty or "periodo" not in long_df.columns:
        records = []
        for h_key, h_label in H_ORDER:
            for n in NS:
                row = {"Periodo": period, "N": n, H_COL: h_label}
                for mode in COST_COLS:
                    row[mode] = float("nan")
                records.append(row)
        return pd.DataFrame(records)
    sub = long_df[long_df["periodo"] == period].copy()
    records = []
    for h_key, h_label in H_ORDER:
        for n in NS:
            row = {"Periodo": period, "N": n, H_COL: h_label}
            for mode in COST_COLS:
                hit = sub[
                    (sub["H_key"] == h_key)
                    & (sub["N"] == n)
                    & (sub["cost_mode"] == mode)
                ]
                if hit.empty:
                    row[mode] = float("nan")
                else:
                    row[mode] = float(hit.iloc[0]["median_final_wealth_brl"])
            records.append(row)
    return pd.DataFrame(records)


def fmt_brl(x: float, *, decimals: int = 2) -> str:
    """Formata valor no padrão IBGE/CONMETRO: espaço no milhar, vírgula no decimal.

    No LaTeX usa ``\\,`` (espaço fino) como separador de milhar.
    """
    if x != x:
        return "—"
    if decimals <= 0:
        # 267743 → "267\,743"
        return f"{x:,.0f}".replace(",", r"\,")
    # 267742.53 → "267\,742,53"
    return f"{x:,.{decimals}f}".replace(",", "X").replace(".", ",").replace("X", r"\,")


def resolve_tex_path(
    tex_dir: Path,
    *,
    tex_name: Optional[str],
    period: str,
    n_periods: int,
) -> Path:
    """Monta o caminho do ``.tex``; ``tex_name`` sobrescreve o basename padrão."""
    period_slug = period.replace("-", "_")
    if not tex_name:
        return tex_dir / f"tabela_patrimonio_final_liq_1MM_{period_slug}.tex"

    raw = Path(tex_name)
    # Se o usuário passou caminho com pasta, respeita; senão usa tex_dir.
    base_dir = raw.parent if raw.parent != Path(".") else tex_dir
    stem = raw.stem  # remove .tex se houver
    if n_periods > 1:
        return base_dir / f"{stem}_{period_slug}.tex"
    return base_dir / f"{stem}.tex"


def _cost_label_tex(mode: str) -> str:
    """Rótulo de custo para cabeçalho LaTeX ((η=1) → ($\\eta=1$))."""
    return (
        COST_COL_LABELS[mode]
        .replace("(η=1)", r"($\eta=1$)")
        .replace("_", r"\_")
    )


def write_tex(wide: pd.DataFrame, path: Path, *, period: str, capital: float) -> None:
    # Ordem: N | H | bruto | fixo | Impacto de Mercado (η=1) | Fixo + …
    # (período vai só no caption — evita coluna redundante e ganha altura útil)
    n_cost = len(COST_COLS)
    col_spec = "cc" + ("c" * n_cost)
    capital_txt = f"{capital:,.0f}".replace(",", ".")
    header_costs = " & ".join(_cost_label_tex(m) for m in COST_COLS)
    lines = [
        r"\begin{table}[htbp]",
        r"\centering",
        (
            r"\caption{Mediana do patrimônio final pós-impostos com liquidação terminal "
            rf"(capital inicial R\$\,{capital_txt}) — período {period}" + "}"
        ),
        r"\label{tab:patrimonio_final_" + period.replace("-", "_") + r"}",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{5.0pt}",
        r"\renewcommand{\arraystretch}{0.92}",
        # Reserva espaço para caption + \tabfonte + margem inferior da página.
        r"\begin{adjustbox}{max width=\linewidth, max height=0.70\textheight, center}",
        rf"\begin{{tabular}}{{@{{}}{col_spec}@{{}}}}",
        r"\toprule",
        rf" &  & \multicolumn{{{n_cost}}}{{c}}{{Patrimônio Final por Tipo de Custo}} \\",
        rf"\cmidrule(lr){{3-{2 + n_cost}}}",
        rf"$N$ & {H_COL} & {header_costs} \\",
        r"\midrule",
    ]

    n_rows = len(wide)
    i = 0
    while i < n_rows:
        h_label = wide.iloc[i][H_COL]
        j = i
        while j < n_rows and wide.iloc[j][H_COL] == h_label:
            j += 1
        block_len = j - i
        for k in range(i, j):
            r = wide.iloc[k]
            cells = [fmt_brl(float(r[m]), decimals=0) for m in COST_COLS]
            if k == i:
                h_cell = rf"\multirow{{{block_len}}}{{*}}{{{h_label}}}"
            else:
                h_cell = ""
            lines.append(
                f"{int(r['N'])} & {h_cell} & "
                + " & ".join(cells)
                + r" \\"
            )
        if j < n_rows:
            lines.append(r"\midrule")
        i = j

    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{adjustbox}",
            (
                r"\tabfonte{Fonte: Elaboração própria. Universo de ações com liquidez "
                r"diária média maior que 1 milhão; "
                rf"capital inicial R\$\,{capital_txt}; mediana \emph{{cross-section}} do "
                r"patrimônio final após liquidação forçada no último pregão "
                r"(custos do modo + IR~15\% PF com isenção mensal de vendas). "
                r"Colunas: bruto (sem custo de transação), fixo (12~bps), "
                r"Impacto de Mercado ($\eta=1$) e Fixo + Impacto de Mercado ($\eta=1$) "
                r"($\sigma\sqrt{|q|/\mathrm{ADV}}$, $\eta\equiv 1$).}"
            ),
            r"\end{table}",
            "",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def write_excel(wide_by_period: Dict[str, pd.DataFrame], path: Path, *, capital: float) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    thin = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)

    first = True
    for period, wide in wide_by_period.items():
        if first:
            ws = wb.active
            ws.title = period[:31]
            first = False
        else:
            ws = wb.create_sheet(period[:31])

        n_cost = len(COST_COLS)
        last_col = 3 + n_cost  # Periodo | N | H | custos...
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=last_col)
        ws["A1"] = (
            f"Mediana do patrimônio final pós-IR (liquidação terminal) | "
            f"capital={capital:,.0f} | {period}"
        )
        ws["A1"].font = Font(bold=True, size=12)
        ws["A1"].alignment = center

        ws.merge_cells("A2:A3")
        ws["A2"] = "Periodo"
        ws.merge_cells("B2:B3")
        ws["B2"] = "N"
        ws.merge_cells("C2:C3")
        ws["C2"] = H_COL
        ws.merge_cells(start_row=2, start_column=4, end_row=2, end_column=last_col)
        ws["D2"] = "Patrimônio Final por Tipo de Custo"
        for col, key in enumerate(COST_COLS, start=4):
            ws.cell(row=3, column=col, value=COST_COL_LABELS[key])

        for col in range(1, last_col + 1):
            for row in (2, 3):
                c = ws.cell(row=row, column=col)
                c.font = Font(bold=True)
                c.alignment = center
                c.border = thin

        start = 4
        for i, rec in enumerate(wide.itertuples(index=False)):
            r = start + i
            ws.cell(row=r, column=1, value=rec[0]).alignment = center
            ws.cell(row=r, column=2, value=int(rec[1])).alignment = center
            ws.cell(row=r, column=3, value=rec[2]).alignment = center
            for j, mode in enumerate(COST_COLS):
                val = rec[3 + j]
                cell = ws.cell(
                    row=r,
                    column=4 + j,
                    value=None if val != val else float(val),
                )
                cell.alignment = center
                cell.number_format = "#,##0.00"
                cell.border = thin
            for col in range(1, 4):
                ws.cell(row=r, column=col).border = thin

        # merge Periodo and H blocks
        if len(wide):
            ws.merge_cells(start_row=start, start_column=1, end_row=start + len(wide) - 1, end_column=1)
            pos = start
            for h_key, h_label in H_ORDER:
                block = wide[wide[H_COL] == h_label]
                blen = len(block)
                if blen > 1:
                    ws.merge_cells(
                        start_row=pos, start_column=3, end_row=pos + blen - 1, end_column=3
                    )
                pos += blen

        for col in range(1, last_col + 1):
            letter = get_column_letter(col)
            if col <= 3:
                ws.column_dimensions[letter].width = 18
            else:
                ws.column_dimensions[letter].width = 22

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def main(argv: Optional[Sequence[str]] = None) -> None:
    args = parse_args(argv)
    periods = [parse_period(p)[0] for p in args.periodos]
    client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=8000)
    db = client[args.db_name]
    long_df = build_long_table(
        db,
        periods,
        universo=args.universo_tag,
        require_ir=args.require_ir,
        min_obs=int(args.min_obs),
        engine=str(args.engine),
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.tex_dir.mkdir(parents=True, exist_ok=True)

    long_path = args.output_dir / "patrimonio_final_long.csv"
    long_df.to_csv(long_path, index=False)
    print(f"Wrote {long_path} ({len(long_df)} rows) | engine={args.engine}")
    if long_df.empty:
        print(
            "AVISO: nenhuma collection casou (verifique se os runs v4.1 "
            "já gravaram aux_metrics_*_v41 no Mongo).",
            flush=True,
        )

    wide_by_period: Dict[str, pd.DataFrame] = {}
    for period in periods:
        wide = pivot_wide(long_df, period)
        wide_by_period[period] = wide
        period_slug = period.replace("-", "_")
        wide_path = args.output_dir / f"tabela_patrimonio_final_liq_1MM_{period_slug}.csv"
        wide_export = wide.rename(columns=COST_COL_LABELS)
        wide_export.to_csv(wide_path, index=False)
        tex_path = resolve_tex_path(
            args.tex_dir,
            tex_name=args.tex_name,
            period=period,
            n_periods=len(periods),
        )
        write_tex(wide, tex_path, period=period, capital=args.capital)
        print(f"Wrote {wide_path}")
        print(f"Wrote {tex_path}")
        n_missing = int(wide[COST_COLS].isna().sum().sum())
        if n_missing and not args.allow_missing:
            print(f"AVISO: {n_missing} células NaN em {period} (use --allow-missing).")

    xlsx_path = args.output_dir / "tabela_patrimonio_final_liq_1MM.xlsx"
    write_excel(wide_by_period, xlsx_path, capital=args.capital)
    print(f"Wrote {xlsx_path}")
    client.close()


if __name__ == "__main__":
    main()
