"""Tabela consolidada: comparativo 1/N vs VW buy-and-hold (patrimônio final e Sharpe).

Pareia, por ``strategy``, as collections ``aux_metrics_{suffix}`` (1/N) e
``aux_metrics_{…_buyhold…}_vw`` (VW) em ``Backtest_Mestrado_PF_LIQUIDEZ_1MM`` e
consolida, por período e número de ativos, a média cross-section das
diferenças (1/N − VW) e o winrate nas métricas:

- patrimônio final (``final_wealth_brl``);
- Sharpe em excesso (``sharpe_excess``).

O lado **VW é sempre buy-and-hold**. ``--rebalance-freq`` define só o H do
1/N. Cenário de custo e motor de deslistagem são fixos por execução via CLI.
Default: 1/N anual + VW B&H + flat 12 bps + **v4.1**
(collections ``…_ir_v41`` / ``…_buyhold_…_ir_v41_vw``; top-up na deslistagem).

Use ``--engine v4`` para o legado (``…_ir`` / ``…_ir_vw``, reset 1/N na deslistagem).

Saídas: CSV, LaTeX e XLSX em ``resultados/liquidez_1mm_1n_vs_vw/``.

Exemplo::

    cd ~/mestrado
    source .venv/bin/activate

    python3 codigo_fonte/mestrado_tabela_1n_vs_vw_consolidada.py \\
      --universo-tag liq_1MM \\
      --cost-mode flat \\
      --tcost-bps 12 \\
      --rebalance-freq annual \\
      --engine v41 \\
      --ir sim
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from pymongo import MongoClient

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

from mestrado_resultados_simulador_pessoa_investidora import (  # noqa: E402
    ComVsSemMetric,
    DEFAULT_MONGO_URI,
    _load_aux_metrics_by_strategy,
    _paired_com_vs_sem_row,
    _pick_metric_column,
)
from mestrado_resultados_simulador_pessoa_investidora_v2 import (  # noqa: E402
    DEFAULT_DB_LIQUIDEZ,
    list_liquidez_collections,
)

DEFAULT_OUTPUT_DIR = REPO_ROOT / "resultados" / "liquidez_1mm_1n_vs_vw"
DEFAULT_ATIVOS = (8, 10, 12, 15, 20, 25, 30, 35, 40)
DEFAULT_PERIODS: Tuple[Tuple[str, int, int, int, int], ...] = (
    ("2001-2025", 2001, 7, 2025, 10),
    ("2006-2025", 2006, 7, 2025, 10),
    ("2011-2025", 2011, 7, 2025, 10),
)
DEFAULT_STEM = "1n_vs_vw_consolidado"
DEFAULT_LABEL = "tab:1n_vs_vw_consolidado"
DEFAULT_TITLE = (
    "Comparativo $1/N$ vs.\\ VW buy-and-hold --- patrimônio final e Sharpe "
    "em excesso (diferenças pareadas por período e número de ativos)"
)

COST_MODES = ("flat", "gross", "barra", "flat_barra", "barra_raw")
REBALANCE_FREQS = ("annual", "semiannual", "quarterly", "monthly", "buyhold")
ENGINE_CHOICES = ("v4", "v41")

COMPARE_METRICS: Tuple[ComVsSemMetric, ...] = (
    ComVsSemMetric("final_wealth_brl", "Patrimônio final (R$)", "aux", 1.0, ndigits=2),
    ComVsSemMetric("sharpe_excess", "Sharpe em excesso", "aux", 1.0, ndigits=2),
)


@dataclass(frozen=True)
class PeriodWindow:
    label: str
    start_y: int
    start_m: int
    end_y: int
    end_m: int


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Gera tabela consolidada 1/N (H da CLI) vs VW buy-and-hold "
            "(patrimônio final e Sharpe) por período e N."
        )
    )
    parser.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    parser.add_argument("--db-name", default=DEFAULT_DB_LIQUIDEZ)
    parser.add_argument(
        "--ativos",
        type=int,
        nargs="+",
        default=list(DEFAULT_ATIVOS),
        help="Números de ativos por carteira (default: 8..40)",
    )
    parser.add_argument(
        "--periodos",
        nargs="*",
        default=None,
        help="Rótulos de período (ex.: 2001-2025). Default: os três horizontes.",
    )
    parser.add_argument("--start-m", type=int, default=7)
    parser.add_argument("--end-y", type=int, default=2025)
    parser.add_argument("--end-m", type=int, default=10)
    parser.add_argument("--universo-tag", default="liq_1MM")
    parser.add_argument("--tcost-bps", type=float, default=12.0)
    parser.add_argument(
        "--cost-mode",
        choices=COST_MODES,
        default="flat",
        help="Cenário de custo (default: flat)",
    )
    parser.add_argument(
        "--eta",
        type=float,
        default=1.0,
        help="η BARRA usado na tag tbarra_eta... (default: 1.0)",
    )
    parser.add_argument(
        "--ir",
        choices=("sim", "nao", "ambos"),
        default="sim",
        help="Modo de IR (default: sim)",
    )
    parser.add_argument(
        "--rebalance-freq",
        choices=REBALANCE_FREQS,
        default="annual",
        help=(
            "Periodicidade H do lado 1/N (default: annual). "
            "O lado VW é sempre buy-and-hold."
        ),
    )
    parser.add_argument(
        "--engine",
        choices=ENGINE_CHOICES,
        default="v41",
        help=(
            "Motor de deslistagem das collections: "
            "v41 = sufixo *_v41 / *_v41_vw (top-up; default); "
            "v4 = legado sem _v41 (reset 1/N na deslistagem)."
        ),
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--stem", default=DEFAULT_STEM)
    parser.add_argument("--label", default=DEFAULT_LABEL)
    parser.add_argument("--title", default=DEFAULT_TITLE)
    parser.add_argument(
        "--allow-missing",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Marca células ausentes com em dash em vez de falhar "
            "(default: True; use --no-allow-missing para abortar)."
        ),
    )
    parser.add_argument("--no-csv", action="store_true")
    parser.add_argument("--no-latex", action="store_true")
    parser.add_argument("--no-xlsx", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument(
        "--list-collections",
        action="store_true",
        help="Lista pares aux_metrics 1/N e *_vw filtrados pelo modo pedido e sai.",
    )
    return parser.parse_args(list(argv) if argv is not None else None)


def resolve_ir_modes(raw: str) -> Tuple[bool, ...]:
    if raw == "sim":
        return (True,)
    if raw == "nao":
        return (False,)
    return (False, True)


def resolve_period_windows(args: argparse.Namespace) -> Tuple[PeriodWindow, ...]:
    if args.periodos:
        lookup = {p.label: p for p in _default_period_windows(args)}
        windows: List[PeriodWindow] = []
        for label in args.periodos:
            if label not in lookup:
                raise RuntimeError(
                    f"Período desconhecido: {label!r}. "
                    f"Disponíveis: {sorted(lookup)}"
                )
            windows.append(lookup[label])
        return tuple(windows)
    return _default_period_windows(args)


def _default_period_windows(args: argparse.Namespace) -> Tuple[PeriodWindow, ...]:
    return tuple(
        PeriodWindow(label, sy, sm, args.end_y, args.end_m)
        for label, sy, sm, _, _ in DEFAULT_PERIODS
    )


def cost_tag(*, cost_mode: str, tcost_bps: float, eta: float) -> str:
    mode = str(cost_mode).lower()
    t_bps = int(round(float(tcost_bps)))
    eta_tag = f"{float(eta):.4g}".replace(".", "p")
    if mode == "barra":
        return f"tbarra_eta{eta_tag}"
    if mode == "barra_raw":
        return "tbarra_raw"
    if mode == "flat_barra":
        return f"t{t_bps}bps_barra_raw"
    if mode == "gross":
        return "tgross"
    if mode == "flat":
        return f"t{t_bps}bps"
    raise ValueError(f"cost_mode inválido: {cost_mode!r}; use {COST_MODES}")


def reb_tag(rebalance_freq: str) -> str:
    freq = str(rebalance_freq).lower()
    if freq == "buyhold":
        return "buyhold"
    if freq in ("annual", "semiannual", "quarterly", "monthly"):
        return f"reb-{freq}"
    raise ValueError(
        f"rebalance-freq inválido: {rebalance_freq!r}; use {REBALANCE_FREQS}"
    )


def engine_suffix(engine: str) -> str:
    """Sufixo Mongo do motor: v4.1 grava ``_v41``; v4 omite."""
    eng = str(engine).lower()
    if eng == "v41":
        return "_v41"
    if eng == "v4":
        return ""
    raise ValueError(f"engine inválido: {engine!r}; use {ENGINE_CHOICES}")


def build_suffix_ew(
    *,
    n_ativos: int,
    window: PeriodWindow,
    args: argparse.Namespace,
    apply_ir: bool,
) -> str:
    ir_tag = "ir" if apply_ir else "noir"
    uni = f"{args.universo_tag}_" if args.universo_tag else ""
    t_tag = cost_tag(
        cost_mode=str(args.cost_mode),
        tcost_bps=float(args.tcost_bps),
        eta=float(args.eta),
    )
    return (
        f"{n_ativos}atv_{uni}{window.start_y}{window.start_m:02d}_"
        f"{window.end_y}{window.end_m:02d}_{reb_tag(args.rebalance_freq)}_"
        f"{t_tag}_{ir_tag}{engine_suffix(args.engine)}"
    )


def build_suffix_vw(
    *,
    n_ativos: int,
    window: PeriodWindow,
    args: argparse.Namespace,
    apply_ir: bool,
) -> str:
    """VW sempre buy-and-hold; mesmo custo/IR/motor do 1/N.

    Sufixos: ``…_buyhold_…_ir_vw`` (v4) ou ``…_buyhold_…_ir_v41_vw`` (v4.1).
    """
    ir_tag = "ir" if apply_ir else "noir"
    uni = f"{args.universo_tag}_" if args.universo_tag else ""
    t_tag = cost_tag(
        cost_mode=str(args.cost_mode),
        tcost_bps=float(args.tcost_bps),
        eta=float(args.eta),
    )
    return (
        f"{n_ativos}atv_{uni}{window.start_y}{window.start_m:02d}_"
        f"{window.end_y}{window.end_m:02d}_{reb_tag('buyhold')}_"
        f"{t_tag}_{ir_tag}{engine_suffix(args.engine)}_vw"
    )


def paired_1n_vs_vw_row(
    db,
    *,
    suffix_ew: str,
    suffix_vw: str,
    metrics: Sequence[ComVsSemMetric],
    allow_missing: bool,
) -> Dict[str, object]:
    aux_fields = sorted({m.key for m in metrics if m.source == "aux"})
    nan_out = {
        "N_par": 0,
        "delta_final_wealth_brl": np.nan,
        "delta_sharpe_excess": np.nan,
        "win_final_wealth_brl": np.nan,
        "win_sharpe_excess": np.nan,
    }
    try:
        df_ew = _load_aux_metrics_by_strategy(db, suffix_ew, aux_fields)
        df_vw = _load_aux_metrics_by_strategy(db, suffix_vw, aux_fields)
    except RuntimeError as exc:
        if allow_missing:
            return {**nan_out, "_missing": str(exc)}
        raise

    out: Dict[str, object] = {"N_par": 0}
    paired_n: Optional[int] = None
    for metric in metrics:
        column = _pick_metric_column(df_ew, metric)
        if column is None or column not in df_vw.columns:
            if allow_missing:
                out[f"delta_{metric.key}"] = np.nan
                out[f"win_{metric.key}"] = np.nan
                continue
            raise RuntimeError(
                f"Coluna {metric.key!r} ausente em aux_metrics 1/N vs VW "
                f"({suffix_ew} / {suffix_vw})."
            )
        # com = 1/N, sem = VW → Δ = média(1/N − VW)
        summary = _paired_com_vs_sem_row(df_ew[column], df_vw[column], metric)
        if paired_n is None and summary["n"] > 0:
            paired_n = summary["n"]
        out[f"delta_{metric.key}"] = summary["Diferença Médias"]
        out[f"win_{metric.key}"] = summary["winrate"]
    out["N_par"] = paired_n or 0
    return out


def build_table(db, args: argparse.Namespace) -> pd.DataFrame:
    metrics = COMPARE_METRICS
    rows: List[Dict[str, object]] = []
    ir_modes = resolve_ir_modes(args.ir)
    if len(ir_modes) != 1:
        raise RuntimeError(
            "Esta tabela consolida um único modo de IR por execução; "
            "use --ir sim ou --ir nao."
        )
    apply_ir = ir_modes[0]
    windows = resolve_period_windows(args)
    if not args.quiet:
        eng = str(args.engine).lower()
        delist_txt = (
            "top-up (v4.1)" if eng == "v41" else "reset 1/N na deslistagem (v4)"
        )
        print(
            f"[1N vs VW] engine={eng} | deslistagem={delist_txt} | "
            f"1/N H={args.rebalance_freq} | VW=buyhold | cost={args.cost_mode}",
            flush=True,
        )
        if eng == "v41":
            print(
                "AVISO: o lado VW exige collections *_v41_vw "
                "(mesmo tratamento de deslistagem do EW v4.1). "
                "Se só existirem *_vw (vw_v4), use --engine v4 ou rode o motor VW v4.1.",
                flush=True,
            )

    for window in windows:
        for n_ativos in args.ativos:
            suffix_ew = build_suffix_ew(
                n_ativos=n_ativos,
                window=window,
                args=args,
                apply_ir=apply_ir,
            )
            suffix_vw = build_suffix_vw(
                n_ativos=n_ativos,
                window=window,
                args=args,
                apply_ir=apply_ir,
            )
            row = paired_1n_vs_vw_row(
                db,
                suffix_ew=suffix_ew,
                suffix_vw=suffix_vw,
                metrics=metrics,
                allow_missing=bool(args.allow_missing),
            )
            rows.append(
                {
                    "Período": window.label,
                    "N": int(n_ativos),
                    "N_par": int(row["N_par"]),
                    "Δ Patrimônio final (R$)": row["delta_final_wealth_brl"],
                    "Δ Sharpe exc.": row["delta_sharpe_excess"],
                    "win Patrim. (%)": row["win_final_wealth_brl"],
                    "win Sharpe (%)": row["win_sharpe_excess"],
                    "_suffix_ew": suffix_ew,
                    "_suffix_vw": suffix_vw,
                    "_engine": str(args.engine),
                }
            )
            if not args.quiet:
                missing = row.get("_missing")
                note = f" | MISSING: {missing}" if missing else ""
                print(
                    f"{window.label} N={n_ativos}: N_par={row['N_par']} "
                    f"| 1/N={suffix_ew} | VW={suffix_vw}{note}",
                    flush=True,
                )

    table = pd.DataFrame(rows)
    period_order = {"2001-2025": 0, "2006-2025": 1, "2011-2025": 2}
    table["_period_order"] = table["Período"].map(period_order)
    table = (
        table.sort_values(["_period_order", "N"])
        .drop(columns=["_period_order"])
        .reset_index(drop=True)
    )
    return table


def _fmt_num(value: object, ndigits: int = 2) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "---"
    return f"{float(value):.{ndigits}f}"


def _fmt_brl(value: object) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "---"
    # Inteiro com milhar em espaço fino LaTeX (ex.: 31\,641), como nas tabelas de patrimônio.
    return f"{float(value):,.0f}".replace(",", r"\,")


def _cost_label(args: argparse.Namespace) -> str:
    mode = str(args.cost_mode).lower()
    if mode == "flat":
        return f"custo proporcional de {float(args.tcost_bps):g} bps"
    if mode == "gross":
        return "gross (sem custo de transação)"
    if mode == "barra":
        return f"barra $\\eta={float(args.eta):.4g}$"
    if mode == "flat_barra":
        return f"flat\\_barra {float(args.tcost_bps):g} bps + BARRA raw"
    if mode == "barra_raw":
        return "barra\\_raw"
    return mode


def _h_label(rebalance_freq: str) -> str:
    labels = {
        "annual": "anual",
        "semiannual": "semestral",
        "quarterly": "trimestral",
        "monthly": "mensal",
        "buyhold": "buy-and-hold",
    }
    return labels.get(str(rebalance_freq).lower(), str(rebalance_freq))


def write_latex(
    table: pd.DataFrame,
    path: Path,
    *,
    title: str,
    label: str,
    args: argparse.Namespace,
    ir: bool,
) -> None:
    lines: List[str] = [
        "% Gerado por mestrado_tabela_1n_vs_vw_consolidada.py",
        "% Requer: \\usepackage{booktabs}",
        "\\begin{table}[H]",
        "\\centering",
        f"\\caption{{{title}}}",
        f"\\label{{{label}}}",
        "\\footnotesize",
        "\\setlength{\\tabcolsep}{3pt}",
        "\\renewcommand{\\arraystretch}{1.12}",
        "\\begin{tabular}{@{}ccccccc@{}}",
        "\\toprule",
        "Período & $N$ & $N_{\\mathrm{par}}$ & "
        "\\shortstack{$\\Delta$ Patrimônio\\\\final (R\\$)} & "
        "\\shortstack{$\\Delta$ Sharpe\\\\exc.} & "
        "\\shortstack{win\\\\Patrim. (\\%)} & "
        "\\shortstack{win\\\\Sharpe (\\%)} \\\\",
        "\\midrule",
    ]

    prev_period: Optional[str] = None
    for _, row in table.iterrows():
        period = str(row["Período"])
        if prev_period is not None and period != prev_period:
            lines.append("\\midrule")
        prev_period = period
        lines.append(
            f"{period} & {int(row['N'])} & {int(row['N_par'])} & "
            f"{_fmt_brl(row['Δ Patrimônio final (R$)'])} & "
            f"{_fmt_num(row['Δ Sharpe exc.'], 2)} & "
            f"{_fmt_num(row['win Patrim. (%)'], 2)} & "
            f"{_fmt_num(row['win Sharpe (%)'], 2)} \\\\"
        )

    ir_txt = "imposto de renda de 15\\%" if ir else "sem IR"
    h_txt = _h_label(str(args.rebalance_freq))
    cost_txt = _cost_label(args)
    # No modo proporcional o rótulo já inclui "custo"; nos demais, prefixa-se.
    cost_clause = (
        cost_txt
        if str(args.cost_mode).lower() == "flat"
        else f"custo: {cost_txt}"
    )
    fonte = (
        r"\tabfonte{Fonte: Elaboração própria. Teste pareado por carteira "
        r"(mesma composição de ativos). $\Delta$ = média pareada "
        r"($1/N$ $-$ VW buy-and-hold). Taxa de vitória: percentual de carteiras "
        r"em que $1/N$ supera VW. "
        f"$1/N$: rebalanceamento {h_txt}; VW: buy-and-hold; "
        f"{cost_clause}; {ir_txt}.}}"
    )
    lines.extend(["\\bottomrule", "\\end{tabular}", fonte, "\\end{table}", ""])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def export_table(
    table: pd.DataFrame, args: argparse.Namespace
) -> Tuple[Path, Path, Path]:
    export_df = table.drop(columns=[c for c in table.columns if c.startswith("_")])
    csv_path = args.output_dir / f"{args.stem}.csv"
    tex_path = args.output_dir / f"{args.stem}.tex"
    xlsx_path = args.output_dir / f"{args.stem}.xlsx"
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if not args.no_csv:
        export_df.to_csv(csv_path, index=False, encoding="utf-8")
    if not args.no_latex:
        ir_modes = resolve_ir_modes(args.ir)
        write_latex(
            export_df,
            tex_path,
            title=args.title,
            label=args.label,
            args=args,
            ir=ir_modes[0],
        )
    if not args.no_xlsx:
        export_df.to_excel(xlsx_path, index=False, sheet_name="1N_vs_VW")
    return csv_path, tex_path, xlsx_path


def _matches_cost_ir_engine(
    name: str, args: argparse.Namespace, apply_ir: bool
) -> bool:
    if not name.startswith("aux_metrics_"):
        return False
    if args.universo_tag and f"_{args.universo_tag}_" not in name:
        return False
    t_tag = cost_tag(
        cost_mode=str(args.cost_mode),
        tcost_bps=float(args.tcost_bps),
        eta=float(args.eta),
    )
    ir_tag = "ir" if apply_ir else "noir"
    eng_sfx = engine_suffix(args.engine)
    # Evita falso positivo de flat (t12bps) em flat_barra (t12bps_barra_raw).
    # v4: …_t12bps_ir  / …_t12bps_ir_vw
    # v41: …_t12bps_ir_v41 / …_t12bps_ir_v41_vw
    needle = f"_{t_tag}_{ir_tag}{eng_sfx}"
    if eng_sfx == "":
        # Não confundir legado com v4.1 (…_ir_v41).
        if name.endswith("_v41") or name.endswith("_v41_vw"):
            return False
    return name.endswith(needle) or name.endswith(f"{needle}_vw")


def list_ew_vw_pairs(args: argparse.Namespace) -> None:
    """Lista pares 1/N (H da CLI) ↔ VW buy-and-hold."""
    names = set(list_liquidez_collections(args.mongo_uri, args.db_name))
    ir_modes = resolve_ir_modes(args.ir)
    apply_ir = ir_modes[0]
    windows = resolve_period_windows(args)
    print(
        f"# engine={args.engine} | 1/N H={args.rebalance_freq} | VW=buyhold | "
        f"pares: aux_metrics_{{ew}} ↔ aux_metrics_{{vw_buyhold}}",
        flush=True,
    )
    n_ok = 0
    for window in windows:
        for n_ativos in args.ativos:
            suffix_ew = build_suffix_ew(
                n_ativos=n_ativos,
                window=window,
                args=args,
                apply_ir=apply_ir,
            )
            suffix_vw = build_suffix_vw(
                n_ativos=n_ativos,
                window=window,
                args=args,
                apply_ir=apply_ir,
            )
            ew_name = f"aux_metrics_{suffix_ew}"
            vw_name = f"aux_metrics_{suffix_vw}"
            if not _matches_cost_ir_engine(ew_name, args, apply_ir):
                continue
            has_ew = ew_name in names
            has_vw = vw_name in names
            if has_ew and has_vw:
                mark = "OK"
                n_ok += 1
            elif has_ew and not has_vw:
                mark = "MISSING_VW"
            elif not has_ew and has_vw:
                mark = "MISSING_EW"
            else:
                mark = "MISSING_BOTH"
            print(f"{mark}\t{ew_name}\t{vw_name}")
    if n_ok == 0:
        print("(nenhum par completo casou com o filtro)", flush=True)


def main(argv: Optional[Sequence[str]] = None) -> Path:
    args = parse_args(argv)
    if args.list_collections:
        list_ew_vw_pairs(args)
        return args.output_dir

    client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=15000)
    try:
        db = client[args.db_name]
        table = build_table(db, args)
    finally:
        client.close()

    csv_path, tex_path, xlsx_path = export_table(table, args)
    if not args.quiet:
        print(f"engine: {args.engine}", flush=True)
        print(f"CSV : {csv_path}", flush=True)
        print(f"LaTeX: {tex_path}", flush=True)
        print(f"XLSX: {xlsx_path}", flush=True)
        print(f"Linhas: {len(table)}", flush=True)
    return tex_path


if __name__ == "__main__":
    main()
