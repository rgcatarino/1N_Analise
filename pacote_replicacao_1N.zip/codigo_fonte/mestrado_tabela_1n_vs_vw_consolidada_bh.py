"""Tabela 1/N vs VW com o canal de ponderação (1/N buy-and-hold − VW buy-and-hold).

Estende ``mestrado_tabela_1n_vs_vw_consolidada.py``. Cada linha continua a
reportar o contraste da CLI (1/N no H pedido − VW buy-and-hold) e acrescenta,
nas mesmas carteiras, o contraste em que os dois lados são buy-and-hold:

- patrimônio final (``final_wealth_brl``);
- Sharpe em excesso (``sharpe_excess``);
- win rate de cada métrica;
- ``N_par`` do pareamento buy-and-hold.

O lado VW permanece buy-and-hold nos dois blocos. O segundo bloco isola a
ponderação (pesos iguais versus capitalização) com o regime de manutenção
fixo. Cenário de custo e motor de deslistagem são os da CLI.

Saídas: CSV, LaTeX e XLSX em ``resultados/liquidez_1mm_1n_vs_vw/``.

Exemplo::

    cd ~/mestrado
    source .venv/bin/activate

    python3 codigo_fonte/mestrado_tabela_1n_vs_vw_consolidada_bh.py \\
      --universo-tag liq_1MM \\
      --cost-mode flat \\
      --tcost-bps 12 \\
      --rebalance-freq annual \\
      --engine v41 \\
      --ir sim
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import pandas as pd
from pymongo import MongoClient

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

from mestrado_tabela_1n_vs_vw_consolidada import (  # noqa: E402
    COMPARE_METRICS,
    DEFAULT_OUTPUT_DIR,
    _cost_label,
    _fmt_brl,
    _fmt_num,
    _h_label,
    build_suffix_ew,
    build_suffix_vw,
    list_liquidez_collections,
    paired_1n_vs_vw_row,
    parse_args as _parse_base_args,
    resolve_ir_modes,
    resolve_period_windows,
)

DEFAULT_STEM = "1n_vs_vw_consolidado_com_bh"
DEFAULT_LABEL = "tab:1n_vs_vw_consolidado"
DEFAULT_TITLE = (
    "Comparativo $1/N$ (rebal.\\ anual e buy-and-hold) vs.\\ VW "
    "(buy-and-hold) --- patrimônio final e Sharpe em excesso "
    "(diferenças pareadas por período e número de ativos)"
)

COL_NPAR = "N_par"
COL_NPAR_BH = "N_par BH"
COL_DW = "Δ Patrimônio final (R$)"
COL_DS = "Δ Sharpe exc."
COL_WW = "win Patrim. (%)"
COL_WS = "win Sharpe (%)"
COL_DW_BH = "Δ Patrimônio BH (R$)"
COL_DS_BH = "Δ Sharpe exc. BH"
COL_WW_BH = "win Patrim. BH (%)"
COL_WS_BH = "win Sharpe BH (%)"


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    """Mesmos argumentos da tabela base, com stem/título do contraste B&H."""
    base = _parse_base_args([])
    raw = list(argv) if argv is not None else None
    args = _parse_base_args(raw)
    tokens = set(raw if raw is not None else sys.argv[1:])
    if "--stem" not in tokens:
        args.stem = DEFAULT_STEM
    if "--label" not in tokens:
        args.label = DEFAULT_LABEL
    if "--title" not in tokens:
        args.title = DEFAULT_TITLE
    if args.output_dir == base.output_dir:
        args.output_dir = DEFAULT_OUTPUT_DIR
    return args


def _args_buyhold(args: argparse.Namespace) -> argparse.Namespace:
    clone = argparse.Namespace(**vars(args))
    clone.rebalance_freq = "buyhold"
    return clone


def build_table(db, args: argparse.Namespace) -> pd.DataFrame:
    metrics = COMPARE_METRICS
    rows: List[Dict[str, object]] = []
    ir_modes = resolve_ir_modes(args.ir)
    if len(ir_modes) != 1:
        raise RuntimeError(
            "Esta tabela consolida um único modo de IR por execução; "
            "use --ir sim ou --ir nao."
        )
    apply_ir = ir_modes[0]
    windows = resolve_period_windows(args)
    args_bh = _args_buyhold(args)
    same_regime = str(args.rebalance_freq).lower() == "buyhold"
    if not args.quiet:
        eng = str(args.engine).lower()
        delist_txt = (
            "top-up (v4.1)" if eng == "v41" else "reset 1/N na deslistagem (v4)"
        )
        print(
            f"[1N vs VW + BH] engine={eng} | deslistagem={delist_txt} | "
            f"1/N H={args.rebalance_freq} | 1/N BH=buyhold | VW=buyhold | "
            f"cost={args.cost_mode}",
            flush=True,
        )

    for window in windows:
        for n_ativos in args.ativos:
            suffix_ew = build_suffix_ew(
                n_ativos=n_ativos,
                window=window,
                args=args,
                apply_ir=apply_ir,
            )
            suffix_vw = build_suffix_vw(
                n_ativos=n_ativos,
                window=window,
                args=args,
                apply_ir=apply_ir,
            )
            suffix_ew_bh = build_suffix_ew(
                n_ativos=n_ativos,
                window=window,
                args=args_bh,
                apply_ir=apply_ir,
            )
            row = paired_1n_vs_vw_row(
                db,
                suffix_ew=suffix_ew,
                suffix_vw=suffix_vw,
                metrics=metrics,
                allow_missing=bool(args.allow_missing),
            )
            if same_regime:
                row_bh = row
            else:
                row_bh = paired_1n_vs_vw_row(
                    db,
                    suffix_ew=suffix_ew_bh,
                    suffix_vw=suffix_vw,
                    metrics=metrics,
                    allow_missing=bool(args.allow_missing),
                )
            rows.append(
                {
                    "Período": window.label,
                    "N": int(n_ativos),
                    COL_NPAR: int(row["N_par"]),
                    COL_DW: row["delta_final_wealth_brl"],
                    COL_DS: row["delta_sharpe_excess"],
                    COL_WW: row["win_final_wealth_brl"],
                    COL_WS: row["win_sharpe_excess"],
                    COL_NPAR_BH: int(row_bh["N_par"]),
                    COL_DW_BH: row_bh["delta_final_wealth_brl"],
                    COL_DS_BH: row_bh["delta_sharpe_excess"],
                    COL_WW_BH: row_bh["win_final_wealth_brl"],
                    COL_WS_BH: row_bh["win_sharpe_excess"],
                    "_suffix_ew": suffix_ew,
                    "_suffix_ew_bh": suffix_ew_bh,
                    "_suffix_vw": suffix_vw,
                    "_engine": str(args.engine),
                }
            )
            if not args.quiet:
                missing = row.get("_missing")
                missing_bh = None if same_regime else row_bh.get("_missing")
                note = f" | MISSING H: {missing}" if missing else ""
                note_bh = f" | MISSING BH: {missing_bh}" if missing_bh else ""
                print(
                    f"{window.label} N={n_ativos}: "
                    f"N_par={row['N_par']} N_par_BH={row_bh['N_par']} "
                    f"| 1/N={suffix_ew} | 1/N BH={suffix_ew_bh} | "
                    f"VW={suffix_vw}{note}{note_bh}",
                    flush=True,
                )

    table = pd.DataFrame(rows)
    period_order = {"2001-2025": 0, "2006-2025": 1, "2011-2025": 2}
    table["_period_order"] = table["Período"].map(period_order)
    table = (
        table.sort_values(["_period_order", "N"])
        .drop(columns=["_period_order"])
        .reset_index(drop=True)
    )
    return table


def _bh_block_header(rebalance_freq: str) -> str:
    if str(rebalance_freq).lower() == "buyhold":
        return r"$1/N$ B\&H $-$ VW B\&H"
    h_txt = _h_label(rebalance_freq)
    return rf"$1/N$ {h_txt} $-$ VW B\&H"


def _npar_diverges(table: pd.DataFrame) -> bool:
    return bool((table[COL_NPAR] != table[COL_NPAR_BH]).any())


def write_latex(
    table: pd.DataFrame,
    path: Path,
    *,
    title: str,
    label: str,
    args: argparse.Namespace,
    ir: bool,
) -> None:
    show_npar_bh = _npar_diverges(table)
    # Período, N, N_par | 4 métricas do H | [N_par BH] + 4 métricas B&H
    n_h = 4
    n_prefix = 3
    h_start = n_prefix + 1
    h_end = n_prefix + n_h
    bh_width = n_h + (1 if show_npar_bh else 0)
    bh_start = h_end + 1
    bh_end = h_end + bh_width
    ncols = bh_end
    colspec = "c" * ncols

    metric_heads = (
        r"\shortstack{$\Delta$ Patrim.\\(R\$)} & "
        r"\shortstack{$\Delta$ Sharpe\\exc.} & "
        r"\shortstack{win\\Patrim.\ (\%)} & "
        r"\shortstack{win\\Sharpe\ (\%)}"
    )
    if show_npar_bh:
        second = rf"$N_{{\mathrm{{par}}}}$ & {metric_heads}"
    else:
        second = metric_heads

    lines: List[str] = [
        "% Gerado por mestrado_tabela_1n_vs_vw_consolidada_bh.py",
        "% Requer: \\usepackage{booktabs}, \\usepackage{graphicx}",
        "\\begin{table}[H]",
        "\\centering",
        f"\\caption{{{title}}}",
        f"\\label{{{label}}}",
        "\\footnotesize",
        "\\setlength{\\tabcolsep}{2.5pt}",
        "\\renewcommand{\\arraystretch}{1.12}",
        "\\resizebox{\\textwidth}{!}{%",
        f"\\begin{{tabular}}{{@{{}}{colspec}@{{}}}}",
        "\\toprule",
        (
            f"& & & \\multicolumn{{{n_h}}}{{c}}{{{_bh_block_header(args.rebalance_freq)}}} & "
            f"\\multicolumn{{{bh_width}}}{{c}}"
            r"{$1/N$ B\&H $-$ VW B\&H} \\"
        ),
        (
            f"\\cmidrule(lr){{{h_start}-{h_end}}} "
            f"\\cmidrule(lr){{{bh_start}-{bh_end}}}"
        ),
        (
            r"Período & $N$ & $N_{\mathrm{par}}$ & "
            f"{metric_heads} & {second} \\\\"
        ),
        "\\midrule",
    ]

    prev_period: Optional[str] = None
    for _, row in table.iterrows():
        period = str(row["Período"])
        if prev_period is not None and period != prev_period:
            lines.append("\\midrule")
        prev_period = period
        cells = [
            period,
            str(int(row["N"])),
            str(int(row[COL_NPAR])),
            _fmt_brl(row[COL_DW]),
            _fmt_num(row[COL_DS], 2),
            _fmt_num(row[COL_WW], 2),
            _fmt_num(row[COL_WS], 2),
        ]
        if show_npar_bh:
            cells.append(str(int(row[COL_NPAR_BH])))
        cells.extend(
            [
                _fmt_brl(row[COL_DW_BH]),
                _fmt_num(row[COL_DS_BH], 2),
                _fmt_num(row[COL_WW_BH], 2),
                _fmt_num(row[COL_WS_BH], 2),
            ]
        )
        lines.append(" & ".join(cells) + r" \\")

    ir_txt = "imposto de renda de 15\\%" if ir else "sem IR"
    h_txt = _h_label(str(args.rebalance_freq))
    if str(args.rebalance_freq).lower() == "buyhold":
        regime_h = "buy-and-hold"
    else:
        regime_h = f"rebalanceamento {h_txt}"
    cost_txt = _cost_label(args)
    cost_clause = (
        cost_txt
        if str(args.cost_mode).lower() == "flat"
        else f"custo: {cost_txt}"
    )
    npar_note = (
        r" $N_{\mathrm{par}}$ do bloco buy-and-hold difere em ao menos uma célula "
        r"e aparece na coluna própria. "
        if show_npar_bh
        else r" $N_{\mathrm{par}}$ é o mesmo nos dois pareamentos. "
    )
    fonte = (
        r"\tabfonte{Fonte: Elaboração própria. Teste pareado por carteira "
        r"(mesma composição de ativos). "
        rf"Bloco $1/N$ {h_txt} $-$ VW B\&H: $\Delta$ = média pareada "
        rf"($1/N$ com {regime_h} $-$ VW buy-and-hold). "
        r"Bloco $1/N$ B\&H $-$ VW B\&H: $\Delta$ = média pareada "
        r"($1/N$ buy-and-hold $-$ VW buy-and-hold), com o regime de "
        r"manutenção fixo. "
        r"Taxa de vitória: percentual de carteiras em que o lado $1/N$ supera a VW. "
        f"{npar_note}"
        f"VW: buy-and-hold; {cost_clause}; {ir_txt}.}}"
    )
    lines.extend(
        [
            "\\bottomrule",
            "\\end{tabular}%",
            "}",
            fonte,
            "\\end{table}",
            "",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def export_table(
    table: pd.DataFrame, args: argparse.Namespace
) -> Tuple[Path, Path, Path]:
    export_df = table.drop(columns=[c for c in table.columns if str(c).startswith("_")])
    csv_path = args.output_dir / f"{args.stem}.csv"
    tex_path = args.output_dir / f"{args.stem}.tex"
    xlsx_path = args.output_dir / f"{args.stem}.xlsx"
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if not args.no_csv:
        export_df.to_csv(csv_path, index=False, encoding="utf-8")
    if not args.no_latex:
        ir_modes = resolve_ir_modes(args.ir)
        write_latex(
            export_df,
            tex_path,
            title=args.title,
            label=args.label,
            args=args,
            ir=ir_modes[0],
        )
    if not args.no_xlsx:
        export_df.to_excel(xlsx_path, index=False, sheet_name="1N_vs_VW_BH")
    return csv_path, tex_path, xlsx_path


def list_ew_vw_bh_pairs(args: argparse.Namespace) -> None:
    """Lista trios 1/N (H da CLI), 1/N buy-and-hold e VW buy-and-hold."""
    names = set(list_liquidez_collections(args.mongo_uri, args.db_name))
    ir_modes = resolve_ir_modes(args.ir)
    apply_ir = ir_modes[0]
    windows = resolve_period_windows(args)
    args_bh = _args_buyhold(args)
    print(
        f"# engine={args.engine} | "
        f"1/N H={args.rebalance_freq} | 1/N BH=buyhold | VW=buyhold",
        flush=True,
    )
    n_ok = 0
    for window in windows:
        for n_ativos in args.ativos:
            suffix_ew = build_suffix_ew(
                n_ativos=n_ativos,
                window=window,
                args=args,
                apply_ir=apply_ir,
            )
            suffix_ew_bh = build_suffix_ew(
                n_ativos=n_ativos,
                window=window,
                args=args_bh,
                apply_ir=apply_ir,
            )
            suffix_vw = build_suffix_vw(
                n_ativos=n_ativos,
                window=window,
                args=args,
                apply_ir=apply_ir,
            )
            ew_name = f"aux_metrics_{suffix_ew}"
            bh_name = f"aux_metrics_{suffix_ew_bh}"
            vw_name = f"aux_metrics_{suffix_vw}"
            has = {
                "EW": ew_name in names,
                "BH": bh_name in names,
                "VW": vw_name in names,
            }
            if all(has.values()):
                mark = "OK"
                n_ok += 1
            else:
                missing = [k for k, ok in has.items() if not ok]
                mark = "MISSING_" + "+".join(missing)
            print(f"{mark}\t{ew_name}\t{bh_name}\t{vw_name}")
    if n_ok == 0:
        print("(nenhum trio completo casou com o filtro)", flush=True)


def main(argv: Optional[Sequence[str]] = None) -> Path:
    args = parse_args(argv)
    if args.list_collections:
        list_ew_vw_bh_pairs(args)
        return args.output_dir

    client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=15000)
    try:
        db = client[args.db_name]
        table = build_table(db, args)
    finally:
        client.close()

    csv_path, tex_path, xlsx_path = export_table(table, args)
    if not args.quiet:
        print(f"engine: {args.engine}", flush=True)
        print(f"CSV : {csv_path}", flush=True)
        print(f"LaTeX: {tex_path}", flush=True)
        print(f"XLSX: {xlsx_path}", flush=True)
        print(f"Linhas: {len(table)}", flush=True)
    return tex_path


if __name__ == "__main__":
    main()
