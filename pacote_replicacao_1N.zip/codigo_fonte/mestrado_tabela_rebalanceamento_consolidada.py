"""Tabela consolidada: comparativo com vs sem rebalanceamento (métricas em excesso).

Consolida, por período e número de ativos, as diferenças pareadas (com − sem)
e winrates nas três métricas em excesso:

- retorno total em excesso;
- Sharpe em excesso;
- volatilidade anual em excesso.

Por padrão lê collections ``aux_metrics_*_v41`` (motor v4.1 / top-up na
deslistagem). Use ``--engine v4`` para o legado sem sufixo ``_v41``.

Exemplo::

    cd ~/mestrado
    source .venv/bin/activate

    python3 codigo_fonte/mestrado_tabela_rebalanceamento_consolidada.py \\
      --universo-tag liq_1MM \\
      --tcost-bps 12 \\
      --ir sim \\
      --engine v41
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Set, Tuple

import numpy as np
import pandas as pd
from pymongo import MongoClient

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

from mestrado_resultados_simulador_pessoa_investidora import (  # noqa: E402
    COM_VS_SEM_METRICS,
    ComVsSemMetric,
    DEFAULT_MONGO_URI,
    _load_aux_metrics_by_strategy,
    _paired_com_vs_sem_row,
    _pick_metric_column,
)
from mestrado_resultados_simulador_pessoa_investidora_v2 import (  # noqa: E402
    DEFAULT_DB_LIQUIDEZ,
    liquidez_suffix,
    list_liquidez_collections,
)

DEFAULT_OUTPUT_DIR = REPO_ROOT / "resultados" / "liquidez_1mm_delist"
DEFAULT_ATIVOS = (8, 10, 12, 15, 20, 25, 30, 35, 40)
DEFAULT_PERIODS: Tuple[Tuple[str, int, int, int, int], ...] = (
    ("2001-2025", 2001, 7, 2025, 10),
    ("2006-2025", 2006, 7, 2025, 10),
    ("2011-2025", 2011, 7, 2025, 10),
)
DEFAULT_STEM = "rebalanceamento_consolidado_excesso"
DEFAULT_LABEL = "tab:rebalanceamento_consolidado_excesso"
DEFAULT_TITLE = (
    "Comparativo com vs.\\ sem rebalanceamento anual --- métricas em excesso "
    "(diferenças pareadas por período e número de ativos)"
)
ENGINE_CHOICES = ("v4", "v41", "all")

EXCESS_METRIC_KEYS = ("total_excess_return", "sharpe_excess", "vol_excess_ann")


@dataclass(frozen=True)
class PeriodWindow:
    label: str
    start_y: int
    start_m: int
    end_y: int
    end_m: int


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Gera tabela consolidada com vs sem rebalanceamento "
            "(métricas em excesso) por período e N."
        )
    )
    parser.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    parser.add_argument("--db-name", default=DEFAULT_DB_LIQUIDEZ)
    parser.add_argument(
        "--ativos",
        type=int,
        nargs="+",
        default=list(DEFAULT_ATIVOS),
        help="Números de ativos por carteira (default: 8..40)",
    )
    parser.add_argument(
        "--periodos",
        nargs="*",
        default=None,
        help="Rótulos de período (ex.: 2001-2025). Default: os três horizontes.",
    )
    parser.add_argument("--start-m", type=int, default=7)
    parser.add_argument("--end-y", type=int, default=2025)
    parser.add_argument("--end-m", type=int, default=10)
    parser.add_argument("--universo-tag", default="liq_1MM")
    parser.add_argument("--tcost-bps", type=float, default=12.0)
    parser.add_argument(
        "--ir",
        choices=("sim", "nao", "ambos"),
        default="sim",
        help="Modo de IR (default: sim)",
    )
    parser.add_argument("--rebalance-freq", default="annual")
    parser.add_argument("--sem-reb-tag", default="buyhold")
    parser.add_argument(
        "--engine",
        choices=ENGINE_CHOICES,
        default="v41",
        help=(
            "Motor das collections aux_metrics_*: "
            "v41 = sufixo *_v41 (default); v4 = legado; "
            "all = prefere v41 se existir, senão legado."
        ),
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--stem", default=DEFAULT_STEM)
    parser.add_argument("--label", default=DEFAULT_LABEL)
    parser.add_argument("--title", default=DEFAULT_TITLE)
    parser.add_argument(
        "--allow-missing",
        action="store_true",
        default=True,
        help="Segue com collections ausentes (células ---; default).",
    )
    parser.add_argument(
        "--require-all",
        dest="allow_missing",
        action="store_false",
        help="Falha se alguma collection solicitada não existir.",
    )
    parser.add_argument("--no-csv", action="store_true")
    parser.add_argument("--no-latex", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument(
        "--list-collections",
        action="store_true",
        help="Lista collections aux_metrics com/sem reb no banco e sai.",
    )
    return parser.parse_args(list(argv) if argv is not None else None)


def resolve_ir_modes(raw: str) -> Tuple[bool, ...]:
    if raw == "sim":
        return (True,)
    if raw == "nao":
        return (False,)
    return (False, True)


def resolve_period_windows(args: argparse.Namespace) -> Tuple[PeriodWindow, ...]:
    if args.periodos:
        lookup = {p.label: p for p in _default_period_windows(args)}
        windows: List[PeriodWindow] = []
        for label in args.periodos:
            if label not in lookup:
                raise RuntimeError(
                    f"Período desconhecido: {label!r}. "
                    f"Disponíveis: {sorted(lookup)}"
                )
            windows.append(lookup[label])
        return tuple(windows)
    return _default_period_windows(args)


def _default_period_windows(args: argparse.Namespace) -> Tuple[PeriodWindow, ...]:
    return tuple(
        PeriodWindow(label, sy, sm, args.end_y, args.end_m)
        for label, sy, sm, _, _ in DEFAULT_PERIODS
    )


def excess_metrics() -> Tuple[ComVsSemMetric, ...]:
    by_key = {m.key: m for m in COM_VS_SEM_METRICS}
    missing = [k for k in EXCESS_METRIC_KEYS if k not in by_key]
    if missing:
        raise RuntimeError(f"Métricas ausentes em COM_VS_SEM_METRICS: {missing}")
    return tuple(by_key[k] for k in EXCESS_METRIC_KEYS)


def engine_suffix(engine: str) -> str:
    """Sufixo Mongo do motor: v4.1 grava ``_v41``; v4 omite."""
    eng = str(engine).lower()
    if eng == "v41":
        return "_v41"
    if eng == "v4":
        return ""
    raise ValueError(f"engine inválido para sufixo fixo: {engine!r}")


def build_base_suffix(
    *,
    n_ativos: int,
    window: PeriodWindow,
    rebalance: bool,
    args: argparse.Namespace,
    apply_ir: bool,
) -> str:
    return liquidez_suffix(
        n_ativos=n_ativos,
        start_y=window.start_y,
        start_m=window.start_m,
        end_y=window.end_y,
        end_m=window.end_m,
        rebalance=rebalance,
        rebalance_freq=args.rebalance_freq,
        tcost_bps=args.tcost_bps,
        apply_stock_ir=apply_ir,
        universo_tag=args.universo_tag,
        sem_reb_tag=args.sem_reb_tag,
    )


def resolve_suffix(
    base: str,
    *,
    engine: str,
    available: Optional[Set[str]] = None,
) -> str:
    """Anexa ``_v41`` conforme ``engine``; em ``all`` prefere v41 se existir."""
    eng = str(engine or "v41").lower()
    v41 = f"{base}_v41"
    if eng == "all":
        if available is None or f"aux_metrics_{v41}" in available:
            return v41
        return base
    return f"{base}{engine_suffix(eng)}"


def build_suffix(
    *,
    n_ativos: int,
    window: PeriodWindow,
    rebalance: bool,
    args: argparse.Namespace,
    apply_ir: bool,
    available: Optional[Set[str]] = None,
) -> str:
    base = build_base_suffix(
        n_ativos=n_ativos,
        window=window,
        rebalance=rebalance,
        args=args,
        apply_ir=apply_ir,
    )
    return resolve_suffix(
        base,
        engine=str(getattr(args, "engine", "v41")),
        available=available,
    )


def paired_excess_row(
    db,
    *,
    suffix_com: str,
    suffix_sem: str,
    metrics: Sequence[ComVsSemMetric],
    allow_missing: bool,
) -> Dict[str, object]:
    aux_fields = sorted({m.key for m in metrics if m.source == "aux"})
    try:
        df_com = _load_aux_metrics_by_strategy(db, suffix_com, aux_fields)
        df_sem = _load_aux_metrics_by_strategy(db, suffix_sem, aux_fields)
    except RuntimeError as exc:
        if allow_missing:
            return {
                "N_par": 0,
                "delta_total_excess_return": np.nan,
                "delta_sharpe_excess": np.nan,
                "delta_vol_excess_ann": np.nan,
                "win_total_excess_return": np.nan,
                "win_sharpe_excess": np.nan,
                "win_vol_excess_ann": np.nan,
                "_missing": str(exc),
            }
        raise

    out: Dict[str, object] = {"N_par": 0}
    paired_n: Optional[int] = None
    for metric in metrics:
        column = _pick_metric_column(df_com, metric)
        if column is None or column not in df_sem.columns:
            if allow_missing:
                out[f"delta_{metric.key}"] = np.nan
                out[f"win_{metric.key}"] = np.nan
                continue
            raise RuntimeError(
                f"Coluna {metric.key!r} ausente em aux_metrics com/sem reb "
                f"({suffix_com} / {suffix_sem})."
            )
        summary = _paired_com_vs_sem_row(df_com[column], df_sem[column], metric)
        if paired_n is None and summary["n"] > 0:
            paired_n = summary["n"]
        out[f"delta_{metric.key}"] = summary["Diferença Médias"]
        out[f"win_{metric.key}"] = summary["winrate"]
    out["N_par"] = paired_n or 0
    return out


def build_table(db, args: argparse.Namespace) -> pd.DataFrame:
    metrics = excess_metrics()
    rows: List[Dict[str, object]] = []
    ir_modes = resolve_ir_modes(args.ir)
    if len(ir_modes) != 1:
        raise RuntimeError(
            "Esta tabela consolida um único modo de IR por execução; "
            "use --ir sim ou --ir nao."
        )
    apply_ir = ir_modes[0]
    windows = resolve_period_windows(args)
    available: Optional[Set[str]] = None
    if str(getattr(args, "engine", "v41")).lower() == "all":
        available = set(db.list_collection_names())

    for window in windows:
        for n_ativos in args.ativos:
            suffix_com = build_suffix(
                n_ativos=n_ativos,
                window=window,
                rebalance=True,
                args=args,
                apply_ir=apply_ir,
                available=available,
            )
            suffix_sem = build_suffix(
                n_ativos=n_ativos,
                window=window,
                rebalance=False,
                args=args,
                apply_ir=apply_ir,
                available=available,
            )
            row = paired_excess_row(
                db,
                suffix_com=suffix_com,
                suffix_sem=suffix_sem,
                metrics=metrics,
                allow_missing=bool(args.allow_missing),
            )
            rows.append(
                {
                    "Período": window.label,
                    "N": int(n_ativos),
                    "N_par": int(row["N_par"]),
                    "Δ Ret. total exc. (%)": row["delta_total_excess_return"],
                    "Δ Sharpe exc.": row["delta_sharpe_excess"],
                    "Δ Vol. anual exc. (p.p.)": row["delta_vol_excess_ann"],
                    "win Ret. (%)": row["win_total_excess_return"],
                    "win Sharpe (%)": row["win_sharpe_excess"],
                    "win Vol. (%)": row["win_vol_excess_ann"],
                    "_suffix_com": suffix_com,
                    "_suffix_sem": suffix_sem,
                }
            )
            if not args.quiet:
                missing = row.get("_missing")
                note = f" | SKIP: {missing}" if missing else ""
                print(
                    f"{window.label} N={n_ativos}: N_par={row['N_par']} "
                    f"| com={suffix_com} | sem={suffix_sem}{note}",
                    flush=True,
                )

    table = pd.DataFrame(rows)
    period_order = {"2001-2025": 0, "2006-2025": 1, "2011-2025": 2}
    table["_period_order"] = table["Período"].map(period_order)
    table = (
        table.sort_values(["_period_order", "N"])
        .drop(columns=["_period_order"])
        .reset_index(drop=True)
    )
    return table


def _fmt_num(value: object, ndigits: int = 2) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "---"
    return f"{float(value):.{ndigits}f}"


def write_latex(
    table: pd.DataFrame,
    path: Path,
    *,
    title: str,
    label: str,
    tcost_bps: float,
    ir: bool,
) -> None:
    lines: List[str] = [
        "% Gerado por mestrado_tabela_rebalanceamento_consolidada.py",
        "% Requer: \\usepackage{booktabs}",
        "\\begin{table}[H]",
        "\\centering",
        f"\\caption{{{title}}}",
        f"\\label{{{label}}}",
        "\\footnotesize",
        "\\setlength{\\tabcolsep}{3pt}",
        "\\renewcommand{\\arraystretch}{1.12}",
        "\\begin{tabular}{@{}llrrrrrrr@{}}",
        "\\toprule",
        "Período & $N$ & $N_{\\mathrm{par}}$ & "
        "\\shortstack{$\\Delta$ Ret.\\\\total exc. (\\%)} & "
        "\\shortstack{$\\Delta$ Sharpe\\\\exc.} & "
        "\\shortstack{$\\Delta$ Vol.\\\\exc. (p.p.)} & "
        "\\shortstack{win\\\\Ret. (\\%)} & "
        "\\shortstack{win\\\\Sharpe (\\%)} & "
        "\\shortstack{win\\\\Vol. (\\%)} \\\\",
        "\\midrule",
    ]

    prev_period: Optional[str] = None
    for _, row in table.iterrows():
        period = str(row["Período"])
        if prev_period is not None and period != prev_period:
            lines.append("\\midrule")
        prev_period = period
        lines.append(
            f"{period} & {int(row['N'])} & {int(row['N_par'])} & "
            f"{_fmt_num(row['Δ Ret. total exc. (%)'], 2)} & "
            f"{_fmt_num(row['Δ Sharpe exc.'], 2)} & "
            f"{_fmt_num(row['Δ Vol. anual exc. (p.p.)'], 2)} & "
            f"{_fmt_num(row['win Ret. (%)'], 2)} & "
            f"{_fmt_num(row['win Sharpe (%)'], 2)} & "
            f"{_fmt_num(row['win Vol. (%)'], 2)} \\\\"
        )

    ir_txt = "imposto de renda de 15\\%" if ir else "sem IR"
    fonte = (
        r"\tabfonte{Fonte: Elaboração própria. Teste pareado por carteira "
        r"(mesma composição de ativos). $\Delta$ = média pareada "
        r"(com rebalanceamento $-$ buy-and-hold). "
        r"Com rebalanceamento: anual em julho, "
        f"{tcost_bps:g} bps, {ir_txt}. "
        r"Sem rebalanceamento: buy-and-hold.}"
    )
    lines.extend(["\\bottomrule", "\\end{tabular}", fonte, "\\end{table}", ""])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def export_table(table: pd.DataFrame, args: argparse.Namespace) -> Tuple[Path, Path]:
    export_df = table.drop(columns=[c for c in table.columns if c.startswith("_")])
    csv_path = args.output_dir / f"{args.stem}.csv"
    tex_path = args.output_dir / f"{args.stem}.tex"
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if not args.no_csv:
        export_df.to_csv(csv_path, index=False, encoding="utf-8")
    if not args.no_latex:
        ir_modes = resolve_ir_modes(args.ir)
        write_latex(
            export_df,
            tex_path,
            title=args.title,
            label=args.label,
            tcost_bps=float(args.tcost_bps),
            ir=ir_modes[0],
        )
    return csv_path, tex_path


def _list_collections_match(name: str, args: argparse.Namespace) -> bool:
    if not ("buyhold" in name or "reb-annual" in name or f"reb-{args.rebalance_freq}" in name):
        return False
    if f"t{int(round(args.tcost_bps))}bps" not in name:
        return False
    eng = str(getattr(args, "engine", "v41")).lower()
    is_v41 = name.endswith("_v41") or "_v41_" in name
    if eng == "v41":
        return is_v41
    if eng == "v4":
        return not is_v41
    return True


def main(argv: Optional[Sequence[str]] = None) -> Path:
    args = parse_args(argv)
    if args.list_collections:
        names = list_liquidez_collections(args.mongo_uri, args.db_name)
        for name in names:
            if _list_collections_match(name, args):
                print(name)
        return args.output_dir

    if not args.quiet:
        print(f"engine: {args.engine}", flush=True)

    client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=15000)
    try:
        db = client[args.db_name]
        table = build_table(db, args)
    finally:
        client.close()

    csv_path, tex_path = export_table(table, args)
    if not args.quiet:
        print(f"CSV : {csv_path}", flush=True)
        print(f"LaTeX: {tex_path}", flush=True)
        print(f"Linhas: {len(table)}", flush=True)
    return tex_path


if __name__ == "__main__":
    main()
