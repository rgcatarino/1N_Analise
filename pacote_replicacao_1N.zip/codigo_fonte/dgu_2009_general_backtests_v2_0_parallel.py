#!/usr/bin/env python3
"""Backtests rolling DGU (2009) — processamento paralelo em lotes.

Versão paralela de ``dgu_2009_general_backtests_v2_0.py``. Processa carteiras
em lotes (default: 10) com múltiplos processos (default: 10 workers), útil
para acelerar grandes volumes de bases CSV.

Exemplos:
    # Lote paralelo (10 carteiras por vez, 10 workers)
    python codigo_fonte/dgu_2009_general_backtests_v2_0_parallel.py \\
        --bases-dir bases_dgu/2001_2025 \\
        --output-dir resultados/dgu_backtest/2001_2025 \\
        --start 2001-01-04 --end 2025-11-30

    # Uma carteira (sem paralelismo)
    python codigo_fonte/dgu_2009_general_backtests_v2_0_parallel.py \\
        --input-file bases_dgu/2001_2025/B3_aleatoria_N10_s15_00001.csv \\
        --output-dir resultados/dgu_backtest/2001_2025

    # Lotes de 10, mas apenas 4 workers (máquina com menos CPUs)
    python codigo_fonte/dgu_2009_general_backtests_v2_0_parallel.py \\
        --bases-dir bases_dgu/2001_2025 \\
        --output-dir resultados/dgu_backtest/2001_2025 \\
        --batch-size 10 --workers 4
"""

from __future__ import annotations

import argparse
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Sequence

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import dgu_2009_general_backtests_v2_0 as dgu_bt  # noqa: E402

DEFAULT_WORKERS = 10
DEFAULT_BATCH_SIZE = 10


@dataclass(frozen=True)
class PortfolioJob:
    path: str
    dgu_module: str
    start: str
    end: str
    output_dir: str
    processed_dir: str | None
    error_dir: str | None
    M: int
    cost_bps: float


def _process_portfolio_job(job: PortfolioJob) -> dict:
    """Worker executado em processo filho (deve ser função de topo)."""
    path = Path(job.path)
    t0 = time.perf_counter()
    try:
        dgu = dgu_bt.load_dgu_module(Path(job.dgu_module))
        dgu_bt.process_local_file(
            path,
            dgu=dgu,
            base_id=None,
            start=job.start,
            end=job.end,
            output_dir=Path(job.output_dir),
            processed_dir=Path(job.processed_dir) if job.processed_dir else None,
            error_dir=Path(job.error_dir) if job.error_dir else None,
            M=job.M,
            cost_bps=job.cost_bps,
        )
        elapsed = time.perf_counter() - t0
        return {
            "path": str(path),
            "base_id": path.stem,
            "ok": True,
            "error": None,
            "elapsed_s": round(elapsed, 2),
        }
    except Exception as exc:
        elapsed = time.perf_counter() - t0
        return {
            "path": str(path),
            "base_id": path.stem,
            "ok": False,
            "error": f"{type(exc).__name__}: {exc}",
            "elapsed_s": round(elapsed, 2),
        }


def _chunked(items: Sequence[Path], batch_size: int) -> list[list[Path]]:
    if batch_size <= 0:
        raise ValueError("batch_size deve ser >= 1")
    return [list(items[i : i + batch_size]) for i in range(0, len(items), batch_size)]


def process_local_batch_parallel(
    bases_dir: Path,
    *,
    dgu_module: Path,
    start: str,
    end: str,
    output_dir: Path,
    processed_dir: Path | None,
    error_dir: Path | None,
    M: int,
    cost_bps: float,
    workers: int,
    batch_size: int,
    skip_existing: bool,
) -> tuple[int, int]:
    files = sorted(bases_dir.glob("*.csv"))
    if skip_existing:
        before = len(files)
        files = [
            path
            for path in files
            if not (output_dir / f"DGU_2009_{path.stem}_Summary_latest.csv").exists()
        ]
        skipped = before - len(files)
        if skipped:
            print(f"Pulando {skipped} carteira(s) com Summary_latest já existente.")

    total = len(files)
    print(f"Total de arquivos a processar: {total}")
    if total == 0:
        return 0, 0

    workers = max(1, workers)
    batches = _chunked(files, batch_size)
    print(f"Lotes: {len(batches)} | batch_size={batch_size} | workers={workers}")

    ok = 0
    errors = 0

    for batch_idx, batch in enumerate(batches, start=1):
        print(f"\n=== Lote {batch_idx}/{len(batches)} ({len(batch)} carteira(s)) ===")
        jobs = [
            PortfolioJob(
                path=str(path),
                dgu_module=str(dgu_module.resolve()),
                start=start,
                end=end,
                output_dir=str(output_dir.resolve()),
                processed_dir=str(processed_dir.resolve()) if processed_dir else None,
                error_dir=str(error_dir.resolve()) if error_dir else None,
                M=M,
                cost_bps=cost_bps,
            )
            for path in batch
        ]

        with ProcessPoolExecutor(max_workers=min(workers, len(batch))) as executor:
            futures = {executor.submit(_process_portfolio_job, job): job for job in jobs}
            for future in as_completed(futures):
                result = future.result()
                status = "OK" if result["ok"] else "ERRO"
                print(
                    f"  [{status}] {result['base_id']} "
                    f"({result['elapsed_s']}s)"
                    + (f" — {result['error']}" if result["error"] else "")
                )
                if result["ok"]:
                    ok += 1
                else:
                    errors += 1

    return ok, errors


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Backtests rolling DGU (2009) — processamento paralelo em lotes."
    )
    p.add_argument("--dgu-module", type=Path, default=dgu_bt.DEFAULT_DGU_MODULE)
    p.add_argument("--start", default=dgu_bt.DEFAULT_START)
    p.add_argument("--end", default=dgu_bt.DEFAULT_END)
    p.add_argument("--M", type=int, default=dgu_bt.DEFAULT_M)
    p.add_argument("--cost-bps", type=float, default=dgu_bt.DEFAULT_COST_BPS)
    p.add_argument("--output-dir", type=Path, default=dgu_bt.DEFAULT_OUTPUT_DIR)

    src = p.add_mutually_exclusive_group(required=False)
    src.add_argument("--input-file", type=Path, help="CSV único de base DGU")
    src.add_argument("--bases-dir", type=Path, help="Pasta com CSVs para processamento em lote")

    p.add_argument("--base-id", help="Identificador da base (somente com --input-file)")
    p.add_argument("--processed-dir", type=Path, help="Mover bases processadas com sucesso")
    p.add_argument("--error-dir", type=Path, help="Mover bases com erro + gravar log")

    p.add_argument(
        "--workers",
        type=int,
        default=DEFAULT_WORKERS,
        help=f"Processos paralelos por lote (default: {DEFAULT_WORKERS})",
    )
    p.add_argument(
        "--batch-size",
        type=int,
        default=DEFAULT_BATCH_SIZE,
        help=f"Carteiras por lote (default: {DEFAULT_BATCH_SIZE})",
    )
    p.add_argument(
        "--skip-existing",
        action="store_true",
        help="Pular carteiras cujo Summary_latest.csv já existe em --output-dir",
    )
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    if args.workers < 1:
        print("Erro: --workers deve ser >= 1", file=sys.stderr)
        return 1
    if args.batch_size < 1:
        print("Erro: --batch-size deve ser >= 1", file=sys.stderr)
        return 1

    print(
        f"Paralelo DGU | workers={args.workers} | batch_size={args.batch_size} | "
        f"skip_existing={args.skip_existing}"
    )

    if args.input_file:
        dgu = dgu_bt.load_dgu_module(args.dgu_module)
        dgu_bt.process_local_file(
            args.input_file,
            dgu=dgu,
            base_id=args.base_id,
            start=args.start,
            end=args.end,
            output_dir=args.output_dir,
            processed_dir=args.processed_dir,
            error_dir=args.error_dir,
            M=args.M,
            cost_bps=args.cost_bps,
        )
        print("Concluído: 1 base processada")
        return 0

    bases_dir = args.bases_dir or dgu_bt.DEFAULT_BASES_DIR
    if not bases_dir.exists():
        print(
            f"Pasta de bases não encontrada: {bases_dir}\n"
            "Use --input-file ou --bases-dir.",
            file=sys.stderr,
        )
        return 1

    ok, errors = process_local_batch_parallel(
        bases_dir,
        dgu_module=args.dgu_module,
        start=args.start,
        end=args.end,
        output_dir=args.output_dir,
        processed_dir=args.processed_dir,
        error_dir=args.error_dir,
        M=args.M,
        cost_bps=args.cost_bps,
        workers=args.workers,
        batch_size=args.batch_size,
        skip_existing=args.skip_existing,
    )
    print(f"\nConcluído: {ok} OK, {errors} erros.")
    return 0 if errors == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
