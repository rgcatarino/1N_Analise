"""Resultados do simulador Pessoa Investidora — v5 (tabela consolidada).

Gera Excel e LaTeX com médias cross-section de carteiras aleatórias 1/N
com filtro de liquidez. Carteiras com a mesma composição de ativos
(ordem irrelevante) são deduplicadas antes do cálculo das médias.

Lê as collections ``res_{sufixo}`` do banco ``Backtest_Mestrado_PF_LIQUIDEZ_1MM``
(ou outro via ``--db-name``). Por padrão usa o motor **v4.1**
(``res_*_ir_v41`` / ``res_*_noir_v41``); use ``--engine v4`` para o legado
sem sufixo ``_v41``.

Exemplo::

    # Ver o que existe no banco (v4.1)
    python codigo_fonte/mestrado_resultados_simulador_pessoa_investidora_v5.py \\
      --universo-tag liq_1MM --engine v41 --list-collections

    # Gerar tabela a partir das collections *_v41
    python codigo_fonte/mestrado_resultados_simulador_pessoa_investidora_v5.py \\
      --universo-tag liq_1MM \\
      --tcost-bps 12 --ir sim \\
      --rebalanceamento com \\
      --engine v41
"""

from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from pymongo import MongoClient
from pymongo.database import Database

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

from mestrado_resultados_simulador_pessoa_investidora import (  # noqa: E402
    DEFAULT_MONGO_URI,
    _normalize_metric_columns,
)
from mestrado_resultados_simulador_pessoa_investidora_v2 import (  # noqa: E402
    DEFAULT_DB_LIQUIDEZ,
    REBALANCE_FREQS,
)

RES_SUFFIX_RE = re.compile(
    r"^(?P<n>\d+)atv_"
    r"(?P<head>.*?)"
    r"(?P<start>\d{6})_(?P<end>\d{6})_"
    r"(?P<reb>reb-[\w]+|buyhold|buy-hold)_"
    r"t(?P<tcost>\d+)bps_(?P<ir>ir|noir)"
    r"(?P<engine>_v41)?$"
)
ENGINE_CHOICES = ("v4", "v41", "all")

DEFAULT_OUTPUT_DIR = REPO_ROOT / "resultados" / "liquidez_1mm_delist"
DEFAULT_ATIVOS = (8, 10, 12, 15, 20, 25, 30, 35, 40)
DEFAULT_EXCLUDE_UNIVERSO_TAGS: Tuple[str, ...] = ("liq_divliq_1MM",)
DEFAULT_PERIOD_WINDOWS: Tuple[Tuple[str, int, int], ...] = (
    ("2001-2025", 2001, 7),
    ("2006-2025", 2006, 7),
    ("2011-2025", 2011, 7),
)
DEFAULT_TITLE = (
    "Desempenho médio de carteiras aleatórias 1/N com filtro de liquidez "
    "(médias cross-section por período)"
)
DEFAULT_TAB_FONTE = (
    r"\tabfonte{Fonte: Elaboração própria. (Rebalanceamento anual em julho, "
    r"custo de transação 12 bps), imposto de renda de 15\% e filtro de liquidez "
    r"diária de 1 milhão de reais.}"
)

TABLE_COLUMNS = (
    "Período",
    "Ativos por carteira",
    "Retorno total (%)",
    "Sharpe anualizado",
    "Retorno médio anualizado (%)",
    "Volatilidade anualizada (%)",
    "Retorno Total em Excesso (%)",
)
EXPORT_COLUMNS = TABLE_COLUMNS + ("N carteiras", "n_carteiras_brutas", "_collection")


@dataclass(frozen=True)
class SummaryMetric:
    key: str
    label: str
    scale: float = 1.0
    ndigits: int = 2
    aliases: Tuple[str, ...] = ()

    @property
    def lookup_keys(self) -> Tuple[str, ...]:
        return (self.key,) + self.aliases


@dataclass(frozen=True)
class ParsedResCollection:
    collection: str
    suffix: str
    n_ativos: int
    universo_tag: str
    start_y: int
    start_m: int
    end_y: int
    end_m: int
    reb_tag: str
    tcost_bps: int
    ir_tag: str
    engine: str = "v4"

    @property
    def period_label(self) -> str:
        return f"{self.start_y}-{self.end_y}"

    @property
    def is_rebalance(self) -> bool:
        return self.reb_tag.startswith("reb-")


SUMMARY_METRICS: Tuple[SummaryMetric, ...] = (
    SummaryMetric("total_return", "Retorno total (%)", 100.0),
    SummaryMetric(
        "monthly_sharpe",
        "Sharpe anualizado",
        aliases=("daily_sharpe",),
    ),
    SummaryMetric("monthly_mean", "Retorno médio anualizado (%)", 100.0),
    SummaryMetric(
        "monthly_vol",
        "Volatilidade anualizada (%)",
        100.0,
        aliases=("daily_vol",),
    ),
    SummaryMetric(
        "total_excess_return",
        "Retorno Total em Excesso (%)",
        100.0,
    ),
)


@dataclass(frozen=True)
class RunPlan:
    tcost_bps: int
    ativos: Tuple[int, ...]
    period_windows: Tuple[Tuple[str, int, int, int, int], ...]
    ir_modes: Tuple[bool, ...]
    universo_tag: str
    collection_index: Tuple[ParsedResCollection, ...]


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Gera tabela consolidada de desempenho médio (Excel + LaTeX) "
            "a partir das collections res_* do simulador Pessoa Investidora."
        )
    )
    parser.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    parser.add_argument("--db-name", default=DEFAULT_DB_LIQUIDEZ)
    parser.add_argument(
        "--ativos",
        type=int,
        nargs="+",
        default=None,
        help=(
            "Ativos por carteira. Omita para inferir do banco "
            f"(template completo: {' '.join(map(str, DEFAULT_ATIVOS))})"
        ),
    )
    parser.add_argument(
        "--ir",
        choices=("sim", "nao", "ambos", "auto"),
        default="auto",
        help="IR nas collections: sim, nao, ambos ou auto (default: auto)",
    )
    parser.add_argument(
        "--rebalanceamento",
        choices=("com", "sem"),
        default="com",
        help="Regime de rebalanceamento (default: com)",
    )
    parser.add_argument(
        "--rebalance-freq",
        choices=REBALANCE_FREQS,
        default="annual",
        help="Periodicidade do rebalanceamento (default: annual)",
    )
    parser.add_argument(
        "--tcost-bps",
        type=float,
        default=None,
        help="Custo em bps. Omita para inferir do banco.",
    )
    parser.add_argument("--start-m", type=int, default=7)
    parser.add_argument("--end-m", type=int, default=10)
    parser.add_argument("--end-y", type=int, default=2025)
    parser.add_argument(
        "--periodos",
        nargs="+",
        default=None,
        help=(
            "Janelas nominais a incluir (ex.: 2001_2025 2006_2025). "
            "Omita para inferir do banco."
        ),
    )
    parser.add_argument(
        "--universo-tag",
        default="",
        help=(
            "Filtra/preferência de tag do universo (ex.: liq_1MM). "
            "Vazio = aceita qualquer tag presente no banco (exceto --exclude-universo-tag)."
        ),
    )
    parser.add_argument(
        "--exclude-universo-tag",
        nargs="+",
        default=None,
        help=(
            "Tags de universo a ignorar (default: liq_divliq_1MM). "
            "Use --exclude-universo-tag '' para não excluir nenhuma."
        ),
    )
    parser.add_argument(
        "--engine",
        choices=ENGINE_CHOICES,
        default="v41",
        help=(
            "Motor das collections res_*: v41 = sufixo *_v41 (default); "
            "v4 = legado sem _v41; all = ambos (preferindo v41 se houver duplicata)."
        ),
    )
    parser.add_argument(
        "--sem-reb-tag",
        default="buyhold",
        help="Tag buy-and-hold no sufixo (default: buyhold)",
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument(
        "--title",
        default=DEFAULT_TITLE,
        help="Título da tabela no Excel/LaTeX",
    )
    parser.add_argument(
        "--stem",
        default="desempenho_carteiras_aleatorias_liquidez",
        help="Prefixo dos arquivos de saída (csv/xlsx/tex)",
    )
    parser.add_argument(
        "--label",
        default="tab:desempenho-carteiras-aleatorias-liquidez",
        help="Label LaTeX da tabela",
    )
    parser.add_argument(
        "--allow-missing",
        action="store_true",
        default=True,
        help="Segue com collections ausentes (células vazias; default)",
    )
    parser.add_argument(
        "--require-all",
        dest="allow_missing",
        action="store_false",
        help="Falha se alguma collection solicitada não existir",
    )
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument(
        "--list-collections",
        action="store_true",
        help="Lista collections res_* reconhecidas no banco e sai",
    )
    args = parser.parse_args(list(argv) if argv is not None else None)
    if not 1 <= args.start_m <= 12 or not 1 <= args.end_m <= 12:
        parser.error("Mês de início/fim deve estar entre 1 e 12.")
    return args


def _most_common(values: Sequence[object]) -> object:
    counts: Dict[object, int] = {}
    for value in values:
        counts[value] = counts.get(value, 0) + 1
    return max(counts, key=lambda key: (counts[key], key))


def _period_label(start_y: int, end_y: int) -> str:
    return f"{start_y}-{end_y}"


def _period_windows_from_db(
    items: Sequence[ParsedResCollection],
) -> Tuple[Tuple[str, int, int, int, int], ...]:
    seen: Dict[Tuple[int, int, int, int], Tuple[str, int, int, int, int]] = {}
    for item in items:
        key = (item.start_y, item.start_m, item.end_y, item.end_m)
        seen[key] = (
            _period_label(item.start_y, item.end_y),
            item.start_y,
            item.start_m,
            item.end_y,
            item.end_m,
        )
    return tuple(seen[k] for k in sorted(seen))


def _period_windows_from_args(
    periodos: Sequence[str],
    *,
    end_y: int,
    end_m: int,
    start_m: int,
) -> Tuple[Tuple[str, int, int, int, int], ...]:
    windows: List[Tuple[str, int, int, int, int]] = []
    for token in periodos:
        if "_" in token:
            start_s, end_s = token.split("_", 1)
            start_y = int(start_s)
            end_y_token = int(end_s)
        elif "-" in token:
            start_s, end_s = token.split("-", 1)
            start_y = int(start_s)
            end_y_token = int(end_s)
        else:
            raise ValueError(f"Período inválido: {token!r}")
        windows.append(
            (
                _period_label(start_y, end_y_token),
                start_y,
                start_m,
                end_y_token,
                end_m,
            )
        )
    return tuple(windows)


def rebalanceamento_file_tag(rebalanceamento: str) -> str:
    """Sufixo de arquivo: com rebalanceamento vs buy-and-hold."""
    return "com_reb" if rebalanceamento == "com" else "sem_reb"


def build_output_stem(
    base_stem: str,
    *,
    rebalanceamento: str,
    ir_tag: Optional[str] = None,
) -> str:
    """Monta stem de saída com indicativo de regime de rebalanceamento."""
    reb_tag = rebalanceamento_file_tag(rebalanceamento)
    if ir_tag:
        return f"{base_stem}_{reb_tag}_{ir_tag}"
    return f"{base_stem}_{reb_tag}"


def rebalanceamento_caption_suffix(rebalanceamento: str) -> str:
    """Sufixo do título LaTeX/Excel conforme regime de rebalanceamento."""
    if rebalanceamento == "com":
        return " — com rebalanceamento anual"
    return " — sem rebalanceamento (buy-and-hold)"


def resolve_export_title(
    title: str,
    rebalanceamento: str,
    *,
    default_title: str,
) -> str:
    """Acrescenta sufixo de rebalanceamento quando o título é o default."""
    if title != default_title:
        return title
    return title + rebalanceamento_caption_suffix(rebalanceamento)


def rebalanceamento_legenda_text(rebalanceamento: str, *, tcost_bps: float = 12.0) -> str:
    """Trecho da nota de rodapé sobre rebalanceamento/custos."""
    if rebalanceamento == "com":
        return (
            f"Rebalanceamento anual em julho, custo de transação {tcost_bps:g} bps"
        )
    return (
        f"Estratégia buy-and-hold (sem rebalanceamento periódico), "
        f"custo de transação {tcost_bps:g} bps na abertura da carteira"
    )


def build_tab_fonte(
    rebalanceamento: str,
    *,
    tcost_bps: float = 12.0,
    benchmark: Optional[str] = None,
    n_carteiras: Optional[int] = None,
) -> str:
    """Monta \\tabfonte{...} conforme regime de rebalanceamento."""
    reb_txt = rebalanceamento_legenda_text(rebalanceamento, tcost_bps=tcost_bps)
    ir_txt = r"imposto de renda de 15\%"
    liq_txt = r"filtro de liquidez diária de 1 milhão de reais"
    excess_txt = r"retorno total em excesso relativo à RF NEFIN"
    body = (
        rf"Fonte: Elaboração própria. ({reb_txt}), {ir_txt} e {liq_txt}. "
        rf"Coluna de excesso: {excess_txt}."
    )
    if n_carteiras is not None:
        body += rf" N carteiras = {int(n_carteiras)}."
    if benchmark:
        body += f" Benchmark: índice {benchmark}."
    return rf"\tabfonte{{{body}}}"


def _n_carteiras_from_frame(frame: pd.DataFrame) -> Optional[int]:
    if "N carteiras" not in frame.columns:
        return None
    values = pd.to_numeric(frame["N carteiras"], errors="coerce").dropna()
    if values.empty:
        return None
    uniq = values.unique()
    if len(uniq) == 1:
        return int(uniq[0])
    return int(values.mode().iloc[0])


def _resolve_exclude_universo_tags(args: argparse.Namespace) -> frozenset[str]:
    if args.exclude_universo_tag is not None:
        if len(args.exclude_universo_tag) == 1 and str(args.exclude_universo_tag[0]).strip() == "":
            return frozenset()
        return frozenset(str(tag).strip() for tag in args.exclude_universo_tag if str(tag).strip())
    return frozenset(DEFAULT_EXCLUDE_UNIVERSO_TAGS)


def _filter_collections(
    index: Sequence[ParsedResCollection],
    *,
    rebalance: bool,
    rebalance_freq: str,
    sem_reb_tag: str,
    universo_tag: str,
    exclude_universo_tags: frozenset[str] = frozenset(),
    engine: str = "v41",
) -> List[ParsedResCollection]:
    requested_tag = str(universo_tag or "").strip()
    eng = str(engine or "v41").lower()
    matched = [
        item
        for item in index
        if _reb_matches(
            item,
            rebalance=rebalance,
            rebalance_freq=rebalance_freq,
            sem_reb_tag=sem_reb_tag,
        )
        and item.universo_tag not in exclude_universo_tags
        and (eng == "all" or item.engine == eng)
    ]
    if not requested_tag:
        return matched
    return [item for item in matched if item.universo_tag == requested_tag]


def filter_collections_for_args(
    index: Sequence[ParsedResCollection],
    args: argparse.Namespace,
) -> List[ParsedResCollection]:
    """Aplica os mesmos filtros de universo/reb/custo usados na execução."""
    rebalance = args.rebalanceamento == "com"
    sem_reb_tag = str(getattr(args, "sem_reb_tag", None) or "buyhold")
    exclude = _resolve_exclude_universo_tags(args)
    filtered = _filter_collections(
        index,
        rebalance=rebalance,
        rebalance_freq=args.rebalance_freq,
        sem_reb_tag=sem_reb_tag,
        universo_tag=str(args.universo_tag or "").strip(),
        exclude_universo_tags=exclude,
        engine=str(getattr(args, "engine", "v41")),
    )
    if args.tcost_bps is not None:
        tcost = int(round(float(args.tcost_bps)))
        filtered = [item for item in filtered if item.tcost_bps == tcost]
    if args.ir == "sim":
        filtered = [item for item in filtered if item.ir_tag == "ir"]
    elif args.ir == "nao":
        filtered = [item for item in filtered if item.ir_tag == "noir"]
    return filtered


def _resolve_ir_modes(requested: str, available_ir: Sequence[str]) -> Tuple[bool, ...]:
    tags = sorted(set(available_ir))
    if requested == "auto":
        if not tags:
            return (False,)
        if len(tags) == 1:
            return (tags[0] == "ir",)
        return tuple(tag == "ir" for tag in tags if tag in ("ir", "noir"))
    if requested == "ambos":
        modes: List[bool] = []
        if "noir" in tags:
            modes.append(False)
        if "ir" in tags:
            modes.append(True)
        return tuple(modes) or (False,)
    if requested == "sim":
        if "ir" in tags:
            return (True,)
        if "noir" in tags:
            print("AVISO: --ir sim, mas só há collections noir no banco; usando noir.", flush=True)
            return (False,)
        return (True,)
    if "noir" in tags:
        return (False,)
    if "ir" in tags:
        print("AVISO: --ir nao, mas só há collections ir no banco; usando ir.", flush=True)
        return (True,)
    return (False,)


def infer_run_plan(
    all_collections: Sequence[ParsedResCollection],
    args: argparse.Namespace,
) -> RunPlan:
    rebalance = args.rebalanceamento == "com"
    sem_reb_tag = str(args.sem_reb_tag or "buyhold")
    universo_tag = str(args.universo_tag or "").strip()
    exclude_universo_tags = _resolve_exclude_universo_tags(args)

    base = _filter_collections(
        all_collections,
        rebalance=rebalance,
        rebalance_freq=args.rebalance_freq,
        sem_reb_tag=sem_reb_tag,
        universo_tag=universo_tag,
        exclude_universo_tags=exclude_universo_tags,
        engine=str(getattr(args, "engine", "v41")),
    )
    if not base:
        raise RuntimeError(
            "Nenhuma collection res_* compatível com rebalanceamento/universo/"
            f"engine={getattr(args, 'engine', 'v41')} no banco."
        )

    if args.tcost_bps is None:
        tcost_bps = int(_most_common([item.tcost_bps for item in base]))
    else:
        tcost_bps = int(round(float(args.tcost_bps)))

    base = [item for item in base if item.tcost_bps == tcost_bps]
    if not base:
        available = sorted(
            {
                item.tcost_bps
                for item in _filter_collections(
                    all_collections,
                    rebalance=rebalance,
                    rebalance_freq=args.rebalance_freq,
                    sem_reb_tag=sem_reb_tag,
                    universo_tag=universo_tag,
                    exclude_universo_tags=exclude_universo_tags,
                    engine=str(getattr(args, "engine", "v41")),
                )
            }
        )
        raise RuntimeError(
            f"Nenhuma collection com tcost={tcost_bps} bps. "
            f"Disponíveis no banco: {available}"
        )

    ir_modes = _resolve_ir_modes(args.ir, [item.ir_tag for item in base])

    if args.periodos:
        period_windows = _period_windows_from_args(
            args.periodos,
            end_y=args.end_y,
            end_m=args.end_m,
            start_m=args.start_m,
        )
    else:
        period_windows = _period_windows_from_db(base)
        if not period_windows:
            period_windows = tuple(
                (label, start_y, start_m, args.end_y, args.end_m)
                for label, start_y, start_m in DEFAULT_PERIOD_WINDOWS
            )

    if args.ativos is None:
        ativos = tuple(sorted({item.n_ativos for item in base}))
    else:
        ativos = tuple(int(n) for n in args.ativos)

    if not universo_tag:
        tags = [item.universo_tag for item in base if item.universo_tag]
        universo_tag = str(_most_common(tags)) if tags else ""

    return RunPlan(
        tcost_bps=tcost_bps,
        ativos=ativos,
        period_windows=period_windows,
        ir_modes=ir_modes,
        universo_tag=universo_tag,
        collection_index=tuple(base),
    )


def parse_res_suffix(suffix: str) -> Optional[ParsedResCollection]:
    match = RES_SUFFIX_RE.match(suffix)
    if not match:
        return None
    start = match.group("start")
    end = match.group("end")
    engine = "v41" if match.group("engine") == "_v41" else "v4"
    return ParsedResCollection(
        collection=f"res_{suffix}",
        suffix=suffix,
        n_ativos=int(match.group("n")),
        universo_tag=match.group("head").rstrip("_"),
        start_y=int(start[:4]),
        start_m=int(start[4:6]),
        end_y=int(end[:4]),
        end_m=int(end[4:6]),
        reb_tag=match.group("reb"),
        tcost_bps=int(match.group("tcost")),
        ir_tag=match.group("ir"),
        engine=engine,
    )


def discover_res_collections(db: Database) -> List[ParsedResCollection]:
    parsed: List[ParsedResCollection] = []
    for name in sorted(db.list_collection_names()):
        if not name.startswith("res_"):
            continue
        item = parse_res_suffix(name[len("res_") :])
        if item is not None:
            parsed.append(item)
    return parsed


def _reb_matches(parsed: ParsedResCollection, *, rebalance: bool, rebalance_freq: str, sem_reb_tag: str) -> bool:
    if rebalance:
        return parsed.reb_tag == f"reb-{rebalance_freq}"
    return parsed.reb_tag in {sem_reb_tag, "buyhold", "buy-hold"}


def _universo_score(parsed: ParsedResCollection, requested_tag: str) -> int:
    if not requested_tag:
        return 0
    if parsed.universo_tag == requested_tag:
        return 2
    if not parsed.universo_tag:
        return 1
    return -1


def resolve_collection(
    index: Sequence[ParsedResCollection],
    *,
    n_ativos: int,
    start_y: int,
    start_m: int,
    end_y: int,
    end_m: int,
    rebalance: bool,
    rebalance_freq: str,
    tcost_bps: float,
    apply_stock_ir: bool,
    universo_tag: str,
    sem_reb_tag: str,
) -> Optional[ParsedResCollection]:
    ir_tag = "ir" if apply_stock_ir else "noir"
    tcost = int(round(float(tcost_bps)))

    def base_filter(item: ParsedResCollection) -> bool:
        return (
            item.n_ativos == int(n_ativos)
            and item.start_y == int(start_y)
            and item.start_m == int(start_m)
            and item.tcost_bps == tcost
            and item.ir_tag == ir_tag
            and _reb_matches(
                item,
                rebalance=rebalance,
                rebalance_freq=rebalance_freq,
                sem_reb_tag=sem_reb_tag,
            )
        )

    def pick_best(candidates: Sequence[ParsedResCollection]) -> Optional[ParsedResCollection]:
        if not candidates:
            return None
        requested_tag = str(universo_tag or "").strip()
        ranked = sorted(
            candidates,
            key=lambda item: (
                1 if item.engine == "v41" else 0,
                _universo_score(item, requested_tag),
                item.end_y,
                item.end_m,
                item.collection,
            ),
            reverse=True,
        )
        best = ranked[0]
        if requested_tag and _universo_score(best, requested_tag) < 0:
            return None
        return best

    exact = [
        item
        for item in index
        if base_filter(item) and item.end_y == int(end_y) and item.end_m == int(end_m)
    ]
    chosen = pick_best(exact)
    if chosen is not None:
        return chosen

    same_end_year = [
        item for item in index if base_filter(item) and item.end_y == int(end_y)
    ]
    chosen = pick_best(same_end_year)
    if chosen is not None:
        return chosen

    any_end = [item for item in index if base_filter(item)]
    return pick_best(any_end)


def print_collection_inventory(
    index: Sequence[ParsedResCollection],
    *,
    db_name: str,
    filters: Optional[Dict[str, object]] = None,
) -> None:
    print(f"{db_name}: {len(index)} collections res_* reconhecidas", flush=True)
    if not index:
        return
    if filters:
        print("Filtros ativos:", flush=True)
        for key, value in filters.items():
            print(f"  {key}: {value}", flush=True)
    print(f"{'N':>3}  {'Período':<12} {'Universo':<16} {'IR':<5} {'Reb':<12} {'bps':>4}  Collection", flush=True)
    for item in index:
        print(
            f"{item.n_ativos:>3}  {item.period_label:<12} "
            f"{(item.universo_tag or '-'):<16} {item.ir_tag:<5} {item.reb_tag:<12} "
            f"{item.tcost_bps:>4}  {item.collection}",
            flush=True,
        )


def _tickers_from_value(value: object) -> Tuple[str, ...]:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return tuple()
    if isinstance(value, (list, tuple, set)):
        parts = [str(item).strip() for item in value if str(item).strip()]
    else:
        text = str(value).strip()
        if not text:
            return tuple()
        if "," in text:
            parts = [part.strip() for part in text.split(",") if part.strip()]
        elif "-" in text:
            parts = [part.strip() for part in text.split("-") if part.strip()]
        else:
            parts = [text]
    return tuple(sorted(parts))


def canonical_portfolio_key(tickers: Sequence[str]) -> str:
    return ",".join(tickers)


def _tickers_for_strategy(strategy: object, tickers_map: Dict[str, Tuple[str, ...]]) -> Tuple[str, ...]:
    strat = str(strategy).strip()
    if strat in tickers_map:
        return tickers_map[strat]
    return _tickers_from_value(strat)


def _load_strategy_tickers(db: Database, suffix: str) -> Dict[str, Tuple[str, ...]]:
    collection_name = f"aux_metrics_{suffix}"
    if collection_name not in db.list_collection_names():
        return {}

    mapping: Dict[str, Tuple[str, ...]] = {}
    for doc in db[collection_name].find({}, {"_id": 0, "strategy": 1, "tickers": 1}):
        strat = str(doc.get("strategy", "")).strip()
        if not strat:
            continue
        tickers = _tickers_from_value(doc.get("tickers"))
        if not tickers:
            tickers = _tickers_from_value(strat)
        if tickers:
            mapping[strat] = tickers
    return mapping


def _load_res_metrics_frame(db: Database, suffix: str) -> pd.DataFrame:
    collection = db[f"res_{suffix}"]
    docs = list(collection.find({"type": "res_display"}, {"_id": 0}))
    if not docs:
        docs = list(collection.find({}, {"_id": 0}))
    if not docs:
        raise RuntimeError(f"Nenhum documento encontrado em {db.name}.res_{suffix}")

    df = pd.DataFrame(docs)
    if "strategy" not in df.columns:
        raise RuntimeError(f"Campo strategy ausente em res_{suffix} ({db.name}).")

    meta_cols = {
        "base_name",
        "type",
        "generated_at_utc",
        "strategy",
        "tickers",
    }
    value_cols = [
        column
        for column in df.columns
        if column not in meta_cols and not str(column).endswith("__text")
    ]
    keep_cols = ["strategy"]
    if "tickers" in df.columns:
        keep_cols.append("tickers")
    keep_cols.extend(value_cols)
    df = df[keep_cols].copy()
    return _normalize_metric_columns(df)


def _dedupe_res_metrics_by_composition(
    df: pd.DataFrame,
    tickers_map: Dict[str, Tuple[str, ...]],
) -> Tuple[pd.DataFrame, int, int]:
    if df.empty:
        return df.set_index("strategy"), 0, 0

    work = df.copy()
    if "tickers" in work.columns:
        work["_portfolio_key"] = [
            canonical_portfolio_key(
                _tickers_from_value(tickers)
                if _tickers_from_value(tickers)
                else _tickers_for_strategy(strategy, tickers_map)
            )
            for strategy, tickers in zip(work["strategy"], work["tickers"])
        ]
    else:
        work["_portfolio_key"] = work["strategy"].map(
            lambda strategy: canonical_portfolio_key(
                _tickers_for_strategy(strategy, tickers_map)
            )
        )

    n_raw = len(work)
    work = work.sort_values(["_portfolio_key", "strategy"], kind="mergesort")
    work = work.drop_duplicates(subset=["_portfolio_key"], keep="first")
    n_unique = len(work)

    metric_cols = [
        column for column in work.columns if column not in {"strategy", "tickers", "_portfolio_key"}
    ]
    work = work[["strategy", *metric_cols]].set_index("strategy")
    for column in work.columns:
        work[column] = pd.to_numeric(work[column], errors="coerce")
    return work, n_raw, n_unique


def _load_total_excess_return_map(
    db: Database,
    suffix: str,
) -> Dict[str, float]:
    """Lê ``total_excess_return`` (vs RF NEFIN) de ``aux_metrics_{suffix}``."""
    collection_name = f"aux_metrics_{suffix}"
    if collection_name not in db.list_collection_names():
        return {}

    mapping: Dict[str, float] = {}
    cursor = db[collection_name].find(
        {},
        {"_id": 0, "strategy": 1, "total_excess_return": 1},
    )
    for doc in cursor:
        strategy = str(doc.get("strategy", "")).strip()
        if not strategy:
            continue
        value = pd.to_numeric(doc.get("total_excess_return"), errors="coerce")
        if pd.isna(value):
            continue
        mapping[strategy] = float(value)
    return mapping


def _attach_total_excess_return(
    db: Database,
    suffix: str,
    df: pd.DataFrame,
) -> pd.DataFrame:
    """Anexa ``total_excess_return`` às métricas ``res_*`` (média cross-section)."""
    out = df.copy()
    excess_map = _load_total_excess_return_map(db, suffix)
    if not excess_map:
        out["total_excess_return"] = np.nan
        return out
    out["total_excess_return"] = [
        excess_map.get(str(strategy).strip(), np.nan) for strategy in out.index
    ]
    return out


def _load_unique_res_metrics(
    db: Database,
    suffix: str,
) -> Tuple[pd.DataFrame, int, int]:
    df = _load_res_metrics_frame(db, suffix)
    tickers_map = _load_strategy_tickers(db, suffix)
    unique_df, n_raw, n_unique = _dedupe_res_metrics_by_composition(df, tickers_map)
    unique_df = _attach_total_excess_return(db, suffix, unique_df)
    return unique_df, n_raw, n_unique


def _pick_metric_column(df: pd.DataFrame, metric: SummaryMetric) -> Optional[str]:
    for key in metric.lookup_keys:
        normalized = key.lower().replace(" ", "_")
        if normalized in df.columns:
            return normalized
    return None


def _mean_metric(df: pd.DataFrame, metric: SummaryMetric) -> Tuple[float, int]:
    column = _pick_metric_column(df, metric)
    if column is None:
        return np.nan, 0
    values = pd.to_numeric(df[column], errors="coerce").dropna()
    if values.empty:
        return np.nan, 0
    return float(values.mean() * metric.scale), int(values.shape[0])


def load_summary_row(
    db: Database,
    parsed: Optional[ParsedResCollection],
    *,
    allow_missing: bool,
    quiet: bool,
    expected_name: str = "",
) -> Dict[str, object]:
    collection_name = parsed.collection if parsed is not None else expected_name
    if parsed is None:
        message = f"Collection não encontrada: {expected_name or '(sem correspondência)'}"
        if allow_missing:
            if not quiet:
                print(f"  SKIP {message}", flush=True)
            row = {metric.label: np.nan for metric in SUMMARY_METRICS}
            row["n_carteiras"] = 0
            row["n_carteiras_brutas"] = 0
            row["_collection"] = expected_name
            return row
        raise RuntimeError(message)

    try:
        df, n_raw, n_unique = _load_unique_res_metrics(db, parsed.suffix)
    except RuntimeError as exc:
        if allow_missing:
            if not quiet:
                print(f"  SKIP {collection_name}: {exc}", flush=True)
            row = {metric.label: np.nan for metric in SUMMARY_METRICS}
            row["n_carteiras"] = 0
            row["n_carteiras_brutas"] = 0
            row["_collection"] = collection_name
            return row
        raise

    if not quiet and n_raw > n_unique:
        print(
            f"  composições únicas: {n_unique} "
            f"(de {n_raw} estratégias; {n_raw - n_unique} duplicadas por composição)",
            flush=True,
        )

    row: Dict[str, object] = {"_collection": collection_name}
    n_values: List[int] = []
    for metric in SUMMARY_METRICS:
        mean_value, n = _mean_metric(df, metric)
        row[metric.label] = mean_value
        n_values.append(n)
    row["n_carteiras"] = n_unique
    row["n_carteiras_brutas"] = n_raw
    return row


def build_summary_table(
    db: Database,
    *,
    ativos: Sequence[int],
    period_windows: Sequence[Tuple[str, int, int, int, int]],
    rebalance: bool,
    rebalance_freq: str,
    tcost_bps: float,
    apply_stock_ir: bool,
    universo_tag: str,
    sem_reb_tag: str,
    allow_missing: bool,
    quiet: bool,
    collection_index: Sequence[ParsedResCollection],
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []

    for period_label, start_y, start_m, end_y, end_m in period_windows:
        for n_ativos in ativos:
            parsed = resolve_collection(
                collection_index,
                n_ativos=int(n_ativos),
                start_y=int(start_y),
                start_m=int(start_m),
                end_y=int(end_y),
                end_m=int(end_m),
                rebalance=rebalance,
                rebalance_freq=rebalance_freq,
                tcost_bps=float(tcost_bps),
                apply_stock_ir=bool(apply_stock_ir),
                universo_tag=str(universo_tag or ""),
                sem_reb_tag=str(sem_reb_tag or "buyhold"),
            )
            collection_name = parsed.collection if parsed is not None else (
                f"res_{n_ativos}atv_*_{start_y}{start_m:02d}_{end_y}{end_m:02d}_*"
            )
            if not quiet:
                status = collection_name if parsed is not None else "NÃO ENCONTRADA"
                print(
                    f"{period_label} | N={n_ativos:>2} | {status}",
                    flush=True,
                )
            metrics = load_summary_row(
                db,
                parsed,
                allow_missing=allow_missing,
                quiet=quiet,
                expected_name=collection_name,
            )
            row = {
                "Período": period_label,
                "Ativos por carteira": int(n_ativos),
            }
            for metric in SUMMARY_METRICS:
                value = metrics.get(metric.label, np.nan)
                if isinstance(value, float) and not np.isnan(value):
                    row[metric.label] = round(value, metric.ndigits)
                else:
                    row[metric.label] = np.nan
            row["N carteiras"] = int(metrics.get("n_carteiras", 0) or 0)
            row["n_carteiras_brutas"] = int(metrics.get("n_carteiras_brutas", 0) or 0)
            row["_collection"] = metrics.get("_collection", collection_name)
            rows.append(row)

    table = pd.DataFrame(rows)
    if not table.empty:
        table["_period_start"] = (
            table["Período"].astype(str).str.split("-", n=1).str[0].astype(int)
        )
        table = table.sort_values(
            ["_period_start", "Ativos por carteira"],
            kind="mergesort",
        ).reset_index(drop=True)
        table = table.drop(columns=["_period_start"])
    return table[list(EXPORT_COLUMNS)]


def _format_count_value(value: object) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    return str(int(value))


def _format_display_value(value: object) -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    if isinstance(value, (float, np.floating)):
        return f"{float(value):.2f}"
    return str(value)


def write_excel(table: pd.DataFrame, path: Path, *, title: str) -> None:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, Side
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "openpyxl é necessário para gravar Excel. Instale com: pip install openpyxl"
        ) from exc

    wb = Workbook()
    ws = wb.active
    ws.title = "Desempenho"

    thin = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    left = Alignment(horizontal="left", vertical="center")

    ncol = len(TABLE_COLUMNS)
    last_col_letter = chr(ord("A") + ncol - 1)
    ws.merge_cells(f"A1:{last_col_letter}1")
    title_cell = ws["A1"]
    title_cell.value = title
    title_cell.font = Font(bold=True, size=12)
    title_cell.alignment = center

    for col, header in enumerate(TABLE_COLUMNS, start=1):
        cell = ws.cell(row=2, column=col, value=header)
        cell.font = Font(bold=True)
        cell.alignment = center
        cell.border = thin

    start_row = 3
    for i, rec in enumerate(table[list(TABLE_COLUMNS)].itertuples(index=False)):
        r = start_row + i
        ws.cell(row=r, column=1, value=rec[0]).alignment = center
        ws.cell(row=r, column=2, value=rec[1]).alignment = center
        for col in range(3, ncol + 1):
            value = rec[col - 1]
            cell = ws.cell(row=r, column=col, value=value if value == value else None)
            cell.alignment = center
            if isinstance(value, (int, float)) and value == value:
                cell.number_format = "0.00"
        for col in range(1, ncol + 1):
            ws.cell(row=r, column=col).border = thin

    widths = {
        "A": 14,
        "B": 18,
        "C": 18,
        "D": 18,
        "E": 28,
        "F": 26,
        "G": 30,
    }
    for letter, width in widths.items():
        ws.column_dimensions[letter].width = width

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def _latex_escape(text: str) -> str:
    replacements = {
        "\\": "\\textbackslash{}",
        "&": "\\&",
        "%": "\\%",
        "$": "\\$",
        "#": "\\#",
        "_": "\\_",
        "{": "\\{",
        "}": "\\}",
        "~": "\\textasciitilde{}",
        "^": "\\textasciicircum{}",
    }
    out = str(text)
    for src, dst in replacements.items():
        out = out.replace(src, dst)
    return out


LATEX_HEADER_WRAPS = {
    "Ativos por carteira": r"\shortstack{Ativos por\\carteira}",
    "Período": "Período",
    "Retorno total (%)": r"\shortstack{Retorno total\\(\%)}",
    "Sharpe anualizado": r"\shortstack{Sharpe\\anualizado}",
    "Retorno médio anualizado (%)": r"\shortstack{Retorno médio\\anualizado (\%)}",
    "Volatilidade anualizada (%)": r"\shortstack{Volatilidade\\anualizada (\%)}",
    "Retorno Total em Excesso (%)": r"\shortstack{Retorno Total\\em Excesso (\%)}",
}

LATEX_COL_SPEC = (
    "@{}"
    r">{\centering\arraybackslash}p{0.11\linewidth}"
    r">{\centering\arraybackslash}p{0.09\linewidth}"
    r">{\centering\arraybackslash}p{0.12\linewidth}"
    r">{\centering\arraybackslash}p{0.09\linewidth}"
    r">{\centering\arraybackslash}p{0.13\linewidth}"
    r">{\centering\arraybackslash}p{0.13\linewidth}"
    r">{\centering\arraybackslash}p{0.14\linewidth}"
    "@{}"
)


def _latex_period_cell(value: object) -> str:
    text = _latex_escape(str(value))
    return rf"\mbox{{{text}}}"


def _latex_header_cells() -> Tuple[str, ...]:
    return tuple(LATEX_HEADER_WRAPS[column] for column in TABLE_COLUMNS)


def write_latex(
    table: pd.DataFrame,
    path: Path,
    *,
    title: str,
    label: str,
    tabfonte: str,
) -> None:
    header_cells = _latex_header_cells()
    lines: List[str] = [
        "% Gerado por mestrado_resultados_simulador_pessoa_investidora_v5.py",
        "% Requer: \\usepackage{array} e \\usepackage{booktabs}",
        "\\begin{table}[htbp]",
        "\\centering",
        f"\\caption{{{_latex_escape(title)}}}",
        f"\\label{{{_latex_escape(label)}}}",
        "\\footnotesize",
        "\\setlength{\\tabcolsep}{3pt}",
        "\\renewcommand{\\arraystretch}{1.15}",
        f"\\begin{{tabular}}{{{LATEX_COL_SPEC}}}",
        "\\toprule",
        " & ".join(header_cells) + r" \\",
        "\\midrule",
    ]

    for rec in table[list(TABLE_COLUMNS)].itertuples(index=False):
        cells = [
            _latex_period_cell(rec[0]),
            str(rec[1]),
            _format_display_value(rec[2]),
            _format_display_value(rec[3]),
            _format_display_value(rec[4]),
            _format_display_value(rec[5]),
            _format_display_value(rec[6]),
        ]
        lines.append(" & ".join(cells) + r" \\")

    lines.extend(
        [
            "\\bottomrule",
            "\\end{tabular}",
            tabfonte,
            "\\end{table}",
            "",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def main(argv: Optional[Sequence[str]] = None) -> Path:
    args = parse_args(argv)
    rebalance = args.rebalanceamento == "com"

    args.output_dir.mkdir(parents=True, exist_ok=True)
    client = MongoClient(args.mongo_uri, serverSelectionTimeoutMS=15000)

    try:
        db = client[args.db_name]
        all_collections = discover_res_collections(db)
        if args.list_collections:
            filtered = filter_collections_for_args(all_collections, args)
            print_collection_inventory(
                filtered,
                db_name=args.db_name,
                filters={
                    "engine": args.engine,
                    "rebalanceamento": args.rebalanceamento,
                    "universo-tag": args.universo_tag or "(qualquer)",
                    "exclude-universo-tag": sorted(_resolve_exclude_universo_tags(args)),
                    "tcost-bps": args.tcost_bps,
                    "ir": args.ir,
                },
            )
            print(
                "\n(Inventário apenas — nenhum CSV/Excel/LaTeX gerado. "
                "Remova --list-collections para exportar arquivos.)",
                flush=True,
            )
            return args.output_dir

        plan = infer_run_plan(all_collections, args)
        if not args.quiet:
            print(
                f"\nPlano inferido do banco:",
                flush=True,
            )
            print(f"  universo: {plan.universo_tag or '(sem tag)'}", flush=True)
            print(f"  engine:   {args.engine}", flush=True)
            print(f"  tcost:    {plan.tcost_bps} bps", flush=True)
            print(f"  ativos:   {' '.join(map(str, plan.ativos))}", flush=True)
            print(
                "  períodos: "
                + ", ".join(label for label, *_ in plan.period_windows),
                flush=True,
            )
            print(
                "  IR:       "
                + ", ".join("sim" if mode else "nao" for mode in plan.ir_modes),
                flush=True,
            )

        frames: List[pd.DataFrame] = []
        for apply_ir in plan.ir_modes:
            ir_tag = "ir" if apply_ir else "noir"
            filtered_index = [
                item
                for item in plan.collection_index
                if item.ir_tag == ir_tag
                and _reb_matches(
                    item,
                    rebalance=rebalance,
                    rebalance_freq=args.rebalance_freq,
                    sem_reb_tag=str(args.sem_reb_tag or "buyhold"),
                )
            ]
            if not args.quiet:
                print(
                    f"\n=== {args.db_name} | IR={'sim' if apply_ir else 'nao'} | "
                    f"{len(filtered_index)} collections ===",
                    flush=True,
                )

            table = build_summary_table(
                db,
                ativos=plan.ativos,
                period_windows=plan.period_windows,
                rebalance=rebalance,
                rebalance_freq=args.rebalance_freq,
                tcost_bps=plan.tcost_bps,
                apply_stock_ir=bool(apply_ir),
                universo_tag=plan.universo_tag,
                sem_reb_tag=str(args.sem_reb_tag or "buyhold"),
                allow_missing=args.allow_missing,
                quiet=args.quiet,
                collection_index=filtered_index,
            )
            frames.append(table)
    finally:
        client.close()

    if not frames:
        raise RuntimeError("Nenhuma linha gerada.")

    export_title = resolve_export_title(
        args.title,
        args.rebalanceamento,
        default_title=DEFAULT_TITLE,
    )

    last_xlsx: Optional[Path] = None
    for apply_ir, frame in zip(plan.ir_modes, frames):
        ir_tag = "ir" if apply_ir else "noir"
        stem = build_output_stem(
            args.stem,
            rebalanceamento=args.rebalanceamento,
            ir_tag=ir_tag if len(plan.ir_modes) > 1 else None,
        )
        label = args.label if len(plan.ir_modes) == 1 else f"{args.label}_{ir_tag}"
        tabfonte = build_tab_fonte(
            args.rebalanceamento,
            tcost_bps=plan.tcost_bps,
            n_carteiras=_n_carteiras_from_frame(frame),
        )

        csv_path = args.output_dir / f"{stem}.csv"
        xlsx_path = args.output_dir / f"{stem}.xlsx"
        tex_path = args.output_dir / f"{stem}.tex"

        frame.to_csv(csv_path, index=False, encoding="utf-8-sig")
        write_excel(frame[list(TABLE_COLUMNS)], xlsx_path, title=export_title)
        write_latex(
            frame[list(TABLE_COLUMNS)],
            tex_path,
            title=export_title,
            label=label,
            tabfonte=tabfonte,
        )
        last_xlsx = xlsx_path

        if not args.quiet:
            print(f"\nCSV:   {csv_path}", flush=True)
            print(f"Excel: {xlsx_path}", flush=True)
            print(f"LaTeX: {tex_path}", flush=True)

    if last_xlsx is None:
        raise RuntimeError("Nenhum arquivo gerado.")
    return last_xlsx


if __name__ == "__main__":
    main()
