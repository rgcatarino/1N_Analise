"""Gera bases mensais DGU (2009) para carteiras aleatórias B3.

Convertido a partir de:
    Economatica_Gerador_Bases_DGU2009_V2.ipynb

Execução local (sem Colab/Drive):
  - lê painel diário de retornos em excesso (pré-calculado ou derivado de preços)
  - sorteia carteiras (1 ticker por empresa)
  - anexa RF/MktRF NEFIN, mensaliza e grava CSVs para o backtest DGU

Exemplos:
    # Painel de excesso já pronto + NEFIN local
    python codigo_fonte/economatica_gerador_bases_dgu2009_v2.py \\
        --excess-daily-path dados/excess_returns_NefinRF_b3_todas_daily.csv \\
        --output-dir bases_dgu \\
        --k-assets 8 --n-portfolios 1000 --seed 15

    # Derivar excesso a partir do painel Economatica + nefin_RF.csv
    python codigo_fonte/economatica_gerador_bases_dgu2009_v2.py \\
        --prices-path ibov/prices_adjust_close_B3_economatica_1986-out_2025.csv \\
        --rf-path nefin_RF.csv \\
        --factors-path nefin_factors.csv \\
        --output-dir bases_dgu \\
        --k-assets 8 10 12 15 20 --n-portfolios 3000
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import re
import sys
import uuid
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
DEFAULT_EXCESS_DAILY = REPO_ROOT / "dados" / "excess_returns_NefinRF_b3_todas_daily.csv"
DEFAULT_PRICES_PATH = REPO_ROOT / "ibov" / "prices_adjust_close_B3_economatica_1986-out_2025.csv"
DEFAULT_RF_PATH = REPO_ROOT / "nefin_RF.csv"
DEFAULT_FACTORS_PATH = REPO_ROOT / "nefin_factors.csv"
DEFAULT_NEFIN_RF_MKT = REPO_ROOT / "dados" / "nefin_RF_MKT.csv"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "bases_dgu"

DEFAULT_START_COMPLETE = "2011-01-04"
DEFAULT_END_COMPLETE = "2025-10-31"
DEFAULT_PANEL_START = "2011-01-04"
DEFAULT_N_PORTFOLIOS = 1000
DEFAULT_K_ASSETS = (8,)
DEFAULT_SEED = 15
DEFAULT_PREFIX = "B3_aleatoria"
TICKER_RE = re.compile(r"^[A-Z]{4}\d", re.IGNORECASE)


def is_ticker_column(name: str) -> bool:
    """Ignora índice CSV (Unnamed: 0) e colunas que não parecem ticker B3."""
    s = str(name).strip()
    if not s or s.startswith("Unnamed"):
        return False
    return bool(TICKER_RE.match(s.upper()))


class ProgressReporter:
    """Imprime percentual de avanço (stderr). Opcionalmente inclui progresso global acumulado."""

    def __init__(
        self,
        label: str,
        total: int,
        *,
        global_current_fn=None,
        global_total: int = 0,
    ):
        self.label = label
        self.total = max(int(total), 1)
        self._global_current_fn = global_current_fn
        self._global_total = max(int(global_total), 0)
        self._step = max(1, self.total // 100)
        self._last_pct = -1.0

    def update(self, current: int) -> None:
        current = min(max(int(current), 0), self.total)
        pct = 100.0 * current / self.total
        if current == self.total or current == 1 or current % self._step == 0:
            if pct != self._last_pct or current == self.total:
                self._last_pct = pct
                msg = f"{self.label}: {pct:6.2f}% ({current}/{self.total})"
                if self._global_total > 0 and self._global_current_fn is not None:
                    gc = self._global_current_fn(current)
                    gp = 100.0 * gc / self._global_total
                    msg += f" | Total: {gp:6.2f}% ({gc}/{self._global_total})"
                print(
                    msg,
                    file=sys.stderr,
                    end="\r" if current < self.total else "\n",
                    flush=True,
                )

    def finish(self) -> None:
        self.update(self.total)


def mensalizar_retorno_diario(
    df: pd.DataFrame,
    date_col: str = "DATE",
    cols: Optional[Iterable[str]] = None,
    freq: str = "ME",
    keep_date_col: bool = False,
    index_to: Optional[str] = None,
) -> pd.DataFrame:
    """Retorno mensal composto: R_m = prod(1+r_d) - 1."""
    if df is None or df.empty:
        return pd.DataFrame()

    dfx = df.copy()
    if date_col in dfx.columns:
        dfx[date_col] = pd.to_datetime(dfx[date_col], errors="coerce")
        dfx = dfx.sort_values(date_col).set_index(date_col)
    else:
        dfx.index = pd.to_datetime(dfx.index, errors="coerce")
        dfx = dfx.sort_index()

    if cols is None:
        asset_cols = list(dfx.columns)
    else:
        asset_cols = [c for c in cols if c in dfx.columns]

    rets_d = dfx[asset_cols].apply(pd.to_numeric, errors="coerce")

    def monthly_compound(x: pd.Series) -> float:
        x = x.dropna()
        if x.empty:
            return np.nan
        return (1.0 + x).prod() - 1.0

    rets_m = rets_d.resample(freq).apply(monthly_compound)
    if index_to == "MS":
        rets_m.index = rets_m.index.to_period("M").to_timestamp("MS")
    if keep_date_col:
        rets_m = rets_m.reset_index().rename(columns={"index": date_col})
    return rets_m


def company_key(ticker: str) -> str:
    t = str(ticker).strip().upper()
    return t[:4] if len(t) >= 4 else t


def sample_random_portfolios(cols, n_portfolios=500, k_assets=10, seed=123):
    rng = np.random.default_rng(seed)
    by_company: dict[str, list[str]] = defaultdict(list)
    for t in cols:
        by_company[company_key(t)].append(t)

    companies = np.array(sorted(by_company.keys()))
    if len(companies) < k_assets:
        raise ValueError(
            f"Não há empresas suficientes: {len(companies)} < {k_assets}. "
            "Reduza k_assets ou amplie o universo."
        )

    portfolios = []
    for _ in range(n_portfolios):
        chosen_companies = rng.choice(companies, size=k_assets, replace=False)
        p = [rng.choice(by_company[c]) for c in chosen_companies]
        assert len(set(map(company_key, p))) == k_assets
        assert len(set(p)) == k_assets
        portfolios.append(p)

    df_ports = pd.DataFrame(portfolios, columns=[f"Asset_{i+1}" for i in range(k_assets)])
    return portfolios, df_ports


def colunas_completas_no_periodo(
    df: pd.DataFrame,
    date_col: str = "DATE",
    start: str = "2011-01-01",
    end: str = "2025-10-31",
    drop_all_nan_dates: bool = True,
) -> list[str]:
    dfx = df.copy()
    dfx[date_col] = pd.to_datetime(dfx[date_col], errors="coerce")
    dfx = dfx.sort_values(date_col)

    ini = pd.Timestamp(start)
    fim = pd.Timestamp(end)
    panel = dfx.loc[(dfx[date_col] >= ini) & (dfx[date_col] <= fim)].copy()
    asset_cols = [c for c in panel.columns if c != date_col and is_ticker_column(c)]
    panel_assets = panel[asset_cols].apply(pd.to_numeric, errors="coerce")

    if drop_all_nan_dates:
        mask_keep = panel_assets.notna().any(axis=1)
        panel_assets = panel_assets.loc[mask_keep]

    return panel_assets.columns[panel_assets.notna().all(axis=0)].tolist()


def _normalize_date_column(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "DATE" not in out.columns:
        for cand in ("Date", "date", "Data"):
            if cand in out.columns:
                out = out.rename(columns={cand: "DATE"})
                break
    if "DATE" not in out.columns:
        raise ValueError("Coluna de data não encontrada (DATE/Date).")
    out["DATE"] = pd.to_datetime(out["DATE"], errors="coerce")
    return out.sort_values("DATE")


def load_excess_daily_from_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    drop = [c for c in df.columns if str(c).startswith("Unnamed")]
    if drop:
        df = df.drop(columns=drop)
    return _normalize_date_column(df)


def build_excess_daily_from_prices(prices_path: Path, rf_path: Path) -> pd.DataFrame:
    print("Lendo painel de preços...", file=sys.stderr, flush=True)
    prices = pd.read_csv(prices_path, low_memory=False)
    drop = [c for c in prices.columns if str(c).startswith("Unnamed")]
    if drop:
        prices = prices.drop(columns=drop)

    date_col = next((c for c in ("Date", "DATE", "Data") if c in prices.columns), None)
    if date_col is None:
        raise ValueError(f"Coluna de data não encontrada em {prices_path}")

    prices[date_col] = pd.to_datetime(prices[date_col], errors="coerce")
    prices = prices.sort_values(date_col).set_index(date_col)
    tickers = [c for c in prices.columns if is_ticker_column(c)]
    if not tickers:
        raise ValueError(f"Nenhuma coluna de ticker B3 encontrada em {prices_path}")

    px = prices[tickers].apply(pd.to_numeric, errors="coerce")
    prog = ProgressReporter("Calculando excesso diário (tickers)", len(tickers))
    chunk = 80
    rets_parts: list[pd.DataFrame] = []
    for i in range(0, len(tickers), chunk):
        batch = tickers[i : i + chunk]
        rets_parts.append(px[batch].pct_change())
        prog.update(min(i + len(batch), len(tickers)))
    prog.finish()
    rets = pd.concat(rets_parts, axis=1)

    rf = pd.read_csv(rf_path)
    rf = _normalize_date_column(rf).set_index("DATE")["RF"].astype(float)
    rf = rf.reindex(rets.index).ffill()

    excess = (1.0 + rets).div(1.0 + rf, axis=0) - 1.0
    excess = excess.reset_index()
    if date_col != "DATE":
        excess = excess.rename(columns={date_col: "DATE"})
    return excess


def load_nefin_rf_mkt(
    *,
    nefin_rf_mkt_path: Path | None = None,
    rf_path: Path | None = None,
    factors_path: Path | None = None,
) -> pd.DataFrame:
    if nefin_rf_mkt_path is not None and nefin_rf_mkt_path.exists():
        df = pd.read_csv(nefin_rf_mkt_path)
        if "DATE" in df.columns:
            df["DATE"] = pd.to_datetime(df["DATE"], errors="coerce")
            return df.set_index("DATE").sort_index()[["MktRF", "RF"]].astype(float)
        return pd.read_csv(nefin_rf_mkt_path, index_col="DATE", parse_dates=True)[
            ["MktRF", "RF"]
        ].astype(float)

    if rf_path is None or factors_path is None:
        raise FileNotFoundError(
            "Informe --nefin-rf-mkt-path ou ambos --rf-path e --factors-path."
        )

    rf = pd.read_csv(rf_path)
    rf = _normalize_date_column(rf).set_index("DATE")["RF"].astype(float)

    factors = pd.read_csv(factors_path)
    drop = [c for c in factors.columns if str(c).startswith("Unnamed")]
    if drop:
        factors = factors.drop(columns=drop)
    date_col = "Date" if "Date" in factors.columns else "DATE"
    factors[date_col] = pd.to_datetime(factors[date_col], errors="coerce")
    factors = factors.set_index(date_col).sort_index()
    if "Rm_minus_Rf" not in factors.columns:
        raise ValueError(f"Coluna Rm_minus_Rf ausente em {factors_path}")
    mkt = factors["Rm_minus_Rf"].rename("MktRF").astype(float)

    out = pd.concat([mkt, rf], axis=1, join="inner").dropna()
    return out


def build_daily_panels(
    df_b3_daily: pd.DataFrame,
    df_portfolios: pd.DataFrame,
    panel_start: str,
    *,
    progress: ProgressReporter | None = None,
) -> list[pd.DataFrame]:
    df_b3_daily = df_b3_daily.copy()
    df_b3_daily["DATE"] = pd.to_datetime(df_b3_daily["DATE"], errors="coerce")
    asset_cols = [c for c in df_portfolios.columns if c.startswith("Asset_")]
    start_ts = pd.Timestamp(panel_start)

    dfs: list[pd.DataFrame] = []
    total = len(df_portfolios)
    for i, (_, row) in enumerate(df_portfolios.iterrows(), start=1):
        tickers = row[asset_cols].dropna().astype(str).tolist()
        tickers = [t for t in tickers if t in df_b3_daily.columns]
        df_filtered = df_b3_daily.loc[df_b3_daily["DATE"] >= start_ts, ["DATE"] + tickers].copy()
        dfs.append(df_filtered)
        if progress is not None:
            progress.update(i)
    if progress is not None:
        progress.finish()
    return dfs


def export_portfolio_bases(
    dfs: list[pd.DataFrame],
    df_nefin_rf: pd.DataFrame,
    output_dir: Path,
    *,
    prefix: str = DEFAULT_PREFIX,
    deterministic_names: bool = False,
    run_tag: str = "",
    progress: ProgressReporter | None = None,
) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []
    total = len(dfs)

    for i, carteira in enumerate(dfs, start=1):
        df_indexed = carteira.set_index("DATE")
        df_merged = df_indexed.join(df_nefin_rf, how="inner")
        if df_merged.empty:
            if progress is not None:
                progress.update(i)
            continue

        rets_m = mensalizar_retorno_diario(df_merged, freq="ME")
        df_out = rets_m.reset_index()
        df_out["DATE"] = pd.to_datetime(df_out["DATE"], errors="coerce").dt.strftime("%Y%m%d")

        if deterministic_names:
            tag = f"_{run_tag}" if run_tag else ""
            out_name = f"{prefix}{tag}_{i-1:05d}.csv"
        else:
            out_name = f"{prefix}_{uuid.uuid4().hex}.csv"

        out_path = output_dir / out_name
        df_out.to_csv(out_path, index=False)
        saved.append(out_path)
        if progress is not None:
            progress.update(i)

    if progress is not None:
        progress.finish()
    return saved


def zip_bases(output_dir: Path, prefix: str, zip_path: Path) -> Path:
    pattern = str(output_dir / f"{prefix}*")
    files = sorted(p for p in glob.glob(pattern) if os.path.isfile(p))
    if not files:
        raise FileNotFoundError(f"Nenhum arquivo encontrado: {pattern}")

    zip_path.parent.mkdir(parents=True, exist_ok=True)
    prog = ProgressReporter("Compactando ZIP", len(files))
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for i, fp in enumerate(files, start=1):
            zf.write(fp, arcname=os.path.basename(fp))
            prog.update(i)
    prog.finish()
    return zip_path


def run_generation(
    *,
    df_b3_daily: pd.DataFrame,
    df_nefin_rf: pd.DataFrame,
    output_dir: Path,
    k_assets: int,
    n_portfolios: int,
    seed: int,
    start_complete: str,
    end_complete: str,
    panel_start: str,
    prefix: str,
    deterministic_names: bool,
    save_manifest: bool,
    global_offset: int = 0,
    global_total: int = 0,
) -> dict:
    cols_ok = colunas_completas_no_periodo(
        df_b3_daily,
        date_col="DATE",
        start=start_complete,
        end=end_complete,
        drop_all_nan_dates=True,
    )
    print(f"Universo completo ({start_complete} → {end_complete}): {len(cols_ok)} tickers")
    if len(cols_ok) < k_assets:
        raise ValueError(
            f"Universo insuficiente para N={k_assets}: apenas {len(cols_ok)} ticker(s) "
            f"sem NaN no período {start_complete} → {end_complete}. "
            "Encurte --start-complete (ex.: 2011-01-04, como no notebook) "
            "ou use --excess-daily-path se já tiver o painel de excesso pré-calculado."
        )

    _, df_portfolios = sample_random_portfolios(
        cols_ok, n_portfolios=n_portfolios, k_assets=k_assets, seed=seed
    )

    panel_prog = ProgressReporter(f"N={k_assets} painéis diários", n_portfolios)
    dfs = build_daily_panels(
        df_b3_daily, df_portfolios, panel_start, progress=panel_prog
    )

    run_tag = f"N{k_assets}_s{seed}"
    export_prog = ProgressReporter(
        f"N={k_assets} exportando CSV",
        n_portfolios,
        global_current_fn=lambda c: global_offset + c,
        global_total=global_total,
    )
    saved = export_portfolio_bases(
        dfs,
        df_nefin_rf,
        output_dir,
        prefix=prefix,
        deterministic_names=deterministic_names,
        run_tag=run_tag,
        progress=export_prog,
    )

    manifest_path = None
    if save_manifest:
        manifest_path = output_dir / f"manifest_{run_tag}.csv"
        df_portfolios.to_csv(manifest_path, index=False)

    return {
        "k_assets": k_assets,
        "n_portfolios_requested": n_portfolios,
        "n_portfolios_exported": len(saved),
        "n_universe": len(cols_ok),
        "manifest": str(manifest_path) if manifest_path else None,
        "output_dir": str(output_dir),
        "sample_files": [str(p) for p in saved[:3]],
    }


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Gera bases mensais DGU (B3 aleatórias) — versão local do notebook Economatica V2"
    )

    src = p.add_mutually_exclusive_group(required=False)
    src.add_argument(
        "--excess-daily-path",
        type=Path,
        default=None,
        help="CSV diário de retornos em excesso (Date/DATE + tickers)",
    )
    src.add_argument(
        "--prices-path",
        type=Path,
        default=None,
        help="Painel Economatica de preços (deriva excesso com --rf-path)",
    )

    p.add_argument("--rf-path", type=Path, default=DEFAULT_RF_PATH, help="nefin_RF.csv")
    p.add_argument(
        "--factors-path",
        type=Path,
        default=DEFAULT_FACTORS_PATH,
        help="nefin_factors.csv (Rm_minus_Rf → MktRF)",
    )
    p.add_argument(
        "--nefin-rf-mkt-path",
        type=Path,
        default=None,
        help="CSV pronto DATE,MktRF,RF (alternativa a rf+factors)",
    )

    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--k-assets", type=int, nargs="+", default=list(DEFAULT_K_ASSETS))
    p.add_argument("--n-portfolios", type=int, default=DEFAULT_N_PORTFOLIOS)
    p.add_argument("--seed", type=int, default=DEFAULT_SEED)
    p.add_argument("--start-complete", default=DEFAULT_START_COMPLETE)
    p.add_argument("--end-complete", default=DEFAULT_END_COMPLETE)
    p.add_argument("--panel-start", default=DEFAULT_PANEL_START)
    p.add_argument("--prefix", default=DEFAULT_PREFIX)
    p.add_argument(
        "--deterministic-names",
        action="store_true",
        help="Nomes B3_aleatoria_N8_s15_00000.csv em vez de UUID",
    )
    p.add_argument("--save-manifest", action="store_true", help="Salva CSV com tickers sorteados")
    p.add_argument("--zip", dest="make_zip", action="store_true", help="Compacta saídas em ZIP")
    p.add_argument(
        "--zip-path",
        type=Path,
        default=None,
        help="Caminho do ZIP (default: output-dir/B3_carteiras_aleatorias.zip)",
    )
    return p


def resolve_excess_daily(args) -> pd.DataFrame:
    if args.prices_path is not None:
        if not args.prices_path.exists():
            raise FileNotFoundError(f"Preços não encontrados: {args.prices_path}")
        if not args.rf_path.exists():
            raise FileNotFoundError(f"RF não encontrada: {args.rf_path}")
        print(f"Derivando excesso diário: {args.prices_path} + {args.rf_path}")
        return build_excess_daily_from_prices(args.prices_path, args.rf_path)

    path = args.excess_daily_path or DEFAULT_EXCESS_DAILY
    if path.exists():
        print(f"Carregando excesso diário: {path}")
        return load_excess_daily_from_csv(path)

    if DEFAULT_PRICES_PATH.exists() and args.rf_path.exists():
        print(
            f"Arquivo de excesso não encontrado ({path}). "
            f"Derivando de {DEFAULT_PRICES_PATH} + {args.rf_path}"
        )
        return build_excess_daily_from_prices(DEFAULT_PRICES_PATH, args.rf_path)

    raise FileNotFoundError(
        f"Nenhuma fonte de excesso diário disponível. Informe --excess-daily-path "
        f"ou --prices-path (default tentado: {path})."
    )


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    df_b3_daily = resolve_excess_daily(args)

    nefin_path = args.nefin_rf_mkt_path
    if nefin_path is None and DEFAULT_NEFIN_RF_MKT.exists():
        nefin_path = DEFAULT_NEFIN_RF_MKT

    df_nefin_rf = load_nefin_rf_mkt(
        nefin_rf_mkt_path=nefin_path,
        rf_path=args.rf_path,
        factors_path=args.factors_path,
    )
    print(f"NEFIN RF/MktRF: {len(df_nefin_rf)} dias ({df_nefin_rf.index.min().date()} → {df_nefin_rf.index.max().date()})")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    summaries = []
    global_total = len(args.k_assets) * args.n_portfolios
    global_offset = 0
    for k in args.k_assets:
        print(f"\n=== Gerando N={k}, {args.n_portfolios} carteiras, seed={args.seed} ===")
        summary = run_generation(
            df_b3_daily=df_b3_daily,
            df_nefin_rf=df_nefin_rf,
            output_dir=args.output_dir,
            k_assets=k,
            n_portfolios=args.n_portfolios,
            seed=args.seed,
            start_complete=args.start_complete,
            end_complete=args.end_complete,
            panel_start=args.panel_start,
            prefix=args.prefix,
            deterministic_names=args.deterministic_names,
            save_manifest=args.save_manifest,
            global_offset=global_offset,
            global_total=global_total,
        )
        global_offset += args.n_portfolios
        summaries.append(summary)
        print(json.dumps(summary, indent=2, ensure_ascii=False))

    if args.make_zip:
        zip_path = args.zip_path or (args.output_dir / "B3_carteiras_aleatorias.zip")
        created = zip_bases(args.output_dir, args.prefix, zip_path)
        print(f"ZIP criado: {created}")

    total = sum(s["n_portfolios_exported"] for s in summaries)
    print(f"\nConcluído: {total} base(s) em {args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
