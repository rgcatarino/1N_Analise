#!/usr/bin/env python3
"""Gera figuras ADV p10 e custo BARRA vs N (coorte 2001, top-N AUM=N×K)."""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "resultados" / "sensibilidade_barra" / (
    "topN_annual_2001_aumN_n_8_10_12_15_20_25_30_35_40"
)
FIG_DIR = ROOT / "texto" / "dissertacao" / "figuras"


def main() -> None:
    formacao = pd.read_csv(OUT_DIR / "formacao_metricas_por_N.csv")
    resumo = pd.read_csv(OUT_DIR / "resumo_por_N.csv")
    FIG_DIR.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(7, 4.2))
    ax.plot(
        formacao["N"],
        formacao["adv_p10"] / 1e6,
        marker="o",
        color="#b85c38",
        label="ADV p10",
    )
    ax.plot(
        formacao["N"],
        formacao["adv_mean"] / 1e6,
        marker="s",
        color="#1f4e79",
        alpha=0.55,
        ls="--",
        label="ADV médio (ref.)",
    )
    ax.set_xlabel("N (ativos)")
    ax.set_ylabel("ADV (R$ milhões)")
    ax.set_title("Liquidez (p10) vs N (liq_top_1MM, formação 200106)")
    ax.legend(frameon=False)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    p10_path = FIG_DIR / "figura_adv_p10_vs_N_topN.png"
    fig.savefig(p10_path, dpi=150)
    fig.savefig(OUT_DIR / "figura_adv_p10_vs_N.png", dpi=150)
    plt.close(fig)

    fig2, ax2 = plt.subplots(figsize=(7, 4.2))
    ax2.plot(
        resumo["N"],
        resumo["mean_cost_bps_net_barra"],
        marker="o",
        color="#1f4e79",
    )
    ax2.axhline(12.0, color="#888888", ls="--", lw=1, label="baseline 12 bps")
    ax2.set_xlabel("N (ativos)")
    ax2.set_ylabel("Custo médio (bps do NAV / rebalance)", fontsize=8)
    ax2.set_title("Impacto de mercado médio vs N (top-N, 1/N, AUM=N×K, anual)")
    ax2.legend(frameon=False)
    ax2.grid(True, alpha=0.3)
    fig2.tight_layout()
    custo_path = FIG_DIR / "figura_custo_barra_vs_N_topN_aumN.png"
    fig2.savefig(custo_path, dpi=150, bbox_inches="tight")
    fig2.savefig(OUT_DIR / "figura_custo_barra_vs_N.png", dpi=150, bbox_inches="tight")
    plt.close(fig2)

    print(f"OK -> {p10_path}")
    print(f"OK -> {custo_path}")


if __name__ == "__main__":
    main()
