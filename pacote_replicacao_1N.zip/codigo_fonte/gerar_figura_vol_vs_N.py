#!/usr/bin/env python3
"""Figura: volatilidade anualizada da carteira 1/N versus N.

Pedido Marcelo (qualificação): queda da volatilidade com N até a assíntota
de risco sistemático.

Modos
-----
backtest  (recomendado para a dissertação)
    Lê ``monthly_vol`` das collections ``res_*`` do Mongo Cap. 5
    (mesmo protocolo: liq_1MM, reb-annual, 12 bps, IR, motor v4.1).
    Média cross-section + bandas p10–p90 alinhadas à Tab. de desempenho.

table
    Plota só as médias do CSV Cap. 5 (rápido; sem bandas).

compute
    Simulação leve a partir de preços (EW mensal). Útil como diagnóstico,
    mas **não** coincide com a coluna de volatilidade da tabela Cap. 5.

Exemplos
--------
    # Alinhado ao backtest da dissertação (2001–2025)
    python codigo_fonte/gerar_figura_vol_vs_N.py --mode backtest \\
      --periodo 2001-2025

    # Médias do CSV Cap. 5
    python codigo_fonte/gerar_figura_vol_vs_N.py --mode table \\
      --periodo 2001-2025

    # Diagnóstico rápido (não usar no texto principal)
    python codigo_fonte/gerar_figura_vol_vs_N.py --mode compute \\
      --sample-n 500 --formation-yyyymm 200106

Saídas (default ``resultados/figuras_vol_vs_N/``):
    figura_vol_vs_N.png
    vol_vs_N_summary.csv
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pymongo import MongoClient

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

from backtest_carteiras_individuais_retornos_v2 import load_prices  # noqa: E402
from barra_market_impact import prices_df_to_wide  # noqa: E402
from mestrado_resultados_simulador_pessoa_investidora import (  # noqa: E402
    DEFAULT_MONGO_URI,
)
from mestrado_resultados_simulador_pessoa_investidora_v2 import (  # noqa: E402
    DEFAULT_DB_LIQUIDEZ,
)
from mestrado_resultados_simulador_pessoa_investidora_v5 import (  # noqa: E402
    _load_unique_res_metrics,
    discover_res_collections,
    resolve_collection,
)
from ticker_continuacao import padronizar_ticker  # noqa: E402

DEFAULT_PRICES_PATH = REPO_ROOT / "ibov" / "prices_adjust_close_B3_economatica_1986-out_2025.csv"
DEFAULT_TABLE_CSV = (
    REPO_ROOT
    / "resultados"
    / "liquidez_1mm_delist"
    / "desempenho_carteiras_aleatorias_liquidez_com_reb.csv"
)
DEFAULT_UNIVERSO_DIR = REPO_ROOT / "resultados" / "carteiras_aleatorias_liquidas"
DEFAULT_OUT_DIR = REPO_ROOT / "resultados" / "figuras_vol_vs_N"
DEFAULT_NS = (8, 10, 12, 15, 20, 25, 30, 35, 40)
DEFAULT_SAMPLE_N = 500
DEFAULT_SEED = 20250725
DEFAULT_PERIOD_START = {
    "2001-2025": (2001, 7),
    "2006-2025": (2006, 7),
    "2011-2025": (2011, 7),
}
COLOR_MAIN = "#1f4e79"
COLOR_BAND = "#1f4e79"
COLOR_ASYMP = "#b85c38"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Gera figura volatilidade anualizada × N (carteiras 1/N)."
    )
    p.add_argument(
        "--mode",
        choices=("backtest", "table", "compute"),
        default="backtest",
        help="backtest = Mongo Cap. 5 (default); table = CSV; compute = preços",
    )
    p.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    p.add_argument(
        "--out-name",
        default="figura_vol_vs_N.png",
        help="Nome do PNG de saída",
    )
    p.add_argument("--dpi", type=int, default=150)

    # --- períodos / grade ---
    p.add_argument(
        "--periodo",
        default="2001-2025",
        help="Período Cap. 5 (default: 2001-2025)",
    )
    p.add_argument(
        "--periodos",
        nargs="+",
        default=None,
        help="Vários períodos (mode table); em backtest usa --periodo",
    )
    p.add_argument("--ns", type=int, nargs="+", default=list(DEFAULT_NS))

    # --- mode table ---
    p.add_argument("--table-csv", type=Path, default=DEFAULT_TABLE_CSV)

    # --- mode backtest (Mongo = Cap. 5) ---
    p.add_argument("--mongo-uri", default=DEFAULT_MONGO_URI)
    p.add_argument("--db-name", default=DEFAULT_DB_LIQUIDEZ)
    p.add_argument("--universo-tag", default="liq_1MM")
    p.add_argument("--tcost-bps", type=float, default=12.0)
    p.add_argument(
        "--rebalance-freq",
        default="annual",
        choices=("monthly", "quarterly", "semiannual", "annual"),
    )
    p.add_argument(
        "--ir",
        choices=("sim", "nao"),
        default="sim",
        help="IR nas collections Cap. 5 (default: sim)",
    )
    p.add_argument("--start-m", type=int, default=7)
    p.add_argument("--end-y", type=int, default=2025)
    p.add_argument("--end-m", type=int, default=10)
    p.add_argument(
        "--vol-metric",
        default="monthly_vol",
        help="Campo em res_* (default: monthly_vol = std(r_m)*sqrt(12))",
    )
    p.add_argument(
        "--vol-scale",
        type=float,
        default=100.0,
        help="Escala do campo Mongo para %% (default: 100)",
    )

    # --- mode compute ---
    p.add_argument("--prices", type=Path, default=DEFAULT_PRICES_PATH)
    p.add_argument("--universo-dir", type=Path, default=DEFAULT_UNIVERSO_DIR)
    p.add_argument("--universo-prefix", default="universo_liq_1MM")
    p.add_argument("--formation-yyyymm", default="200106")
    p.add_argument("--sample-n", type=int, default=DEFAULT_SAMPLE_N)
    p.add_argument("--seed", type=int, default=DEFAULT_SEED)
    p.add_argument("--start-y", type=int, default=2001)
    p.add_argument(
        "--min-obs-frac",
        type=float,
        default=0.50,
        help="Fração mínima de meses válidos da carteira (mode compute)",
    )
    p.add_argument("--ticker-min-months", type=int, default=24)
    p.add_argument(
        "--require-start",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    p.add_argument(
        "--no-asymp",
        action="store_true",
        help="Não sobrepor assíntota / curva teórica",
    )
    p.add_argument("--title", default=None)
    return p.parse_args()


def theoretical_vol_curve(
    ns: Sequence[int],
    *,
    sigma_bar_pct: float,
    rho_bar: float,
) -> pd.Series:
    rho = float(np.clip(rho_bar, -0.99, 0.99))
    sig = float(sigma_bar_pct)
    vals = [sig * np.sqrt((1.0 - rho) / n + rho) for n in ns]
    return pd.Series(vals, index=list(ns), name="vol_theory_pct")


# ---------------------------------------------------------------------------
# mode table
# ---------------------------------------------------------------------------


def load_table_vol(csv_path: Path, periodos: Sequence[str]) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    required = {"Período", "Ativos por carteira", "Volatilidade anualizada (%)"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"{csv_path} sem colunas {sorted(missing)}")
    out = df[df["Período"].astype(str).isin(periodos)].copy()
    if out.empty:
        available = sorted(df["Período"].astype(str).unique())
        raise ValueError(f"Período(s) {list(periodos)} ausentes. Disponíveis: {available}")
    out = out.rename(
        columns={
            "Período": "periodo",
            "Ativos por carteira": "N",
            "Volatilidade anualizada (%)": "vol_mean_pct",
        }
    )
    out["N"] = out["N"].astype(int)
    out["vol_mean_pct"] = out["vol_mean_pct"].astype(float)
    return out.sort_values(["periodo", "N"]).reset_index(drop=True)


def plot_from_table(
    summary: pd.DataFrame,
    *,
    out_path: Path,
    dpi: int,
    title: Optional[str],
) -> None:
    periodos = list(summary["periodo"].unique())
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    cmap = [COLOR_MAIN, COLOR_ASYMP, "#2e7d32", "#6a1b9a"]
    for i, per in enumerate(periodos):
        sub = summary[summary["periodo"] == per]
        ax.plot(
            sub["N"],
            sub["vol_mean_pct"],
            marker="o",
            color=cmap[i % len(cmap)],
            lw=1.8,
            label=str(per),
        )
    ax.set_xlabel("N (número de ativos)")
    ax.set_ylabel("Volatilidade anualizada (%)")
    ax.set_title(
        title
        or "Volatilidade média de carteiras 1/N versus N "
        "(filtro ADV ≥ R$ 1 mi, rebalanceamento anual)"
    )
    if len(periodos) > 1:
        ax.legend(frameon=False, title="Período")
    else:
        last = float(summary["vol_mean_pct"].iloc[-1])
        ax.axhline(
            last,
            color=COLOR_ASYMP,
            ls="--",
            lw=1.2,
            alpha=0.85,
            label=f"referência em N={int(summary['N'].iloc[-1])} ({last:.1f}%)",
        )
        ax.legend(frameon=False)
    ax.grid(True, alpha=0.3)
    ax.set_xticks(sorted(summary["N"].unique()))
    fig.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    print(f"Figura -> {out_path}", flush=True)


# ---------------------------------------------------------------------------
# mode backtest (Mongo Cap. 5)
# ---------------------------------------------------------------------------


def _period_start(periodo: str, start_m: int) -> Tuple[int, int]:
    if periodo in DEFAULT_PERIOD_START:
        return DEFAULT_PERIOD_START[periodo]
    text = str(periodo).replace("_", "-")
    start_y = int(text.split("-")[0])
    return start_y, int(start_m)


def _pick_vol_series(df: pd.DataFrame, metric: str) -> pd.Series:
    candidates = [metric, metric.lower(), "monthly_vol", "daily_vol"]
    cols = {str(c).lower().replace(" ", "_"): c for c in df.columns}
    for key in candidates:
        norm = key.lower().replace(" ", "_")
        if norm in cols:
            return pd.to_numeric(df[cols[norm]], errors="coerce")
    raise RuntimeError(
        f"Campo de volatilidade '{metric}' ausente. "
        f"Colunas: {sorted(map(str, df.columns))[:40]}…"
    )


def load_backtest_vol_summary(
    *,
    mongo_uri: str,
    db_name: str,
    periodo: str,
    ns: Sequence[int],
    universo_tag: str,
    tcost_bps: float,
    rebalance_freq: str,
    apply_stock_ir: bool,
    start_m: int,
    end_y: int,
    end_m: int,
    vol_metric: str,
    vol_scale: float,
) -> pd.DataFrame:
    start_y, start_m_eff = _period_start(periodo, start_m)
    client = MongoClient(mongo_uri, serverSelectionTimeoutMS=15000)
    db = client[db_name]
    index = discover_res_collections(db)
    if not index:
        raise RuntimeError(f"Nenhuma collection res_* em {db_name}")

    rows = []
    for n in ns:
        parsed = resolve_collection(
            index,
            n_ativos=int(n),
            start_y=int(start_y),
            start_m=int(start_m_eff),
            end_y=int(end_y),
            end_m=int(end_m),
            rebalance=True,
            rebalance_freq=str(rebalance_freq),
            tcost_bps=float(tcost_bps),
            apply_stock_ir=bool(apply_stock_ir),
            universo_tag=str(universo_tag),
            sem_reb_tag="buyhold",
        )
        if parsed is None:
            print(f"  SKIP N={n}: collection não encontrada", flush=True)
            continue
        print(f"  N={n:>2} | {parsed.collection}", flush=True)
        df, n_raw, n_unique = _load_unique_res_metrics(db, parsed.suffix)
        vols = _pick_vol_series(df, vol_metric).dropna() * float(vol_scale)
        if vols.empty:
            print(f"  SKIP N={n}: sem valores de {vol_metric}", flush=True)
            continue
        arr = vols.to_numpy(dtype=float)
        rows.append(
            {
                "periodo": periodo,
                "N": int(n),
                "n_carteiras": int(n_unique),
                "n_carteiras_brutas": int(n_raw),
                "vol_mean_pct": float(arr.mean()),
                "vol_median_pct": float(np.median(arr)),
                "vol_p10_pct": float(np.percentile(arr, 10)),
                "vol_p90_pct": float(np.percentile(arr, 90)),
                "vol_std_pct": float(arr.std(ddof=1)) if len(arr) > 1 else 0.0,
                "collection": parsed.collection,
            }
        )
    client.close()
    if not rows:
        raise RuntimeError(
            "Nenhuma célula carregada do Mongo. "
            "Verifique --mongo-uri, --db-name, --universo-tag e --periodo."
        )
    return pd.DataFrame(rows).sort_values("N").reset_index(drop=True)


def _fit_equicorr_from_means(
    ns: Sequence[int],
    means_pct: Sequence[float],
) -> Tuple[Optional[pd.Series], Optional[float], Optional[float], Optional[float]]:
    """Ajusta σ̄ e ρ̄ por MQ em σ²(N) = a/N + b (b=σ̄²ρ̄, a=σ̄²(1−ρ̄))."""
    n_arr = np.asarray(list(ns), dtype=float)
    v_arr = np.asarray(list(means_pct), dtype=float)
    if len(n_arr) < 3 or np.any(~np.isfinite(v_arr)):
        return None, None, None, None
    y = v_arr**2
    x = 1.0 / n_arr
    A = np.column_stack([x, np.ones_like(x)])
    coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
    a, b = float(coef[0]), float(coef[1])
    if b <= 0 or a + b <= 0:
        return None, None, None, None
    sigma2 = a + b
    rho = b / sigma2
    if not (0.0 < rho < 1.0):
        return None, None, None, None
    sigma_bar = float(np.sqrt(sigma2))
    theory = theoretical_vol_curve(list(ns), sigma_bar_pct=sigma_bar, rho_bar=rho)
    asymptote = float(sigma_bar * np.sqrt(rho))
    return theory, asymptote, sigma_bar, rho


def plot_bands(
    summary: pd.DataFrame,
    *,
    theory: Optional[pd.Series],
    asymptote_pct: Optional[float],
    out_path: Path,
    dpi: int,
    title: Optional[str],
    meta_line: str,
) -> None:
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    if {"vol_p10_pct", "vol_p90_pct"}.issubset(summary.columns):
        ax.fill_between(
            summary["N"],
            summary["vol_p10_pct"],
            summary["vol_p90_pct"],
            color=COLOR_BAND,
            alpha=0.18,
            label="p10–p90",
        )
    ax.plot(
        summary["N"],
        summary["vol_mean_pct"],
        marker="o",
        color=COLOR_MAIN,
        lw=1.8,
        label="média cross-section",
    )
    if theory is not None and theory.notna().any():
        ax.plot(
            theory.index,
            theory.values,
            color=COLOR_ASYMP,
            ls="--",
            lw=1.4,
            label="curva teórica (equicorr.)",
        )
    if asymptote_pct is not None and np.isfinite(asymptote_pct):
        ax.axhline(
            float(asymptote_pct),
            color=COLOR_ASYMP,
            ls=":",
            lw=1.0,
            alpha=0.7,
            label=f"assíntota σ̄√ρ̄ ({float(asymptote_pct):.1f}%)",
        )
    ax.set_xlabel("N (número de ativos)")
    ax.set_ylabel("Volatilidade anualizada (%)")
    ax.set_title(
        title
        or "Diversificação: volatilidade de carteiras 1/N versus N"
    )
    ax.legend(frameon=False, loc="upper right")
    ax.grid(True, alpha=0.3)
    ax.set_xticks(list(summary["N"]))
    ax.text(
        0.01,
        -0.18,
        meta_line,
        transform=ax.transAxes,
        fontsize=8,
        color="#444444",
        va="top",
    )
    fig.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    print(f"Figura -> {out_path}", flush=True)


def run_backtest(args: argparse.Namespace) -> pd.DataFrame:
    apply_ir = args.ir == "sim"
    print(
        f"Mongo {args.db_name} | {args.universo_tag} | "
        f"reb-{args.rebalance_freq} | t{int(args.tcost_bps)}bps | "
        f"{'ir' if apply_ir else 'noir'} | período {args.periodo}",
        flush=True,
    )
    summary = load_backtest_vol_summary(
        mongo_uri=args.mongo_uri,
        db_name=args.db_name,
        periodo=args.periodo,
        ns=args.ns,
        universo_tag=args.universo_tag,
        tcost_bps=args.tcost_bps,
        rebalance_freq=args.rebalance_freq,
        apply_stock_ir=apply_ir,
        start_m=args.start_m,
        end_y=args.end_y,
        end_m=args.end_m,
        vol_metric=args.vol_metric,
        vol_scale=args.vol_scale,
    )

    theory: Optional[pd.Series] = None
    asymptote_pct: Optional[float] = None
    if not args.no_asymp:
        theory, asymptote_pct, sigma_bar, rho = _fit_equicorr_from_means(
            summary["N"].tolist(),
            summary["vol_mean_pct"].tolist(),
        )
        if theory is not None and rho is not None and sigma_bar is not None:
            summary["vol_theory_pct"] = summary["N"].map(theory)
            summary["sigma_bar_pct"] = sigma_bar
            summary["rho_bar"] = rho
            summary["asymptote_pct"] = asymptote_pct
            print(
                f"Teoria (ajustada às médias do backtest): "
                f"σ̄={sigma_bar:.2f}%  ρ̄={rho:.3f}  assíntota≈{asymptote_pct:.2f}%",
                flush=True,
            )
        else:
            asymptote_pct = float(summary["vol_mean_pct"].iloc[-1])
            print(
                "Aviso: ajuste equicorr. instável; "
                f"assíntota = média em N={int(summary['N'].iloc[-1])} "
                f"({asymptote_pct:.2f}%).",
                flush=True,
            )

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = out_dir / "vol_vs_N_summary.csv"
    summary.to_csv(csv_path, index=False)
    print(f"Summary -> {csv_path}", flush=True)

    n_med = int(summary["n_carteiras"].median()) if "n_carteiras" in summary else 0
    meta = (
        f"{args.universo_tag} | {args.periodo} | "
        f"reb-{args.rebalance_freq}, {int(args.tcost_bps)} bps, "
        f"{'IR 15%' if apply_ir else 'sem IR'} | "
        f"~{n_med} carteiras/N | {args.vol_metric}"
    )
    plot_bands(
        summary,
        theory=theory,
        asymptote_pct=asymptote_pct,
        out_path=out_dir / args.out_name,
        dpi=args.dpi,
        title=args.title
        or "Diversificação: volatilidade de carteiras 1/N versus N",
        meta_line=meta,
    )
    return summary


def run_table(args: argparse.Namespace) -> pd.DataFrame:
    periodos = args.periodos if args.periodos else [args.periodo]
    summary = load_table_vol(args.table_csv, periodos)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = out_dir / "vol_vs_N_summary.csv"
    summary.to_csv(csv_path, index=False)
    print(f"Summary -> {csv_path}", flush=True)
    plot_from_table(
        summary,
        out_path=out_dir / args.out_name,
        dpi=args.dpi,
        title=args.title,
    )
    return summary


# ---------------------------------------------------------------------------
# mode compute (diagnóstico; não alinhar ao texto Cap. 5)
# ---------------------------------------------------------------------------


def _formation_to_universe_path(universo_dir: Path, prefix: str, yyyymm: str) -> Path:
    return Path(universo_dir) / f"{prefix}_{yyyymm}.csv"


def load_universe_tickers(universo_path: Path) -> List[str]:
    df = pd.read_csv(universo_path)
    col = "ticker" if "ticker" in df.columns else df.columns[0]
    tickers: List[str] = []
    seen = set()
    for raw in df[col].astype(str):
        t = padronizar_ticker(raw.strip().upper())
        if not t or t in seen:
            continue
        seen.add(t)
        tickers.append(t)
    if len(tickers) < 2:
        raise ValueError(f"Universo insuficiente em {universo_path}")
    return tickers


def _month_end_prices(px_daily: pd.DataFrame) -> pd.DataFrame:
    try:
        return px_daily.resample("ME").last()
    except ValueError:
        return px_daily.resample("M").last()


def _ew_monthly_returns(px_m: pd.DataFrame, tickers: Sequence[str]) -> pd.Series:
    cols = [t for t in tickers if t in px_m.columns]
    if len(cols) < 2:
        return pd.Series(dtype=float)
    return px_m[cols].pct_change().mean(axis=1, skipna=True)


def _ann_vol_pct(r_m: pd.Series, *, min_obs: int) -> float:
    r = r_m.dropna()
    if len(r) < min_obs:
        return float("nan")
    return float(r.std(ddof=1) * np.sqrt(12.0) * 100.0)


def _estimate_avg_vol_corr(px_m: pd.DataFrame, tickers: Sequence[str]) -> Tuple[float, float]:
    cols = [t for t in tickers if t in px_m.columns]
    rets = px_m[cols].pct_change()
    ok = [c for c in rets.columns if float(rets[c].notna().mean()) >= 0.40]
    if len(ok) < 3:
        return float("nan"), float("nan")
    rets = rets[ok]
    vols = rets.std(ddof=1, skipna=True) * np.sqrt(12.0) * 100.0
    sigma_bar = float(vols.mean())
    corr = rets.corr(min_periods=24)
    vals = corr.values
    n = vals.shape[0]
    mask = ~np.eye(n, dtype=bool)
    pairwise = vals[mask]
    pairwise = pairwise[np.isfinite(pairwise)]
    if pairwise.size == 0:
        return sigma_bar, float("nan")
    return sigma_bar, float(np.mean(pairwise))


def sample_portfolios(
    tickers: Sequence[str],
    ns: Sequence[int],
    *,
    sample_n: int,
    seed: int,
) -> Dict[int, List[Tuple[str, ...]]]:
    rng = np.random.default_rng(seed)
    univ = np.array(list(tickers), dtype=object)
    out: Dict[int, List[Tuple[str, ...]]] = {}
    for n in ns:
        if n > len(univ):
            raise ValueError(f"N={n} > universo ({len(univ)})")
        bags: List[Tuple[str, ...]] = []
        for _ in range(sample_n):
            pick = rng.choice(univ, size=n, replace=False)
            bags.append(tuple(sorted(str(x) for x in pick)))
        out[int(n)] = bags
    return out


def compute_vol_summary(
    px_m: pd.DataFrame,
    portfolios: Dict[int, List[Tuple[str, ...]]],
    *,
    min_obs_frac: float,
) -> pd.DataFrame:
    n_months = len(px_m)
    min_obs = max(24, int(np.ceil(min_obs_frac * n_months)))
    rows = []
    for n, bags in sorted(portfolios.items()):
        vols = []
        for tickers in bags:
            r = _ew_monthly_returns(px_m, tickers)
            v = _ann_vol_pct(r, min_obs=min_obs)
            if np.isfinite(v):
                vols.append(v)
        if not vols:
            raise RuntimeError(f"Nenhuma carteira válida para N={n} (min_obs={min_obs})")
        arr = np.asarray(vols, dtype=float)
        rows.append(
            {
                "N": n,
                "n_carteiras": len(arr),
                "vol_mean_pct": float(arr.mean()),
                "vol_median_pct": float(np.median(arr)),
                "vol_p10_pct": float(np.percentile(arr, 10)),
                "vol_p90_pct": float(np.percentile(arr, 90)),
                "vol_std_pct": float(arr.std(ddof=1)) if len(arr) > 1 else 0.0,
            }
        )
    return pd.DataFrame(rows)


def _filter_tickers_for_sampling(
    px_m: pd.DataFrame,
    tickers: Sequence[str],
    *,
    ticker_min_months: int,
    require_start: bool,
) -> List[str]:
    cols = [t for t in tickers if t in px_m.columns]
    if not cols:
        return []
    sub = px_m[cols]
    n_obs = sub.notna().sum(axis=0)
    keep = n_obs[n_obs >= int(ticker_min_months)].index.tolist()
    if require_start and len(sub) > 0:
        start_ok = sub.iloc[: min(2, len(sub))].notna().any(axis=0)
        keep = [t for t in keep if bool(start_ok.get(t, False))]
    return list(keep)


def run_compute(args: argparse.Namespace) -> pd.DataFrame:
    univ_path = _formation_to_universe_path(
        args.universo_dir, args.universo_prefix, args.formation_yyyymm
    )
    if not univ_path.is_file():
        raise FileNotFoundError(f"Universo ausente: {univ_path}")

    print(f"Carregando preços: {args.prices}", flush=True)
    px_daily = prices_df_to_wide(load_prices(Path(args.prices)))
    rename = {c: padronizar_ticker(str(c)) for c in px_daily.columns}
    px_daily = px_daily.rename(columns=rename)
    px_daily = px_daily.loc[:, ~px_daily.columns.duplicated()].sort_index()

    start = pd.Timestamp(year=args.start_y, month=args.start_m, day=1)
    end = pd.Timestamp(year=args.end_y, month=args.end_m, day=28) + pd.offsets.MonthEnd(0)
    px_daily = px_daily.loc[(px_daily.index >= start) & (px_daily.index <= end)]
    if px_daily.empty:
        raise RuntimeError("Painel de preços vazio no intervalo solicitado")

    tickers = load_universe_tickers(univ_path)
    tickers = [t for t in tickers if t in px_daily.columns]
    print(f"Universo {univ_path.name}: {len(tickers)} tickers com preço", flush=True)

    px_m = _month_end_prices(px_daily)
    tickers = _filter_tickers_for_sampling(
        px_m,
        tickers,
        ticker_min_months=args.ticker_min_months,
        require_start=args.require_start,
    )
    print(
        f"Após filtro amostrável (≥{args.ticker_min_months} meses"
        f"{', com preço no início' if args.require_start else ''}): "
        f"{len(tickers)} tickers",
        flush=True,
    )

    ns_req = [int(n) for n in args.ns]
    n_max = len(tickers)
    if n_max < 2:
        raise RuntimeError("Universo amostrável insuficiente (< 2 tickers).")
    ns = [n for n in ns_req if n <= n_max]
    dropped = [n for n in ns_req if n > n_max]
    if dropped:
        print(f"Aviso: N={dropped} > universo amostrável ({n_max}); omitidos.", flush=True)
    if not ns:
        raise RuntimeError(f"Nenhum N ≤ universo amostrável ({n_max}).")
    if ns != ns_req:
        print(f"Grade efetiva de N: {ns}", flush=True)

    portfolios = sample_portfolios(
        tickers, ns, sample_n=args.sample_n, seed=args.seed
    )
    print(f"Calculando vol para N={ns} × {args.sample_n} carteiras…", flush=True)
    summary = compute_vol_summary(
        px_m[tickers], portfolios, min_obs_frac=args.min_obs_frac
    )

    theory: Optional[pd.Series] = None
    asymptote_pct: Optional[float] = None
    sigma_bar, rho_bar = float("nan"), float("nan")
    if not args.no_asymp:
        sigma_bar, rho_bar = _estimate_avg_vol_corr(px_m, tickers)
        if np.isfinite(sigma_bar) and np.isfinite(rho_bar):
            theory = theoretical_vol_curve(
                ns, sigma_bar_pct=sigma_bar, rho_bar=rho_bar
            )
            asymptote_pct = float(sigma_bar * np.sqrt(max(rho_bar, 0.0)))
            print(
                f"Teoria: σ̄={sigma_bar:.2f}%  ρ̄={rho_bar:.3f}  "
                f"assíntota≈{asymptote_pct:.2f}%",
                flush=True,
            )
            summary["vol_theory_pct"] = summary["N"].map(theory)
            summary["sigma_bar_pct"] = sigma_bar
            summary["rho_bar"] = rho_bar
            summary["asymptote_pct"] = asymptote_pct

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = out_dir / "vol_vs_N_summary.csv"
    summary.to_csv(csv_path, index=False)
    print(f"Summary -> {csv_path}", flush=True)

    meta = (
        f"[diagnóstico compute] {args.universo_prefix}_{args.formation_yyyymm} | "
        f"{args.start_y}-{args.start_m:02d}→{args.end_y}-{args.end_m:02d} | "
        f"{args.sample_n} carteiras/N | seed={args.seed}"
    )
    if np.isfinite(rho_bar):
        meta += f" | ρ̄={rho_bar:.2f}"

    plot_bands(
        summary,
        theory=theory,
        asymptote_pct=asymptote_pct,
        out_path=out_dir / args.out_name,
        dpi=args.dpi,
        title=args.title,
        meta_line=meta,
    )
    return summary


def main() -> int:
    args = parse_args()
    if args.mode == "backtest":
        summary = run_backtest(args)
    elif args.mode == "table":
        summary = run_table(args)
    else:
        summary = run_compute(args)
    print(summary.to_string(index=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
